2008-03-27

This project shows an error that occurs if a module is included by a profile that was activated by a property.

To see the error, create a new Maven2 job in Hudson configured like this:

Root POM: hudson-assertionError-test/pom.xml
Goals   : install -X -Dinclude-optional

(Or just copy the job configuration file from 'hudson-job-config/config.xml')

When you tell Hudson to build it, this error will be printed:

started
Parsing POMs
[hudson-assertionError-test] $ java -cp E:\apps\apache-tomcat-6.0.16\webapps\hudson\WEB-INF\lib\maven-agent-1.199.jar;E:\apps\apache-maven-2.0.8\boot\classworlds-1.1.jar hudson.maven.agent.Main E:\apps\apache-maven-2.0.8 E:\apps\apache-tomcat-6.0.16\webapps\hudson\WEB-INF\lib\remoting-1.199.jar E:\apps\apache-tomcat-6.0.16\webapps\hudson\WEB-INF\lib\maven-interceptor-1.199.jar
???channel started
+ Error stacktraces are turned on.
Maven version: 2.0.8
Java version: 1.5.0_07
OS name: "windows xp" version: "5.1" arch: "x86" Family: "windows"

[...]

[INFO] ------------------------------------------------------------------------
[INFO] Building module 2 (OPTIONAL)
[INFO]    task-segment: [install]
[INFO] ------------------------------------------------------------------------
[DEBUG] Configuring mojo 'org.apache.maven.plugins:maven-resources-plugin:2.2:resources' -->
[INFO] ------------------------------------------------------------------------
[ERROR] FATAL ERROR
[INFO] ------------------------------------------------------------------------
[INFO] reporters.get(com.orgecc.test.hudson:hudson-assertionError-test-module-2)==null. reporters={com.orgecc.test.hudson:hudson-assertionError-test-root=[hudson.maven.reporters.MavenArtifactArchiver@d1223d, hudson.maven.reporters.MavenFingerprinter@1ee8c1, hudson.maven.reporters.MavenJavadocArchiver@142db11, hudson.maven.reporters.SurefireArchiver@3c4c33, hudson.maven.reporters.BuildInfoRecorder@aecd51], com.orgecc.test.hudson:hudson-assertionError-test-module-1=[hudson.maven.reporters.MavenArtifactArchiver@fcfd10, hudson.maven.reporters.MavenFingerprinter@ae735, hudson.maven.reporters.MavenJavadocArchiver@29b99c, hudson.maven.reporters.SurefireArchiver@158bc22, hudson.maven.reporters.BuildInfoRecorder@3ac11b]} proxies={com.orgecc.test.hudson:hudson-assertionError-test-root=hudson.maven.MavenModuleSetBuild$Builder$FilterImpl@a76306, com.orgecc.test.hudson:hudson-assertionError-test-module-1=hudson.maven.MavenModuleSetBuild$Builder$FilterImpl@1563e06}
[INFO] ------------------------------------------------------------------------
[DEBUG] Trace
java.lang.AssertionError: reporters.get(com.orgecc.test.hudson:hudson-assertionError-test-module-2)==null. reporters={com.orgecc.test.hudson:hudson-assertionError-test-root=[hudson.maven.reporters.MavenArtifactArchiver@d1223d, hudson.maven.reporters.MavenFingerprinter@1ee8c1, hudson.maven.reporters.MavenJavadocArchiver@142db11, hudson.maven.reporters.SurefireArchiver@3c4c33, hudson.maven.reporters.BuildInfoRecorder@aecd51], com.orgecc.test.hudson:hudson-assertionError-test-module-1=[hudson.maven.reporters.MavenArtifactArchiver@fcfd10, hudson.maven.reporters.MavenFingerprinter@ae735, hudson.maven.reporters.MavenJavadocArchiver@29b99c, hudson.maven.reporters.SurefireArchiver@158bc22, hudson.maven.reporters.BuildInfoRecorder@3ac11b]} proxies={com.orgecc.test.hudson:hudson-assertionError-test-root=hudson.maven.MavenModuleSetBuild$Builder$FilterImpl@a76306, com.orgecc.test.hudson:hudson-assertionError-test-module-1=hudson.maven.MavenModuleSetBuild$Builder$FilterImpl@1563e06}
	at hudson.maven.MavenModuleSetBuild$Builder.postModule(MavenModuleSetBuild.java:506)
	at hudson.maven.MavenBuilder$Adapter.fireLeaveModule(MavenBuilder.java:261)
	at hudson.maven.MavenBuilder$Adapter.postBuild(MavenBuilder.java:225)
	at org.apache.maven.lifecycle.LifecycleExecutorInterceptor.execute(LifecycleExecutorInterceptor.java:45)
	at org.apache.maven.DefaultMaven.doExecute(DefaultMaven.java:333)
	at org.apache.maven.DefaultMaven.execute(DefaultMaven.java:126)
	at org.apache.maven.cli.MavenCli.main(MavenCli.java:282)
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)
	at java.lang.reflect.Method.invoke(Unknown Source)
	at org.codehaus.classworlds.Launcher.launchEnhanced(Launcher.java:315)
	at org.codehaus.classworlds.Launcher.launch(Launcher.java:255)
	at hudson.maven.agent.Main.launch(Main.java:97)
	at hudson.maven.MavenBuilder.call(MavenBuilder.java:129)
	at hudson.maven.MavenModuleSetBuild$Builder.call(MavenModuleSetBuild.java:476)
	at hudson.maven.MavenModuleSetBuild$Builder.call(MavenModuleSetBuild.java:422)
	at hudson.remoting.UserRequest.perform(UserRequest.java:69)
	at hudson.remoting.UserRequest.perform(UserRequest.java:23)
	at hudson.remoting.Request$2.run(Request.java:200)
	at java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)
	at java.util.concurrent.FutureTask$Sync.innerRun(Unknown Source)
	at java.util.concurrent.FutureTask.run(Unknown Source)
	at java.util.concurrent.ThreadPoolExecutor$Worker.runTask(Unknown Source)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)
	at java.lang.Thread.run(Unknown Source)
[INFO] ------------------------------------------------------------------------

