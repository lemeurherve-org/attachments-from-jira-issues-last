class Core {
    public String getVersion() { return "0.0.1"; }
}
