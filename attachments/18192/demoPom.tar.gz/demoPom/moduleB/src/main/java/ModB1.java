class ModB1 {
    public static String getName() {
        Core core = new Core();
        System.out.println("Core Version:" + core.getVersion());
        return "ModB1";
    }
}
