class ModB2 {
    public static String getName() { return "ModB2"; }
}
