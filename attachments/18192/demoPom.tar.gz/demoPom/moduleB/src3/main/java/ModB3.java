class ModB3 {
    public static String getName() { return "ModB3"; }
}
