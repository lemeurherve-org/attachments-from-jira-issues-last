package hudson.plugins.jobConfigHistory;

import hudson.XmlFile;
import hudson.model.Action;
import hudson.model.Hudson;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.kohsuke.stapler.Stapler;
import org.kohsuke.stapler.export.Exported;

/**
 * @author Stefan Brausch
 */

public class ConfigHistoryAction implements Action {

    private static final long serialVersionUID = 1L;

    public String getDisplayName() {
        return "All Jobs Configuration History";
    }

    public String getIconFileName() {
        return "setting.gif";
    }

    public String getUrlName() {
        return "ConfigHistoryAll";
    }

    @Exported
    public List<ConfigInfo> getConfigs() {
        ArrayList<ConfigInfo> configs = new ArrayList<ConfigInfo>();
        File jobList = new File(Hudson.getInstance().getRootDir(), "jobs");
        File[] jobDirs = jobList.listFiles();
        for (int j = 0; j < jobDirs.length; j++) {
            try {
                File dirList = new File(jobDirs[j], "config-history");
                File[] configDirs = dirList.listFiles();
                for (int i = 0; i < configDirs.length; i++) {
                    File configDir = configDirs[i];

                    XmlFile myConfig = new XmlFile(new File(configDir,
                            "history.xml"));
                    HistoryDescr histDescr = new HistoryDescr("", "", "", "");
                    try {
                        histDescr = (HistoryDescr) myConfig.read();
                    } catch (IOException e) {

                        Logger.getLogger("IO-Exception: " + e.getMessage());
                    }

                    ConfigInfo config = new ConfigInfo();
                    config.setDate(histDescr.getTimestamp());
                    config.setUser(histDescr.getUser());
                    config.setUserId(histDescr.getUserID());
                    config.setOperation(histDescr.getOperation());
                    config.setJob(jobDirs[j].getName());
                    config.setFile(configDir.getAbsolutePath());
                    configs.add(config);

                }
            } catch (Exception e) {

                Logger.getLogger("Exception: " + e.getMessage());
            }
        }
        Collections.sort(configs, new Comparator<ConfigInfo>() {
            public int compare(ConfigInfo o1, ConfigInfo o2) {
                return o2.getDate().compareTo(o1.getDate());
            }
        });
        return configs;
    }

    @Exported
    public String getFile() {

        String filePath = Stapler.getCurrentRequest().getParameter("file");
        String rawFile = "not found for: " + filePath;
        XmlFile myConfig = new XmlFile(new File(filePath, "config.xml"));
        try {
            rawFile = myConfig.asString();
        } catch (IOException e) {
            Logger.getLogger("Exception: " + e.getMessage());
        }
        return rawFile;
    }

    @Exported
    public String getType() {
        return Stapler.getCurrentRequest().getParameter("type");

    }

    public boolean isRawOutput() {
        return Stapler.getCurrentRequest().getParameter("type")
                .equalsIgnoreCase("raw");

    }

    public boolean isXmlOutput() {
        return Stapler.getCurrentRequest().getParameter("type")
                .equalsIgnoreCase("xml");

    }

}