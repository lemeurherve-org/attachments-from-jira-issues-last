package hudson.plugins.jobConfigHistory;

import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Action;
import hudson.model.BuildListener;
import hudson.model.Descriptor;
import hudson.tasks.Publisher;

import java.io.IOException;

import org.kohsuke.stapler.StaplerRequest;

/**
 * @author Stefan Brausch
 */

public class JobConfigHistoryPublisher extends Publisher {

    JobConfigHistoryPublisher() {

    }

    public Descriptor<Publisher> getDescriptor() {
        return DescriptorImpl.INSTANCE;
    }

    public boolean perform(AbstractBuild<?, ?> build, Launcher launcher,
            BuildListener listener) throws InterruptedException, IOException {

        return true;
    }

    public Action getProjectAction(AbstractProject<?, ?> project) {

        return new ConfigHistoryProjectAction(project, this);
    }

    public static final DescriptorImpl DESCRIPTOR = new DescriptorImpl();

    public static final class DescriptorImpl extends Descriptor<Publisher> {

        DescriptorImpl() {
            super(JobConfigHistoryPublisher.class);
            load();
        }

        @Override
        public String getDisplayName() {

            return "Job Config History";
        }

        public boolean configure(StaplerRequest req) throws FormException {
            save();
            return super.configure(req);
        }

        public JobConfigHistoryPublisher newInstance(StaplerRequest req)
                throws FormException {

            return new JobConfigHistoryPublisher();
        }

        public static final DescriptorImpl INSTANCE = new DescriptorImpl();
    }
}
