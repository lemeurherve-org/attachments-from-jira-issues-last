package hudson.plugins.jobConfigHistory;

import hudson.Plugin;
import hudson.model.Hudson;
import hudson.model.Project;
import hudson.tasks.BuildStep;

import java.io.IOException;

import javax.servlet.ServletException;

import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;

/**
 * Entry point of jobConfigHistory plugin.
 *
 * @author Stefan Brausch
 * @plugin
 */
public class PluginImpl extends Plugin {

    JobConfigHistoryJobListener jobListener = null;

    public void start() throws Exception {

        jobListener = new JobConfigHistoryJobListener();
        Hudson.getInstance().getJobListeners().add(jobListener);

        ConfigHistoryAction mainAction = new ConfigHistoryAction();
        Hudson.getInstance().getActions().add(mainAction);

        BuildStep.PUBLISHERS.add(JobConfigHistoryPublisher.DescriptorImpl.INSTANCE);
    }

    /**
     * @see hudson.Plugin#stop()
     */
    @Override
    public void stop() throws Exception {
        Hudson.getInstance().getJobListeners().remove(jobListener);
    }
}
