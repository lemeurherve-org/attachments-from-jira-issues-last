package hudson.plugins.perforce.perforce_tag;

import hudson.*;
import hudson.model.*;
import hudson.plugins.perforce.PerforceSCM;

import java.io.*;
import java.util.Map;

import com.tek42.perforce.*;
import com.tek42.perforce.process.Executor;
import com.tek42.perforce.model.Workspace;
import com.tek42.perforce.model.Label;
import groovy.lang.Binding;
import groovy.lang.GroovyShell;
import org.codehaus.groovy.control.CompilerConfiguration;

public class PerforceTagPlugin {

	static final String DESCRIPTION = "Perform Perforce tagging on succesful build";

	static final String CONFIG_PREFIX = "perforcetag.";


    private static AbstractProject getRootProject(AbstractProject abstractProject)
    {
        if (abstractProject.getParent() instanceof Hudson)
        {
            return abstractProject;
        }
        else
        {
            return getRootProject((AbstractProject) abstractProject.getParent());
        }
    }


    public static boolean perform(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener, String tagName)
    {
        PrintStream logger = listener.getLogger();

        if (!Result.SUCCESS.equals(build.getResult()))
        {
            logger.println("Skipping Perforce Tagging as build result was not successful.");

            return true;
        }

        AbstractProject rootProject = getRootProject(build.getProject());

        if (!(rootProject.getScm() instanceof PerforceSCM))
        {
            logger.println("Perforce Tag plugin does not support tagging for SCM " + rootProject.getScm() + ".");

            return true;
        }

        PerforceSCM scm = PerforceSCM.class.cast(rootProject.getScm());
        if (scm != null) {
            Depot depot = scm.getDepot();
            if (depot != null) {
				Executor p4 = depot.getExecFactory().newExecutor();
                try
                {

					// Evaluate the groovy tag name
					listener.getLogger().println("The expression for tag name is : " + tagName);

					Map<String, String> env = build.getEnvVars();
					tagName = evalGroovyExpression(env, tagName);

					listener.getLogger().println("The expression for tag name is : " + tagName);

					listener.getLogger().println("Project Path :" + scm.getProjectPath());
                    String view = scm.getProjectPath();
                    listener.getLogger().println("Going to label this view : " + view + " with this tag : " + tagName);

                    Label label = new Label();
                    label.setName(tagName);
                    label.setOwner(depot.getUser());
                    label.setRevision("");
                    label.addView(view);
                    depot.getLabels().saveLabel(label);


					String [] labelSync = new String [] {"p4", "labelsync", "-a", "-l", tagName, view};
					p4.exec(labelSync);

					String line = null;
					BufferedReader reader = p4.getReader();
					while((line = reader.readLine()) != null) {
						listener.getLogger().println("Executing labelsync cmd : " + line);
					}
					reader.close();
                    listener.getLogger().println("Perforce LabelSync Done Successfully!!");
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                finally {
					p4.close();
				}
            }
        }
        return true;
    }

    static String evalGroovyExpression(Map<String, String> env, String expression)
		{
			Binding binding = new Binding();
			binding.setVariable("env", env);
			binding.setVariable("sys", System.getProperties());
			CompilerConfiguration config = new CompilerConfiguration();
			//config.setDebug(true);
			GroovyShell shell = new GroovyShell(binding, config);
			Object result = shell.evaluate("return \"" + expression + "\"");
			if (result == null)
			{
				return "";
			}
			else
			{
				return result.toString().trim();
			}
	}
}
