package foo.bar.group;

import junit.framework.TestCase;

public class MyPropertiesTest extends TestCase {
    
    public MyPropertiesTest(String name){
        super(name);
    }
    
    public void testProperties(){
    	String prop = System.getProperties().getProperty("myProperty");
        assertNotNull(prop);
    }
    
}