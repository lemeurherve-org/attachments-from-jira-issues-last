package test;

public class Test {

	public static 
	void helloWorld()
	{
		System.out.println("Hello world");
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		helloWorld();
	}

}
