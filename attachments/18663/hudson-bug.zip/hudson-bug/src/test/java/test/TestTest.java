package test;

import org.junit.Test;

public class TestTest {

	@Test
	public void testHelloWorld() {
		test.Test.helloWorld();
	}

}
