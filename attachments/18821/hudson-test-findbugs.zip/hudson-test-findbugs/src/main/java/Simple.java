
/**
 * A simple class for testing.
 */
public class Simple {
}