package hudson.plugins.cppncss;

import hudson.model.AbstractBuild;
import hudson.model.Action;
import hudson.model.HealthReport;
import hudson.plugins.cppncss.parser.StatisticsResult;

/**
 * TODO javadoc.
 *
 * @author Stephen Connolly
 * @since 08-Jan-2008 21:15:05
 */
public class CppNCSSBuildIndividualReport extends AbstractBuildReport<AbstractBuild<?, ?>>
        implements Action {

    private HealthReport healthReport;

    public CppNCSSBuildIndividualReport(StatisticsResult results, Integer functionCcnViolationThreshold, Integer functionNcssViolationThreshold) {
        super(results, functionCcnViolationThreshold, functionNcssViolationThreshold);
    }

    /**
     * Write-once setter for property 'build'.
     *
     * @param build The value to set the build to.
     */
    @Override
    public synchronized void setBuild(AbstractBuild<?, ?> build) {
        super.setBuild(build);
        if (this.getBuild() != null) {
            getResults().setOwner(this.getBuild());
        }
    }

    /**
     * {@inheritDoc}
     */
    public HealthReport getBuildHealth() {
        return healthReport;
    }

    public void setBuildHealth(HealthReport healthReport) {
        this.healthReport = healthReport;
    }
}
