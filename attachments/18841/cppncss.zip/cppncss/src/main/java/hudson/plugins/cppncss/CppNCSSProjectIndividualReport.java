package hudson.plugins.cppncss;

import hudson.model.AbstractProject;
import hudson.model.ProminentProjectAction;

/**
 * TODO javadoc.
 *
 * @author Stephen Connolly
 * @since 08-Jan-2008 22:05:48
 */
public class CppNCSSProjectIndividualReport extends AbstractProjectReport<AbstractProject<?, ?>> implements ProminentProjectAction {
    public CppNCSSProjectIndividualReport(AbstractProject<?, ?> project, Integer functionCcnViolationThreshold, Integer functionNcssViolationThreshold) {
        super(project, functionCcnViolationThreshold, functionNcssViolationThreshold);
    }

    protected Class<? extends AbstractBuildReport> getBuildActionClass() {
        return CppNCSSBuildIndividualReport.class;
    }
}
