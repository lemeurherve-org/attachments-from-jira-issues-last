/**
 * 
 */
package hudson.plugins.starteam;

import hudson.FilePath.FileCallable;
import hudson.model.TaskListener;
import hudson.remoting.VirtualChannel;

import java.io.File;
import java.io.IOException;
import java.util.Date;

/**
 * This Actor class allow to check for changes in starteam repository between
 * builds.
 * 
 * @author Steve Favez <sfavez@verisign.com>
 * 
 */
public class StarTeamPollingActor implements FileCallable<Boolean> {

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = -5678102033953507247L;

	private String hostname;

	private int port;

	private String user;

	private String passwd;

	private String projectname;

	private String viewname;

	private String foldername;

	private final TaskListener listener;

	private final Date sinceDate;

	private final Date currentDate;

	/**
	 * Default constructor.
	 * 
	 * @param aHostname
	 *            starteam host name
	 * @param port
	 *            starteam port
	 * @param aUser
	 *            starteam connection user name
	 * @param aPassword
	 *            starteam connection password
	 * @param aProjectname
	 *            starteam project name
	 * @param aViewname
	 *            starteam view name
	 * @param aFoldername
	 *            starteam parent folder name
	 * @param aSinceDate
	 *            starteam last build date
	 * @param aCurrentDate
	 *            starteam current date
	 * @param aListener
	 *            Hudson task listener.
	 */
	public StarTeamPollingActor(String aHostname, int port, String aUser,
			String aPassword, String aProjectname, String aViewname,
			String aFoldername, Date aSinceDate, Date aCurrentDate,
			TaskListener aListener) {
		this.hostname = aHostname;
		this.port = port;
		this.user = aUser;
		this.passwd = aPassword;
		this.projectname = aProjectname;
		this.viewname = aViewname;
		this.foldername = aFoldername;
		this.listener = aListener;
		this.sinceDate = aSinceDate;
		this.currentDate = aCurrentDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hudson.FilePath.FileCallable#invoke(java.io.File,
	 * hudson.remoting.VirtualChannel)
	 */
	public Boolean invoke(File aFolder, VirtualChannel aChannel)
			throws IOException {
		
		if (sinceDate == null) {
			return false ;
		}
		
		StarTeamConnection connection = new StarTeamConnection(hostname, port,
				user, passwd, projectname, viewname, foldername);
		try {
			connection.initialize();
		} catch (StarTeamSCMException e) {
			listener.getLogger().println(e.getLocalizedMessage());
			connection.close();
			return false;
		}
		Date synchronizedSinceDate = connection
				.calculatePreviousDateWithTimeZoneCheck(sinceDate, currentDate);
		if (connection.findChangedFiles(aFolder, listener.getLogger(),
				synchronizedSinceDate).isEmpty()) {
			connection.close();
			return false;
		}
		connection.close();
		return true;
	}

}
