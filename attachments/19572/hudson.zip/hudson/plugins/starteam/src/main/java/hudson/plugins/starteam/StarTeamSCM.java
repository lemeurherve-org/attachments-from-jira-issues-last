package hudson.plugins.starteam;

import hudson.Extension;
import hudson.FilePath;
import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.model.TaskListener;
import hudson.scm.ChangeLogParser;
import hudson.scm.SCM;
import hudson.scm.SCMDescriptor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import net.sf.json.JSONObject;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;

/**
 * StarTeam SCM plugin for Hudson.
 * Add support for change log and synchronization between starteam repository and hudson's workspace.
 * Add support for change log creation.
 * Refactoring to use Extension annotation and to remove use of deprecated API.
 * 
 * @author Ilkka Laukkanen <ilkka.s.laukkanen@gmail.com>
 * @author Steve Favez <sfavez@verisign.com>
 */
public class StarTeamSCM extends SCM {

	private final String user;
	private final String passwd;
	private final String projectname;
	private final String viewname;
	private final String foldername;
	private final String hostname;
	private final int port;

	/**
	 * 
	 * default stapler constructor.
	 * 
	 * @param aHostname
	 *            starteam host name.
	 * @param aPort
	 *            starteam port name
	 * @param aProjectname
	 *            name of the project
	 * @param aViewname
	 *            name of the view
	 * @param aFoldername
	 *            parent folder name.
	 * @param aUsername
	 *            the user name required to connect to starteam's server
	 * @param aPassword
	 *            password required to connect to starteam's server
	 * 
	 * @stapler-constructor
	 */
	@DataBoundConstructor
	public StarTeamSCM(String aHostname, int aPort, String aProjectname,
			String aViewname, String aFoldername, String aUsername,
			String aPassword) {
		this.hostname = aHostname;
		this.port = aPort;
		this.projectname = aProjectname;
		this.viewname = aViewname;
		this.foldername = aFoldername;
		this.user = aUsername;
		this.passwd = aPassword;
	}

	/*
	 * @see hudson.scm.SCM#checkout(hudson.model.AbstractBuild, hudson.Launcher,
	 * hudson.FilePath, hudson.model.BuildListener, java.io.File)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean checkout(AbstractBuild build, Launcher aLauncher,
			FilePath aWorkspace, BuildListener aListener, File aChangelogFile)
			throws IOException, InterruptedException {
		boolean status = false;

		Date previousBuildDate = null;
		if (build.getPreviousBuild() != null) {
			previousBuildDate = build.getPreviousBuild().getTimestamp()
					.getTime();
		}
		Date currentBuildDate = build.getTimestamp().getTime();

		//create a FilePath to be able to create changelog file on a remote computer.
		FilePath changeLogFilePath = new FilePath( aChangelogFile ) ;
		
		// Create an actor to do the checkout, possibly on a remote machine
		StarTeamCheckoutActor co_actor = new StarTeamCheckoutActor(hostname,
				port, user, passwd, projectname, viewname, foldername,
				previousBuildDate, currentBuildDate, changeLogFilePath, aListener);
		if (aWorkspace.act(co_actor)) {
			// change log is written during checkout (only one pass for
			// comparison)
			status = true;
		} else {
			aListener.getLogger().println("StarTeam checkout failed");
			status = false;
		}
		return status;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hudson.scm.SCM#createChangeLogParser()
	 */
	@Override
	public ChangeLogParser createChangeLogParser() {
		return new StarTeamChangeLogParser();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hudson.scm.SCM#getDescriptor()
	 */
	@Override
	public StarTeamSCMDescriptorImpl getDescriptor() {
		return (StarTeamSCMDescriptorImpl)super.getDescriptor() ;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hudson.scm.SCM#pollChanges(hudson.model.AbstractProject,
	 * hudson.Launcher, hudson.FilePath, hudson.model.TaskListener)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean pollChanges(final AbstractProject aProject,
			final Launcher aLauncher, final FilePath aWorkspace,
			final TaskListener aListener) throws IOException,
			InterruptedException {
		boolean status = false;

		Date lastBuildDate = null;
		if (aProject.getLastBuild() != null) {
			lastBuildDate = aProject.getLastBuild().getTimestamp().getTime();
		}
		Date currentServerDate = new Date();
		// Create an actor to do the polling, possibly on a remote machine
		StarTeamPollingActor p_actor = new StarTeamPollingActor(hostname, port,
				user, passwd, projectname, viewname, foldername, lastBuildDate,
				currentServerDate, aListener);

		if (aWorkspace.act(p_actor)) {
			status = true;
		} else {
			aListener.getLogger().println("StarTeam polling failed");
		}
		return status;
	}

	/**
	 * Descriptor class for the SCM class.
	 * 
	 * @author Ilkka Laukkanen <ilkka.s.laukkanen@gmail.com>
	 * 
	 */
	@Extension
	public static final class StarTeamSCMDescriptorImpl extends
			SCMDescriptor<StarTeamSCM> {

		private final Collection<StarTeamSCM> scms = new ArrayList<StarTeamSCM>();

		public StarTeamSCMDescriptorImpl() {
			super(StarTeamSCM.class, null);
			load() ;
		}

		@Override
		public String getDisplayName() {
			return "StarTeam";
		}

		@Override
		public SCM newInstance(StaplerRequest aRequest, JSONObject aFormData)
				throws hudson.model.Descriptor.FormException {
			// Go ahead and create the scm.. the bindParameters() method
			// takes the request and nabs all "starteam." -prefixed
			// parameters from it, then sets the scm instance's fields
			// according to those parameters.
			StarTeamSCM scm = null;
			try {
				scm = aRequest.bindParameters(StarTeamSCM.class, "starteam.");
				scms.add(scm);
			} catch (RuntimeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// We don't have working repo browsers yet...
			// scm.repositoryBrowser = RepositoryBrowsers.createInstance(
			// StarTeamRepositoryBrowser.class, req, "starteam.browser");
			return scm;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * hudson.model.Descriptor#configure(org.kohsuke.stapler.StaplerRequest)
		 */
		@Override
		public boolean configure(StaplerRequest aRequest) throws FormException {
			// This is used for the global configuration
			return true;
		}

	}

	/**
	 * Get the hostname this SCM is using.
	 * 
	 * @return The hostname.
	 */
	public String getHostname() {
		return hostname;
	}

	/**
	 * Get the port number this SCM is using.
	 * 
	 * @return The port.
	 */
	public int getPort() {
		return port;
	}

	/**
	 * Get the project name this SCM is connected to.
	 * 
	 * @return The project's name.
	 */
	public String getProjectname() {
		return projectname;
	}

	/**
	 * Get the view name in the project this SCM uses.
	 * 
	 * @return The name of the view.
	 */
	public String getViewname() {
		return viewname;
	}

	/**
	 * Get the root folder name of our monitored workspace.
	 * 
	 * @return The name of the folder.
	 */
	public String getFoldername() {
		return foldername;
	}

	/**
	 * Get the username used to connect to starteam.
	 * 
	 * @return The username.
	 */
	public String getUsername() {
		return user;
	}

	/**
	 * Get the password used to connect to starteam.
	 * 
	 * @return The password.
	 */
	public String getPassword() {
		return passwd;
	}
}
