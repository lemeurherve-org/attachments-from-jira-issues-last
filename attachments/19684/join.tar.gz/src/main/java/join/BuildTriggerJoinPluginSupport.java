/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package join;

import hudson.model.AbstractProject;
import hudson.model.DependencyGraph.Dependency;
import hudson.model.Result;
import hudson.tasks.BuildTrigger;
import hudson.tasks.BuildTrigger.DescriptorImpl;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author wolfs
 */
public class BuildTriggerJoinPluginSupport extends JoinDependencyPluginSupport<BuildTrigger.DescriptorImpl, BuildTrigger> {

    protected static class BuildTriggerJoinDependency extends JoinDependency<Dependency> {
        private Result threshold;

        private BuildTriggerJoinDependency(AbstractProject<?,?> upstream, AbstractProject<?,?> downstream, AbstractProject<?,?> splitProject, Result threshold) {
            super(upstream, downstream,splitProject);
            this.threshold = threshold;
            splitDependency = new Dependency(splitProject, downstream);
        }

        @Override
        protected boolean conditionIsMet(Result overallResult) {
            return overallResult.isBetterOrEqualTo(threshold);
        }

    }

    @Override
    protected Class<DescriptorImpl> getDescriptorType() {
        return BuildTrigger.DescriptorImpl.class;
    }

    @Override
    public boolean triggersIntermediateBuilds() {
        return true;
    }

    @Override
    protected Class<BuildTrigger> getPublisherType() {
        return BuildTrigger.class;
    }

    @Override
    protected List<AbstractProject<?, ?>> getDownstreamProjects(BuildTrigger publisher) {
        List<AbstractProject<?,?>> list = new ArrayList<AbstractProject<?, ?>>();
        for (AbstractProject<?,?> downstreamProject: publisher.getChildProjects()) {
            if (!downstreamProject.isDisabled()) {
                list.add(downstreamProject);
            }
        }
        return list;
    }

    @Override
    public boolean isInstalled() {
        return true;
    }

    @Override
    protected String getPluginName() {
        throw new UnsupportedOperationException("Included in Hudson");
    }

    @Override
    public List<Dependency> getDependencies(AbstractProject<?, ?> downstream, BuildTrigger publisher, AbstractProject<?, ?> splitProject) {
        List<Dependency> dependencies = new ArrayList<Dependency>();
        for (AbstractProject<?,?> joinProject: publisher.getChildProjects()) {
            dependencies.add(new BuildTriggerJoinDependency(downstream, joinProject, splitProject, publisher.getThreshold()));
        }
        return dependencies;
    }

}
