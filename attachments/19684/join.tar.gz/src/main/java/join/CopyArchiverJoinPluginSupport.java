/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package join;

import com.thalesgroup.hudson.plugins.copyarchiver.CopyArchiverPublisher;
import hudson.FilePath;
import hudson.Launcher;
import hudson.Proc;
import hudson.model.AbstractBuild;
import hudson.model.BuildListener;
import hudson.model.TaskListener;
import hudson.remoting.Channel;
import hudson.remoting.Channel.Listener;
import hudson.remoting.VirtualChannel;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author wolfs
 */
public class CopyArchiverJoinPluginSupport extends JoinPerformingPluginSupport<CopyArchiverPublisher.CopyArchiverDescriptor, CopyArchiverPublisher> {
    private static final Logger LOGGER = Logger.getLogger(CopyArchiverJoinPluginSupport.class.getName());

    @Override
    protected String getPluginName() {
        return "copyarchiver";
    }

    @Override
    protected Class<CopyArchiverPublisher.CopyArchiverDescriptor> getDescriptorType() {
        return CopyArchiverPublisher.CopyArchiverDescriptor.class;
    }

    @Override
    protected Class<CopyArchiverPublisher> getPublisherType() {
        return CopyArchiverPublisher.class;
    }

    private static class FakeLauncher extends Launcher {

        FakeLauncher(AbstractBuild<?,?> build, TaskListener listener) {
            super(listener,build.getBuiltOn().getChannel());
        }

        @Override
        public Proc launch(ProcStarter starter) throws IOException {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        @Override
        public Channel launchChannel(String[] cmd, OutputStream out, FilePath workDir, Map<String, String> envVars) throws IOException, InterruptedException {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        @Override
        public void kill(Map<String, String> modelEnvVars) throws IOException, InterruptedException {
            throw new UnsupportedOperationException("Not supported yet.");
        }

    }

    @Override
    protected void perform(AbstractBuild<?, ?> triggeringBuild, TaskListener listener, CopyArchiverPublisher publisher) {
        try {
            Launcher launcher = new FakeLauncher(triggeringBuild, listener);
            publisher.perform(triggeringBuild, launcher, (BuildListener)listener);
        } catch (Throwable e) {
            listener.getLogger().println("[Join] Error when running CopyArchiver Plugin: " + e);
            LOGGER.log(Level.SEVERE, "Exception when running CopyArchiver", e);
        }
    }


}
