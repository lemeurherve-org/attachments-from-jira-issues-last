package join;

import java.util.ArrayList;
import java.util.List;

import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Action;
import hudson.model.Descriptor;
import hudson.model.Result;
import hudson.model.Run;
import hudson.model.TaskListener;
import hudson.tasks.Publisher;
import hudson.util.DescribableList;
import hudson.model.Cause.UpstreamCause;

public class JoinAction implements Action {
    private List<String> pendingDownstreamProjects;
    private List<String> completedDownstreamProjects;
    private List<String> consideredBuilds;
    private transient String joinProjects;
    private DescribableList<Publisher, Descriptor<Publisher>> joinPublishers;
    private boolean evenIfDownstreamUnstable;
    private Result overallResult;
    
    public JoinAction(JoinTrigger joinTrigger, List<AbstractProject> downstreamProjects) {
        this.pendingDownstreamProjects = new ArrayList<String>();
        for(AbstractProject project : downstreamProjects) {
            if(!project.isDisabled()) {
                this.pendingDownstreamProjects.add(project.getName());
            }
        }

        this.joinPublishers = joinTrigger.getJoinPublishers();
        this.completedDownstreamProjects = new ArrayList<String>();
        this.consideredBuilds = new ArrayList<String>();
        this.overallResult = Result.SUCCESS;
    }

    public String getDisplayName() {
        return null;
    }

    public String getIconFileName() {
        return null;
    }

    public String getUrlName() {
        return "join";
    }

    public boolean updateDownstreamFinished(AbstractBuild<?,?> upstreamBuild, AbstractBuild<?,?> finishedBuild, TaskListener listener) {
        AbstractProject finishedBuildProject = finishedBuild.getProject();
        if (!consideredBuilds.contains(finishedBuild.toString())) {
            consideredBuilds.add(finishedBuild.toString());
            if (pendingDownstreamProjects.remove(finishedBuildProject.getName())) {
                this.overallResult = this.overallResult.combine(finishedBuild.getResult());
                completedDownstreamProjects.add(finishedBuildProject.getName());
                if (pendingDownstreamProjects.isEmpty()) {
                    for (JoinPluginSupport pluginSupport: JoinTrigger.getSupportedPlugins()) {
                        if (pluginSupport instanceof JoinPerformingPluginSupport) {
                            final JoinPerformingPluginSupport performingPlugin =
                                    (JoinPerformingPluginSupport) pluginSupport;
                            performingPlugin.perform(finishedBuild, listener, joinPublishers);
                        }
                    }
                }
            } else {
                listener.getLogger().println("[Join] Pending does not contain " + finishedBuildProject);
            }
        } else {
            listener.getLogger().println("[Join] Pending build " + finishedBuild + " already considered");
        }
        return shouldTriggerJoinBuilds(listener, upstreamBuild);
    }

    public Result getOverallResult() {
        return overallResult;
    }

    private boolean shouldTriggerJoinBuilds(TaskListener listener, AbstractBuild<?, ?> upstreamBuild) {
        if (pendingDownstreamProjects.isEmpty()) {
            listener.getLogger().println("All downstream projects complete!");
            return true;
        } else {
            listener.getLogger().println("Project " + upstreamBuild.getProject().getName() + " still waiting for " + pendingDownstreamProjects.size() + " builds to complete");
        }
        return false;
    }

    public class JoinCause extends UpstreamCause {

        public JoinCause(Run<?, ?> arg0) {
            super(arg0);
        }
        
    }
}
