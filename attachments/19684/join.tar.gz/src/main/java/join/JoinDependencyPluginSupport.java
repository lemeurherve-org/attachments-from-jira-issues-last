/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package join;

import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Action;
import hudson.model.Cause;
import hudson.model.Cause.UpstreamCause;
import hudson.model.DependencyGraph.Dependency;
import hudson.model.Descriptor;
import hudson.model.Result;
import hudson.model.Run;
import hudson.model.TaskListener;
import hudson.tasks.Publisher;
import hudson.util.DescribableList;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author wolfs
 */
public abstract class JoinDependencyPluginSupport<DESC extends Descriptor, PUB extends Publisher> extends
 JoinPluginSupport<DESC, PUB> {
    private static final Logger LOGGER = Logger.getLogger(JoinDependencyPluginSupport.class.getName());

    public abstract boolean triggersIntermediateBuilds();

    protected static class JoinDependency<DEP extends Dependency> extends Dependency {
        private AbstractProject<?,?> splitProject;
        protected DEP splitDependency;

        protected JoinDependency(AbstractProject<?,?> upstream, AbstractProject<?,?> downstream, AbstractProject<?,?> splitProject) {
            super(upstream, downstream);
            this.splitProject = splitProject;
        }

        @Override
        public boolean shouldTriggerBuild(AbstractBuild build, TaskListener listener, List<Action> actions) {
            AbstractBuild<?,?> splitBuild = getSplitBuild(build);
            if (splitBuild != null) {
                final JoinAction joinAction = splitBuild.getAction(JoinAction.class);
                if(joinAction != null) {
                    listener.getLogger().println("Notifying upstream build " + splitBuild + " of job completion");
                    boolean joinDownstreamFinished = joinAction.updateDownstreamFinished(splitBuild, build, listener);
                    joinDownstreamFinished = joinDownstreamFinished &&
                            conditionIsMet(joinAction.getOverallResult()) &&
                                splitDependency.shouldTriggerBuild(splitBuild, listener, actions);
                    return joinDownstreamFinished;
                }
            }
            // does not go in the build log, since this is normal for any downstream project that
            // runs without the join plugin enabled
            LOGGER.log(Level.FINER, "Join notifier cannot find upstream JoinAction: {0}", splitBuild);
            return false;
        }

        private AbstractBuild getSplitBuild(AbstractBuild build) {
            final List<Cause> causes = build.getCauses();
            AbstractBuild joinBuild = null;
            for (Cause cause : causes) {
                if (cause instanceof JoinAction.JoinCause) {
                    continue;
                }
                if (cause instanceof UpstreamCause) {
                    UpstreamCause uc = (UpstreamCause) cause;
                    final int upstreamBuildNum = uc.getUpstreamBuild();
                    final String upstreamProject = uc.getUpstreamProject();
                    if (splitProject.getName().equals(upstreamProject)) {
                        final Run upstreamRun = splitProject.getBuildByNumber(upstreamBuildNum);
                        if (upstreamRun instanceof AbstractBuild) {
                            joinBuild = (AbstractBuild) upstreamRun;
                            break;
                        }
                    }
                }
            }
            return joinBuild;
        }

        protected boolean conditionIsMet(Result overallResult) {
            return true;
        }


    }


    public List<AbstractProject<?,?>> getDownstreamProjects(AbstractProject<?,?> project) {
        List<AbstractProject<?,?>> projects = new ArrayList<AbstractProject<?, ?>>();
        if (isInstalled()) {
            final List<PUB> publishers = getPublishers(project);
            projects = getDownstreamForPublishers(publishers);
        }
        return projects;
    }

    protected List<AbstractProject<?, ?>> getDownstreamForPublishers(final List<PUB> publishers) {
        List<AbstractProject<?, ?>> projects = new ArrayList<AbstractProject<?, ?>>();
        for (PUB publisher : publishers) {
            if (publisher != null) {
                projects = getDownstreamProjects(publisher);
            }
        }
        return projects;
    }

    protected abstract List<AbstractProject<?,?>> getDownstreamProjects(PUB publisher);
    
    public List<Dependency> getDependencies(
            AbstractProject<?,?> downstream,
            DescribableList<Publisher,Descriptor<Publisher>> publisherList,
            AbstractProject<?,?> splitProject) {
        List<Dependency> dependencies = new ArrayList<Dependency>();
        if (isInstalled()) {
            List<PUB> publishers = publisherList.getAll(getPublisherType());
            for (PUB publisher: publishers) {
                dependencies.addAll(getDependencies(downstream, publisher, splitProject));
            }
        }
        return dependencies;
    }

    public abstract List<Dependency> getDependencies(
            AbstractProject<?,?> downstream,
            PUB publisher,
            AbstractProject<?,?> splitProject);

}
