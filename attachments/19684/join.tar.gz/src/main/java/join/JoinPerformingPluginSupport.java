/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package join;

import hudson.model.AbstractBuild;
import hudson.model.Descriptor;
import hudson.model.TaskListener;
import hudson.tasks.Publisher;
import hudson.util.DescribableList;
import java.util.List;

/**
 *
 * @author wolfs
 */
public abstract class JoinPerformingPluginSupport<DESC extends Descriptor, PUB extends Publisher>
        extends JoinPluginSupport<DESC, PUB> {
        protected abstract void perform(AbstractBuild<?,?> triggeringBuild, TaskListener listener, PUB publisher);

        public void perform(
                AbstractBuild<?,?> triggeringBuild,
                TaskListener listener,
                DescribableList<Publisher, Descriptor<Publisher>> publishers) {
            final List<PUB> performingPublishers = publishers.getAll(getPublisherType());
            for (PUB publisher: performingPublishers) {
                perform(triggeringBuild, listener, publisher);
            }
        }
}
