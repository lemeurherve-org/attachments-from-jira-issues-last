/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package join;

import hudson.model.AbstractProject;
import hudson.model.Descriptor;
import hudson.model.Hudson;
import hudson.model.listeners.ItemListener;
import hudson.tasks.Publisher;
import java.util.List;

/**
 *
 * @author wolfs
 */
public abstract class JoinPluginSupport<DESC extends Descriptor, PUB extends Publisher> {

    private ItemListener defaultItemListener = new ItemListener();

    public boolean isInstalled() {
        return Hudson.getInstance().getPlugin(getPluginName()) != null;
    }

    protected abstract String getPluginName();
    protected abstract Class<DESC> getDescriptorType();
    protected abstract Class<PUB> getPublisherType();

    public DESC getDescriptor() {
        return Hudson.getInstance().getDescriptorByType(getDescriptorType());
    }

    public List<PUB> getPublishers(AbstractProject<?,?> project) {
        return project.getPublishersList().getAll(getPublisherType());
    }

    public ItemListener getItemListener() {
        return defaultItemListener;
    }

}
