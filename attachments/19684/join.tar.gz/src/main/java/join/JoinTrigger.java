/*
 * The MIT License
 * 
 * Copyright (c) 2004-2009, Sun Microsystems, Inc., Kohsuke Kawaguchi, Brian Westrich, Martin Eigenbrodt
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package join;

import hudson.Extension;
import hudson.Functions;
import hudson.Launcher;
import hudson.Plugin;
import hudson.maven.AbstractMavenProject;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.model.DependencyGraph;
import hudson.model.Descriptor;
import hudson.model.FreeStyleProject;
import hudson.model.Hudson;
import hudson.model.Item;
import hudson.model.Project;
import hudson.model.Saveable;
import hudson.model.DependecyDeclarer;
import hudson.model.DependencyGraph.Dependency;
import hudson.model.listeners.ItemListener;
import hudson.tasks.BuildStep;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.BuildTrigger;
import hudson.tasks.Publisher;
import hudson.tasks.Recorder;
import hudson.util.DescribableList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;

import org.kohsuke.stapler.StaplerRequest;

@Extension
public class JoinTrigger extends Recorder implements DependecyDeclarer {

    @Override
    public boolean prebuild(AbstractBuild<?, ?> build, BuildListener listener) {
        for( BuildStep bs : joinPublishers )
            if(!bs.prebuild(build,listener))
                return false;
        return true;
    }

    @Override
    public boolean perform(AbstractBuild<?, ?> build, Launcher launcher,
            BuildListener listener) throws InterruptedException, IOException {
        JoinAction joinAction = new JoinAction(this, getDownstream(build.getProject()));
        build.addAction(joinAction);
        return true;
    }

    private transient String joinProjects;
    
    private DescribableList<Publisher,Descriptor<Publisher>> joinPublishers =
        new DescribableList<Publisher,Descriptor<Publisher>>((Saveable)null);

    private transient boolean evenIfDownstreamUnstable;
    private static transient List<JoinPluginSupport<?,?>> supportedPlugins;

    static {
        List<JoinPluginSupport<?,?>> list1 = new ArrayList<JoinPluginSupport<?,?>>();
        list1.add(new BuildTriggerJoinPluginSupport());
        list1.add(new ParameterizedTriggerJoinPluginSupport());
        list1.add(new CopyArchiverJoinPluginSupport());
        supportedPlugins = Collections.unmodifiableList(list1);
    }
    
    public JoinTrigger() {
        this(new DescribableList<Publisher, Descriptor<Publisher>>((Saveable)null));
    }

    public JoinTrigger(DescribableList<Publisher,Descriptor<Publisher>> publishers) {
        if (publishers != null) {
            this.joinPublishers = publishers;
        }
    }

    public void buildDependencyGraph(AbstractProject owner, DependencyGraph graph) {
        final List<AbstractProject> downstreamProjects = getDownstream(owner);
        for (JoinPluginSupport<?, ?> supportedPlugin : supportedPlugins) {
            if (supportedPlugin instanceof JoinDependencyPluginSupport<?,?>) {
                final JoinDependencyPluginSupport supportedDepPlugin =
                        (JoinDependencyPluginSupport) supportedPlugin;
                for (AbstractProject downstreamProject: downstreamProjects) {
                    final List<Dependency> dependencies =
                            supportedDepPlugin.getDependencies(downstreamProject, joinPublishers, owner);
                    for (Dependency dependency : dependencies) {
                        graph.addDependency(dependency);
                    }
                }
            }
        }
    }
    
    public List<AbstractProject> getDownstream(AbstractProject<?,?> project) {
        ArrayList<AbstractProject> ret = new ArrayList<AbstractProject>();
        for (JoinPluginSupport supportedPlugin: supportedPlugins) {
            if (supportedPlugin instanceof JoinDependencyPluginSupport) {
                final JoinDependencyPluginSupport dependencyPlugin = (JoinDependencyPluginSupport) supportedPlugin;
                if (dependencyPlugin.triggersIntermediateBuilds()) {
                    ret.addAll(dependencyPlugin.getDownstreamProjects(project));
                }
            }
        }
        return ret;
        
    }

    public static class DescriptorImpl extends BuildStepDescriptor<Publisher> {
        @Extension
        public static final DescriptorImpl DESCRIPTOR = new DescriptorImpl();

        public String getDisplayName() {
            return "Join Trigger";
        }

        @Override
        public String getHelpFile() {
            return "/plugin/join/help/joinTrigger.html";
        }

        @Override
        public JoinTrigger newInstance(StaplerRequest req, JSONObject formData) throws FormException {
            LOGGER.finer(formData.toString());
            DescribableList<Publisher,Descriptor<Publisher>> publishers = 
                new DescribableList<Publisher,Descriptor<Publisher>>((Saveable)null);

            JSONObject joinPublishers = formData.optJSONObject("joinPublishers");
            if(joinPublishers != null) {
                publishers.rebuild(req, joinPublishers, getApplicableDescriptors());
            }

            JSONObject experimentalpostbuild = formData.optJSONObject("experimentalpostbuildactions");
            if(experimentalpostbuild != null) {
                JSONObject joinTriggers = experimentalpostbuild.optJSONObject("joinPublishers");
                if(joinTriggers != null) {
                    LOGGER.log(Level.FINEST, "EPB: {0}{1}", new Object[]{joinTriggers.toString(), joinTriggers.isArray()});
                    publishers.rebuild(req, joinTriggers, Publisher.all());
                }
            }

            LOGGER.log(Level.FINER, "Parsed {0} publishers", publishers.size());
            return new JoinTrigger(publishers);
        }

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> jobType) {
            boolean freeStyle = FreeStyleProject.class.isAssignableFrom(jobType);
            if(freeStyle) {
                return true;
            }
            Plugin mavenProjectPlugin = Hudson.getInstance().getPlugin("maven-plugin");
            return mavenProjectPlugin != null && AbstractMavenProject.class.isAssignableFrom(jobType);
        }

        public List<Descriptor<Publisher>> getApplicableDescriptors() {
            ArrayList<Descriptor<Publisher>> list = new ArrayList<Descriptor<Publisher>>();
            for (JoinPluginSupport<?,?> supportedPlugin: supportedPlugins) {
                if (supportedPlugin.isInstalled()) {
                    list.add(supportedPlugin.getDescriptor());
                }
            }
            return list;
        }
        
        public List<Descriptor<Publisher>> getApplicableExperimentalDescriptors(AbstractProject<?,?> project) {
            List<Descriptor<Publisher>> list = Functions.getPublisherDescriptors(project);
            LOGGER.log(Level.FINEST, "publisher count before removing publishers: {0}", list.size());
            // need to prevent infinite recursion, so we remove the Join publisher.
            list.remove(Hudson.getInstance().getDescriptorByType(DescriptorImpl.class));
            list.removeAll(getApplicableDescriptors());
            LOGGER.log(Level.FINEST, "publisher count after removing publishers: {0}", list.size());
            return list;
        }


        @Extension
        public static class ItemListenerImpl extends ItemListener {
            @Override
            public void onRenamed(Item item, String oldName, String newName) {
                // update BuildTrigger of other projects that point to this object.
                // can't we generalize this?
                for( Project<?,?> p : Hudson.getInstance().getProjects() ) {
                    BuildTrigger t = p.getPublishersList().get(BuildTrigger.class);
                    if(t!=null) {
                        if(t.onJobRenamed(oldName,newName)) {
                            try {
                                p.save();
                            } catch (IOException e) {
                                LOGGER.log(Level.WARNING, "Failed to persist project setting during rename from "+oldName+" to "+newName,e);
                            }
                        }
                    }
                }
            }
        }
    }

    private static final Logger LOGGER = Logger.getLogger(JoinTrigger.class.getName());

    private boolean containsAnyDescriptor(
            List<Descriptor<Publisher>> applicableDescriptors) {
        for(Descriptor<Publisher> descriptor : applicableDescriptors) {
           if(joinPublishers.contains(descriptor)) {
               return true;
           }
        }
        return false;
    }
    
    public boolean useExperimentalPostBuildActions(AbstractProject<?,?> project) {
        return containsAnyDescriptor(DescriptorImpl.DESCRIPTOR.getApplicableExperimentalDescriptors(project));
    }
    
    public DescribableList<Publisher, Descriptor<Publisher>> getJoinPublishers() {
        return joinPublishers;
    }

    private Object readResolve() throws IOException {
        if(this.joinPublishers == null) {
            this.joinPublishers = new DescribableList<Publisher,Descriptor<Publisher>>((Saveable)null);
        }
        if (StringUtils.isNotBlank(joinProjects)) {
            final List<Publisher> publishers = joinPublishers.getAll(Publisher.class);
            publishers.add(new BuildTrigger(joinProjects, evenIfDownstreamUnstable));
            joinPublishers = new DescribableList<Publisher, Descriptor<Publisher>>((Saveable)null, publishers);
        }
        return this;
    }

    public BuildStepMonitor getRequiredMonitorService() {
        return BuildStepMonitor.NONE;
    }

    public static List<JoinPluginSupport<?, ?>> getSupportedPlugins() {
        return supportedPlugins;
    }
}
