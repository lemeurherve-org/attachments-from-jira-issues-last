/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package join;

import hudson.model.AbstractProject;
import hudson.model.DependencyGraph.Dependency;
import hudson.model.Result;
import hudson.plugins.parameterizedtrigger.BuildTrigger;
import hudson.plugins.parameterizedtrigger.BuildTrigger.DescriptorImpl;
import hudson.plugins.parameterizedtrigger.BuildTriggerConfig;
import hudson.plugins.parameterizedtrigger.ParameterizedDependency;
import hudson.plugins.parameterizedtrigger.ResultCondition;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import join.JoinDependencyPluginSupport;

/**
 *
 * @author wolfs
 */
public class ParameterizedTriggerJoinPluginSupport extends JoinDependencyPluginSupport<BuildTrigger.DescriptorImpl, BuildTrigger> {

    protected class ParameterizedJoinDependency extends JoinDependency<ParameterizedDependency> {
        private BuildTriggerConfig config;

        private ParameterizedJoinDependency(AbstractProject<?,?> upstream, AbstractProject<?,?> downstream, AbstractProject<?,?> splitProject,BuildTriggerConfig config) {
            super(upstream, downstream,splitProject);
            splitDependency = new ParameterizedDependency(splitProject, downstream, config);
            this.config = config;
        }

        @Override
        protected boolean conditionIsMet(Result overallResult) {
            // This is bad but sadly the method is package-private and not public!
            try {
                final ResultCondition condition = config.getCondition();
                final Method isMetMethod = condition.getClass().getDeclaredMethod("isMet", Result.class);
                isMetMethod.setAccessible(true);
                return (Boolean)isMetMethod.invoke(condition, overallResult);
            } catch (Exception ex) {
                Logger.getLogger(ParameterizedTriggerJoinPluginSupport.class.getName()).log(Level.SEVERE, null, ex);
            }
            return true;
        }


    }

    @Override
    protected String getPluginName() {
        return "parameterized-trigger";
    }

    @Override
    protected Class<DescriptorImpl> getDescriptorType() {
        return BuildTrigger.DescriptorImpl.class;
    }

    @Override
    public boolean triggersIntermediateBuilds() {
        return true;
    }

    @Override
    protected Class<BuildTrigger> getPublisherType() {
        return BuildTrigger.class;
    }

    @Override
    protected List<AbstractProject<?, ?>> getDownstreamProjects(BuildTrigger publisher) {
        List<AbstractProject<?,?>> list = new ArrayList<AbstractProject<?, ?>>();
        for (BuildTriggerConfig config: publisher.getConfigs()) {
            for (AbstractProject<?,?> downstreamProject: config.getProjectList()) {
                if (!downstreamProject.isDisabled()) {
                    list.add(downstreamProject);
                }
            }
        }
        return list;
    }

    @Override
    public List<Dependency> getDependencies(AbstractProject<?, ?> downstream, BuildTrigger publisher, AbstractProject<?, ?> splitProject) {
        List<Dependency> dependencies = new ArrayList<Dependency>();
        for (BuildTriggerConfig config: publisher.getConfigs()) {
            for (AbstractProject<?,?> joinProject: config.getProjectList()) {
                dependencies.add(new ParameterizedJoinDependency(downstream, joinProject, splitProject, config));
            }
        }
        return dependencies;
    }

}
