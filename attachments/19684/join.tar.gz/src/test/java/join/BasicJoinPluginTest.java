/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package join;

import com.thalesgroup.hudson.plugins.copyarchiver.CopyArchiver;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Descriptor;
import hudson.model.FreeStyleProject;
import hudson.model.Saveable;
import hudson.plugins.parameterizedtrigger.AbstractBuildParameters;
import hudson.plugins.parameterizedtrigger.BuildTriggerConfig;
import hudson.plugins.parameterizedtrigger.ResultCondition;
import hudson.tasks.BuildTrigger;
import hudson.tasks.Publisher;
import hudson.util.DescribableList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.jvnet.hudson.test.HudsonTestCase;

/**
 *
 * @author wolfs
 */
public abstract class BasicJoinPluginTest extends HudsonTestCase {
    protected FreeStyleProject splitProject;
    protected FreeStyleProject joinProject;

    public static void assertInSequence(AbstractBuild<?,?>... builds) {
        AbstractBuild<?,?> previousBuild = null;
        for (AbstractBuild<?, ?> build : builds) {
            if (previousBuild != null) {
                assertFinished(previousBuild).beforeStarted(build);
            }
            previousBuild = build;
        }
    }

    public static <T extends AbstractBuild<?,?>>
            void assertInSequence(AbstractBuild<?,?> firstBuild, List<T> intermediateBuilds, AbstractBuild<?,?> lastBuild) {
        assertFinished(firstBuild).beforeStarted(intermediateBuilds);
        assertStarted(lastBuild).afterFinished(intermediateBuilds);
    }

    public static <ProjectT extends AbstractProject<ProjectT,BuildT>, BuildT extends AbstractBuild<ProjectT, BuildT>>
            BuildT getUniqueBuild(AbstractProject<ProjectT, BuildT> project) {
        final List<BuildT> builds = project.getBuilds();
        assertTrue("Project " + project + " should have been built exactly once but was triggered " + builds.size() + " times!",
                builds.size() == 1);
        final BuildT build = builds.get(0);
        return build;
    }

    public static void assertNotBuilt(AbstractProject<?, ?> project) {
        final List<?> builds = project.getBuilds();
        assertTrue("Project " + project + " should not have been built!", builds.isEmpty());
    }

    public static <ProjectT extends AbstractProject<ProjectT,BuildT>, BuildT extends AbstractBuild<ProjectT, BuildT>>
            List<BuildT> getUniqueBuilds(List<ProjectT> projects) {
        final List<BuildT> buildList = new ArrayList<BuildT>();
        for (AbstractProject<ProjectT, BuildT> project : projects) {
            buildList.add(getUniqueBuild(project));
        }
        return buildList;
    }

    protected FreeStyleProject createFailingFreeStyleProject() throws Exception {
        final FreeStyleProject project = createFreeStyleProject();
        project.getPublishersList().add(ResultSetter.FAILURE());
        return project;
    }

    protected FreeStyleProject createUnstableFreeStyleProject() throws Exception {
        final FreeStyleProject project = createFreeStyleProject();
        project.getPublishersList().add(ResultSetter.UNSTABLE());
        return project;
    }

    protected List<FreeStyleProject> createFreeStyleProjects(int number) throws Exception {
        List<FreeStyleProject> createdProjects = new ArrayList<FreeStyleProject>();
        for (int i=0; i<number; i++) {
            createdProjects.add(createFreeStyleProject());
        }
        return createdProjects;
    }

    public static void addJoinTriggerToSplitProject(AbstractProject<?,?> splitProject, AbstractProject<?,?> joinProject) throws Exception {
        splitProject.getPublishersList().add(new JoinTrigger(new DescribableList<Publisher, Descriptor<Publisher>>(
                (Saveable)null,Collections.singletonList(new BuildTrigger(joinProject.getName(), false)))));
    }

    public static void addParameterizedJoinTriggerToProject(AbstractProject<?,?> splitProject, AbstractProject<?,?> joinProject, AbstractBuildParameters... params) throws Exception {
        addParameterizedJoinTriggerToProject(splitProject, joinProject, ResultCondition.SUCCESS, params);
    }

    public static void addParameterizedJoinTriggerToProject(AbstractProject<?,?> splitProject, AbstractProject<?,?> joinProject, ResultCondition condition, AbstractBuildParameters... params) throws Exception {
        final BuildTriggerConfig config = new hudson.plugins.parameterizedtrigger.BuildTriggerConfig(joinProject.getName(), condition, params);
        splitProject.getPublishersList().add(new JoinTrigger(new DescribableList<Publisher, Descriptor<Publisher>>(
                (Saveable)null, Collections.singletonList(new hudson.plugins.parameterizedtrigger.BuildTrigger(config)))));
    }

    public static void addProjectToSplitProject(AbstractProject<?,?> splitProject, AbstractProject<?,?> projectToAdd) throws Exception {
        splitProject.getPublishersList().add(new BuildTrigger(projectToAdd.getName(), false));
    }

    public static <T extends AbstractProject<?,?>> void addProjectsToSplitProject(AbstractProject<?,?> splitProject, List<T> projectsToAdd) throws Exception {
        for (AbstractProject<?,?> projectToAdd: projectsToAdd) {
            addProjectToSplitProject(splitProject, projectToAdd);
        }
    }

    public static BuildTimeConstraint assertFinished(AbstractBuild<?,?> build) {
        return BuildTimeConstraint.finished(build);
    }

    public static BuildTimeConstraint assertStarted(AbstractBuild<?,?> build) {
        return BuildTimeConstraint.started(build);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        splitProject = createFreeStyleProject("splitProject");
        joinProject = createFreeStyleProject("joinProject");
    }

    public static class BuildTimeConstraint {
        private final long millis;
        private final String buildName;
        private final String state;

        public static BuildTimeConstraint finished(AbstractBuild<?,?> build) {
            final long started = build.getTimestamp().getTimeInMillis();
            final long duration = build.getDuration();
            final long finished = started + duration;
            return new BuildTimeConstraint(build.toString(), "finished", finished);
        }

        public static BuildTimeConstraint started(AbstractBuild<?,?> build) {
            final long started = build.getTimestamp().getTimeInMillis();
            return new BuildTimeConstraint(build.toString(), "started", started);
        }

        BuildTimeConstraint(String buildName, String state, long millis) {
            this.millis = millis;
            this.buildName = buildName;
            this.state = state;
        }

        public void beforeStarted(AbstractBuild<?,?> build) {
            final long started = build.getTimestamp().getTimeInMillis();
            assertTrue(String.format("%s not %s before %s started!", buildName, state, build.toString()),
                    millis < started);
        }

        public <T extends AbstractBuild<?,?>> void beforeStarted(List<T> builds) {
            for (T build : builds) {
                beforeStarted(build);
            }
        }


        public void afterFinished(AbstractBuild<?,?> build) {
            final long started = build.getTimestamp().getTimeInMillis();
            final long duration = build.getDuration();
            final long finished = started + duration;
            assertTrue(String.format("%s not %s after %s finished!", buildName, state, build.toString()),
                    millis > finished);
        }

        public <T extends AbstractBuild<?,?>> void afterFinished(List<T> builds) {
            for (T build : builds) {
                afterFinished(build);
            }
        }
    }

}
