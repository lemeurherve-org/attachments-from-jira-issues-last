/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package join;

import com.thalesgroup.hudson.plugins.copyarchiver.ArchivedJobEntry;
import com.thalesgroup.hudson.plugins.copyarchiver.CopyArchiverPublisher;
import hudson.model.Cause.UserCause;
import hudson.model.Descriptor;
import hudson.model.FreeStyleBuild;
import hudson.model.FreeStyleProject;
import hudson.model.Saveable;
import hudson.tasks.BuildTrigger;
import hudson.tasks.Publisher;
import hudson.util.DescribableList;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author wolfs
 */
public class CopyArchiverJoinPluginSupportTest extends BasicJoinPluginTest {
    public void testCopyArchiver() throws Exception {
        List<FreeStyleProject> intermediateProjects = createFreeStyleProjects(2);
        addProjectsToSplitProject(splitProject, intermediateProjects);
        List<ArchivedJobEntry> jobs = new ArrayList<ArchivedJobEntry>();
        for (FreeStyleProject project : intermediateProjects) {
            jobs.add(new ArchivedJobEntry(project.getName(), "*", ""));
        }
        final CopyArchiverPublisher copyArchiver =
                new CopyArchiverPublisher(splitProject.getRootDir().getAbsolutePath(), null, true, false, jobs);
        final List<Publisher> publisherList = new ArrayList<Publisher>();
        publisherList.add(copyArchiver);
        publisherList.add(new BuildTrigger(joinProject.getName(), false));
        splitProject.getPublishersList().add(new JoinTrigger(new DescribableList<Publisher, Descriptor<Publisher>>(
                (Saveable)null, publisherList)));

        hudson.rebuildDependencyGraph();

        final FreeStyleBuild splitBuild = splitProject.scheduleBuild2(0, new UserCause()).get();
        waitUntilNoActivity();
        final List<FreeStyleBuild> intermediateBuilds = JoinTriggerTest.
                <FreeStyleProject,FreeStyleBuild>getUniqueBuilds(intermediateProjects);
        final FreeStyleBuild joinBuild = getUniqueBuild(joinProject);
        assertInSequence(splitBuild, intermediateBuilds, joinBuild);
    }
}
