package oracle.hudson.plugins.perforce_tag;

import com.tek42.perforce.Depot;
import com.tek42.perforce.PerforceException;
import com.tek42.perforce.model.Label;
import groovy.lang.Binding;
import groovy.lang.GroovyShell;
import hudson.FilePath;
import hudson.Launcher;
import hudson.model.*;
import hudson.plugins.perforce.*;
import org.apache.commons.lang.StringUtils;
import org.codehaus.groovy.control.CompilerConfiguration;


import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



/**
 * @author Anil Arora
 */
@SuppressWarnings(
        {"UtilityClass", "ImplicitCallToSuper", "MethodReturnOfConcreteClass",
                "MethodParameterOfConcreteClass", "InstanceofInterfaces"})
public class PerforceTagPlugin {

    /**
     * Creates a new PerforceTagPlugin object.
     */
    private PerforceTagPlugin() {
    }

    /**
     * True if the operation was successful.
     *
     * @param abstractBuild build
     * @param launcher      launcher
     * @param buildListener build listener
     * @param tagLabelStr tag base URL string
     * @param tagComment    tag comment
     * @return true if the operation was successful
     */
    @SuppressWarnings({"FeatureEnvy", "UnusedDeclaration", "TypeMayBeWeakened",
            "LocalVariableOfConcreteClass"})
    public static boolean perform(AbstractBuild<?,?> abstractBuild,
                                  Launcher launcher,
                                  BuildListener buildListener,
                                  String tagLabel, String tagComment) throws IOException {
        PrintStream logger = buildListener.getLogger();

        if (!Result.SUCCESS.equals(abstractBuild.getResult())) {
            logger.println(Messages.UnsuccessfulBuild());
            return true;
        }

        AbstractProject<?, ?> rootProject =
                abstractBuild.getProject().getRootProject();

        Map<String, String> env;

        if (!(rootProject.getScm() instanceof PerforceSCM)) {
            logger.println(Messages.NotPerforce(rootProject.getScm().toString()));
            return true;
        }

        PerforceSCM scm = PerforceSCM.class.cast(rootProject.getScm());
        try {
            env = abstractBuild.getEnvironment(buildListener);
        } catch (Exception e) {
            logger.println(
                    "Failed to get environment. " + e.getLocalizedMessage());
            return false;
        }

        AbstractBuild build = rootProject.getBuilds().get(0);
        // Let SubversionSCM fill revision number.
        // It is guaranteed for getBuilds() return the latest build (i.e.
        // current build) at first
        // The passed in abstractBuild may be the sub maven module and not
        // have revision.txt holding Svn revision information, so need to use
        // the build associated with the root level project.
        scm.buildEnvVars(build, env);

        PerforceTagAction action = build.getAction(PerforceTagAction.class);
        if (action.isTagged()) {
            logger.println("Workspace has already been tagged to " + action.getTag());
            return true;
        }

        String revision = Integer.toString(action.getChangeNumber());
        FilePath workspace = build.getWorkspace();

        String evalLabel = evalGroovyExpression(env, tagLabel);
        String evalComment = evalGroovyExpression(env, tagComment);

        logger.println("Creating/updating perforce label " + evalLabel + " to revision " + revision);
        logger.println("Comment: " + evalComment);
        try {

        Label label = new Label();
        label.setName(evalLabel);
        label.setDescription(evalComment);
        label.setRevision(revision);

        String projectPath = substituteParameters(scm.getProjectPath(), build.getBuildVariables());

        // Only take the depot paths and add them to the view.
        logger.println("Project path is " + projectPath);
        List<String> viewPairs = parseProjectPath(projectPath, "workspace");
        logger.println("Parsed view pairs " + viewPairs);
        for (int i=0; i < viewPairs.size(); i+=2){    
            String depotPath = viewPairs.get(i);
            logger.println("Adding view " + depotPath);
            label.addView(depotPath);
        }

        Depot depot = getDepot(scm);
        try {
            depot.getLabels().saveLabel(label);
        } catch(PerforceException e) {
            logger.println("Failed to issue perforce label.");
            e.printStackTrace(logger);
            return false;
        }

        action.setTag(evalLabel);
        build.save();
        }
        catch (IOException xcp) {
            logger.println("Got io exception");
            xcp.printStackTrace(logger);
            throw xcp;
        }
        catch (RuntimeException xcp) {
            logger.println("Got runtime exception");
            xcp.printStackTrace(logger);
            throw xcp;
        }

        return true;
    }

    protected static Depot getDepot(PerforceSCM scm) {

        Depot depot = new Depot();
        depot.setUser(scm.getP4User());

        PerforcePasswordEncryptor encryptor = new PerforcePasswordEncryptor();
        depot.setPassword(encryptor.decryptString(scm.getP4Passwd()));

        depot.setPort(scm.getP4Port());
        depot.setClient(scm.getP4Client());

        depot.setExecutable(scm.getP4Exe());
        depot.setSystemDrive(scm.getP4SysDrive());
        depot.setSystemRoot(scm.getP4SysRoot());

        depot.setCharset(scm.getP4Charset());
        depot.setCommandCharset(scm.getP4CommandCharset());

        return depot;
    }
    

    @SuppressWarnings({"StaticMethodOnlyUsedInOneClass", "TypeMayBeWeakened"})
    static String evalGroovyExpression(Map<String, String> env, String evalText) {
        Binding binding = new Binding();
        binding.setVariable("env", env);
        binding.setVariable("sys", System.getProperties());
        CompilerConfiguration config = new CompilerConfiguration();
        GroovyShell shell = new GroovyShell(binding, config);
        Object result = shell.evaluate("return \"" + evalText + "\"");
        if (result == null) {
            return "";
        } else {
            return result.toString().trim();
        }
    }


    /* Regular expressions for parsing view mappings.
     */
    private static final Pattern COMMENT = Pattern.compile("^$|^#.*$");
    private static final Pattern DEPOT_ONLY = Pattern.compile("^[+-]?//\\S+?(/\\S+)$");
    private static final Pattern DEPOT_ONLY_QUOTED = Pattern.compile("^\"[+-]?//\\S+?(/[^\"]+)\"$");
    private static final Pattern DEPOT_AND_WORKSPACE =
            Pattern.compile("^([+-]?//\\S+?/\\S+)\\s+//\\S+?(/\\S+)$");
    private static final Pattern DEPOT_AND_WORKSPACE_QUOTED =
            Pattern.compile("^\"([+-]?//\\S+?/[^\"]+)\"\\s+\"//\\S+?(/[^\"]+)\"$");

    /**
     * Parses the projectPath into a list of pairs of strings representing the depot and client
     * paths. Even items are depot and odd items are client.
     * <p>
     * This parser can handle quoted or non-quoted mappings, normal two-part mappings, or one-part
     * mappings with an implied right part. It can also deal with +// or -// mapping forms.
     */
    static List<String> parseProjectPath(String projectPath, String p4Client) {
        List<String> parsed = new ArrayList<String>();
        for (String line : projectPath.split("\n")) {
            Matcher depotOnly = DEPOT_ONLY.matcher(line);
            if (depotOnly.find()) {
                // add the trimmed depot path, plus a manufactured client path
                parsed.add(line.trim());
                parsed.add("//" + p4Client + depotOnly.group(1));
            } else {
                Matcher depotOnlyQuoted = DEPOT_ONLY_QUOTED.matcher(line);
                if (depotOnlyQuoted.find()) {
                    // add the trimmed quoted depot path, plus a manufactured quoted client path
                    parsed.add(line.trim());
                    parsed.add("\"//" + p4Client + depotOnlyQuoted.group(1) + "\"");
                } else {
                    Matcher depotAndWorkspace = DEPOT_AND_WORKSPACE.matcher(line);
                    if (depotAndWorkspace.find()) {
                        // add the found depot path and the clientname-tweaked client path
                        parsed.add(depotAndWorkspace.group(1));
                        parsed.add("//" + p4Client + depotAndWorkspace.group(2));
                    } else {
                        Matcher depotAndWorkspaceQuoted = DEPOT_AND_WORKSPACE_QUOTED.matcher(line);
                        if (depotAndWorkspaceQuoted.find()) {
                           // add the found depot path and the clientname-tweaked client path
                            parsed.add("\"" + depotAndWorkspaceQuoted.group(1) + "\"");
                            parsed.add("\"//" + p4Client + depotAndWorkspaceQuoted.group(2) + "\"");
                        }
                        // Assume anything else is a comment and ignore it
                    }
                }
            }
        }
        return parsed;
    }

    static String substituteParameters(String string, Map<String,String> subst) {
        if(string == null) return null;
        String newString = new String(string);
        for (Map.Entry<String,String> entry : subst.entrySet()){
            newString = newString.replace("${" + entry.getKey() + "}", entry.getValue());
        }
        return newString;
    }





}

