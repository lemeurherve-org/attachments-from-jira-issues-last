package oracle.hudson.plugins.perforce_tag;

import hudson.tasks.BuildStepMonitor;
import java.io.IOException;
import java.util.HashMap;

import hudson.Extension;
import hudson.Launcher;
import hudson.Util;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.Notifier;
import hudson.tasks.Publisher;
import hudson.util.FormValidation;
import net.sf.json.JSONObject;
import org.codehaus.groovy.control.CompilationFailedException;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;
import org.kohsuke.stapler.StaplerRequest;


/**
 * Performs <tt>p4 label</tt> when the build was successfully done. Note that
 * this plugin is executed after the build state is finalized, and the errors
 * happened in this plugin doesn't affect to the state of the build.
 *
 * @author Anil Arora
 */
@SuppressWarnings({"PublicMethodNotExposedInInterface"})
public class PerforceTagPublisher extends Notifier {

    /**
     * tag base URL
     */
    private String tagLabel = null;

    private String tagComment = null;

    @DataBoundConstructor
    public PerforceTagPublisher(String tagLabel, String tagComment) {
        this.tagLabel = tagLabel;
        this.tagComment = tagComment;
    }

    /**
     * Returns the tag base URL value.
     *
     * @return the tag base URL value.
     */
    public String getTagLabel() {
        return this.tagLabel;
    }

    public String getTagComment() {
        return this.tagComment;
    }

    public BuildStepMonitor getRequiredMonitorService() {
        return BuildStepMonitor.BUILD;
    }

    @Override
    public boolean perform(AbstractBuild<?, ?> abstractBuild,
                           Launcher launcher,
                           BuildListener buildListener)
            throws InterruptedException, IOException {
        return PerforceTagPlugin.perform(abstractBuild, launcher, buildListener,
                this.getTagLabel(), this.getTagComment());
    }

    @Override
    public boolean needsToRunAfterFinalized() {
        return true;
    }

    /**
     * Returns the descriptor value.
     *
     * @return the descriptor value.
     */
    @Override
    public PerforceTagDescriptorImpl getDescriptor() {
        return (PerforceTagDescriptorImpl)super.getDescriptor();
    }

    @Extension
    public static final class PerforceTagDescriptorImpl
            extends BuildStepDescriptor<Publisher> {

        private String defaultTagLabel = null;

        private String tagComment;

        /**
         * Creates a new PerforceTagDescriptorImpl object.
         */
        public PerforceTagDescriptorImpl() {
            this.defaultTagLabel = Messages.DefaultTagLabel();
            this.tagComment = Messages.DefaultTagComment();
            load();
        }

        /**
         * Returns the display name value.
         *
         * @return the display name value.
         */
        @Override
        public String getDisplayName() {
            return Messages.DisplayName();
        }

        @Override
        public boolean configure(StaplerRequest req, JSONObject formData)
                throws FormException {
            req.bindJSON(this, formData);
            save();

            return super.configure(req, formData);
        }

        public FormValidation doCheckTagLabel(@QueryParameter final String value) {
            if (Util.fixEmptyAndTrim(value) == null) {
                return FormValidation.error(Messages.MissingLabel());
            }
            try {
                PerforceTagPlugin.evalGroovyExpression(
                        new HashMap<String, String>(), value);
                return FormValidation.ok();
            } catch (CompilationFailedException e) {
                return FormValidation.error(Messages.BadGroovy(e.getMessage()));
            }
        }

        public FormValidation doCheckDefaultTagLabel(@QueryParameter final String value) {
            return doCheckTagLabel(value);
        }

        /**
         * Returns the default tag base URL value.
         *
         * @return the default tag base URL value.
         */
        public String getDefaultTagLabel() {
            return this.defaultTagLabel;
        }

        /**
         * Sets the value of default tag base URL.
         *
         * @param defaultTagBaseURL the default tag base URL value.
         */
        public void setDefaultTagLabel(String defaultTagLabel) {
            this.defaultTagLabel = defaultTagLabel;
        }

        /**
         * Returns the tag comment value.
         *
         * @return the tag comment value.
         */
        public String getTagComment() {
            return this.tagComment;
        }

        /**
         * Sets the value of tag comment.
         *
         * @param tagComment the tag comment value.
         */
        public void setTagComment(String tagComment) {
            this.tagComment = tagComment;
        }

        public FormValidation doCheckTagComment(@QueryParameter final String value) {
            try {
                PerforceTagPlugin.evalGroovyExpression(
                        new HashMap<String, String>(), value);
                return FormValidation.ok();
            } catch (CompilationFailedException e) {
                return FormValidation.error(Messages.BadGroovy(e.getMessage()));
            }
        }

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> jobType) {
            // need to check if this is a subversion project??
            return true;
        }

    }
}

