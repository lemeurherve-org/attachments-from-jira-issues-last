/**
 * 
 */
package hudson.plugins.persona;

import hudson.ExtensionList;
import hudson.model.AbstractBuild;
import hudson.model.Hudson;
import hudson.plugins.persona.simple.Image;
import hudson.plugins.persona.simple.SimplePersona;
import hudson.plugins.persona.xml.XmlBasedPersona;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.logging.Logger;

/**
 * Random persona
 * 
 * @author tanguy.de.lignieres
 *
 */
public class RandomPersona extends SimplePersona {
    private static final Logger LOGGER = Logger.getLogger(RandomPersona.class.getName());
    
	/**
	 * Random persona display name
	 */
	public static final String RANDOM_PERSONA_DISPLAYNAME = "Random Persona";
	
	/**
	 * Random persona id
	 */
	public static final String RANDOM_PERSONA_ID = "RandomPersonaId";
	
	/**
	 * Persona Randomizer
	 */
    private static final Random random = new Random();
    
    private Map<AbstractBuild<?,?>, XmlBasedPersona> mapPersonas =
    	new HashMap<AbstractBuild<?,?>, XmlBasedPersona>();
    
    private XmlBasedPersona currentPersona;
    
    /**
     * Creates a RandomPersona
     * 
     * @return
     * 		A newly created RandomPersona
     */
    public static RandomPersona create() {
    	return new RandomPersona();
    }
    
	/**
	 * Default constructor
	 */
	private RandomPersona() {
		super(RANDOM_PERSONA_ID, null);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Image getDefaultImage() {
//		LOGGER.info("getDefaultImage,currentPersona="
//				+ (null == currentPersona ? currentPersona
//						: currentPersona.getDisplayName()));
		return getCurrentPersona().getDefaultImage();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Image getImage(AbstractBuild<?, ?> build) {
//		LOGGER.info("getImage,currentPersona="
//				+ (null == currentPersona ? currentPersona
//						: currentPersona.getDisplayName()));
		return getCurrentPersona().getImage(build);
	}

	/**
	 * {@inheritDoc}
	 */
	public String getDisplayName() {
		return RANDOM_PERSONA_DISPLAYNAME;
	}

	@Override
    public synchronized String getRandomQuoteText() {
//		LOGGER.info("getRandomQuoteText,currentPersona="
//				+ (null == currentPersona ? currentPersona
//						: currentPersona.getDisplayName()));
		return getCurrentPersona().getDisplayName()
			+ " - "
			+ getCurrentPersona().getRandomQuoteText();
    }
	
	/**
	 * Retourne la persona associ� au build
	 * 
	 * @param build
	 * 			Le build pour lequel retourner la persona
	 * @return
	 * 			La persona associ�e au build
	 */
	public XmlBasedPersona getPersona(AbstractBuild<?,?> build) {
		return mapPersonas.get(build);
	}
	
	/**
	 * Retourne le current persona, en g�n�re une si non existante
	 * 
	 * @return
	 * 			La current persona
	 */
	public XmlBasedPersona getCurrentPersona() {
		if (null == currentPersona) {
			currentPersona = resetCurrentPersona();
//			LOGGER.info("getCurrentPersona,currentPersona="
//					+ (null == currentPersona ? currentPersona
//							: currentPersona.getDisplayName()));
		}
		
		return currentPersona;
	}
	
	/**
	 * Retourne le current persona, apr�s en avoir g�n�rer une
	 * 
	 * @return
	 * 			La current persona
	 */
	public XmlBasedPersona resetCurrentPersona() {
//		LOGGER.info("resetCurrentPersona,currentPersona="
//				+ (null == currentPersona ? currentPersona
//						: currentPersona.getDisplayName()));
		currentPersona = randomPersona();
		LOGGER.info("resetCurrentPersona,currentPersona="
				+ (null == currentPersona ? currentPersona
						: currentPersona.getDisplayName()));
		return currentPersona;
	}
	
    /**
     * Returns a random persona form all personas
     * 
     * @return
     * 		A random persona
     */
    public static XmlBasedPersona randomPersona() {
    	ExtensionList<XmlBasedPersona> personas = allXmlBased();
    	return personas.get(random.nextInt(personas.size()));
    }
    
    /**
     * Returns all the registered {@link XmlBasedPersona}s.
     */
    public static ExtensionList<XmlBasedPersona> allXmlBased() {
        return Hudson.getInstance().getExtensionList(XmlBasedPersona.class);
    }
}
