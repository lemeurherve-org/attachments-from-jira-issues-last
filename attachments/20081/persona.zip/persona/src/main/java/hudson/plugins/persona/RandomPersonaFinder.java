/**
 * 
 */
package hudson.plugins.persona;

import hudson.Extension;
import hudson.ExtensionComponent;
import hudson.ExtensionFinder;
import hudson.model.Hudson;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

/**
 * @author tanguy.de.lignieres
 *
 */
@Extension
public class RandomPersonaFinder extends ExtensionFinder {
    @Override
    public <T> Collection<ExtensionComponent<T>> find(Class<T> type, Hudson hudson) {
        if (type!=Persona.class) {
			return Collections.emptyList();
		}

        List<ExtensionComponent<RandomPersona>> r = new ArrayList<ExtensionComponent<RandomPersona>>();

        parsePersonaInto(r);
        
        return (List)r;
    }

    private void parsePersonaInto(Collection<ExtensionComponent<RandomPersona>> result) {
    	result.add(new ExtensionComponent<RandomPersona>(RandomPersona.create()));
    }

    private static final Logger LOGGER = Logger.getLogger(RandomPersona.class.getName());


}
