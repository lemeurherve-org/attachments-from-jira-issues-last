/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.hudson.ci.assembly;

/**
 *
 * @author Michal Hlavac <hlavki@hlavki.eu>
 */
public class Main {
    
    public static void main(String[] args) throws Exception {
        System.out.println("Hello!");
    }
}
