The parameterized NUnit test suite 'YodaRequests_Failure' with 2 tests is 
completely missing in junitResult.xml.

There are also test suites in nunit-result.xml which have currently no tests. 
But this seems to have no impact on the missing test mentioned above. Because
when I removed the empty test suites manually from nunit-result.xml and 
changed the file to read only, the tests were still missing on next job build.