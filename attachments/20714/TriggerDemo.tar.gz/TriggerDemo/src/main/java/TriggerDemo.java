package TriggerDemo;

import antlr.ANTLRException;
import hudson.EnvVars;
import hudson.Extension;
import hudson.Launcher;
import hudson.model.ParameterDefinition;
import hudson.model.ParametersDefinitionProperty;
import hudson.model.PasswordParameterValue;
import hudson.model.StringParameterValue;
import hudson.model.BooleanParameterValue;
import hudson.model.RunParameterValue;
import hudson.model.FileParameterValue;

import hudson.tasks.CommandInterpreter;
import hudson.tasks.Shell;
import hudson.tasks.BatchFile;

import hudson.Util;
import hudson.FilePath;

import hudson.model.AbstractProject;
import hudson.model.AbstractBuild;
import hudson.model.AbstractItem;
import hudson.model.BuildableItem;
import hudson.model.Cause;
import hudson.model.Item;
import hudson.model.Job;
import hudson.model.Hudson;
import hudson.model.Run;
import hudson.model.StreamBuildListener;
import hudson.model.TaskListener;
import hudson.model.TopLevelItem;


import hudson.triggers.Trigger;
import hudson.triggers.TriggerDescriptor;
import org.kohsuke.stapler.DataBoundConstructor;


import java.io.*;


import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;



public class TriggerDemo extends Trigger<BuildableItem> {
	private static Logger LOGGER = Logger.getLogger(TriggerDemo.class.getName());

	private String script;

        private FilePath workspace;

    @DataBoundConstructor
    public TriggerDemo(String schedule, String script) throws ANTLRException {
        super(schedule);
        this.script = Util.fixEmpty(script);
    }
   
    @SuppressWarnings({"UnusedDeclaration"})
    public String getScript() {
        return script;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public String getSchedule() {
        return spec;
    }

    @Extension
    public static class DescriptorImpl extends TriggerDescriptor {
        
    	public String getDisplayName() {
            return "[Jenkins Trigger Demo v1.0] To illustrate JENKINS-10621 & JENKINS-10622";
        }

        public boolean isApplicable(Item item) {
            return item instanceof TopLevelItem;
        }
        
        @Override
        public String getHelpFile() {
            return "/plugin/TriggerDemo/help.html";
        }
    }
    
    public void run() {
           try {

            // Is hudson shutting down or is a build on progress ?
            if (Hudson.getInstance().isQuietingDown()) {
                LOGGER.log(Level.FINE,"[Job " +  ((AbstractItem) job).getDisplayName() + "] End Trigger - Hudson Shutdown in progress");
                return;
            }
            
            // JENKINS-10622 Workaround - Cron tab should not run when Job is disabled
            if (((AbstractProject) job).isDisabled()) {
                LOGGER.log(Level.FINE,"[Job " +  ((AbstractItem) job).getDisplayName() + "] End Trigger - Job Disabled");
                return;
            }

            if ( ! ((AbstractProject) job).isBuildable()) {
                LOGGER.log(Level.FINE,"[Job " +  ((AbstractItem) job).getDisplayName() + "] End Trigger - Job Disabled");
                return;
            }

            if (((Job) job).isInQueue()) {
                LOGGER.log(Level.FINE,"[Job " + ((AbstractItem) job).getDisplayName() + "] End Trigger - Build in queue");
                return;
            }

            // JENKINS-10621 - workspace value is not correct if custom workspace is defined
            // Get Workspace
            workspace = Hudson.getInstance().getWorkspaceFor((TopLevelItem) job);
            LOGGER.log(Level.FINE,"[Job " + ((AbstractItem) job).getDisplayName() + "] Workspace from getInstance: " + workspace);
            
            if ( ((AbstractBuild)((Job)job).getLastBuild())!= null && ((AbstractBuild)((Job)job).getLastBuild()).getWorkspace() != null) {
                workspace = ((AbstractBuild)((Job)job).getLastBuild()).getWorkspace();
                LOGGER.log(Level.FINE,"[Job " + ((AbstractItem) job).getDisplayName() + "] Workspace for getLastBuild: " + workspace);
            } 
            // Schedule the Build
            job.scheduleBuild(0, new MyCause("Trig by TriggerDemo"));

           

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE,"[Job " + ((AbstractItem) job).getDisplayName() + "] End Trigger - Problem while executing ShellTrigger.run()", e);
            return;
        }

        LOGGER.log(Level.FINE,"[Job " +  ((AbstractItem) job).getDisplayName() + "] Trigger went all fine");

    }


    // ====================================================================================
    // Class to define the Cause of the build
    // ====================================================================================
    private static class MyCause extends Cause {
        private final String description;

        public MyCause(String description) {
            this.description = description;
        }

        public String getShortDescription() {
            return description;
        }
    }

}

