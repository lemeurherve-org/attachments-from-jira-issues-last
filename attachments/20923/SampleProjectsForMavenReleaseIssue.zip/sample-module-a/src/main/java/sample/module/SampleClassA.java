package sample.module;

public class SampleClassA {
	String something;

	public String getSomething() {
		return something;
	}

	public void setSomething(String something) {
		this.something = something;
	}
	

}
