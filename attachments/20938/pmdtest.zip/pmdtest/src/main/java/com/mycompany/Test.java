package com.mycompany;

public class Test {

    public void error() {
        try {

        } catch (Exception e) {
            // TODO: handle exception
        } finally {
            // TODO: cleanup
        }

    }
}
