from selenium import selenium
import unittest, time, re
import HTMLTestRunner

class se_ff_smoke_test(unittest.TestCase):
    def setUp(self):
        self.verificationErrors = []
        self.selenium = selenium("ci.talondata.com", 4444, "*iexplore", "http://www.warmfuzzyland.com/")
        self.selenium.start()
    
    def test_home_page_link(self):
        sel = self.selenium
        sel.open("/")
        sel.click("link=Warmfuzzyland")
        sel.wait_for_page_to_load("30000")
        self.failUnless(sel.is_text_present("Warmfuzzyland"))

    def test_deep_link(self):
        sel=self.selenium
        sel.open("/")
        sel.click("link=battle report")
        sel.wait_for_page_to_load("30000")
        self.failUnless(sel.is_text_present("battle report"))
    
    def tearDown(self):
        self.selenium.stop()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    #unittest.main()
    # THis just prints html to stdout, which might work
    HTMLTestRunner.main()
    # write to a file
    #fp = file('sel_report.html', 'wb')
    #runner = HTMLTestRunner.HTMLTestRunner(
    #            stream=fp,
    #            title='Selenium Web Test',
    #            description='This demonstrates the report output by HTMLTestRunner.'
    #            )
   # 
    # run the test
    #runner.run(se_ff_smoke_test)
   
    
