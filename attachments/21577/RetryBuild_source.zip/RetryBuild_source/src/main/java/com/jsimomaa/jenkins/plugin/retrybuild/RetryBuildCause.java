package com.jsimomaa.jenkins.plugin.retrybuild;

import hudson.model.Cause;

/**
 * Hello world!
 *
 */
public class RetryBuildCause extends Cause {
 
    @Override   
    public String getShortDescription() {
        return Messages.RetryBuildCause_Description();
    }
    
}
