package com.jsimomaa.jenkins.plugin.RetryBuild;

import com.jsimomaa.jenkins.plugin.retrybuild.RetryBuildCause;
import com.jsimomaa.jenkins.plugin.retrybuild.RetryBuildPublisher;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Result;
import hudson.model.TaskListener;
import hudson.model.listeners.RunListener;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class RetryBuildListener extends RunListener<AbstractBuild<?, ?>> {
	
        int loops = 0;
	int upstreamBuildNumber = 0;
	
	AbstractProject getUpstreamProject(AbstractProject project) {
		List<AbstractProject> upstreamProjects = project.getUpstreamProjects();
		if (upstreamProjects.size() == 1) return upstreamProjects.get(0);
		else return null;
	}
	
	@Override
	public void onStarted(AbstractBuild<?, ?> build, TaskListener listener) {
        
            System.out.println("Testing if we have come to the end of our build loop with TSDummy.");
            AbstractProject proj = build.getProject();
            
            if ("TSDummy".equals(proj.getName())) {
                System.out.println("TSDummy matches build" + proj);
                proj = getUpstreamProject(proj);
                do {
                    if ("TSDummy".equals(proj.getName())) {
                       return;
                    }    
                    else {
                       AbstractBuild<?, ?> uBuild = (AbstractBuild<?, ?>)proj.getLastBuild();
                       if (uBuild.getResult() == Result.SUCCESS) {
                       }     
                       else { 
                          build.setResult(Result.FAILURE);
                          System.out.println("Build that caused Failure: " + uBuild);
                          return;
                       }
                proj = getUpstreamProject(proj);
                    }
                } while (proj != null);
            }
        }
	
	 @Override
	 public void onCompleted(AbstractBuild<?, ?> build, TaskListener listener) {
            if (build.getResult() == Result.SUCCESS) {
                System.out.println("Build "+ build + "was successful!");
                return;
	    }
	    
	    System.out.println("Current build name and number: " + build);
	    AbstractProject proj = build.getProject();
	    //for (Object usp : proj.getUpstreamProjects()) {
               //     System.out.println("usp " + usp);
	       //     AbstractProject<?,?> usproj = (AbstractProject<?, ?>) usp;
	       //     System.out.println("upstream project: " + usproj);
	       //     for (Object dsp : proj.getDownstreamProjects()) {
	       //         AbstractProject<?,?> dsproj = (AbstractProject<?, ?>) dsp;
	       //         System.out.println("downstream project: " + dsproj);
	       //     hudson.model.Run lastBuild = usproj.getLastBuild();
	       ////     System.out.println("last build: " + lastBuild);
	        //    if (lastBuild != null) {
	        //        int i = lastBuild.getNumber();
	        //        System.out.println("first upstream project, last build #: " + i);
	        //        System.out.println("upstrambuild #: " + upstreamBuildNumber);
	        //        //System.out.println("loops #: " + loops);
	        //           loops = 0;
	        //            upstreamBuildNumber = i;
	        //            System.out.println("upstrambuild #: " + upstreamBuildNumber);
	        //            //System.out.println("loops #: " + loops);
	         //       }
	          //  }
	        //}
	        //}
	 
         RetryBuildPublisher retrybuild = build.getProject().getPublishersList().get(RetryBuildPublisher.class);
               
         int quietPeriod = retrybuild.getQuietPeriod();     
	 int amountRetry = retrybuild.getAmountRetry(); 
         System.out.println("Amount of retries: " + amountRetry);
         System.out.println("Amount of loops: " + loops);
         
	 if(loops++ < amountRetry) {
            LOGGER.log(Level.FINE, "about to try to schedule a build");
            scheduleBuild(build, quietPeriod);
            System.out.println("Scheduled a new build");
       } else {
            loops = 0; 
            try {
                System.out.println("Trying to schedule downstream build..");
                for (Object dsp : proj.getDownstreamProjects()) {   
                AbstractProject<?,?> dsproj = (AbstractProject<?, ?>) dsp;
                AbstractBuild nBuild = dsproj.getLastBuild();
                dsproj.scheduleBuild(quietPeriod, new RetryBuildCause());
                System.out.println("Downstream project scheduled:" + dsproj);
            } 
            } finally {
                System.out.println("No downstream projects!");
            }
     }
	 }
	 
	 public boolean scheduleBuild(AbstractBuild<?, ?> build, int n) {
		 return build.getProject().scheduleBuild(n, new RetryBuildCause());
	 }
	 
	 
	 private static final Logger LOGGER = Logger.getLogger(RetryBuildListener.class.getName());
			 
}