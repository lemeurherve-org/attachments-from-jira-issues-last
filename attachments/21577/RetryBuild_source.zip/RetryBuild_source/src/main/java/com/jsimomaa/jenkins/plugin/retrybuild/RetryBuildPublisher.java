package com.jsimomaa.jenkins.plugin.retrybuild;

import com.jsimomaa.jenkins.plugin.RetryBuild.RetryBuildListener;
import hudson.Extension;
import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.model.Descriptor.FormException;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.Notifier;
import hudson.tasks.Publisher;

import java.io.IOException;
import java.util.logging.Logger;
import net.sf.json.JSONObject;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;

/**
 * Reschedules a build if the current one fails.
 *
 * @author Nayan Hajratwala <nayan@chikli.com>
 */
public class RetryBuildPublisher extends Notifier {
    
    private final int amountRetry;
    private final int quietPeriod;
    
    @DataBoundConstructor    
    public RetryBuildPublisher(int amountRetry, int quietPeriod) {

        this.amountRetry = amountRetry;
        this.quietPeriod = quietPeriod;
    }
    
    public int getQuietPeriod() {
        return quietPeriod;
    }
        
    public int getAmountRetry() {
        return amountRetry;
    }
    
    @Override
    public boolean perform(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener) throws InterruptedException, IOException {
            // Nothing to do during the build, see RetryBuildListener
        return true;
    }

    public BuildStepMonitor getRequiredMonitorService() {
        return BuildStepMonitor.BUILD;
    }
    
    @Override
    public DescriptorImpl getDescriptor() {
        // see Descriptor javadoc for more about what a descriptor is.
        return (DescriptorImpl) super.getDescriptor();
    }
    
    @Extension(optional = true)
    public final static RetryBuildListener LISTENER = new RetryBuildListener();
    
    /**
     * Descriptor for {@link RetryBuildPublisher}. Used as a singleton.
     * The class is marked as public so that it can be accessed from views.
     *
     * <p>
     * See <tt>views/hudson/plugins/naginator/NaginatorBuilder/*.jelly</tt>
     * for the actual HTML fragment for the configuration screen.
     */
    @Extension(optional = true)
    public static final class DescriptorImpl extends BuildStepDescriptor<Publisher> {
        
        public DescriptorImpl() {
            super(RetryBuildPublisher.class);
        }
        
        public String getDisplayName() {
            return "Retry build after failure (RetryBuild)";
        }
        
        
        @Override
        public boolean isApplicable(Class<? extends AbstractProject> jobType) {
            return true;
        }
        
        @Override
        public Notifier newInstance(StaplerRequest req, JSONObject formData) throws FormException {
            return req.bindJSON(RetryBuildPublisher.class, formData);
        }
    }
    
   
    private static final Logger LOGGER = Logger.getLogger(RetryBuildPublisher.class.getName());
    
}