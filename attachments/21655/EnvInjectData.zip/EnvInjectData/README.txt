I created a brand new "free stype project" called Alex_test.
It's set to build on a windows machine that does not have java 1.27.
It has java version 1.25.  The Jenkins Master, which is on a centos has java 1.27

The first time I built it, no plugins were selected.
This is build "1".  You'll see that the PATH is being tweaked, but JAVA_HOME is still set to 1.25.
It's strange that environment variables are being tweaked even though no plugin has been checked.

The second time I built it, I selected "Inject environment variables to the build process" and add to "Properties Content":
foo=bar
You'll see that PATH is still being tweaked, but JAVA_HOME has now been modified.

This is with Inject Plugin 1.35.

Note, for both builds, I've copied in the config.xml for you.

==================================================================
With Inject Plugin 1.38, something similar happened but with "multi-configuration projects", 
which is why we downgraded back to Inject Plugin 1.35.

The workaround is easy enough:
Use "Set environment variables through a file" and point it to a file on the Jenkins Master.
All of our builds were broken until we applied the workaround, which kinda sucked to modify so many jobs, but a least it's working now :)

Thank you for looking into this.  If you want us to try anything out, let me know.