//
//  testAppAppDelegate.h
//  testApp
//
//  Created by Mahesh on 25/04/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface testAppAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
	IBOutlet NSTextField *txtfield;
	IBOutlet NSButton *btn;
}

@property (assign) IBOutlet NSWindow *window;
@property (assign) IBOutlet NSTextField *txtfield;
@property (assign) IBOutlet NSButton *btn;

-(IBAction)close:(id)sender;

@end
