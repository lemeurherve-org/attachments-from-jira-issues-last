//
//  testAppAppDelegate.m
//  testApp
//
//  Created by Mahesh on 25/04/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "testAppAppDelegate.h"

@implementation testAppAppDelegate

@synthesize window;
@synthesize txtfield;
@synthesize btn;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
	NSDictionary *args = [[NSUserDefaults standardUserDefaults] volatileDomainForName:NSArgumentDomain];
	[txtfield setStringValue:[args objectForKey:@"s"]];
}

-(IBAction)close:(id)sender
{
	[NSApp terminate:sender];
}
@end
