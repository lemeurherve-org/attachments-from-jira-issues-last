package com.tupilabs.test.yahoonews;


import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.testng.annotations.Test;

@Test
public class YahooNewsTest {

    /**
     * Tests whether the menu for the news site is available or not.
     */
    public void testMenuIsPresent() {
        try {
            Document doc = Jsoup.connect("http://nz.news.yahoo.com/").followRedirects(true).timeout(3600).get();
            Elements elements = doc.select("div.top-nav");
            assertTrue(elements.size() > 0);
        } catch (IOException ioe) {
            fail("" + ioe.getMessage());
        }
    }
    
}
