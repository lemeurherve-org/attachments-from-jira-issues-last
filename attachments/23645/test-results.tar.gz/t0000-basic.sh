ok 1 - .git/objects should be empty after git init in an empty repo
ok 2 - .git/objects should have 3 subdirectories
ok 3 - success is reported like this
not ok 4 - pretend we have a known breakage # TODO known breakage
ok 5 - pretend we have fixed a known breakage (run in sub test-lib)
ok 6 - test runs if prerequisite is satisfied
ok 7 # skip unmet prerequisite causes test to be skipped (missing DONTHAVEIT)
ok 8 - test runs if prerequisites are satisfied
ok 9 # skip unmet prerequisites causes test to be skipped (missing DONTHAVEIT of HAVEIT,DONTHAVEIT)
ok 10 # skip unmet prerequisites causes test to be skipped (missing DONTHAVEIT of DONTHAVEIT,HAVEIT)
ok 11 - test runs if lazy prereq is satisfied
ok 12 # skip missing lazy prereqs skip tests (missing !LAZY_TRUE)
ok 13 - negative lazy prereqs checked
ok 14 # skip missing negative lazy prereqs will skip (missing LAZY_FALSE)
ok 15 - tests clean up after themselves
ok 16 - tests clean up even on failures
ok 17 - git update-index without --add should fail adding
ok 18 - git update-index with --add should succeed
ok 19 - writing tree out with git write-tree
ok 20 - validate object ID of a known tree
ok 21 - git update-index without --remove should fail removing
ok 22 - git update-index with --remove should be able to remove
ok 23 - git write-tree should be able to write an empty tree
ok 24 - validate object ID of a known tree
ok 25 - adding various types of objects with git update-index --add
ok 26 - showing stage with git ls-files --stage
ok 27 - validate git ls-files output for a known tree
ok 28 - writing tree out with git write-tree
ok 29 - validate object ID for a known tree
ok 30 - showing tree with git ls-tree
ok 31 # skip git ls-tree output for a known tree (missing SYMLINKS)
ok 32 - showing tree with git ls-tree -r
ok 33 - git ls-tree -r output for a known tree
ok 34 - showing tree with git ls-tree -r -t
ok 35 # skip git ls-tree -r output for a known tree (missing SYMLINKS)
ok 36 - writing partial tree out with git write-tree --prefix
ok 37 - validate object ID for a known tree
ok 38 - writing partial tree out with git write-tree --prefix
ok 39 - validate object ID for a known tree
ok 40 - put invalid objects into the index
ok 41 - writing this tree without --missing-ok
ok 42 - writing this tree with --missing-ok
ok 43 - git read-tree followed by write-tree should be idempotent
ok 44 - validate git diff-files output for a know cache/work tree state
ok 45 - git update-index --refresh should succeed
ok 46 - no diff after checkout and git update-index --refresh
ok 47 - git commit-tree records the correct tree in a commit
ok 48 - git commit-tree records the correct parent in a commit
ok 49 - git commit-tree omits duplicated parent in a commit
ok 50 - update-index D/F conflict
ok 51 - very long name in the index handled sanely
# still have 1 known breakage(s)
# passed all remaining 50 test(s)
1..51
