ok 1 - setup
ok 2 # skip write-tree should notice unwritable repository (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
ok 3 # skip commit should notice unwritable repository (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
ok 4 # skip update-index should notice unwritable repository (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
ok 5 # skip add should notice unwritable repository (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
# passed all 5 test(s)
1..5
