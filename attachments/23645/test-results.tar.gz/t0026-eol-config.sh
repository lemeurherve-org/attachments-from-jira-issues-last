ok 1 - setup
ok 2 - eol=lf puts LFs in normalized file
ok 3 - eol=crlf puts CRLFs in normalized file
ok 4 - autocrlf=true overrides eol=lf
ok 5 - autocrlf=true overrides unset eol
# passed all 5 test(s)
1..5
