ok 1 - normalize path:  => 
ok 2 - normalize path: . => 
ok 3 - normalize path: ./ => 
ok 4 - normalize path: ./. => 
ok 5 - normalize path: ./.. => ++failed++
ok 6 - normalize path: ../. => ++failed++
ok 7 - normalize path: ./../.// => ++failed++
ok 8 - normalize path: dir/.. => 
ok 9 - normalize path: dir/sub/../.. => 
ok 10 - normalize path: dir/sub/../../.. => ++failed++
ok 11 - normalize path: dir => dir
ok 12 - normalize path: dir// => dir/
ok 13 - normalize path: ./dir => dir
ok 14 - normalize path: dir/. => dir/
ok 15 - normalize path: dir///./ => dir/
ok 16 - normalize path: dir//sub/.. => dir/
ok 17 - normalize path: dir/sub/../ => dir/
ok 18 - normalize path: dir/sub/../. => dir/
ok 19 - normalize path: dir/s1/../s2/ => dir/s2/
ok 20 - normalize path: d1/s1///s2/..//../s3/ => d1/s3/
ok 21 - normalize path: d1/s1//../s2/../../d2 => d2
ok 22 - normalize path: d1/.../d2 => d1/.../d2
ok 23 - normalize path: d1/..././../d2 => d1/d2
ok 24 # skip normalize path: / => / (missing POSIX)
ok 25 # skip normalize path: // => / (missing POSIX)
ok 26 # skip normalize path: /// => / (missing POSIX)
ok 27 # skip normalize path: /. => / (missing POSIX)
ok 28 # skip normalize path: /./ => / (missing POSIX)
ok 29 # skip normalize path: /./.. => ++failed++ (missing POSIX)
ok 30 # skip normalize path: /../. => ++failed++ (missing POSIX)
ok 31 # skip normalize path: /./../.// => ++failed++ (missing POSIX)
ok 32 # skip normalize path: /dir/.. => / (missing POSIX)
ok 33 # skip normalize path: /dir/sub/../.. => / (missing POSIX)
ok 34 # skip normalize path: /dir/sub/../../.. => ++failed++ (missing POSIX)
ok 35 # skip normalize path: /dir => /dir (missing POSIX)
ok 36 # skip normalize path: /dir// => /dir/ (missing POSIX)
ok 37 # skip normalize path: /./dir => /dir (missing POSIX)
ok 38 # skip normalize path: /dir/. => /dir/ (missing POSIX)
ok 39 # skip normalize path: /dir///./ => /dir/ (missing POSIX)
ok 40 # skip normalize path: /dir//sub/.. => /dir/ (missing POSIX)
ok 41 # skip normalize path: /dir/sub/../ => /dir/ (missing POSIX)
ok 42 # skip normalize path: //dir/sub/../. => /dir/ (missing POSIX)
ok 43 # skip normalize path: /dir/s1/../s2/ => /dir/s2/ (missing POSIX)
ok 44 # skip normalize path: /d1/s1///s2/..//../s3/ => /d1/s3/ (missing POSIX)
ok 45 # skip normalize path: /d1/s1//../s2/../../d2 => /d2 (missing POSIX)
ok 46 # skip normalize path: /d1/.../d2 => /d1/.../d2 (missing POSIX)
ok 47 # skip normalize path: /d1/..././../d2 => /d1/d2 (missing POSIX)
ok 48 - longest ancestor: / / => -1
ok 49 - longest ancestor: /foo / => 63
ok 50 - longest ancestor: /foo /fo => -1
ok 51 - longest ancestor: /foo /foo => -1
ok 52 - longest ancestor: /foo /bar => -1
ok 53 - longest ancestor: /foo /foo/bar => -1
ok 54 - longest ancestor: /foo /foo:/bar => -1
ok 55 - longest ancestor: /foo /:/foo:/bar => 63
ok 56 - longest ancestor: /foo /foo:/:/bar => 63
ok 57 - longest ancestor: /foo /:/bar:/foo => 63
ok 58 - longest ancestor: /foo/bar / => 63
ok 59 - longest ancestor: /foo/bar /fo => -1
ok 60 - longest ancestor: /foo/bar /foo => 67
ok 61 - longest ancestor: /foo/bar /foo/ba => -1
ok 62 - longest ancestor: /foo/bar /:/fo => 63
ok 63 - longest ancestor: /foo/bar /foo:/foo/ba => 67
ok 64 - longest ancestor: /foo/bar /bar => -1
ok 65 - longest ancestor: /foo/bar /fo => -1
ok 66 - longest ancestor: /foo/bar /foo:/bar => 67
ok 67 - longest ancestor: /foo/bar /:/foo:/bar => 67
ok 68 - longest ancestor: /foo/bar /foo:/:/bar => 67
ok 69 - longest ancestor: /foo/bar /:/bar:/fo => 63
ok 70 - longest ancestor: /foo/bar /:/bar => 63
ok 71 - longest ancestor: /foo/bar /foo => 67
ok 72 - longest ancestor: /foo/bar /foo:/bar => 67
ok 73 - longest ancestor: /foo/bar /bar => -1
ok 74 - strip_path_suffix
ok 75 - absolute path rejects the empty string
ok 76 - real path rejects the empty string
ok 77 # skip real path works on absolute paths 1 (missing POSIX)
ok 78 - real path works on absolute paths 2
ok 79 # skip real path removes extra leading slashes (missing POSIX)
ok 80 - real path removes other extra slashes
ok 81 # skip real path works on symlinks (missing SYMLINKS)
# passed all 81 test(s)
1..81
