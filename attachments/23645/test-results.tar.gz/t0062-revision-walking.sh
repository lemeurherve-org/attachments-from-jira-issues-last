ok 1 - setup
ok 2 - revision walking can be done twice
# passed all 2 test(s)
1..2
