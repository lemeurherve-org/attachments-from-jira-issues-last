ok 1 - split foo:bar:baz at :, max -1
ok 2 - split foo:bar:baz at :, max 0
ok 3 - split foo:bar:baz at :, max 1
ok 4 - split foo:bar:baz at :, max 2
ok 5 - split foo:bar: at :, max -1
ok 6 - split  at :, max -1
ok 7 - split : at :, max -1
ok 8 - test filter_string_list
ok 9 - test remove_duplicates
# passed all 9 test(s)
1..9
