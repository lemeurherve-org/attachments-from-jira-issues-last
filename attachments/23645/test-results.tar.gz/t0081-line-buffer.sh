ok 1 - hello world
ok 2 - 0-length read, send along greeting
ok 3 # skip read from file descriptor (missing NOT_MINGW)
ok 4 - skip, copy null byte
ok 5 - read null byte
ok 6 - long reads are truncated
ok 7 - long copies are truncated
ok 8 - long binary reads are truncated
# passed all 8 test(s)
1..8
