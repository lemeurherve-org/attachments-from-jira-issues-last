1..0 # SKIP skipping credential-cache tests, unix sockets not available
