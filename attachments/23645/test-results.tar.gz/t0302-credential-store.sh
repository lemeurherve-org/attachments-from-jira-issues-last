ok 1 - helper (store) has no existing data
ok 2 - helper (store) stores password
ok 3 - helper (store) can retrieve password
ok 4 - helper (store) requires matching protocol
ok 5 - helper (store) requires matching host
ok 6 - helper (store) requires matching username
ok 7 - helper (store) requires matching path
ok 8 - helper (store) can forget host
ok 9 - helper (store) can store multiple users
ok 10 - helper (store) can forget user
ok 11 - helper (store) remembers other user
# passed all 11 test(s)
1..11
