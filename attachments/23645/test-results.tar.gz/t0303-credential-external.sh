1..0 # SKIP used to test external credential helpers
