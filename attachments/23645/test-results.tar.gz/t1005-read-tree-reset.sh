ok 1 - setup
ok 2 - reset should work
ok 3 - reset should remove remnants from a failed merge
ok 4 - Porcelain reset should remove remnants too
ok 5 - Porcelain checkout -f should remove remnants too
ok 6 - Porcelain checkout -f HEAD should remove remnants too
# passed all 6 test(s)
1..6
