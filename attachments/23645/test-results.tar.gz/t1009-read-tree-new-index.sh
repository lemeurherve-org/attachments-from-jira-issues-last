ok 1 - setup
ok 2 - non-existent index file
ok 3 - empty index file
# passed all 3 test(s)
1..3
