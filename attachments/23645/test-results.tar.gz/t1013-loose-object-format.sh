ok 1 - setup
ok 2 - read standard-format loose objects
ok 3 - read experimental-format loose objects
ok 4 - read standard-format objects deflated with smaller window buffer
# passed all 4 test(s)
1..4
