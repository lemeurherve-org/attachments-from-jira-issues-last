ok 1 - setup
ok 2 - add a large file or two
ok 3 - checkout a large file
ok 4 - packsize limit
ok 5 - diff --raw
ok 6 - hash-object
ok 7 - cat-file a large file
ok 8 - cat-file a large file from a tag
ok 9 - git-show a large file
ok 10 - index-pack
ok 11 - repack
ok 12 - pack-objects with large loose object
ok 13 - tar achiving
ok 14 - zip achiving, store only
ok 15 - zip achiving, deflate
# passed all 15 test(s)
1..15
