ok 1 - setup input tests
ok 2 - autocrlf=true converts on input
ok 3 - eol=crlf converts on input
ok 4 - ident converts on input
ok 5 - user-defined filters convert on input
ok 6 - setup output tests
ok 7 - autocrlf=true converts on output
ok 8 - eol=crlf converts on output
ok 9 - user-defined filters convert on output
ok 10 - ident converts on output
# passed all 10 test(s)
1..10
