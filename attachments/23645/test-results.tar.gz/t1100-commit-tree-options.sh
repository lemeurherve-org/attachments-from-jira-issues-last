ok 1 - test preparation: write empty tree
ok 2 - construct commit
ok 3 - read commit
ok 4 - compare commit
ok 5 - flags and then non flags
# passed all 5 test(s)
1..5
