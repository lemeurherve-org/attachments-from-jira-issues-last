ok 1 - clear default config
ok 2 - initial
ok 3 - mixed case
ok 4 - similar section
ok 5 - uppercase section
ok 6 - replace with non-match
ok 7 - replace with non-match (actually matching)
ok 8 - non-match result
ok 9 - find mixed-case key by canonical name
ok 10 - find mixed-case key by non-canonical name
ok 11 - subsections are not canonicalized by git-config
ok 12 - unset with cont. lines
ok 13 - unset with cont. lines is correct
ok 14 - multiple unset
ok 15 - multiple unset is correct
ok 16 - --replace-all missing value
ok 17 - --replace-all
ok 18 - all replaced
ok 19 - really mean test
ok 20 - really really mean test
ok 21 - get value
ok 22 - unset
ok 23 - multivar
ok 24 - non-match
ok 25 - non-match value
ok 26 - multi-valued get returns final one
ok 27 - multi-valued get-all returns all
ok 28 - multivar replace
ok 29 - ambiguous unset
ok 30 - invalid unset
ok 31 - multivar unset
ok 32 - invalid key
ok 33 - correct key
ok 34 - hierarchical section
ok 35 - hierarchical section value
ok 36 - working --list
ok 37 - --list without repo produces empty output
ok 38 - --get-regexp
ok 39 - --add
ok 40 - get variable with no value
ok 41 - get variable with empty value
ok 42 - get-regexp variable with no value
ok 43 - get-regexp --bool variable with no value
ok 44 - get-regexp variable with empty value
ok 45 - get bool variable with no value
ok 46 - get bool variable with empty value
ok 47 - no arguments, but no crash
ok 48 - new section is partial match of another
ok 49 - new variable inserts into proper section
ok 50 - alternative GIT_CONFIG (non-existing file should fail)
ok 51 - alternative GIT_CONFIG
ok 52 - alternative GIT_CONFIG (--file)
ok 53 - refer config from subdirectory
ok 54 - refer config from subdirectory via GIT_CONFIG
ok 55 - --set in alternative GIT_CONFIG
ok 56 - rename section
ok 57 - rename succeeded
ok 58 - rename non-existing section
ok 59 - rename succeeded
ok 60 - rename another section
ok 61 - rename succeeded
ok 62 - rename a section with a var on the same line
ok 63 - rename succeeded
ok 64 - renaming empty section name is rejected
ok 65 - renaming to bogus section is rejected
ok 66 - remove section
ok 67 - section was removed properly
ok 68 - section ending
ok 69 - numbers
ok 70 - invalid unit
ok 71 - bool
ok 72 - invalid bool (--get)
ok 73 - invalid bool (set)
ok 74 - set --bool
ok 75 - set --int
ok 76 - get --bool-or-int
ok 77 - set --bool-or-int
ok 78 # skip set --path (missing NOT_MINGW)
ok 79 # skip get --path (missing HOMEVAR)
ok 80 # skip get --path copes with unset $HOME (missing NOT_MINGW)
ok 81 - get --path barfs on boolean variable
ok 82 - quoting
ok 83 - key with newline
ok 84 - value with newline
ok 85 - value continued on next line
ok 86 - --null --list
ok 87 - --null --get-regexp
ok 88 - inner whitespace kept verbatim
ok 89 # skip symlinked configuration (missing SYMLINKS)
ok 90 - nonexistent configuration
ok 91 # skip symlink to nonexistent configuration (missing SYMLINKS)
ok 92 - check split_cmdline return
ok 93 - git -c "key=value" support
ok 94 - key sanity-checking
ok 95 - git -c works with aliases of builtins
ok 96 - git -c does not split values on equals
ok 97 - git -c dies on bogus config
ok 98 - git -c complains about empty key
ok 99 - git -c complains about empty key and value
ok 100 - git config --edit works
ok 101 - git config --edit respects core.editor
ok 102 - barf on syntax error
ok 103 - barf on incomplete section header
ok 104 - barf on incomplete string
# passed all 104 test(s)
1..104
