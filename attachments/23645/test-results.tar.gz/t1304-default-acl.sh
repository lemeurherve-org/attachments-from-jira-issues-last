ok 1 - checking for a working acl setup
ok 2 # skip Setup test repo (missing SETFACL)
ok 3 # skip Objects creation does not break ACLs with restrictive umask (missing SETFACL)
ok 4 # skip git gc does not break ACLs with restrictive umask (missing SETFACL)
# passed all 4 test(s)
1..4
