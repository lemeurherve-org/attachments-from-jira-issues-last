ok 1 - ref name '' is invalid
ok 2 # skip ref name '/' is invalid (missing NOT_MINGW)
ok 3 # skip ref name '/' is invalid with options --allow-onelevel (missing NOT_MINGW)
ok 4 # skip ref name '/' is invalid with options --normalize (missing NOT_MINGW)
ok 5 # skip ref name '/' is invalid with options --allow-onelevel --normalize (missing NOT_MINGW)
ok 6 - ref name 'foo/bar/baz' is valid
ok 7 - ref name 'foo/bar/baz' is valid with options --normalize
ok 8 - ref name 'refs///heads/foo' is invalid
ok 9 - ref name 'refs///heads/foo' is valid with options --normalize
ok 10 - ref name 'heads/foo/' is invalid
ok 11 # skip ref name '/heads/foo' is invalid (missing NOT_MINGW)
ok 12 # skip ref name '/heads/foo' is valid with options --normalize (missing NOT_MINGW)
ok 13 - ref name '///heads/foo' is invalid
ok 14 - ref name '///heads/foo' is valid with options --normalize
ok 15 - ref name './foo' is invalid
ok 16 - ref name './foo/bar' is invalid
ok 17 - ref name 'foo/./bar' is invalid
ok 18 - ref name 'foo/bar/.' is invalid
ok 19 - ref name '.refs/foo' is invalid
ok 20 - ref name 'heads/foo..bar' is invalid
ok 21 - ref name 'heads/foo?bar' is invalid
ok 22 - ref name 'foo./bar' is valid
ok 23 - ref name 'heads/foo.lock' is invalid
ok 24 - ref name 'heads///foo.lock' is invalid
ok 25 - ref name 'foo.lock/bar' is invalid
ok 26 - ref name 'foo.lock///bar' is invalid
ok 27 - ref name 'heads/foo@bar' is valid
ok 28 - ref name 'heads/v@{ation' is invalid
ok 29 - ref name 'heads/foo\bar' is invalid
ok 30 - ref name 'heads/foo	' is invalid
ok 31 - ref name 'heads/foo' is invalid
ok 32 - ref name 'heads/fuß' is valid
ok 33 - ref name 'heads/*foo/bar' is invalid with options --refspec-pattern
ok 34 - ref name 'heads/foo*/bar' is invalid with options --refspec-pattern
ok 35 - ref name 'heads/f*o/bar' is invalid with options --refspec-pattern
ok 36 - ref name 'foo' is invalid
ok 37 - ref name 'foo' is valid with options --allow-onelevel
ok 38 - ref name 'foo' is invalid with options --refspec-pattern
ok 39 - ref name 'foo' is valid with options --refspec-pattern --allow-onelevel
ok 40 - ref name 'foo' is invalid with options --normalize
ok 41 - ref name 'foo' is valid with options --allow-onelevel --normalize
ok 42 - ref name 'foo/bar' is valid
ok 43 - ref name 'foo/bar' is valid with options --allow-onelevel
ok 44 - ref name 'foo/bar' is valid with options --refspec-pattern
ok 45 - ref name 'foo/bar' is valid with options --refspec-pattern --allow-onelevel
ok 46 - ref name 'foo/bar' is valid with options --normalize
ok 47 - ref name 'foo/*' is invalid
ok 48 - ref name 'foo/*' is invalid with options --allow-onelevel
ok 49 - ref name 'foo/*' is valid with options --refspec-pattern
ok 50 - ref name 'foo/*' is valid with options --refspec-pattern --allow-onelevel
ok 51 - ref name '*/foo' is invalid
ok 52 - ref name '*/foo' is invalid with options --allow-onelevel
ok 53 - ref name '*/foo' is valid with options --refspec-pattern
ok 54 - ref name '*/foo' is valid with options --refspec-pattern --allow-onelevel
ok 55 - ref name '*/foo' is invalid with options --normalize
ok 56 - ref name '*/foo' is valid with options --refspec-pattern --normalize
ok 57 - ref name 'foo/*/bar' is invalid
ok 58 - ref name 'foo/*/bar' is invalid with options --allow-onelevel
ok 59 - ref name 'foo/*/bar' is valid with options --refspec-pattern
ok 60 - ref name 'foo/*/bar' is valid with options --refspec-pattern --allow-onelevel
ok 61 - ref name '*' is invalid
ok 62 - ref name '*' is invalid with options --allow-onelevel
ok 63 - ref name '*' is invalid with options --refspec-pattern
ok 64 - ref name '*' is valid with options --refspec-pattern --allow-onelevel
ok 65 - ref name 'foo/*/*' is invalid with options --refspec-pattern
ok 66 - ref name 'foo/*/*' is invalid with options --refspec-pattern --allow-onelevel
ok 67 - ref name '*/foo/*' is invalid with options --refspec-pattern
ok 68 - ref name '*/foo/*' is invalid with options --refspec-pattern --allow-onelevel
ok 69 - ref name '*/*/foo' is invalid with options --refspec-pattern
ok 70 - ref name '*/*/foo' is invalid with options --refspec-pattern --allow-onelevel
ok 71 # skip ref name '/foo' is invalid (missing NOT_MINGW)
ok 72 # skip ref name '/foo' is invalid with options --allow-onelevel (missing NOT_MINGW)
ok 73 # skip ref name '/foo' is invalid with options --refspec-pattern (missing NOT_MINGW)
ok 74 # skip ref name '/foo' is invalid with options --refspec-pattern --allow-onelevel (missing NOT_MINGW)
ok 75 # skip ref name '/foo' is invalid with options --normalize (missing NOT_MINGW)
ok 76 # skip ref name '/foo' is valid with options --allow-onelevel --normalize (missing NOT_MINGW)
ok 77 # skip ref name '/foo' is invalid with options --refspec-pattern --normalize (missing NOT_MINGW)
ok 78 # skip ref name '/foo' is valid with options --refspec-pattern --allow-onelevel --normalize (missing NOT_MINGW)
ok 79 - check-ref-format --branch @{-1}
ok 80 - check-ref-format --branch from subdir
ok 81 - ref name 'heads/foo' simplifies to 'heads/foo'
ok 82 - ref name 'refs///heads/foo' simplifies to 'refs/heads/foo'
ok 83 # skip ref name '/heads/foo' simplifies to 'heads/foo' (missing NOT_MINGW)
ok 84 - ref name '///heads/foo' simplifies to 'heads/foo'
ok 85 - check-ref-format --normalize rejects 'foo'
ok 86 # skip check-ref-format --normalize rejects '/foo' (missing NOT_MINGW)
ok 87 - check-ref-format --normalize rejects 'heads/foo/../bar'
ok 88 - check-ref-format --normalize rejects 'heads/./foo'
ok 89 - check-ref-format --normalize rejects 'heads\foo'
ok 90 - check-ref-format --normalize rejects 'heads/foo.lock'
ok 91 - check-ref-format --normalize rejects 'heads///foo.lock'
ok 92 - check-ref-format --normalize rejects 'foo.lock/bar'
ok 93 - check-ref-format --normalize rejects 'foo.lock///bar'
# passed all 93 test(s)
1..93
