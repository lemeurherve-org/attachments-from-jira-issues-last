ok 1 - setup
ok 2 - log -g shows reflog headers
ok 3 - oneline reflog format
ok 4 - reflog default format
ok 5 - override reflog default format
ok 6 - using @{now} syntax shows reflog date (multiline)
ok 7 - using @{now} syntax shows reflog date (oneline)
ok 8 - using @{now} syntax shows reflog date (format=%gd)
ok 9 - using --date= shows reflog date (multiline)
ok 10 - using --date= shows reflog date (oneline)
ok 11 - using --date= shows reflog date (format=%gd)
ok 12 - log.date does not invoke "--date" magic (multiline)
ok 13 - log.date does not invoke "--date" magic (oneline)
ok 14 - log.date does not invoke "--date" magic (format=%gd)
ok 15 - --date magic does not override explicit @{0} syntax
ok 16 - empty reflog file
# passed all 16 test(s)
1..16
