ok 1 - toplevel: is-bare-repository
ok 2 - toplevel: is-inside-git-dir
ok 3 - toplevel: is-inside-work-tree
ok 4 - toplevel: prefix
ok 5 - toplevel: git-dir
ok 6 - .git/: is-bare-repository
ok 7 - .git/: is-inside-git-dir
ok 8 - .git/: is-inside-work-tree
ok 9 - .git/: prefix
ok 10 - .git/: git-dir
ok 11 - .git/objects/: is-bare-repository
ok 12 - .git/objects/: is-inside-git-dir
ok 13 - .git/objects/: is-inside-work-tree
ok 14 - .git/objects/: prefix
ok 15 - .git/objects/: git-dir
ok 16 - subdirectory: is-bare-repository
ok 17 - subdirectory: is-inside-git-dir
ok 18 - subdirectory: is-inside-work-tree
ok 19 - subdirectory: prefix
ok 20 - subdirectory: git-dir
ok 21 - core.bare = true: is-bare-repository
ok 22 - core.bare = true: is-inside-git-dir
ok 23 - core.bare = true: is-inside-work-tree
ok 24 - core.bare undefined: is-bare-repository
ok 25 - core.bare undefined: is-inside-git-dir
ok 26 - core.bare undefined: is-inside-work-tree
ok 27 - GIT_DIR=../.git, core.bare = false: is-bare-repository
ok 28 - GIT_DIR=../.git, core.bare = false: is-inside-git-dir
ok 29 - GIT_DIR=../.git, core.bare = false: is-inside-work-tree
ok 30 - GIT_DIR=../.git, core.bare = false: prefix
ok 31 - GIT_DIR=../.git, core.bare = true: is-bare-repository
ok 32 - GIT_DIR=../.git, core.bare = true: is-inside-git-dir
ok 33 - GIT_DIR=../.git, core.bare = true: is-inside-work-tree
ok 34 - GIT_DIR=../.git, core.bare = true: prefix
ok 35 - GIT_DIR=../.git, core.bare undefined: is-bare-repository
ok 36 - GIT_DIR=../.git, core.bare undefined: is-inside-git-dir
ok 37 - GIT_DIR=../.git, core.bare undefined: is-inside-work-tree
ok 38 - GIT_DIR=../.git, core.bare undefined: prefix
ok 39 - GIT_DIR=../repo.git, core.bare = false: is-bare-repository
ok 40 - GIT_DIR=../repo.git, core.bare = false: is-inside-git-dir
ok 41 - GIT_DIR=../repo.git, core.bare = false: is-inside-work-tree
ok 42 - GIT_DIR=../repo.git, core.bare = false: prefix
ok 43 - GIT_DIR=../repo.git, core.bare = true: is-bare-repository
ok 44 - GIT_DIR=../repo.git, core.bare = true: is-inside-git-dir
ok 45 - GIT_DIR=../repo.git, core.bare = true: is-inside-work-tree
ok 46 - GIT_DIR=../repo.git, core.bare = true: prefix
ok 47 - GIT_DIR=../repo.git, core.bare undefined: is-bare-repository
ok 48 - GIT_DIR=../repo.git, core.bare undefined: is-inside-git-dir
ok 49 - GIT_DIR=../repo.git, core.bare undefined: is-inside-work-tree
ok 50 - GIT_DIR=../repo.git, core.bare undefined: prefix
# passed all 50 test(s)
1..50
