ok 1 - setup
ok 2 - @{upstream} resolves to correct full name
ok 3 - @{u} resolves to correct full name
ok 4 - my-side@{upstream} resolves to correct full name
ok 5 - my-side@{u} resolves to correct commit
ok 6 - not-tracking@{u} fails
ok 7 - <branch>@{u}@{1} resolves correctly
ok 8 - @{u} without specifying branch fails on a detached HEAD
ok 9 - checkout -b new my-side@{u} forks from the same
ok 10 - merge my-side@{u} records the correct name
ok 11 - branch -d other@{u}
ok 12 - checkout other@{u}
ok 13 - branch@{u} works when tracking a local branch
ok 14 - branch@{u} error message when no upstream
ok 15 - @{u} error message when no upstream
ok 16 - branch@{u} error message with misspelt branch
ok 17 - @{u} error message when not on a branch
ok 18 - branch@{u} error message if upstream branch not fetched
ok 19 - pull works when tracking a local branch
ok 20 - @{u} works when tracking a local branch
ok 21 - log -g other@{u}
ok 22 - log -g other@{u}@{now}
# passed all 22 test(s)
1..22
