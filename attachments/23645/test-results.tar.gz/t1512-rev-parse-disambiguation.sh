ok 1 - blob and tree
ok 2 - warn ambiguity when no candidate matches type hint
ok 3 - disambiguate tree-ish
ok 4 - disambiguate blob
ok 5 - disambiguate tree
ok 6 - first commit
ok 7 - disambiguate commit-ish
ok 8 - disambiguate commit
ok 9 - log name1..name2 takes only commit-ishes on both ends
ok 10 - rev-parse name1..name2 takes only commit-ishes on both ends
ok 11 - git log takes only commit-ish
ok 12 - git reset takes only commit-ish
ok 13 - first tag
not ok 14 - two semi-ambiguous commit-ish # TODO known breakage
not ok 15 - three semi-ambiguous tree-ish # TODO known breakage
ok 16 - parse describe name
ok 17 - more history
not ok 18 - parse describe name taking advantage of generation # TODO known breakage
ok 19 - parse describe name not ignoring ambiguity
ok 20 - ambiguous commit-ish
ok 21 - rev-parse --disambiguate
# still have 3 known breakage(s)
# passed all remaining 18 test(s)
1..21
