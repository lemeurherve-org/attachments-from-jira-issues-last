ok 1 # skip setup (missing SYMLINKS)
ok 2 # skip switch from symlink to dir (missing SYMLINKS)
ok 3 # skip Remove temporary directories & switch to master (missing SYMLINKS)
ok 4 # skip switch from dir to symlink (missing SYMLINKS)
# passed all 4 test(s)
1..4
