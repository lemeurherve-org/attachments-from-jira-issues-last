ok 1 - setup
ok 2 - branch switching
ok 3 - path checkout
# passed all 3 test(s)
1..3
