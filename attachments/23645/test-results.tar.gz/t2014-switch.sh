ok 1 - setup
ok 2 - check all changes are staged
ok 3 - second commit
ok 4 - check
# passed all 4 test(s)
1..4
