ok 1 - setup
ok 2 - checkout from unborn preserves untracked files
ok 3 - checkout from unborn preserves index contents
ok 4 - checkout from unborn merges identical index contents
ok 5 - checking out another branch from unborn state
ok 6 - checking out in a newly created repo
# passed all 6 test(s)
1..6
