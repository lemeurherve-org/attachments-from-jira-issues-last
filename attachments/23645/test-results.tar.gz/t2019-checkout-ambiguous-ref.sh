ok 1 - setup ambiguous refs
ok 2 - checkout ambiguous ref succeeds
ok 3 - checkout produces ambiguity warning
ok 4 - checkout chooses branch over tag
ok 5 - checkout reports switch to branch
ok 6 - checkout vague ref succeeds
ok 7 - checkout produces ambiguity warning
ok 8 - checkout chooses branch over tag
ok 9 - checkout reports switch to branch
# passed all 9 test(s)
1..9
