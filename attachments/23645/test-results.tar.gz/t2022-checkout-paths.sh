ok 1 - setup
ok 2 - checking out paths out of a tree does not clobber unrelated paths
# passed all 2 test(s)
1..2
