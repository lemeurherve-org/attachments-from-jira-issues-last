ok 1 - setup
ok 2 - add records switch clears
ok 3 - rm records reset clears
ok 4 - plumbing clears
ok 5 - add records checkout -m undoes
ok 6 - unmerge with plumbing
ok 7 - rerere and rerere forget
ok 8 - rerere and rerere forget (subdirectory)
# passed all 8 test(s)
1..8
