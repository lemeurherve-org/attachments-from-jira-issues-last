ok 1 - update-index --nonsense fails
ok 2 - update-index --nonsense dumps usage
ok 3 - update-index -h with corrupt index
ok 4 - --cacheinfo does not accept blob null sha1
ok 5 - --cacheinfo does not accept gitlink null sha1
# passed all 5 test(s)
1..5
