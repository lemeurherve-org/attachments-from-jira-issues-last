ok 1 - setup
ok 2 - modify
ok 3 - diff-files
ok 4 - diff-index
ok 5 - add -u
ok 6 - commit -a
# passed all 6 test(s)
1..6
