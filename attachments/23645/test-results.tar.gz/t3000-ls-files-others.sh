ok 1 - setup 
ok 2 - setup: expected output
ok 3 - ls-files --others
ok 4 - ls-files --others --directory
ok 5 - --no-empty-directory hides empty directory
ok 6 # skip ls-files --others with symlinked submodule (missing SYMLINKS)
# passed all 6 test(s)
1..6
