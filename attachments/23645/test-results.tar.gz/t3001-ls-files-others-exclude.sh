ok 1 - git ls-files --others with various exclude options.
ok 2 - git ls-files --others with \r\n line endings.
ok 3 - setup skip-worktree gitignore
ok 4 - git ls-files --others with various exclude options.
ok 5 - restore gitignore
ok 6 - git status honors core.excludesfile
ok 7 - trailing slash in exclude allows directory match(1)
ok 8 - trailing slash in exclude allows directory match (2)
ok 9 - trailing slash in exclude forces directory match (1)
ok 10 - trailing slash in exclude forces directory match (2)
ok 11 - negated exclude matches can override previous ones
ok 12 - subdirectory ignore (setup)
ok 13 - subdirectory ignore (toplevel)
ok 14 - subdirectory ignore (l1/l2)
ok 15 - subdirectory ignore (l1)
ok 16 - pattern matches prefix completely
# passed all 16 test(s)
1..16
