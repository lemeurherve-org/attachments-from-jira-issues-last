ok 1 - prepare
ok 2 - ls-files with mixed levels
ok 3 - ls-files -c
ok 4 - ls-files -o
# passed all 4 test(s)
1..4
