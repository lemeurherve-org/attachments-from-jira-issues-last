ok 1 - setup repo with criss-cross history
ok 2 - recursive merge between F and G, causes segfault
# passed all 2 test(s)
1..2
