ok 1 - setup
ok 2 - naive merge fails
ok 3 - --ignore-space-change makes merge succeed
ok 4 - naive cherry-pick fails
ok 5 - -Xignore-space-change makes cherry-pick succeed
ok 6 - --ignore-space-change: our w/s-only change wins
ok 7 - --ignore-space-change: their real change wins over w/s
ok 8 - --ignore-space-change: does not ignore new spaces
ok 9 - --ignore-all-space drops their new spaces
ok 10 - --ignore-all-space keeps our new spaces
ok 11 - --ignore-space-at-eol
# passed all 11 test(s)
1..11
