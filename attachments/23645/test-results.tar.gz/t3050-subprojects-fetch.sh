ok 1 - setup
ok 2 - clone
ok 3 - advance
ok 4 - fetch
# passed all 4 test(s)
1..4
