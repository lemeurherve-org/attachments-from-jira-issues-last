ok 1 # skip setup (missing NOT_MINGW)
ok 2 # skip ls-tree a* matches literally (missing NOT_MINGW)
# passed all 2 test(s)
1..2
