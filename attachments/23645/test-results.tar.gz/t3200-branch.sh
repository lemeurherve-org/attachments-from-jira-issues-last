ok 1 - prepare a trivial repository
ok 2 - git branch --help should not have created a bogus branch
ok 3 - branch -h in broken repository
ok 4 - git branch abc should create a branch
ok 5 - git branch a/b/c should create a branch
ok 6 - git branch -l d/e/f should create a branch and a log
ok 7 - git branch -d d/e/f should delete a branch and a log
ok 8 - git branch j/k should work after branch j has been deleted
ok 9 - git branch l should work after branch l/m has been deleted
ok 10 - git branch -m dumps usage
ok 11 - git branch -m m m/m should work
ok 12 - git branch -m n/n n should work
ok 13 - git branch -m o/o o should fail when o/p exists
ok 14 - git branch -m q r/q should fail when r exists
ok 15 - git branch -M foo bar should fail when bar is checked out
ok 16 - git branch -M baz bam should succeed when baz is checked out
ok 17 - git branch -M master should work when master is checked out
ok 18 - git branch -M master master should work when master is checked out
ok 19 - git branch -M master2 master2 should work when master is checked out
ok 20 - git branch -v -d t should work
ok 21 - git branch -v -m t s should work
ok 22 - git branch -m -d t s should fail
ok 23 - git branch --list -d t should fail
ok 24 - git branch --column
not ok - 25 git branch --column with an extremely long branch name
#	
#		long=this/is/a/part/of/long/branch/name &&
#		long=z$long/$long/$long/$long &&
#		test_when_finished "git branch -d $long" &&
#		git branch $long &&
#		COLUMNS=80 git branch --column=column >actual &&
#		cat >expected <<EOF &&
#	  a/b/c
#	  abc
#	  bam
#	  bar
#	  foo
#	  j/k
#	  l
#	  m/m
#	* master
#	  master2
#	  n
#	  o/o
#	  o/p
#	  q
#	  r
#	  $long
#	EOF
#		test_cmp expected actual
#	
ok 26 - git branch with column.*
ok 27 - git branch --column -v should fail
ok 28 - git branch -v with column.ui ignored
ok 29 - git branch -m q q2 without config should succeed
ok 30 - git branch -m s/s s should work when s/t is deleted
ok 31 - config information was renamed, too
ok 32 - deleting a symref
ok 33 - deleting a dangling symref
ok 34 - renaming a symref is not allowed
ok 35 # skip git branch -m u v should fail when the reflog for u is a symlink (missing SYMLINKS)
ok 36 - test tracking setup via --track
ok 37 - test tracking setup (non-wildcard, matching)
ok 38 - test tracking setup (non-wildcard, not matching)
ok 39 - test tracking setup via config
ok 40 - test overriding tracking setup via --no-track
ok 41 - no tracking without .fetch entries
ok 42 - test tracking setup via --track but deeper
ok 43 - test deleting branch deletes branch config
ok 44 - test deleting branch without config
ok 45 - test --track without .fetch entries
ok 46 - branch from non-branch HEAD w/autosetupmerge=always
ok 47 - branch from non-branch HEAD w/--track causes failure
ok 48 - branch from tag w/--track causes failure
ok 49 - use --set-upstream-to modify HEAD
ok 50 - use --set-upstream-to modify a particular branch
ok 51 - --unset-upstream should fail if given a non-existent branch
ok 52 - test --unset-upstream on HEAD
ok 53 - test --unset-upstream on a particular branch
ok 54 - --set-upstream shows message when creating a new branch that exists as remote-tracking
ok 55 - --set-upstream with two args only shows the deprecation message
ok 56 - --set-upstream with one arg only shows the deprecation message if the branch existed
ok 57 - git checkout -b g/h/i -l should create a branch and a log
ok 58 - checkout -b makes reflog by default
ok 59 - checkout -b does not make reflog when core.logAllRefUpdates = false
ok 60 - checkout -b with -l makes reflog when core.logAllRefUpdates = false
ok 61 - avoid ambiguous track
ok 62 - autosetuprebase local on a tracked local branch
ok 63 - autosetuprebase always on a tracked local branch
ok 64 - autosetuprebase remote on a tracked local branch
ok 65 - autosetuprebase never on a tracked local branch
ok 66 - autosetuprebase local on a tracked remote branch
ok 67 - autosetuprebase never on a tracked remote branch
ok 68 - autosetuprebase remote on a tracked remote branch
ok 69 - autosetuprebase always on a tracked remote branch
ok 70 - autosetuprebase unconfigured on a tracked remote branch
ok 71 - autosetuprebase unconfigured on a tracked local branch
ok 72 - autosetuprebase unconfigured on untracked local branch
ok 73 - autosetuprebase unconfigured on untracked remote branch
ok 74 - autosetuprebase never on an untracked local branch
ok 75 - autosetuprebase local on an untracked local branch
ok 76 - autosetuprebase remote on an untracked local branch
ok 77 - autosetuprebase always on an untracked local branch
ok 78 - autosetuprebase never on an untracked remote branch
ok 79 - autosetuprebase local on an untracked remote branch
ok 80 - autosetuprebase remote on an untracked remote branch
ok 81 - autosetuprebase always on an untracked remote branch
ok 82 - autosetuprebase always on detached HEAD
ok 83 - detect misconfigured autosetuprebase (bad value)
ok 84 - detect misconfigured autosetuprebase (no value)
ok 85 - attempt to delete a branch without base and unmerged to HEAD
ok 86 - attempt to delete a branch merged to its base
ok 87 - attempt to delete a branch merged to its base
ok 88 - use set-upstream on the current branch
ok 89 - use --edit-description
ok 90 - detect typo in branch name when using --edit-description
ok 91 - refuse --edit-description on unborn branch for now
ok 92 - --merged catches invalid object names
# failed 1 among 92 test(s)
1..92
