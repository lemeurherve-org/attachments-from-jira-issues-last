ok 1 - setup / mkdir
ok 2 - setup 10
ok 3 - notes work
ok 4 # skip notes timing with /usr/bin/time (missing USR_BIN_TIME of USR_BIN_TIME,NOT_EXPENSIVE)
ok 5 - teardown / cd ..
ok 6 # skip setup / mkdir (missing EXPENSIVE)
ok 7 # skip setup 100 (missing EXPENSIVE)
ok 8 # skip notes work (missing EXPENSIVE)
ok 9 # skip notes timing with /usr/bin/time (missing EXPENSIVE,USR_BIN_TIME of USR_BIN_TIME,EXPENSIVE)
ok 10 # skip teardown / cd .. (missing EXPENSIVE)
ok 11 # skip setup / mkdir (missing EXPENSIVE)
ok 12 # skip setup 1000 (missing EXPENSIVE)
ok 13 # skip notes work (missing EXPENSIVE)
ok 14 # skip notes timing with /usr/bin/time (missing EXPENSIVE,USR_BIN_TIME of USR_BIN_TIME,EXPENSIVE)
ok 15 # skip teardown / cd .. (missing EXPENSIVE)
ok 16 # skip setup / mkdir (missing EXPENSIVE)
ok 17 # skip setup 10000 (missing EXPENSIVE)
ok 18 # skip notes work (missing EXPENSIVE)
ok 19 # skip notes timing with /usr/bin/time (missing EXPENSIVE,USR_BIN_TIME of USR_BIN_TIME,EXPENSIVE)
ok 20 # skip teardown / cd .. (missing EXPENSIVE)
# passed all 20 test(s)
1..20
