ok 1 - prepare repository with topic branch
ok 2 - pick top patch from topic branch into master
ok 3 - rebase topic branch against new master and check git am did not get halted
ok 4 - rebase --merge topic branch that was partially merged upstream
ok 5 - rebase ignores empty commit
ok 6 - rebase --keep-empty
ok 7 - rebase --keep-empty keeps empty even if already in upstream
# passed all 7 test(s)
1..7
