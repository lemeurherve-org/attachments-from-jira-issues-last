ok 1 - setup
ok 2 - rebase commit with multi-line subject
ok 3 - rebase commit with diff in message
# passed all 3 test(s)
1..3
