ok 1 - setup
ok 2 - skip same-resolution merges with -p
ok 3 - keep different-resolution merges with -p
# passed all 3 test(s)
1..3
