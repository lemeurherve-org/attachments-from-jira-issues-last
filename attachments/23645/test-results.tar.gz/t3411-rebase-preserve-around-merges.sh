ok 1 - setup
ok 2 - squash F1 into D1
ok 3 - rebase two levels of merge
# passed all 3 test(s)
1..3
