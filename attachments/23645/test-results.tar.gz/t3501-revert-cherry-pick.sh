ok 1 - setup
ok 2 - cherry-pick --nonsense
ok 3 - revert --nonsense
ok 4 - cherry-pick after renaming branch
ok 5 - revert after renaming branch
ok 6 - cherry-pick on stat-dirty working tree
ok 7 - revert forbidden on dirty working tree
# passed all 7 test(s)
1..7
