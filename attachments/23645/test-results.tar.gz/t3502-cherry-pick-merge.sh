ok 1 - setup
ok 2 - cherry-pick a non-merge with -m should fail
ok 3 - cherry pick a merge without -m should fail
ok 4 - cherry pick a merge (1)
ok 5 - cherry pick a merge (2)
ok 6 - cherry pick a merge relative to nonexistent parent should fail
ok 7 - revert a non-merge with -m should fail
ok 8 - revert a merge without -m should fail
ok 9 - revert a merge (1)
ok 10 - revert a merge (2)
ok 11 - revert a merge relative to nonexistent parent should fail
# passed all 11 test(s)
1..11
