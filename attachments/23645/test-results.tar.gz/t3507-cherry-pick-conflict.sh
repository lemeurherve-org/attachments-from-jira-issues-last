ok 1 - setup
ok 2 - failed cherry-pick does not advance HEAD
ok 3 - advice from failed cherry-pick
ok 4 - advice from failed cherry-pick --no-commit
ok 5 - failed cherry-pick sets CHERRY_PICK_HEAD
ok 6 - successful cherry-pick does not set CHERRY_PICK_HEAD
ok 7 - cherry-pick --no-commit does not set CHERRY_PICK_HEAD
ok 8 - cherry-pick w/dirty tree does not set CHERRY_PICK_HEAD
ok 9 - cherry-pick --strategy=resolve w/dirty tree does not set CHERRY_PICK_HEAD
ok 10 - GIT_CHERRY_PICK_HELP suppresses CHERRY_PICK_HEAD
ok 11 - git reset clears CHERRY_PICK_HEAD
ok 12 - failed commit does not clear CHERRY_PICK_HEAD
ok 13 - cancelled commit does not clear CHERRY_PICK_HEAD
ok 14 - successful commit clears CHERRY_PICK_HEAD
ok 15 - failed cherry-pick produces dirty index
ok 16 - failed cherry-pick registers participants in index
ok 17 - failed cherry-pick describes conflict in work tree
ok 18 - diff3 -m style
ok 19 - revert also handles conflicts sanely
ok 20 - failed revert sets REVERT_HEAD
ok 21 - successful revert does not set REVERT_HEAD
ok 22 - revert --no-commit sets REVERT_HEAD
ok 23 - revert w/dirty tree does not set REVERT_HEAD
ok 24 - GIT_CHERRY_PICK_HELP does not suppress REVERT_HEAD
ok 25 - git reset clears REVERT_HEAD
ok 26 - failed commit does not clear REVERT_HEAD
ok 27 - revert conflict, diff3 -m style
ok 28 - failed cherry-pick does not forget -s
ok 29 - commit after failed cherry-pick does not add duplicated -s
ok 30 - commit after failed cherry-pick adds -s at the right place
# passed all 30 test(s)
1..30
