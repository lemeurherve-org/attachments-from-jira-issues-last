ok 1 - setup
ok 2 - cherry-pick first..fourth works
ok 3 - cherry-pick three one two works
ok 4 - output to keep user entertained during multi-pick
ok 5 - cherry-pick --strategy resolve first..fourth works
ok 6 - output during multi-pick indicates merge strategy
ok 7 - cherry-pick --ff first..fourth works
ok 8 - cherry-pick -n first..fourth works
ok 9 - revert first..fourth works
ok 10 - revert ^first fourth works
ok 11 - revert fourth fourth~1 fourth~2 works
ok 12 - cherry-pick -3 fourth works
ok 13 - cherry-pick --stdin works
# passed all 13 test(s)
1..13
