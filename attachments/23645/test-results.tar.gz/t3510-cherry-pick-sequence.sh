ok 1 - setup
ok 2 - cherry-pick persists data on failure
ok 3 - cherry-pick mid-cherry-pick-sequence
ok 4 - cherry-pick persists opts correctly
ok 5 - cherry-pick cleans up sequencer state upon success
ok 6 - --quit does not complain when no cherry-pick is in progress
ok 7 - --abort requires cherry-pick in progress
ok 8 - --quit cleans up sequencer state
ok 9 - --quit keeps HEAD and conflicted index intact
ok 10 - --abort to cancel multiple cherry-pick
ok 11 - --abort to cancel single cherry-pick
ok 12 - cherry-pick --abort to cancel multiple revert
ok 13 - revert --abort works, too
ok 14 - --abort to cancel single revert
ok 15 - --abort keeps unrelated change, easy case
ok 16 - --abort refuses to clobber unrelated change, harder case
ok 17 - cherry-pick still writes sequencer state when one commit is left
ok 18 - --abort after last commit in sequence
ok 19 - cherry-pick does not implicitly stomp an existing operation
ok 20 - --continue complains when no cherry-pick is in progress
ok 21 - --continue complains when there are unresolved conflicts
ok 22 - --continue of single cherry-pick
ok 23 - --continue of single revert
ok 24 - --continue after resolving conflicts
ok 25 - --continue after resolving conflicts and committing
ok 26 - --continue asks for help after resolving patch to nil
ok 27 - follow advice and skip nil patch
ok 28 - --continue respects opts
ok 29 - --continue of single-pick respects -x
ok 30 - --continue respects -x in first commit in multi-pick
not ok 31 - --signoff is automatically propagated to resolved conflict # TODO known breakage
not ok 32 - --signoff dropped for implicit commit of resolution, multi-pick case # TODO known breakage
not ok 33 - sign-off needs to be reaffirmed after conflict resolution, single-pick case # TODO known breakage
ok 34 - malformed instruction sheet 1
ok 35 - malformed instruction sheet 2
ok 36 - empty commit set
ok 37 - malformed instruction sheet 3
ok 38 - instruction sheet, fat-fingers version
ok 39 - commit descriptions in insn sheet are optional
# still have 3 known breakage(s)
# passed all remaining 36 test(s)
1..39
