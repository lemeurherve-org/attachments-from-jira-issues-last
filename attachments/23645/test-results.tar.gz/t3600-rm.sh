ok 1 - Initialize test directory
Your filesystem does not allow tabs in filenames.
ok 2 # skip add files with funny names (missing FUNNYNAMES)
ok 3 - Pre-check that foo exists and is in index before git rm foo
ok 4 - Test that git rm foo succeeds
ok 5 - Test that git rm --cached foo succeeds if the index matches the file
ok 6 - Test that git rm --cached foo succeeds if the index matches the file
ok 7 - Test that git rm --cached foo fails if the index matches neither the file nor HEAD
ok 8 - Test that git rm --cached -f foo works in case where --cached only did not
ok 9 - Post-check that foo exists but is not in index after git rm foo
ok 10 - Pre-check that bar exists and is in index before "git rm bar"
ok 11 - Test that "git rm bar" succeeds
ok 12 - Post-check that bar does not exist and is not in index after "git rm -f bar"
ok 13 - Test that "git rm -- -q" succeeds (remove a file that looks like an option)
ok 14 # skip Test that "git rm -f" succeeds with embedded space, tab, or newline characters. (missing FUNNYNAMES)
ok 15 # skip Test that "git rm -f" fails if its rm fails (missing SANITY)
ok 16 - When the rm in "git rm -f" fails, it should not remove the file from the index
ok 17 - Remove nonexistent file with --ignore-unmatch
ok 18 - "rm" command printed
ok 19 - "rm" command suppressed with --quiet
ok 20 - Re-add foo and baz
ok 21 - Modify foo -- rm should refuse
ok 22 - Modified foo -- rm -f should work
ok 23 - Re-add foo and baz for HEAD tests
ok 24 - foo is different in index from HEAD -- rm should refuse
ok 25 - but with -f it should work.
ok 26 - refuse to remove cached empty file with modifications
ok 27 - remove intent-to-add file without --force
ok 28 - Recursive test setup
ok 29 - Recursive without -r fails
ok 30 - Recursive with -r but dirty
ok 31 - Recursive with -r -f
ok 32 - Remove nonexistent file returns nonzero exit status
ok 33 - Call "rm" from outside the work tree
ok 34 - refresh index before checking if it is up-to-date
ok 35 - choking "git rm" should not let it die with cruft
ok 36 - rm removes subdirectories recursively
ok 37 - rm removes empty submodules from work tree
ok 38 - rm removes removed submodule from index
ok 39 - rm removes work tree of unmodified submodules
ok 40 - rm removes a submodule with a trailing /
ok 41 - rm fails when given a file with a trailing /
ok 42 - rm succeeds when given a directory with a trailing /
ok 43 - rm of a populated submodule with different HEAD fails unless forced
ok 44 - rm of a populated submodule with modifications fails unless forced
ok 45 - rm of a populated submodule with untracked files fails unless forced
ok 46 - setup submodule conflict
ok 47 - rm removes work tree of unmodified conflicted submodule
ok 48 - rm of a conflicted populated submodule with different HEAD fails unless forced
ok 49 - rm of a conflicted populated submodule with modifications fails unless forced
ok 50 - rm of a conflicted populated submodule with untracked files fails unless forced
ok 51 - rm of a conflicted populated submodule with a .git directory fails even when forced
ok 52 - rm of a conflicted unpopulated submodule succeeds
ok 53 - rm of a populated submodule with a .git directory fails even when forced
ok 54 - setup subsubmodule
ok 55 - rm recursively removes work tree of unmodified submodules
ok 56 - rm of a populated nested submodule with different nested HEAD fails unless forced
ok 57 - rm of a populated nested submodule with nested modifications fails unless forced
ok 58 - rm of a populated nested submodule with nested untracked files fails unless forced
ok 59 - rm of a populated nested submodule with a nested .git directory fails even when forced
# passed all 59 test(s)
1..59
