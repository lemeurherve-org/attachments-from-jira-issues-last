filemode disabled on the filesystem
ok 1 - setup (initial)
ok 2 - status works (initial)
ok 3 - setup expected
ok 4 - diff works (initial)
ok 5 - revert works (initial)
ok 6 - setup (commit)
ok 7 - status works (commit)
ok 8 - setup expected
ok 9 - diff works (commit)
ok 10 - revert works (commit)
ok 11 - setup expected
ok 12 - setup fake editor
ok 13 - dummy edit works
ok 14 - setup patch
ok 15 - setup fake editor
ok 16 - bad edit rejected
ok 17 - setup patch
ok 18 - garbage edit rejected
ok 19 - setup patch
ok 20 - setup expected
ok 21 - real edit works
ok 22 - skip files similarly as commit -a
ok 23 # skip patch does not affect mode (missing FILEMODE of PERL,FILEMODE)
ok 24 # skip stage mode but not hunk (missing FILEMODE of PERL,FILEMODE)
ok 25 # skip stage mode and hunk (missing FILEMODE of PERL,FILEMODE)
ok 26 - setup again
ok 27 - setup patch
ok 28 - setup expected
ok 29 - add first line works
ok 30 - setup expected
ok 31 - deleting a non-empty file
ok 32 - setup expected
ok 33 - deleting an empty file
ok 34 - split hunk setup
ok 35 - split hunk "add -p (edit)"
ok 36 - patch mode ignores unmerged entries
# passed all 36 test(s)
1..36
