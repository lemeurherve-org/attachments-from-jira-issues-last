ok 1 - setup
ok 2 - no encoding header for base case
not ok 3 - UTF-16 refused because of NULs # TODO known breakage
ok 4 - ISO8859-1 setup
ok 5 - eucJP setup
ok 6 - ISO-2022-JP setup
ok 7 - check encoding header for ISO8859-1
ok 8 - check encoding header for eucJP
ok 9 - check encoding header for ISO-2022-JP
ok 10 - config to remove customization
ok 11 - ISO8859-1 should be shown in UTF-8 now
ok 12 - eucJP should be shown in UTF-8 now
ok 13 - ISO-2022-JP should be shown in UTF-8 now
ok 14 - config to add customization
ok 15 - ISO8859-1 should be shown in itself now
ok 16 - eucJP should be shown in itself now
ok 17 - ISO-2022-JP should be shown in itself now
ok 18 - config to tweak customization
ok 19 - ISO8859-1 should be shown in UTF-8 now
ok 20 - eucJP should be shown in UTF-8 now
ok 21 - ISO-2022-JP should be shown in UTF-8 now
ok 22 - eucJP should be shown in eucJP now
ok 23 - ISO-2022-JP should be shown in eucJP now
ok 24 - eucJP should be shown in ISO-2022-JP now
ok 25 - ISO-2022-JP should be shown in ISO-2022-JP now
ok 26 - No conversion with ISO8859-1
ok 27 - No conversion with eucJP
ok 28 - No conversion with ISO-2022-JP
ok 29 - commit --fixup with eucJP encoding
ok 30 - commit --squash with ISO-2022-JP encoding
# still have 1 known breakage(s)
# passed all remaining 29 test(s)
1..30
