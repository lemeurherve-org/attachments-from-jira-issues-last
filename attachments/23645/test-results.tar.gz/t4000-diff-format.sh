ok 1 - update-index --add two files with and without +x.
ok 2 - git diff-files -p after editing work tree.
filemode disabled on the filesystem
# passed all 2 test(s)
1..2
