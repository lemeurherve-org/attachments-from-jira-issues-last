ok 1 - adding test file NN and Z/NN
ok 2 - adding test file ND and Z/ND
ok 3 - adding test file NM and Z/NM
ok 4 - adding test file DN and Z/DN
ok 5 - adding test file DD and Z/DD
ok 6 - adding test file DM and Z/DM
ok 7 - adding test file MN and Z/MN
ok 8 - adding test file MD and Z/MD
ok 9 - adding test file MM and Z/MM
ok 10 - adding test file SS
ok 11 - adding test file TT
ok 12 - prepare initial tree
ok 13 - change in branch A (removal)
ok 14 - change in branch A (modification)
ok 15 - change in branch A (modification)
ok 16 - change in branch A (modification)
ok 17 - change in branch A (modification)
ok 18 - change in branch A (modification)
ok 19 - change in branch A (modification)
ok 20 - change in branch A (addition)
ok 21 - change in branch A (addition)
ok 22 - change in branch A (addition)
ok 23 - change in branch A (addition)
ok 24 - change in branch A (addition)
ok 25 - change in branch A (edit)
ok 26 - change in branch A (change file to directory)
ok 27 - recording branch A tree
ok 28 - reading original tree and checking out
ok 29 - change in branch B (removal)
ok 30 - change in branch B (modification)
ok 31 - change in branch B (modification)
ok 32 - change in branch B (modification)
ok 33 - change in branch B (modification)
ok 34 - change in branch B (modification)
ok 35 - change in branch B (modification)
ok 36 - change in branch B (addition)
ok 37 - change in branch B (addition)
ok 38 - change in branch B (addition)
ok 39 - change in branch B (addition)
ok 40 - change in branch B (addition and modification)
ok 41 - change in branch B (modification)
ok 42 - change in branch B (addition of a file to conflict with directory)
ok 43 - recording branch B tree
ok 44 - keep contents of 3 trees for easy access
ok 45 - diff-tree of known trees.
ok 46 - diff-tree of known trees.
ok 47 - diff-tree of known trees.
ok 48 - diff-tree of known trees.
ok 49 - diff-tree of known trees.
ok 50 - diff-tree of known trees.
ok 51 - diff-tree --stdin of known trees.
ok 52 - diff-tree --stdin of known trees.
ok 53 - diff-cache O with A in cache
ok 54 - diff-cache O with B in cache
ok 55 - diff-cache A with B in cache
ok 56 - diff-files with O in cache and A checked out
ok 57 - diff-files with O in cache and B checked out
ok 58 - diff-files with A in cache and B checked out
ok 59 - diff-tree O A == diff-tree -R A O
ok 60 - diff-tree -r O A == diff-tree -r -R A O
ok 61 - diff-tree B A == diff-tree -R A B
ok 62 - diff-tree -r B A == diff-tree -r -R A B
ok 63 - diff can read from stdin
# passed all 63 test(s)
1..63
