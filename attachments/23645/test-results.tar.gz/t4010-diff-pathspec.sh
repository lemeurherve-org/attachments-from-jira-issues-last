ok 1 - setup
ok 2 - limit to path should show nothing
ok 3 - limit to path1 should show path1/file1
ok 4 - limit to path1/ should show path1/file1
ok 5 - "*file1" should show path1/file1
ok 6 - limit to file0 should show file0
ok 7 - limit to file0/ should emit nothing.
ok 8 - diff-tree pathspec
ok 9 - diff-tree with wildcard shows dir also matches
ok 10 - diff-tree -r with wildcard
ok 11 - diff-tree with wildcard shows dir also matches
ok 12 - diff-tree -r with wildcard from beginning
ok 13 - diff-tree -r with wildcard
# passed all 13 test(s)
1..13
