ok 1 - builtin ada pattern compiles
ok 2 - builtin ada wordRegex pattern compiles
ok 3 - builtin bibtex pattern compiles
ok 4 - builtin bibtex wordRegex pattern compiles
ok 5 - builtin cpp pattern compiles
ok 6 - builtin cpp wordRegex pattern compiles
ok 7 - builtin csharp pattern compiles
ok 8 - builtin csharp wordRegex pattern compiles
ok 9 - builtin fortran pattern compiles
ok 10 - builtin fortran wordRegex pattern compiles
ok 11 - builtin html pattern compiles
ok 12 - builtin html wordRegex pattern compiles
ok 13 - builtin java pattern compiles
ok 14 - builtin java wordRegex pattern compiles
ok 15 - builtin matlab pattern compiles
ok 16 - builtin matlab wordRegex pattern compiles
ok 17 - builtin objc pattern compiles
ok 18 - builtin objc wordRegex pattern compiles
ok 19 - builtin pascal pattern compiles
ok 20 - builtin pascal wordRegex pattern compiles
ok 21 - builtin perl pattern compiles
ok 22 - builtin perl wordRegex pattern compiles
ok 23 - builtin php pattern compiles
ok 24 - builtin php wordRegex pattern compiles
ok 25 - builtin python pattern compiles
ok 26 - builtin python wordRegex pattern compiles
ok 27 - builtin ruby pattern compiles
ok 28 - builtin ruby wordRegex pattern compiles
ok 29 - builtin tex pattern compiles
ok 30 - builtin tex wordRegex pattern compiles
ok 31 - default behaviour
ok 32 - set up .gitattributes declaring drivers to test
ok 33 - preset java pattern
ok 34 - preset perl pattern
ok 35 - perl pattern accepts K&R style brace placement, too
ok 36 - but is not distracted by end of <<here document
ok 37 - perl pattern is not distracted by sub within POD
ok 38 - perl pattern gets full line of POD header
ok 39 - perl pattern is not distracted by forward declaration
ok 40 - custom pattern
ok 41 - last regexp must not be negated
ok 42 - pattern which matches to end of line
ok 43 - alternation in pattern
# passed all 43 test(s)
1..43
