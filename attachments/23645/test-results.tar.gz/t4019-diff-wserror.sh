ok 1 - setup
ok 2 - default
ok 3 - default (attribute)
ok 4 - default, tabwidth=10 (attribute)
ok 5 - no check (attribute)
ok 6 - no check, tabwidth=10 (attribute), must be irrelevant
ok 7 - without -trail
ok 8 - without -trail (attribute)
ok 9 - without -space
ok 10 - without -space (attribute)
ok 11 - with indent-non-tab only
ok 12 - with indent-non-tab only (attribute)
ok 13 - with indent-non-tab only, tabwidth=10
ok 14 - with indent-non-tab only, tabwidth=10 (attribute)
ok 15 - with cr-at-eol
ok 16 - with cr-at-eol (attribute)
ok 17 - trailing empty lines (1)
ok 18 - trailing empty lines (2)
ok 19 - checkdiff shows correct line number for trailing blank lines
ok 20 - do not color trailing cr in context
ok 21 - color new trailing blank lines
# passed all 21 test(s)
1..21
