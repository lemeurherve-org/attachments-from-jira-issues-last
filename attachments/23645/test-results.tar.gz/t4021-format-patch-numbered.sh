ok 1 - setup
ok 2 - single patch defaults to no numbers
ok 3 - multiple patch defaults to numbered
ok 4 - Use --numbered
ok 5 - format.numbered = true
ok 6 - format.numbered && single patch
ok 7 - format.numbered && --no-numbered
ok 8 - format.numbered && --keep-subject
ok 9 - format.numbered = auto
ok 10 - format.numbered = auto && single patch
ok 11 - format.numbered = auto && --no-numbered
ok 12 - --start-number && --numbered
# passed all 12 test(s)
1..12
