ok 1 - setup
ok 2 - diff -U0
# passed all 2 test(s)
1..2
