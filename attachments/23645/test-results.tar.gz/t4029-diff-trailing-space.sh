ok 1 - diff honors config option, diff.suppressBlankEmpty
# passed all 1 test(s)
1..1
