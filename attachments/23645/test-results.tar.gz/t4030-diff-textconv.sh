ok 1 - setup binary file with history
ok 2 - file is considered binary by porcelain
ok 3 - file is considered binary by plumbing
ok 4 - setup textconv filters
ok 5 - diff produces text
ok 6 - diff-tree produces binary
ok 7 - log produces text
ok 8 - format-patch produces binary
ok 9 - status -v produces text
ok 10 - grep-diff (-G) operates on textconv data (add)
ok 11 - grep-diff (-G) operates on textconv data (modification)
ok 12 - pickaxe (-S) operates on textconv data (add)
ok 13 - pickaxe (-S) operates on textconv data (modification)
ok 14 - diffstat does not run textconv
ok 15 - textconv does not act on symlinks
# passed all 15 test(s)
1..15
