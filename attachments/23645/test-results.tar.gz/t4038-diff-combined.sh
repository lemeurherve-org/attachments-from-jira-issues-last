ok 1 - setup
ok 2 - check combined output (1)
ok 3 - check combined output (2)
ok 4 - diagnose truncated file
# passed all 4 test(s)
1..4
