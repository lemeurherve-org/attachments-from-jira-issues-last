ok 1 - setup
ok 2 - diff-index does not examine assume-unchanged entries
ok 3 - diff-files does not examine assume-unchanged entries
# passed all 3 test(s)
1..3
