ok 1 - added submodule
ok 2 - added submodule, set diff.submodule
ok 3 - --submodule=short overrides diff.submodule
ok 4 - diff.submodule does not affect plumbing
ok 5 - modified submodule(forward)
ok 6 - modified submodule(forward)
ok 7 - modified submodule(forward) --submodule
ok 8 - modified submodule(forward) --submodule=short
ok 9 - modified submodule(backward)
ok 10 - modified submodule(backward and forward)
ok 11 - typechanged submodule(submodule->blob), --cached
ok 12 - typechanged submodule(submodule->blob)
ok 13 - typechanged submodule(submodule->blob)
ok 14 - nonexistent commit
ok 15 - typechanged submodule(blob->submodule)
ok 16 - submodule is up to date
ok 17 - submodule contains untracked content
ok 18 - submodule contains untracked content (untracked ignored)
ok 19 - submodule contains untracked content (dirty ignored)
ok 20 - submodule contains untracked content (all ignored)
ok 21 - submodule contains untracked and modifed content
ok 22 - submodule contains untracked and modifed content (untracked ignored)
ok 23 - submodule contains untracked and modifed content (dirty ignored)
ok 24 - submodule contains untracked and modifed content (all ignored)
ok 25 - submodule contains modifed content
ok 26 - submodule is modified
ok 27 - modified submodule contains untracked content
ok 28 - modified submodule contains untracked content (untracked ignored)
ok 29 - modified submodule contains untracked content (dirty ignored)
ok 30 - modified submodule contains untracked content (all ignored)
ok 31 - modified submodule contains untracked and modifed content
ok 32 - modified submodule contains untracked and modifed content (untracked ignored)
ok 33 - modified submodule contains untracked and modifed content (dirty ignored)
ok 34 - modified submodule contains untracked and modifed content (all ignored)
ok 35 - modified submodule contains modifed content
ok 36 - deleted submodule
ok 37 - multiple submodules
ok 38 - path filter
ok 39 - given commit
ok 40 - given commit --submodule
ok 41 - given commit --submodule=short
ok 42 - setup .git file for sm2
ok 43 - diff --submodule with .git file
ok 44 - diff --submodule with objects referenced by alternates
# passed all 44 test(s)
1..44
