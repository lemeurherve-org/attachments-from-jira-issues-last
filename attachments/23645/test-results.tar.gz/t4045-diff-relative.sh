ok 1 - setup
ok 2 - -p --relative=subdir/
ok 3 - -p --relative=subdir
ok 4 - -p --relative=sub
ok 5 - --numstat --relative=subdir/
ok 6 - --numstat --relative=subdir
ok 7 - --numstat --relative=sub
ok 8 - --stat --relative=subdir/
ok 9 - --stat --relative=subdir
ok 10 - --stat --relative=sub
ok 11 - --raw --relative=subdir/
ok 12 - --raw --relative=subdir
ok 13 - --raw --relative=sub
# passed all 13 test(s)
1..13
