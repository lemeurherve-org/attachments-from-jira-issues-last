ok 1 - histogram diff
ok 2 - histogram diff output is valid
ok 3 - completely different files
# passed all 3 test(s)
1..3
