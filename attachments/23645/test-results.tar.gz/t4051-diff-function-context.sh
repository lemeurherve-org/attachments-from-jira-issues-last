ok 1 - setup
ok 2 - diff -U0 -W
ok 3 - diff -W
# passed all 3 test(s)
1..3
