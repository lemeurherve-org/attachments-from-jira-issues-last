ok 1 - set up terminal for tests
ok 2 - preparation
ok 3 - format-patch: small change with long name gives more space to the name
ok 4 - format-patch --stat=width: a long name is given more room when the bar is short
ok 5 - format-patch --stat-width=width with long name
ok 6 - format-patch --stat=...,name-width with long name
ok 7 - format-patch --stat-name-width with long name
ok 8 - diff: small change with long name gives more space to the name
ok 9 - diff --stat=width: a long name is given more room when the bar is short
ok 10 - diff --stat-width=width with long name
ok 11 - diff --stat=...,name-width with long name
ok 12 - diff --stat-name-width with long name
ok 13 - show: small change with long name gives more space to the name
ok 14 - show --stat=width: a long name is given more room when the bar is short
ok 15 - show --stat-width=width with long name
ok 16 - show --stat=...,name-width with long name
ok 17 - show --stat-name-width with long name
ok 18 - log: small change with long name gives more space to the name
ok 19 - log --stat=width: a long name is given more room when the bar is short
ok 20 - log --stat-width=width with long name
ok 21 - log --stat=...,name-width with long name
ok 22 - log --stat-name-width with long name
ok 23 - preparation for big change tests
ok 24 - format-patch ignores COLUMNS (big change)
ok 25 - format-patch --graph ignores COLUMNS (big change)
ok 26 - diff respects COLUMNS (big change)
ok 27 - show respects COLUMNS (big change)
ok 28 - show --graph respects COLUMNS (big change)
ok 29 - log respects COLUMNS (big change)
ok 30 - log --graph respects COLUMNS (big change)
ok 31 - format-patch ignores not enough COLUMNS (big change)
ok 32 - format-patch --graph ignores not enough COLUMNS (big change)
ok 33 - diff respects not enough COLUMNS (big change)
ok 34 - show respects not enough COLUMNS (big change)
ok 35 - show --graph respects not enough COLUMNS (big change)
ok 36 - log respects not enough COLUMNS (big change)
ok 37 - log --graph respects not enough COLUMNS (big change)
ok 38 - format-patch ignores statGraphWidth config
ok 39 - format-patch --graph ignores statGraphWidth config
ok 40 - diff respects statGraphWidth config
ok 41 - show respects statGraphWidth config
ok 42 - show --graph respects statGraphWidth config
ok 43 - log respects statGraphWidth config
ok 44 - log --graph respects statGraphWidth config
ok 45 - format-patch --stat=width with big change
ok 46 - format-patch --stat-width=width with big change
ok 47 - format-patch --stat-graph-width with big change
ok 48 - format-patch --stat-width=width --graph with big change
ok 49 - format-patch --stat-graph-width --graph with big change
ok 50 - diff --stat=width with big change
ok 51 - diff --stat-width=width with big change
ok 52 - diff --stat-graph-width with big change
ok 53 - show --stat=width with big change
ok 54 - show --stat-width=width with big change
ok 55 - show --stat-graph-width with big change
ok 56 - show --stat-width=width --graph with big change
ok 57 - show --stat-graph-width --graph with big change
ok 58 - log --stat=width with big change
ok 59 - log --stat-width=width with big change
ok 60 - log --stat-graph-width with big change
ok 61 - log --stat-width=width --graph with big change
ok 62 - log --stat-graph-width --graph with big change
ok 63 - preparation for long filename tests
ok 64 - format-patch --stat=width with big change is more balanced
ok 65 - format-patch --stat=width --graph with big change is balanced
ok 66 - diff --stat=width with big change is more balanced
ok 67 - show --stat=width with big change is more balanced
ok 68 - show --stat=width --graph with big change is balanced
ok 69 - log --stat=width with big change is more balanced
ok 70 - log --stat=width --graph with big change is balanced
ok 71 - format-patch ignores COLUMNS (long filename)
ok 72 - format-patch --graph ignores COLUMNS (long filename)
ok 73 - diff respects COLUMNS (long filename)
ok 74 - show respects COLUMNS (long filename)
ok 75 - show --graph respects COLUMNS (long filename)
ok 76 - log respects COLUMNS (long filename)
ok 77 - log --graph respects COLUMNS (long filename)
ok 78 - format-patch ignores prefix greater than COLUMNS (big change)
ok 79 - format-patch --graph ignores prefix greater than COLUMNS (big change)
ok 80 - diff respects prefix greater than COLUMNS (big change)
ok 81 - show respects prefix greater than COLUMNS (big change)
ok 82 - show --graph respects prefix greater than COLUMNS (big change)
ok 83 - log respects prefix greater than COLUMNS (big change)
ok 84 - log --graph respects prefix greater than COLUMNS (big change)
ok 85 - merge --stat respects COLUMNS (big change)
ok 86 - merge --stat respects COLUMNS (long filename)
# passed all 86 test(s)
1..86
