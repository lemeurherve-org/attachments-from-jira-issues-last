ok 1 - setup
ok 2 - git diff --no-index directories
ok 3 - git diff --no-index relative path outside repo
# passed all 3 test(s)
1..3
