ok 1 - setup
ok 2 - the default number of context lines is 3
ok 3 - diff.context honored by "log"
ok 4 - The -U option overrides diff.context
ok 5 - diff.context honored by "diff"
ok 6 - plumbing not affected
ok 7 - non-integer config parsing
ok 8 - negative integer config parsing
ok 9 - -U0 is valid, so is diff.context=0
# passed all 9 test(s)
1..9
