ok 1 - setup
ok 2 - stat binary diff -- should not fail.
ok 3 - stat binary -p0 diff -- should not fail.
ok 4 - stat binary diff (copy) -- should not fail.
ok 5 - check binary diff -- should fail.
ok 6 - check binary diff (copy) -- should fail.
ok 7 - check incomplete binary diff with replacement -- should fail.
ok 8 - check incomplete binary diff with replacement (copy) -- should fail.
ok 9 - check binary diff with replacement.
ok 10 - check binary diff with replacement (copy).
ok 11 - apply binary diff -- should fail.
ok 12 - apply binary diff -- should fail.
ok 13 - apply binary diff (copy) -- should fail.
ok 14 - apply binary diff (copy) -- should fail.
ok 15 - apply binary diff with full-index
ok 16 - apply binary diff with full-index (copy)
ok 17 - apply full-index binary diff in new repo
ok 18 - apply binary diff without replacement.
ok 19 - apply binary diff without replacement (copy).
ok 20 - apply binary diff.
ok 21 - apply binary diff (copy).
ok 22 - apply binary -p0 diff
# passed all 22 test(s)
1..22
