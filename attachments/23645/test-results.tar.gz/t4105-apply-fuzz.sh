ok 1 - setup
ok 2 - unmodified patch
ok 3 - minus offset
ok 4 - plus offset
ok 5 - big offset
ok 6 - fuzz with no offset
ok 7 - fuzz with minus offset
ok 8 - fuzz with plus offset
ok 9 - fuzz with big offset
# passed all 9 test(s)
1..9
