ok 1 - file creation
ok 2 - patch2 fails (retab)
ok 3 - patch2 applies with --ignore-whitespace
ok 4 - patch2 reverse applies with --ignore-space-change
ok 5 - patch2 applies (apply.ignorewhitespace = change)
ok 6 - patch3 fails (missing string at EOL)
ok 7 - patch4 fails (missing EOL at EOF)
ok 8 - patch5 applies (leading whitespace)
ok 9 - patches do not mangle whitespace
ok 10 - re-create file (with --ignore-whitespace)
ok 11 - patch5 fails (--no-ignore-whitespace)
# passed all 11 test(s)
1..11
