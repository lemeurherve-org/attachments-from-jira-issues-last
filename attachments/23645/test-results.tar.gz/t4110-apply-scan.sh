ok 1 - git apply scan
# passed all 1 test(s)
1..1
