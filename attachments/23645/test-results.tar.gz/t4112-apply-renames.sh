ok 1 - check rename/copy patch
ok 2 - apply rename/copy patch
# passed all 2 test(s)
1..2
