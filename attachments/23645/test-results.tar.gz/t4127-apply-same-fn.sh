ok 1 - setup
ok 2 - apply same filename with independent changes
ok 3 - apply same filename with overlapping changes
ok 4 - apply same new filename after rename
ok 5 - apply same old filename after rename -- should fail.
ok 6 - apply A->B (rename), C->A (rename), A->A -- should pass.
# passed all 6 test(s)
1..6
