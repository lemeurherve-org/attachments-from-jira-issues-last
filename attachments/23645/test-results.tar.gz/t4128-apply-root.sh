ok 1 - setup
ok 2 - apply --directory -p (1)
ok 3 - apply --directory -p (2) 
ok 4 - apply --directory (new file)
ok 5 - apply --directory -p (new file)
ok 6 - apply --directory (delete file)
ok 7 - apply --directory (quoted filename)
# passed all 7 test(s)
1..7
