ok 1 - setup
ok 2 - plain, git-style file creation patch
ok 3 - plain, traditional patch
ok 4 - plain, traditional file creation patch
ok 5 - with spaces, git-style file creation patch
ok 6 - with spaces, traditional patch
ok 7 - with spaces, traditional file creation patch
ok 8 # skip with tab, git-style file creation patch (missing FUNNYNAMES)
ok 9 # skip with tab, traditional patch (missing FUNNYNAMES)
ok 10 # skip with tab, traditional file creation patch (missing FUNNYNAMES)
ok 11 # skip with backslash, git-style file creation patch (missing BSLASHPSPEC)
ok 12 # skip with backslash, traditional patch (missing BSLASHPSPEC)
ok 13 # skip with backslash, traditional file creation patch (missing BSLASHPSPEC)
ok 14 # skip with quote, git-style file creation patch (missing FUNNYNAMES)
ok 15 # skip with quote, traditional patch (missing FUNNYNAMES)
ok 16 # skip with quote, traditional file creation patch (missing FUNNYNAMES)
ok 17 - whitespace-damaged traditional patch
ok 18 - traditional patch with colon in timezone
ok 19 - traditional, whitespace-damaged, colon in timezone
# passed all 19 test(s)
1..19
