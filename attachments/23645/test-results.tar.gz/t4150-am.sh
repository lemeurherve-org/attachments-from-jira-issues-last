ok 1 - setup: messages
ok 2 - setup
ok 3 - am applies patch correctly
ok 4 - am applies patch e-mail not in a mbox
ok 5 - am applies patch e-mail not in a mbox with CRLF
ok 6 - am applies patch e-mail with preceding whitespace
ok 7 - setup: new author and committer
ok 8 - am changes committer and keeps author
ok 9 - am --signoff adds Signed-off-by: line
ok 10 - am stays in branch
ok 11 - am --signoff does not add Signed-off-by: line if already there
ok 12 - am without --keep removes Re: and [PATCH] stuff
ok 13 - am --keep really keeps the subject
ok 14 - am --keep-non-patch really keeps the non-patch part
ok 15 - am -3 falls back to 3-way merge
ok 16 - am -3 -p0 can read --no-prefix patch
ok 17 - am can rename a file
ok 18 - am -3 can rename a file
ok 19 - am -3 can rename a file after falling back to 3-way merge
ok 20 - am -3 -q is quiet
ok 21 - am pauses on conflict
ok 22 - am --skip works
ok 23 - am --resolved works
ok 24 - am takes patches from a Pine mailbox
ok 25 - am fails on mail without patch
ok 26 - am fails on empty patch
ok 27 - am works from stdin in subdirectory
ok 28 - am works from file (relative path given) in subdirectory
ok 29 - am works from file (absolute path given) in subdirectory
ok 30 - am --committer-date-is-author-date
ok 31 - am without --committer-date-is-author-date
ok 32 - am --ignore-date
ok 33 - am into an unborn branch
ok 34 - am newline in subject
ok 35 - am -q is quiet
ok 36 - am empty-file does not infloop
# passed all 36 test(s)
1..36
