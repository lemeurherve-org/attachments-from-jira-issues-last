ok 1 - setup
ok 2 - am stops at a patch that does not apply
ok 3 - am --skip continue after failed am
ok 4 - am --abort goes back after failed am
ok 5 - am -3 stops at a patch that does not apply
ok 6 - am -3 --skip continue after failed am -3
ok 7 - am --abort goes back after failed am -3
ok 8 - am --abort will keep the local commits intact
# passed all 8 test(s)
1..8
