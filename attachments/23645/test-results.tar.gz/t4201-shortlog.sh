ok 1 - setup
ok 2 - default output format
ok 3 - pretty format
ok 4 - --abbrev
ok 5 - output from user-defined format is re-wrapped
ok 6 # skip shortlog wrapping (missing NOT_MINGW)
ok 7 # skip shortlog from non-git directory (missing NOT_MINGW)
ok 8 - shortlog should add newline when input line matches wraplen
ok 9 # skip shortlog encoding (missing NOT_MINGW)
# passed all 9 test(s)
1..9
