ok 1 - set up basic repos
ok 2 - alias builtin format
ok 3 - alias masking builtin format
ok 4 - alias user-defined format
ok 5 - alias user-defined tformat
ok 6 - alias non-existent format
ok 7 - alias of an alias
ok 8 - alias masking an alias
ok 9 - alias loop
ok 10 - NUL separation
ok 11 - NUL termination
ok 12 - NUL separation with --stat
not ok 13 - NUL termination with --stat # TODO known breakage
# still have 1 known breakage(s)
# passed all remaining 12 test(s)
1..13
