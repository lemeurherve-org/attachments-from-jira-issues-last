ok 1 - setup
not ok - 2 "git log :/" should be ambiguous
#	
#		test_must_fail git log :/ 2>error &&
#		grep ambiguous error
#	
ok 3 - "git log :" should be ambiguous
ok 4 - git log -- :
not ok - 5 git log HEAD -- :/
#	
#		cat >expected <<-EOF &&
#		24b24cf initial
#		EOF
#		(cd sub && git log --oneline HEAD -- :/ >../actual) &&
#		test_cmp expected actual
#	
# failed 2 among 5 test(s)
1..5
