ok 1 - setup
ok 2 - log --grep
ok 3 - log --grep --regexp-ignore-case
ok 4 - log --grep -i
ok 5 - log --author --regexp-ignore-case
ok 6 - log --author -i
ok 7 - log -G (nomatch)
ok 8 - log -G (match)
ok 9 - log -G --regexp-ignore-case (nomatch)
ok 10 - log -G -i (nomatch)
ok 11 - log -G --regexp-ignore-case (match)
ok 12 - log -G -i (match)
ok 13 - log -S (nomatch)
ok 14 - log -S (match)
ok 15 - log -S --regexp-ignore-case (match)
ok 16 - log -S -i (match)
ok 17 - log -S --regexp-ignore-case (nomatch)
ok 18 - log -S -i (nomatch)
# passed all 18 test(s)
1..18
