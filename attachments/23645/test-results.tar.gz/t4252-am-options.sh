ok 1 - setup
ok 2 - interrupted am --whitespace=fix
ok 3 - interrupted am -C1
ok 4 - interrupted am -p2
ok 5 - interrupted am -C1 -p2
ok 6 - interrupted am --directory="frotz nitfol"
ok 7 - apply to a funny path
ok 8 - am --reject
# passed all 8 test(s)
1..8
