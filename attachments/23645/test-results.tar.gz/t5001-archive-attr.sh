ok 1 - setup
ok 2 - git archive
ok 3 -  archive/ignored does not exist
ok 4 -  archive/ignored-by-tree does not exist
ok 5 -  archive/ignored-by-worktree exists
ok 6 - git archive with worktree attributes
ok 7 -  worktree/ignored does not exist
ok 8 -  worktree/ignored-by-tree exists
ok 9 -  worktree/ignored-by-worktree does not exist
ok 10 - git archive --worktree-attributes option
ok 11 -  worktree2/ignored does not exist
ok 12 -  worktree2/ignored-by-tree exists
ok 13 -  worktree2/ignored-by-worktree does not exist
ok 14 - git archive vs. bare
ok 15 - git archive with worktree attributes, bare
ok 16 -  bare-worktree/ignored does not exist
ok 17 -  bare-worktree/ignored-by-tree exists
ok 18 -  bare-worktree/ignored-by-worktree exists
ok 19 - export-subst
ok 20 - git tar-tree vs. git archive with worktree attributes
ok 21 - git tar-tree vs. git archive with worktree attrs, bare
# passed all 21 test(s)
1..21
