ok 1 - setup
ok 2 - git archive
ok 3 -  archive/ignored does not exist
ok 4 -  archive/not-ignored-dir/ignored does not exist
ok 5 -  archive/not-ignored-dir/ignored-only-if-dir exists
ok 6 -  archive/not-ignored-dir/ exists
ok 7 -  archive/ignored-only-if-dir/ does not exist
ok 8 -  archive/ignored-ony-if-dir/ignored-by-ignored-dir does not exist
ok 9 -  archive/one-level-lower/ exists
ok 10 -  archive/one-level-lower/two-levels-lower/ignored-only-if-dir/ does not exist
ok 11 -  archive/one-level-lower/two-levels-lower/ignored-ony-if-dir/ignored-by-ignored-dir does not exist
# passed all 11 test(s)
1..11
