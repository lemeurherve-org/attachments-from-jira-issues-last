ok 1 - populate workdir
ok 2 # skip add symlink (missing UNZIP_SYMLINKS,SYMLINKS of SYMLINKS,UNZIP_SYMLINKS)
ok 3 - prepare file list
ok 4 - add ignored file
ok 5 - add files to repository
ok 6 - create bare clone
ok 7 - remove ignored file
ok 8 - git archive --format=zip
ok 9 -  extract ZIP archive
ok 10 -  validate filenames
ok 11 -  validate file contents
ok 12 - git archive --format=zip in a bare repo
ok 13 - git archive --format=zip vs. the same in a bare repo
ok 14 - git archive --format=zip with --output
ok 15 - git archive with --output, inferring format
ok 16 - git archive --format=zip with prefix
ok 17 -  extract ZIP archive
ok 18 -  validate filenames
ok 19 -  validate file contents
ok 20 - git archive -0 --format=zip on large files
ok 21 -  extract ZIP archive
ok 22 -  validate filenames
ok 23 -  validate file contents
ok 24 - git archive --format=zip on large files
ok 25 -  extract ZIP archive
ok 26 -  validate filenames
ok 27 -  validate file contents
# passed all 27 test(s)
1..27
