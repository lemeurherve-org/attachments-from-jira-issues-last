ok 1 - setup
ok 2 - setup: two scripts for reading pull requests
ok 3 - pull request when forgot to push
ok 4 - pull request after push
ok 5 - request names an appropriate branch
ok 6 - pull request format
ok 7 - request-pull ignores OPTIONS_KEEPDASHDASH poison
# passed all 7 test(s)
1..7
