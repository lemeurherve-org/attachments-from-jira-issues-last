ok 1 - setup base
ok 2 - setup patch_clone
ok 3 - indirectly clone patch_clone
ok 4 - clone of patch_clone is incomplete
# passed all 4 test(s)
1..4
