ok 1 - setup
ok 2 - check corruption
ok 3 - rev-list notices corruption (1)
ok 4 - rev-list notices corruption (2)
ok 5 - pack-objects notices corruption
# passed all 5 test(s)
1..5
