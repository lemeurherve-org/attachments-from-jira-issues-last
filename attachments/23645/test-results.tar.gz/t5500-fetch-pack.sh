ok 1 - setup
ok 2 - 1st pull
ok 3 - post 1st pull setup
ok 4 - 2nd pull
ok 5 - 3rd pull
ok 6 - single branch clone
ok 7 - single branch object count
ok 8 - single given branch clone
ok 9 - clone shallow
ok 10 - clone shallow object count
ok 11 - clone shallow object count (part 2)
ok 12 - fsck in shallow repo
ok 13 - simple fetch in shallow repo
ok 14 - no changes expected
ok 15 - fetch same depth in shallow repo
ok 16 - no changes expected
ok 17 - add two more
ok 18 - pull in shallow repo
ok 19 - clone shallow object count
ok 20 - add two more (part 2)
ok 21 - deepening pull in shallow repo
ok 22 - clone shallow object count
ok 23 - deepening fetch in shallow repo
ok 24 - clone shallow object count
ok 25 - pull in shallow repo with missing merge base
ok 26 - additional simple shallow deepenings
ok 27 - clone shallow object count
ok 28 - clone shallow without --no-single-branch
ok 29 - clone shallow object count
ok 30 - clone shallow with --branch
ok 31 - clone shallow object count
ok 32 - clone shallow with detached HEAD
ok 33 - shallow clone pulling tags
ok 34 - shallow cloning single tag
ok 35 - setup tests for the --stdin parameter
ok 36 - fetch refs from cmdline
ok 37 - fetch refs from stdin
ok 38 - fetch mixed refs from cmdline and stdin
ok 39 - test duplicate refs from stdin
ok 40 - set up tests of missing reference
ok 41 - test lonely missing ref
ok 42 - test missing ref after existing
ok 43 - test missing ref before existing
ok 44 - test --all, --depth, and explicit head
ok 45 - test --all, --depth, and explicit tag
# passed all 45 test(s)
1..45
