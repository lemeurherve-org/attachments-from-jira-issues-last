ok 1 - setup
ok 2 - pushing into a repository with the same alternate
ok 3 - fetching from a repository with the same alternate
# passed all 3 test(s)
1..3
