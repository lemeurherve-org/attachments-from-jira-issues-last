ok 1 - setup
ok 2 - clone without alternate
ok 3 - further commits in the original
ok 4 - copy commit and tree but not blob by hand
ok 5 - quickfetch should not leave a corrupted repository
ok 6 - quickfetch should not copy from alternate
ok 7 - quickfetch should handle ~1000 refs (on Windows)
# passed all 7 test(s)
1..7
