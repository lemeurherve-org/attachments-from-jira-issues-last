GIT_DEBUG_SEND_PACK not supported - skipping tests
ok 1 # skip setup (missing NOT_MINGW)
ok 2 # skip setup expect (missing NOT_MINGW)
ok 3 # skip fetch A (new commit : 1 connection) (missing NOT_MINGW)
ok 4 # skip create tag T on A, create C on branch cat (missing NOT_MINGW)
ok 5 # skip setup expect (missing NOT_MINGW)
ok 6 # skip fetch C, T (new branch, tag : 1 connection) (missing NOT_MINGW)
ok 7 # skip create commits O, B, tag S on B (missing NOT_MINGW)
ok 8 # skip setup expect (missing NOT_MINGW)
ok 9 # skip fetch B, S (commit and tag : 1 connection) (missing NOT_MINGW)
ok 10 # skip setup expect (missing NOT_MINGW)
ok 11 # skip new clone fetch master and tags (missing NOT_MINGW)
# passed all 11 test(s)
1..11
