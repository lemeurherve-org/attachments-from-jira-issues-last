ok 1 - setup
ok 2 - fetch without strict
ok 3 - fetch with !fetch.fsckobjects
ok 4 - fetch with fetch.fsckobjects
ok 5 - fetch with transfer.fsckobjects
ok 6 - push without strict
ok 7 - push with !receive.fsckobjects
ok 8 - push with receive.fsckobjects
ok 9 - push with transfer.fsckobjects
# passed all 9 test(s)
1..9
