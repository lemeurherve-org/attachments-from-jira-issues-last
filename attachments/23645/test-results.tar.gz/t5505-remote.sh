ok 1 - setup
ok 2 - remote information for the origin
ok 3 - add another remote
ok 4 - check remote tracking
ok 5 - remote forces tracking branches
ok 6 - remove remote
ok 7 - remove remote
ok 8 - remove remote protects local branches
ok 9 - show
ok 10 - show -n
ok 11 - prune
ok 12 - set-head --delete
ok 13 - set-head --auto
ok 14 - set-head --auto fails w/multiple HEADs
ok 15 - set-head explicit
ok 16 - prune --dry-run
ok 17 - add --mirror && prune
ok 18 - add --mirror=fetch
ok 19 - fetch mirrors act as mirrors during fetch
ok 20 - fetch mirrors can prune
ok 21 - fetch mirrors do not act as mirrors during push
ok 22 - add fetch mirror with specific branches
ok 23 - fetch mirror respects specific branches
ok 24 - add --mirror=push
ok 25 - push mirrors act as mirrors during push
ok 26 - push mirrors do not act as mirrors during fetch
ok 27 - push mirrors do not allow you to specify refs
ok 28 - add alt && prune
ok 29 - add with reachable tags (default)
ok 30 - add --tags
ok 31 - add --no-tags
ok 32 - reject --no-no-tags
ok 33 - update
ok 34 - update with arguments
ok 35 - update --prune
ok 36 - update default
ok 37 - update default (overridden, with funny whitespace)
ok 38 - update (with remotes.default defined)
ok 39 - "remote show" does not show symbolic refs
ok 40 - reject adding remote with an invalid name
ok 41 - rename a remote
ok 42 - rename does not update a non-default fetch refspec
ok 43 - rename a remote with name part of fetch spec
ok 44 - rename a remote with name prefix of other remote
ok 45 - migrate a remote from named file in $GIT_DIR/remotes
ok 46 - migrate a remote from named file in $GIT_DIR/branches
ok 47 - remote prune to cause a dangling symref
ok 48 - show empty remote
ok 49 - remote set-branches requires a remote
ok 50 - remote set-branches
ok 51 - remote set-branches with --mirror
ok 52 - new remote
ok 53 - remote set-url bar
ok 54 - remote set-url baz bar
ok 55 - remote set-url zot bar
ok 56 - remote set-url --push zot baz
ok 57 - remote set-url --push zot
ok 58 - remote set-url --push qux zot
ok 59 - remote set-url --push foo qu+x
ok 60 - remote set-url --push --add aaa
ok 61 - remote set-url --push bar aaa
ok 62 - remote set-url --push --delete bar
ok 63 - remote set-url --push --delete foo
ok 64 - remote set-url --add bbb
ok 65 - remote set-url --delete .*
ok 66 - remote set-url --delete bbb
ok 67 - remote set-url --delete baz
ok 68 - remote set-url --add ccc
ok 69 - remote set-url --delete baz
# passed all 69 test(s)
1..69
