ok 1 - setup
ok 2 - br-config-explicit
ok 3 - br-config-explicit config-explicit
ok 4 - br-config-explicit-merge
ok 5 - br-config-explicit-merge config-explicit
ok 6 - br-config-explicit-octopus
ok 7 - br-config-explicit-octopus config-explicit
ok 8 - br-config-glob
ok 9 - br-config-glob config-glob
ok 10 - br-config-glob-merge
ok 11 - br-config-glob-merge config-glob
ok 12 - br-config-glob-octopus
ok 13 - br-config-glob-octopus config-glob
ok 14 - br-remote-explicit
ok 15 - br-remote-explicit remote-explicit
ok 16 - br-remote-explicit-merge
ok 17 - br-remote-explicit-merge remote-explicit
ok 18 - br-remote-explicit-octopus
ok 19 - br-remote-explicit-octopus remote-explicit
ok 20 - br-remote-glob
ok 21 - br-remote-glob remote-glob
ok 22 - br-remote-glob-merge
ok 23 - br-remote-glob-merge remote-glob
ok 24 - br-remote-glob-octopus
ok 25 - br-remote-glob-octopus remote-glob
ok 26 - br-branches-default
ok 27 - br-branches-default branches-default
ok 28 - br-branches-default-merge
ok 29 - br-branches-default-merge branches-default
ok 30 - br-branches-default-octopus
ok 31 - br-branches-default-octopus branches-default
ok 32 - br-branches-one
ok 33 - br-branches-one branches-one
ok 34 - br-branches-one-merge
ok 35 - br-branches-one-merge branches-one
ok 36 - br-branches-one-octopus
ok 37 - br-branches-one-octopus branches-one
ok 38 - master
ok 39 - master config-explicit
ok 40 - master config-glob
ok 41 - master remote-explicit
ok 42 - master remote-glob
ok 43 - master branches-default
ok 44 - master branches-one
ok 45 - br-unconfig
ok 46 - br-unconfig config-explicit
ok 47 - br-unconfig config-glob
ok 48 - br-unconfig remote-explicit
ok 49 - br-unconfig remote-glob
ok 50 - br-unconfig branches-default
ok 51 - br-unconfig branches-one
ok 52 - master ../.git
ok 53 - master ../.git one
ok 54 - master ../.git one two
ok 55 - master --tags ../.git
ok 56 - master ../.git tag tag-one tag tag-three
ok 57 - master ../.git tag tag-one-tree tag tag-three-file
ok 58 - master ../.git one tag tag-one tag tag-three-file
ok 59 - br-unconfig ../.git
ok 60 - br-unconfig ../.git one
ok 61 - br-unconfig ../.git one two
ok 62 - br-unconfig --tags ../.git
ok 63 - br-unconfig ../.git tag tag-one tag tag-three
ok 64 - br-unconfig ../.git tag tag-one-tree tag tag-three-file
ok 65 - br-unconfig ../.git one tag tag-one tag tag-three-file
# passed all 65 test(s)
1..65
