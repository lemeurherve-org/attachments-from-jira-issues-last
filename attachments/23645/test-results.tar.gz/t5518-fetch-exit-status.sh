ok 1 - setup
ok 2 - non-fast-forward fetch
ok 3 - forced update
# passed all 3 test(s)
1..3
