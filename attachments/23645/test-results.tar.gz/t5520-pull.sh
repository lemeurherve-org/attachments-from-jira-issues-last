ok 1 - setup
ok 2 - pulling into void
ok 3 - checking the results
ok 4 - pulling into void using master:master
ok 5 - pulling into void does not overwrite untracked files
ok 6 - test . as a remote
ok 7 - the default remote . should not break explicit pull
ok 8 - --rebase
ok 9 - pull.rebase
ok 10 - branch.to-rebase.rebase
ok 11 - branch.to-rebase.rebase should override pull.rebase
ok 12 - --rebase with rebased upstream
ok 13 - --rebase with rebased default upstream
ok 14 - rebased upstream + fetch + pull --rebase
ok 15 - pull --rebase dies early with dirty working directory
ok 16 - pull --rebase works on branch yet to be born
ok 17 - setup for detecting upstreamed changes
ok 18 - git pull --rebase detects upstreamed changes
ok 19 - setup for avoiding reapplying old patches
ok 20 - git pull --rebase does not reapply old patches
ok 21 - git pull --rebase against local branch
# passed all 21 test(s)
1..21
