ok 1 - setup
ok 2 - git pull -q
ok 3 - git pull
ok 4 - git pull -v
ok 5 - git pull -v -q
ok 6 - git pull -q -v
ok 7 - git pull --force
ok 8 - git pull --all
# passed all 8 test(s)
1..8
