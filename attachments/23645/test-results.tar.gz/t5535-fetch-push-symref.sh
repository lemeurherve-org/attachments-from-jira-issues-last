ok 1 - setup
ok 2 - push
ok 3 - fetch
# passed all 3 test(s)
1..3
