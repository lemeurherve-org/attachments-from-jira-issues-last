1..0 # SKIP git-daemon testing disabled (define GIT_TEST_GIT_DAEMON to enable)
