ok 1 - setup
ok 2 - clone -o
ok 3 - redirected clone
ok 4 - redirected clone -v
# passed all 4 test(s)
1..4
