ok 1 - setup
ok 2 - tags can be excluded by rev-list options
ok 3 - die if bundle file cannot be created
not ok 4 - bundle --stdin # TODO known breakage
not ok 5 - bundle --stdin <rev-list options> # TODO known breakage
ok 6 - empty bundle file is rejected
ok 7 - ridiculously long subject in boundary
# still have 2 known breakage(s)
# passed all remaining 5 test(s)
1..7
