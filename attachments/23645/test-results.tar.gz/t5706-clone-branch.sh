ok 1 - setup
ok 2 - vanilla clone chooses HEAD
ok 3 - clone -b chooses specified branch
ok 4 - clone -b sets up tracking
ok 5 - clone -b does not munge remotes/origin/HEAD
ok 6 - clone -b with bogus branch
# passed all 6 test(s)
1..6
