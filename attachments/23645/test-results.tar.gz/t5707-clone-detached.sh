ok 1 - setup
ok 2 - clone repo (detached HEAD points to branch)
ok 3 - cloned HEAD matches
not ok 4 - cloned HEAD is detached # TODO known breakage
ok 5 - clone repo (detached HEAD points to tag)
ok 6 - cloned HEAD matches
ok 7 - cloned HEAD is detached
ok 8 - clone repo (detached HEAD points to history)
ok 9 - cloned HEAD matches
ok 10 - cloned HEAD is detached
ok 11 - clone repo (orphan detached HEAD)
ok 12 - cloned HEAD matches
ok 13 - cloned HEAD is detached
# still have 1 known breakage(s)
# passed all remaining 12 test(s)
1..13
