ok 1 - preparing first repository
ok 2 - preparing second repository
ok 3 - preparing third repository
ok 4 - creating too deep nesting
ok 5 - invalidity of deepest repository
ok 6 - validity of third repository
ok 7 - validity of fourth repository
ok 8 - breaking of loops
ok 9 - that info/alternates is necessary
ok 10 - that relative alternate is possible for current dir
ok 11 - that relative alternate is only possible for current dir
# passed all 11 test(s)
1..11
