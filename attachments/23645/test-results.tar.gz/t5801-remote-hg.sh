1..0 # SKIP skipping git remote-hg tests: requires Python 2.4 or newer
