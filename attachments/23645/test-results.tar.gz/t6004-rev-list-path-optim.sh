ok 1 - setup
ok 2 - path-optimization
ok 3 - further setup
ok 4 - path optimization 2
ok 5 - pathspec with leading path
ok 6 - pathspec with glob (1)
ok 7 - pathspec with glob (2)
# passed all 7 test(s)
1..7
