ok 1 - setup
ok 2 - --left-right
ok 3 - --count
ok 4 - --cherry-pick foo comes up empty
ok 5 - --cherry-pick bar does not come up empty
ok 6 - bar does not come up empty
ok 7 - --cherry-pick bar does not come up empty (II)
ok 8 - --cherry-mark
ok 9 - --cherry-mark --left-right
ok 10 - --cherry-pick --right-only
ok 11 - --cherry-pick --left-only
ok 12 - --cherry
ok 13 - --cherry --count
ok 14 - --cherry-mark --count
ok 15 - --cherry-mark --left-right --count
ok 16 - --cherry-pick with independent, but identical branches
ok 17 - --count --left-right
# passed all 17 test(s)
1..17
