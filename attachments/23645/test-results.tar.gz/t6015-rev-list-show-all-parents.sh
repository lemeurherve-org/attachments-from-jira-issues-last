ok 1 - set up --show-all --parents test
ok 2 - --parents rewrites TREESAME parents correctly
ok 3 - --parents --show-all does not rewrites TREESAME parents
# passed all 3 test(s)
1..3
