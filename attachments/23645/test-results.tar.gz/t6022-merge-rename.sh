ok 1 - setup
ok 2 - pull renaming branch into unrenaming one
ok 3 - pull renaming branch into another renaming one
ok 4 - pull unrenaming branch into renaming one
ok 5 - pull conflicting renames
ok 6 - interference with untracked working tree file
ok 7 - interference with untracked working tree file
ok 8 - interference with untracked working tree file
ok 9 - updated working tree file should prevent the merge
ok 10 - updated working tree file should prevent the merge
ok 11 - interference with untracked working tree file
ok 12 - merge of identical changes in a renamed file
ok 13 - setup for rename + d/f conflicts
ok 14 - Rename+D/F conflict; renamed file merges + dir not in way
ok 15 - Rename+D/F conflict; renamed file merges but dir in way
ok 16 - Same as previous, but merged other way
ok 17 - Rename+D/F conflict; renamed file cannot merge, dir not in way
ok 18 - Rename+D/F conflict; renamed file cannot merge and dir in the way
ok 19 - Same as previous, but merged other way
ok 20 - setup both rename source and destination involved in D/F conflict
ok 21 - both rename source and destination involved in D/F conflict
ok 22 - setup pair rename to parent of other (D/F conflicts)
ok 23 - pair rename to parent of other (D/F conflicts) w/ untracked dir
ok 24 - pair rename to parent of other (D/F conflicts) w/ clean start
ok 25 - setup rename of one file to two, with directories in the way
ok 26 - check handling of differently renamed file with D/F conflicts
ok 27 - setup rename one file to two; directories moving out of the way
ok 28 - check handling of differently renamed file with D/F conflicts
ok 29 - setup avoid unnecessary update, normal rename
ok 30 - avoid unnecessary update, normal rename
ok 31 - setup to test avoiding unnecessary update, with D/F conflict
ok 32 - avoid unnecessary update, with D/F conflict
ok 33 - setup avoid unnecessary update, dir->(file,nothing)
ok 34 - avoid unnecessary update, dir->(file,nothing)
ok 35 - setup avoid unnecessary update, modify/delete
ok 36 - avoid unnecessary update, modify/delete
ok 37 - setup avoid unnecessary update, rename/add-dest
ok 38 - avoid unnecessary update, rename/add-dest
ok 39 - setup merge of rename + small change
ok 40 - merge rename + small change
ok 41 - setup for use of extended merge markers
ok 42 - merge master into rename has correct extended markers
ok 43 - merge rename into master has correct extended markers
ok 44 - setup spurious "refusing to lose untracked" message
ok 45 - no spurious "refusing to lose untracked" message
ok 46 - do not follow renames for empty files
# passed all 46 test(s)
1..46
