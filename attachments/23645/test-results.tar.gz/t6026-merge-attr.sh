ok 1 - setup
ok 2 - merge
ok 3 - check merge result in index
ok 4 - check merge result in working tree
ok 5 - retry the merge with longer context
ok 6 - custom merge backend
ok 7 - custom merge backend
ok 8 - up-to-date merge without common ancestor
# passed all 8 test(s)
1..8
