ok 1 - set up basic repo with 1 file (hello) and 4 commits
ok 2 - bisect starts with only one bad
ok 3 - bisect does not start with only one good
ok 4 - bisect start with one bad and good
ok 5 - bisect fails if given any junk instead of revs
ok 6 - bisect reset: back in the master branch
ok 7 - bisect reset: back in another branch
ok 8 - bisect reset when not bisecting
ok 9 - bisect reset removes packed refs
ok 10 - bisect reset removes bisect state after --no-checkout
ok 11 - bisect start: back in good branch
ok 12 - bisect start: no ".git/BISECT_START" created if junk rev
ok 13 - bisect start: existing ".git/BISECT_START" not modified if junk rev
ok 14 - bisect start: no ".git/BISECT_START" if mistaken rev
ok 15 - bisect start: no ".git/BISECT_START" if checkout error
ok 16 - bisect skip: successfull result
ok 17 - bisect skip: cannot tell between 3 commits
ok 18 - bisect skip: cannot tell between 2 commits
ok 19 - bisect skip: with commit both bad and skipped
ok 20 - "git bisect run" simple case
ok 21 - "git bisect run" with more complex "git bisect start"
ok 22 - bisect skip: add line and then a new test
ok 23 - bisect skip and bisect replay
ok 24 - bisect run & skip: cannot tell between 2
ok 25 - bisect run & skip: find first bad
ok 26 - bisect skip only one range
ok 27 - bisect skip many ranges
ok 28 - bisect starting with a detached HEAD
ok 29 - bisect errors out if bad and good are mistaken
ok 30 - bisect does not create a "bisect" branch
ok 31 - side branch creation
ok 32 - good merge base when good and bad are siblings
ok 33 - skipped merge base when good and bad are siblings
ok 34 - bad merge base when good and bad are siblings
ok 35 - many merge bases creation
ok 36 - good merge bases when good and bad are siblings
ok 37 - optimized merge base checks
ok 38 - "parallel" side branch creation
ok 39 - restricting bisection on one dir
ok 40 - restricting bisection on one dir and a file
ok 41 - skipping away from skipped commit
ok 42 - erroring out when using bad path parameters
ok 43 - test bisection on bare repo - --no-checkout specified
ok 44 - test bisection on bare repo - --no-checkout defaulted
ok 45 - broken branch creation
ok 46 - bisect fails if tree is broken on start commit
ok 47 - bisect fails if tree is broken on trial commit
ok 48 - bisect: --no-checkout - start commit bad
ok 49 - bisect: --no-checkout - trial commit bad
ok 50 - bisect: --no-checkout - target before breakage
ok 51 - bisect: --no-checkout - target in breakage
ok 52 - bisect: --no-checkout - target after breakage
ok 53 - bisect: demonstrate identification of damage boundary
# passed all 53 test(s)
1..53
