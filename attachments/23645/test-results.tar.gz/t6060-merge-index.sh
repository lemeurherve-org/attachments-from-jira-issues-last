ok 1 - setup diverging branches
ok 2 - read-tree does not resolve content merge
ok 3 - git merge-index git-merge-one-file resolves
ok 4 - setup bare merge
ok 5 - merge-one-file fails without a work tree
ok 6 - merge-one-file respects GIT_WORK_TREE
ok 7 - merge-one-file respects core.worktree
# passed all 7 test(s)
1..7
