ok 1 - listing all tags in an empty tree should succeed
ok 2 - listing all tags in an empty tree should output nothing
ok 3 - looking for a tag in an empty tree should fail
ok 4 - creating a tag in an empty tree should fail
ok 5 - creating a tag for HEAD in an empty tree should fail
ok 6 - creating a tag for an unknown revision should fail
ok 7 - creating a tag using default HEAD should succeed
ok 8 - listing all tags if one exists should succeed
ok 9 - listing all tags if one exists should output that tag
ok 10 - listing a tag using a matching pattern should succeed
ok 11 - listing a tag using a matching pattern should output that tag
ok 12 - listing tags using a non-matching pattern should suceed
ok 13 - listing tags using a non-matching pattern should output nothing
ok 14 - trying to create a tag with the name of one existing should fail
ok 15 - trying to create a tag with a non-valid name should fail
ok 16 - creating a tag using HEAD directly should succeed
ok 17 - trying to delete an unknown tag should fail
ok 18 - trying to delete tags without params should succeed and do nothing
ok 19 - deleting two existing tags in one command should succeed
ok 20 - creating a tag with the name of another deleted one should succeed
ok 21 - trying to delete two tags, existing and not, should fail in the 2nd
ok 22 - trying to delete an already deleted tag should fail
ok 23 - listing all tags should print them ordered
ok 24 - listing tags with substring as pattern must print those matching
ok 25 - listing tags with a suffix as pattern must print those matching
ok 26 - listing tags with a prefix as pattern must print those matching
ok 27 - listing tags using a name as pattern must print that one matching
ok 28 - listing tags using a name as pattern must print that one matching
ok 29 - listing tags with ? in the pattern should print those matching
ok 30 - listing tags using v.* should print nothing because none have v.
ok 31 - listing tags using v* should print only those having v
ok 32 - tag -l can accept multiple patterns
ok 33 - listing tags in column
ok 34 - listing tags in column with column.*
ok 35 - listing tag with -n --column should fail
ok 36 - listing tags -n in column with column.ui ignored
ok 37 - a non-annotated tag created without parameters should point to HEAD
ok 38 - trying to verify an unknown tag should fail
ok 39 - trying to verify a non-annotated and non-signed tag should fail
ok 40 - trying to verify many non-annotated or unknown tags, should fail
ok 41 - creating an annotated tag with -m message should succeed
ok 42 - creating an annotated tag with -F messagefile should succeed
ok 43 - creating an annotated tag with -F - should succeed
ok 44 - trying to create a tag with a non-existing -F file should fail
ok 45 - trying to create tags giving both -m or -F options should fail
ok 46 - creating a tag with an empty -m message should succeed
ok 47 - creating a tag with an empty -F messagefile should succeed
ok 48 - extra blanks in the message for an annotated tag should be removed
ok 49 - creating a tag with blank -m message with spaces should succeed
ok 50 - creating a tag with blank -F messagefile with spaces should succeed
ok 51 - creating a tag with -F file of spaces and no newline should succeed
ok 52 - creating a tag using a -F messagefile with #comments should succeed
ok 53 - creating a tag with a #comment in the -m message should succeed
ok 54 - creating a tag with #comments in the -F messagefile should succeed
ok 55 - creating a tag with a file of #comment and no newline should succeed
ok 56 - listing the one-line message of a non-signed tag should succeed
ok 57 - listing the zero-lines message of a non-signed tag should succeed
ok 58 - listing many message lines of a non-signed tag should succeed
ok 59 - annotations for blobs are empty
ok 60 - trying to verify an annotated non-signed tag should fail
ok 61 - trying to verify a file-annotated non-signed tag should fail
ok 62 - trying to verify two annotated non-signed tags should fail
ok 63 - creating a signed tag with -m message should succeed
ok 64 - sign with a given key id
ok 65 - sign with an unknown id (1)
ok 66 - sign with an unknown id (2)
ok 67 - -u implies signed tag
ok 68 - creating a signed tag with -F messagefile should succeed
ok 69 - creating a signed tag with -F - should succeed
ok 70 - -s implies annotated tag
ok 71 - trying to create a signed tag with non-existing -F file should fail
ok 72 - verifying a signed tag should succeed
ok 73 - verifying two signed tags in one command should succeed
ok 74 - verifying many signed and non-signed tags should fail
ok 75 - verifying a forged tag should fail
ok 76 - creating a signed tag with an empty -m message should succeed
ok 77 - creating a signed tag with an empty -F messagefile should succeed
ok 78 - extra blanks in the message for a signed tag should be removed
ok 79 - creating a signed tag with a blank -m message should succeed
ok 80 - creating a signed tag with blank -F file with spaces should succeed
ok 81 - creating a signed tag with spaces and no newline should succeed
ok 82 - creating a signed tag with a -F file with #comments should succeed
ok 83 - creating a signed tag with #commented -m message should succeed
ok 84 - creating a signed tag with #commented -F messagefile should succeed
ok 85 - creating a signed tag with a #comment and no newline should succeed
ok 86 - listing the one-line message of a signed tag should succeed
ok 87 - listing the zero-lines message of a signed tag should succeed
ok 88 - listing many message lines of a signed tag should succeed
ok 89 - creating a signed tag pointing to a tree should succeed
ok 90 - creating a signed tag pointing to a blob should succeed
ok 91 - creating a signed tag pointing to another tag should succeed
ok 92 - creating a signed tag with rfc1991
ok 93 - reediting a signed tag body omits signature
ok 94 - verifying rfc1991 signature
ok 95 - list tag with rfc1991 signature
ok 96 - verifying rfc1991 signature without --rfc1991
ok 97 - list tag with rfc1991 signature without --rfc1991
ok 98 - reediting a signed tag body omits signature
ok 99 - git tag -s fails if gpg is misconfigured
ok 100 - verify signed tag fails when public key is not present
ok 101 - git tag -a fails if tag annotation is empty
ok 102 - message in editor has initial comment
ok 103 - message in editor has initial comment: first line
ok 104 - message in editor has initial comment: remainder
ok 105 - overwriting an annoted tag should use its previous body
ok 106 - filename for the message is relative to cwd
ok 107 - filename for the message is relative to cwd
ok 108 - creating second commit and tag
ok 109 - creating third commit without tag
ok 110 - checking that first commit is in all tags (hash)
ok 111 - checking that first commit is in all tags (tag)
ok 112 - checking that first commit is in all tags (relative)
ok 113 - checking that second commit only has one tag
ok 114 - checking that third commit has no tags
ok 115 - creating simple branch
ok 116 - checking that branch head only has one tag
ok 117 - merging original branch into this branch
ok 118 - checking that original branch head has one tag now
ok 119 - checking that initial commit is in all tags
ok 120 - mixing incompatibles modes and options is forbidden
ok 121 - --points-at cannot be used in non-list mode
ok 122 - --points-at finds lightweight tags
ok 123 - --points-at finds annotated tags of commits
ok 124 - --points-at finds annotated tags of tags
ok 125 - multiple --points-at are OR-ed together
# passed all 125 test(s)
1..125
