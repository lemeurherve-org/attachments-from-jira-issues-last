ok 1 - determine default editor
ok 2 - setup
ok 3 - dumb should error out when falling back on vi
ok 4 - dumb should prefer EDITOR to VISUAL
ok 5 - Using vi
ok 6 - Using EDITOR
ok 7 - Using VISUAL
ok 8 - Using core_editor
ok 9 - Using GIT_EDITOR
ok 10 - Using vi (override)
ok 11 - Using EDITOR (override)
ok 12 - Using VISUAL (override)
ok 13 - Using core_editor (override)
ok 14 - Using GIT_EDITOR (override)
ok 15 - editor with a space
ok 16 - core.editor with a space
# passed all 16 test(s)
1..16
