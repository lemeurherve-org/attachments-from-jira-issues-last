ok 1 - setup
ok 2 - read-tree updates worktree, absent case
ok 3 - read-tree updates worktree, dirty case
ok 4 - read-tree removes worktree, absent case
ok 5 - read-tree removes worktree, dirty case
ok 6 - index setup
ok 7 - git-add ignores worktree content
ok 8 - git-add ignores worktree content
ok 9 - git-rm fails if worktree is dirty
ok 10 - git-clean, absent case
ok 11 - git-clean, dirty case
# passed all 11 test(s)
1..11
