ok 1 - status untracked directory with --ignored
ok 2 - status untracked directory with --ignored -u
ok 3 - status ignored directory with --ignore
ok 4 - status ignored directory with --ignore -u
ok 5 - status untracked directory with ignored files with --ignore
ok 6 - status untracked directory with ignored files with --ignore -u
ok 7 - status ignored tracked directory with --ignore
ok 8 - status ignored tracked directory with --ignore -u
ok 9 - status ignored tracked directory and uncommitted file with --ignore
ok 10 - status ignored tracked directory and uncommitted file with --ignore -u
# passed all 10 test(s)
1..10
