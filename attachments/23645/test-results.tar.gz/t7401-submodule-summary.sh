not ok - 1 added submodule
#	
#		git add sm1 &&
#		git submodule summary >actual &&
#		cat >expected <<-EOF &&
#	* sm1 0000000...a2c4dab (2):
#	  > Add foo2
#	
#	EOF
#		test_cmp expected actual
#	
not ok - 2 modified submodule(forward)
#	
#		git submodule summary >actual &&
#		cat >expected <<-EOF &&
#	* sm1 a2c4dab...4c8d358 (1):
#	  > Add foo3
#	
#	EOF
#		test_cmp expected actual
#	
not ok - 3 modified submodule(forward), --files
#	
#		git submodule summary --files >actual &&
#		cat >expected <<-EOF &&
#	* sm1 a2c4dab...4c8d358 (1):
#	  > Add foo3
#	
#	EOF
#		test_cmp expected actual
#	
not ok - 4 modified submodule(backward)
#	
#	    git submodule summary >actual &&
#	    cat >expected <<-EOF &&
#	* sm1 4c8d358...db425b6 (2):
#	  < Add foo3
#	  < Add foo2
#	
#	EOF
#		test_cmp expected actual
#	
not ok - 5 modified submodule(backward and forward)
#	
#	    git submodule summary >actual &&
#	    cat >expected <<-EOF &&
#	* sm1 4c8d358...41fbea9 (4):
#	  > Add foo5
#	  > Add foo4
#	  < Add foo3
#	  < Add foo2
#	
#	EOF
#		test_cmp expected actual
#	
not ok - 6 --summary-limit
#	
#	    git submodule summary -n 3 >actual &&
#	    cat >expected <<-EOF &&
#	* sm1 4c8d358...41fbea9 (4):
#	  > Add foo5
#	  > Add foo4
#	  < Add foo3
#	
#	EOF
#	    test_cmp expected actual
#	
ok 7 - typechanged submodule(submodule->blob), --cached
ok 8 - typechanged submodule(submodule->blob), --files
ok 9 - typechanged submodule(submodule->blob)
ok 10 - nonexistent commit
ok 11 - typechanged submodule(blob->submodule)
not ok - 12 deleted submodule
#	
#	    git submodule summary >actual &&
#	    cat >expected <<-EOF &&
#	* sm1 6858906...0000000:
#	
#	EOF
#	    test_cmp expected actual
#	
not ok - 13 multiple submodules
#	
#	    git submodule summary >actual &&
#	    cat >expected <<-EOF &&
#	* sm1 6858906...0000000:
#	
#	* sm2 0000000...fa9eeaf (2):
#	  > Add foo9
#	
#	EOF
#	    test_cmp expected actual
#	
not ok - 14 path filter
#	
#	    git submodule summary sm2 >actual &&
#	    cat >expected <<-EOF &&
#	* sm2 0000000...fa9eeaf (2):
#	  > Add foo9
#	
#	EOF
#	    test_cmp expected actual
#	
not ok - 15 given commit
#	
#	    git submodule summary HEAD^ >actual &&
#	    cat >expected <<-EOF &&
#	* sm1 6858906...0000000:
#	
#	* sm2 0000000...fa9eeaf (2):
#	  > Add foo9
#	
#	EOF
#	    test_cmp expected actual
#	
not ok - 16 --for-status
#	
#	    git submodule summary --for-status HEAD^ >actual &&
#	    test_i18ncmp actual - <<EOF
#	# Submodule changes to be committed:
#	#
#	# * sm1 6858906...0000000:
#	#
#	# * sm2 0000000...fa9eeaf (2):
#	#   > Add foo9
#	#
#	EOF
#	
ok 17 - fail when using --files together with --cached
ok 18 - should not fail in an empty repo
# failed 11 among 18 test(s)
1..18
