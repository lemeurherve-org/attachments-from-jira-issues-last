ok 1 - setup
ok 2 - change submodule
ok 3 - change submodule url
ok 4 - "git submodule sync" should update submodule URLs
ok 5 - "git submodule sync --recursive" should update all submodule URLs
ok 6 - "git submodule sync" should update known submodule URLs
ok 7 - "git submodule sync" should not vivify uninteresting submodule
ok 8 - "git submodule sync" handles origin URL of the form foo
ok 9 - "git submodule sync" handles origin URL of the form foo/bar
ok 10 - "git submodule sync --recursive" propagates changes in origin
ok 11 - "git submodule sync" handles origin URL of the form ./foo
ok 12 - "git submodule sync" handles origin URL of the form ./foo/bar
ok 13 - "git submodule sync" handles origin URL of the form ../foo
ok 14 - "git submodule sync" handles origin URL of the form ../foo/bar
ok 15 - "git submodule sync" handles origin URL of the form ../foo/bar with deeply nested submodule
# passed all 15 test(s)
1..15
