ok 1 - setup
ok 2 - setup for merge search
ok 3 - merge with one side as a fast-forward of the other
ok 4 - merging should conflict for non fast-forward
ok 5 - merging should fail for ambiguous common parent
ok 6 - merging should fail for changes that are backwards
not ok - 7 git submodule status should display the merge conflict properly with merge base
#	
#	       (cd merge-search &&
#	       cat >.gitmodules <<EOF &&
#	[submodule "sub"]
#	       path = sub
#	       url = $TRASH_DIRECTORY/sub
#	EOF
#	       cat >expect <<EOF &&
#	U0000000000000000000000000000000000000000 sub
#	EOF
#	       git submodule status > actual &&
#	       test_cmp expect actual &&
#		git reset --hard)
#	
not ok - 8 git submodule status should display the merge conflict properly without merge-base
#	
#	       (cd merge-search &&
#		git checkout -b test-no-merge-base g &&
#		test_must_fail git merge b &&
#	       cat >.gitmodules <<EOF &&
#	[submodule "sub"]
#	       path = sub
#	       url = $TRASH_DIRECTORY/sub
#	EOF
#	       cat >expect <<EOF &&
#	U0000000000000000000000000000000000000000 sub
#	EOF
#	       git submodule status > actual &&
#	       test_cmp expect actual &&
#	       git reset --hard)
#	
ok 9 - merging with a modify/modify conflict between merge bases
ok 10 - setup for recursive merge with submodule
ok 11 - recursive merge with submodule
# failed 2 among 11 test(s)
1..11
