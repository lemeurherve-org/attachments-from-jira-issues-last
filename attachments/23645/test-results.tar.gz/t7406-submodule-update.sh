ok 1 - setup a submodule tree
ok 2 - submodule update detaching the HEAD 
ok 3 - submodule update does not fetch already present commits
ok 4 - submodule update should fail due to local changes
ok 5 - submodule update should throw away changes with --force 
ok 6 - submodule update --force forcibly checks out submodules
ok 7 - submodule update --rebase staying on master
ok 8 - submodule update --merge staying on master
ok 9 - submodule update - rebase in .git/config
ok 10 - submodule update - checkout in .git/config but --rebase given
ok 11 - submodule update - merge in .git/config
ok 12 - submodule update - checkout in .git/config but --merge given
ok 13 - submodule update - checkout in .git/config
ok 14 - submodule init picks up rebase
ok 15 - submodule init picks up merge
ok 16 - submodule update --merge  - ignores --merge  for new submodules
ok 17 - submodule update --rebase - ignores --rebase for new submodules
ok 18 - submodule update ignores update=merge config for new submodules
ok 19 - submodule update ignores update=rebase config for new submodules
ok 20 - submodule init picks up update=none
ok 21 - submodule update - update=none in .git/config
ok 22 - submodule update - update=none in .git/config but --checkout given
ok 23 - submodule update --init skips submodule with update=none
ok 24 - submodule update continues after checkout error
ok 25 - submodule update continues after recursive checkout error
ok 26 - submodule update exit immediately in case of merge conflict
ok 27 - submodule update exit immediately after recursive rebase error
ok 28 - add different submodules to the same path
ok 29 - submodule add places git-dir in superprojects git-dir
ok 30 - submodule update places git-dir in superprojects git-dir
ok 31 - submodule add places git-dir in superprojects git-dir recursive
ok 32 - submodule update places git-dir in superprojects git-dir recursive
ok 33 - submodule add properly re-creates deeper level submodules
ok 34 - submodule update properly revives a moved submodule
ok 35 # skip submodule update can handle symbolic links in pwd (missing SYMLINKS)
# passed all 35 test(s)
1..35
