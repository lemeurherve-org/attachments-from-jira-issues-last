ok 1 - preparing first repository
ok 2 - preparing second repository
ok 3 - preparing superproject
ok 4 - submodule add --reference
ok 5 - after add: existence of info/alternates
ok 6 - that reference gets used with add
ok 7 - cloning superproject
ok 8 - update with reference
ok 9 - after update: existence of info/alternates
ok 10 - that reference gets used with update
# passed all 10 test(s)
1..10
