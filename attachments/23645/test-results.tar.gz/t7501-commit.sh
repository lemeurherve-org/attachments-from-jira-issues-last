ok 1 - initial status
ok 2 - fail initial amend
ok 3 - setup: initial commit
ok 4 - -m and -F do not mix
ok 5 - -m and -C do not mix
ok 6 - paths and -a do not mix
ok 7 - can use paths with --interactive
ok 8 - using invalid commit with -C
ok 9 - nothing to commit
ok 10 - setup: non-initial commit
ok 11 - commit message from non-existing file
ok 12 - empty commit message
ok 13 - template "emptyness" check does not kick in with -F
ok 14 - template "emptyness" check
ok 15 - setup: commit message from file
ok 16 - amend commit
ok 17 - amend --only ignores staged contents
ok 18 - set up editor
ok 19 - amend without launching editor
ok 20 - --amend --edit
ok 21 - --amend --edit of empty message
ok 22 - -m --edit
ok 23 - -m and -F do not mix
ok 24 - using message from other commit
ok 25 - editing message from other commit
ok 26 - message from stdin
ok 27 - overriding author from command line
ok 28 - interactive add
ok 29 - commit --interactive doesn't change index if editor aborts
ok 30 - editor not invoked if -F is given
ok 31 - partial commit that involves removal (1)
ok 32 - partial commit that involves removal (2)
ok 33 - partial commit that involves removal (3)
ok 34 - amend commit to fix author
ok 35 - amend commit to fix date
ok 36 - commit complains about bogus date
ok 37 - sign off (1)
ok 38 - sign off (2)
ok 39 - signoff gap
ok 40 - signoff gap 2
ok 41 - multiple -m
ok 42 - amend commit to fix author
ok 43 - git commit <file> with dirty index
ok 44 - same tree (single parent)
ok 45 - same tree (single parent) --allow-empty
ok 46 - same tree (merge and amend merge)
ok 47 - amend using the message from another commit
ok 48 - amend using the message from a commit named with tag
ok 49 - amend can copy notes
ok 50 - commit a file whose name is a dash
# passed all 50 test(s)
1..50
