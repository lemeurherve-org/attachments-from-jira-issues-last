ok 1 - output summary format
ok 2 - output summary format: root-commit
ok 3 - output summary format for commit with an empty diff
ok 4 - output summary format for merges
ok 5 - the basics
ok 6 - partial
ok 7 - partial modification in a subdirectory
ok 8 - partial removal
ok 9 - sign off
ok 10 - multiple -m
ok 11 - verbose
ok 12 - verbose respects diff config
ok 13 - cleanup commit messages (verbatim,-t)
ok 14 - cleanup commit messages (verbatim,-F)
ok 15 - cleanup commit messages (verbatim,-m)
ok 16 - cleanup commit messages (whitespace,-F)
ok 17 - cleanup commit messages (strip,-F)
ok 18 - cleanup commit messages (strip,-F,-e)
ok 19 - cleanup commit messages (strip,-F,-e): output
ok 20 - message shows author when it is not equal to committer
ok 21 # skip message shows committer when it is automatic (missing AUTOIDENT)
ok 22 - do not fire editor when committer is bogus
ok 23 - do not fire editor in the presence of conflicts
ok 24 # skip a SIGTERM should break locks (missing EXECKEEPSPID)
ok 25 - Hand committing of a redundant merge removes dups
ok 26 - A single-liner subject with a token plus colon is not a footer
ok 27 - commit
ok 28 - commit
ok 29 - commit --status
ok 30 - commit --no-status
ok 31 - commit with commit.status = yes
ok 32 - commit with commit.status = no
ok 33 - commit --status with commit.status = yes
ok 34 - commit --no-status with commit.status = yes
ok 35 - commit --status with commit.status = no
ok 36 - commit --no-status with commit.status = no
ok 37 - commit
ok 38 - commit
ok 39 - commit --status
ok 40 - commit --no-status
ok 41 - commit with commit.status = yes
ok 42 - commit with commit.status = no
ok 43 - commit --status with commit.status = yes
ok 44 - commit --no-status with commit.status = yes
ok 45 - commit --status with commit.status = no
ok 46 - commit --no-status with commit.status = no
# passed all 46 test(s)
1..46
