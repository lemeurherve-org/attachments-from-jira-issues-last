ok 1 - status -h in broken repository
ok 2 - commit -h in broken repository
ok 3 - setup
ok 4 - status (1)
ok 5 - status --column
ok 6 - status (2)
ok 7 - status (advice.statusHints false)
ok 8 - status -s
ok 9 - status with gitignore
ok 10 - status with gitignore (nothing untracked)
ok 11 - status -s -b
ok 12 - status -s -z -b
ok 13 - setup dir3
ok 14 - status -uno
ok 15 - status (status.showUntrackedFiles no)
ok 16 - status -uno (advice.statusHints false)
ok 17 - status -s -uno
ok 18 - status -s (status.showUntrackedFiles no)
ok 19 - status -unormal
ok 20 - status (status.showUntrackedFiles normal)
ok 21 - status -s -unormal
ok 22 - status -s (status.showUntrackedFiles normal)
ok 23 - status -uall
ok 24 - status (status.showUntrackedFiles all)
ok 25 - teardown dir3
ok 26 - status -s -uall
ok 27 - status -s (status.showUntrackedFiles all)
ok 28 - status with relative paths
ok 29 - status -s with relative paths
ok 30 - status --porcelain ignores relative paths setting
ok 31 - setup unique colors
ok 32 - status with color.ui
ok 33 - status with color.status
ok 34 - status -s with color.ui
ok 35 - status -s with color.status
ok 36 - status -s -b with color.status
ok 37 - status --porcelain ignores color.ui
ok 38 - status --porcelain ignores color.status
ok 39 - status --porcelain respects -b
ok 40 - status without relative paths
ok 41 - status -s without relative paths
ok 42 - dry-run of partial commit excluding new file in index
ok 43 - status refreshes the index
ok 44 - setup status submodule summary
ok 45 - status submodule summary is disabled by default
ok 46 - status --untracked-files=all does not show submodule
ok 47 - status -s submodule summary is disabled by default
ok 48 - status -s --untracked-files=all does not show submodule
ok 49 - status submodule summary
ok 50 - status -s submodule summary
ok 51 - status submodule summary (clean submodule): commit
ok 52 - status -s submodule summary (clean submodule)
ok 53 - status -z implies porcelain
ok 54 - commit --dry-run submodule summary (--amend)
ok 55 # skip status succeeds in a read-only repository (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
ok 56 - --ignore-submodules=untracked suppresses submodules with untracked content
ok 57 - .gitmodules ignore=untracked suppresses submodules with untracked content
ok 58 - .git/config ignore=untracked suppresses submodules with untracked content
ok 59 - --ignore-submodules=dirty suppresses submodules with untracked content
ok 60 - .gitmodules ignore=dirty suppresses submodules with untracked content
ok 61 - .git/config ignore=dirty suppresses submodules with untracked content
ok 62 - --ignore-submodules=dirty suppresses submodules with modified content
ok 63 - .gitmodules ignore=dirty suppresses submodules with modified content
ok 64 - .git/config ignore=dirty suppresses submodules with modified content
ok 65 - --ignore-submodules=untracked doesn't suppress submodules with modified content
ok 66 - .gitmodules ignore=untracked doesn't suppress submodules with modified content
ok 67 - .git/config ignore=untracked doesn't suppress submodules with modified content
ok 68 - --ignore-submodules=untracked doesn't suppress submodule summary
ok 69 - .gitmodules ignore=untracked doesn't suppress submodule summary
ok 70 - .git/config ignore=untracked doesn't suppress submodule summary
ok 71 - --ignore-submodules=dirty doesn't suppress submodule summary
ok 72 - .gitmodules ignore=dirty doesn't suppress submodule summary
ok 73 - .git/config ignore=dirty doesn't suppress submodule summary
ok 74 - --ignore-submodules=all suppresses submodule summary
not ok 75 - .gitmodules ignore=all suppresses submodule summary # TODO known breakage
not ok 76 - .git/config ignore=all suppresses submodule summary # TODO known breakage
# still have 2 known breakage(s)
# passed all remaining 74 test(s)
1..76
