ok 1 - prepare for conflicts
ok 2 - status when conflicts unresolved
ok 3 - status when conflicts resolved before commit
ok 4 - prepare for rebase conflicts
ok 5 - status when rebase in progress before resolving conflicts
ok 6 - status when rebase in progress before rebase --continue
ok 7 - prepare for rebase_i_conflicts
ok 8 - status during rebase -i when conflicts unresolved
ok 9 - status during rebase -i after resolving conflicts
ok 10 - status when rebasing -i in edit mode
ok 11 - status when splitting a commit
ok 12 - status after editing the last commit with --amend during a rebase -i
ok 13 - prepare for several edits
ok 14 - status: (continue first edit) second edit
ok 15 - status: (continue first edit) second edit and split
ok 16 - status: (continue first edit) second edit and amend
ok 17 - status: (amend first edit) second edit
ok 18 - status: (amend first edit) second edit and split
ok 19 - status: (amend first edit) second edit and amend
ok 20 - status: (split first edit) second edit
ok 21 - status: (split first edit) second edit and split
ok 22 - status: (split first edit) second edit and amend
ok 23 - prepare am_session
ok 24 - status in an am session: file already exists
ok 25 - status in an am session: file does not exist
ok 26 - status in an am session: empty patch
ok 27 - status when bisecting
ok 28 - status when rebase conflicts with statushints disabled
ok 29 - prepare for cherry-pick conflicts
ok 30 - status when cherry-picking before resolving conflicts
ok 31 - status when cherry-picking after resolving conflicts
# passed all 31 test(s)
1..31
