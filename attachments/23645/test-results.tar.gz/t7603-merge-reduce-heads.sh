ok 1 - setup
ok 2 - merge c1 with c2, c3, c4, c5
ok 3 - pull c2, c3, c4, c5 into c1
ok 4 - setup
ok 5 - merge E and I
ok 6 - verify merge result
ok 7 - add conflicts
ok 8 - merge E2 and I2, causing a conflict and resolve it
ok 9 - verify merge result
ok 10 - fast-forward to redundant refs
ok 11 - verify merge result
ok 12 - merge up-to-date redundant refs
ok 13 - verify merge result
# passed all 13 test(s)
1..13
