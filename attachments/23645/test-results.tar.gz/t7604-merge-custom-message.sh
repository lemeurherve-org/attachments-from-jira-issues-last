ok 1 - setup
ok 2 - merge c2 with a custom message
ok 3 - merge --log appends to custom message
# passed all 3 test(s)
1..3
