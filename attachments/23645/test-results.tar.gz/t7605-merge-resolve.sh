ok 1 - setup
ok 2 - merge c1 to c2
ok 3 - merge c2 to c3 (fails)
# passed all 3 test(s)
1..3
