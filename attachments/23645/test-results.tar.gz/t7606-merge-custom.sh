ok 1 - set up custom strategy
ok 2 - setup
ok 3 - merge c2 with a custom strategy
ok 4 - trivial merge with custom strategy
# passed all 4 test(s)
1..4
