ok 1 - setup
ok 2 - will not overwrite untracked file
ok 3 - will overwrite tracked file
ok 4 - will not overwrite new file
ok 5 - will not overwrite staged changes
ok 6 - will not overwrite removed file
ok 7 - will not overwrite re-added file
ok 8 - will not overwrite removed file with staged changes
not ok 9 - will not overwrite unstaged changes in renamed file # TODO known breakage
ok 10 - will not overwrite untracked subtree
ok 11 - will not overwrite untracked file in leading path
ok 12 # skip will not overwrite untracked symlink in leading path (missing SYMLINKS)
ok 13 # skip will not be confused by symlink in leading path (missing SYMLINKS)
ok 14 - will not overwrite untracked file on unborn branch
ok 15 - will not overwrite untracked file on unborn branch .git/MERGE_HEAD sanity etc.
ok 16 - failed merge leaves unborn branch in the womb
ok 17 - set up unborn branch and content
ok 18 - will not clobber WT/index when merging into unborn
# still have 1 known breakage(s)
# passed all remaining 17 test(s)
1..18
