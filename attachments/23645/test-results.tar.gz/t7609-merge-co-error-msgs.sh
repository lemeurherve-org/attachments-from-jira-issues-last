ok 1 - setup
ok 2 - untracked files overwritten by merge (fast and non-fast forward)
ok 3 - untracked files or local changes ovewritten by merge
ok 4 - cannot switch branches because of local changes
ok 5 - not uptodate file porcelain checkout error
ok 6 - not_uptodate_dir porcelain checkout error
# passed all 6 test(s)
1..6
