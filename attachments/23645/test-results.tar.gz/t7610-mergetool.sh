ok 1 - setup
ok 2 - custom mergetool
ok 3 - mergetool crlf
ok 4 - mergetool in subdir
ok 5 - mergetool on file in parent dir
ok 6 - mergetool skips autoresolved
ok 7 - mergetool merges all from subdir
ok 8 - mergetool skips resolved paths when rerere is active
ok 9 - conflicted stash sets up rerere
ok 10 - mergetool takes partial path
ok 11 - deleted vs modified submodule
ok 12 - file vs modified submodule
ok 13 - submodule in subdirectory
ok 14 - directory vs modified submodule
ok 15 - file with no base
ok 16 - custom commands override built-ins
# passed all 16 test(s)
1..16
