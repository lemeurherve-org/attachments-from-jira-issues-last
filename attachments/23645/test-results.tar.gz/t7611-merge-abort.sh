ok 1 - setup
ok 2 - fails without MERGE_HEAD (unstarted merge)
ok 3 - fails without MERGE_HEAD (unstarted merge): .git/MERGE_HEAD sanity
ok 4 - fails without MERGE_HEAD (completed merge)
ok 5 - fails without MERGE_HEAD (completed merge): .git/MERGE_HEAD sanity
ok 6 - Forget previous merge
ok 7 - Abort after --no-commit
ok 8 - Abort after conflicts
ok 9 - Clean merge with dirty index fails
ok 10 - Conflicting merge with dirty index fails
ok 11 - Reset index (but preserve worktree changes)
ok 12 - Abort clean merge with non-conflicting dirty worktree
ok 13 - Abort conflicting merge with non-conflicting dirty worktree
ok 14 - Reset worktree changes
ok 15 - Fail clean merge with conflicting dirty worktree
ok 16 - Fail conflicting merge with conflicting dirty worktree
ok 17 - Reset worktree changes
ok 18 - Fail clean merge with matching dirty worktree
ok 19 - Abort clean merge with matching dirty index
ok 20 - Reset worktree changes
ok 21 - Fail conflicting merge with matching dirty worktree
ok 22 - Abort conflicting merge with matching dirty index
ok 23 - Reset worktree changes
ok 24 - Abort merge with pre- and post-merge worktree changes
ok 25 - Reset worktree changes
ok 26 - Abort merge with pre- and post-merge index changes
# passed all 26 test(s)
1..26
