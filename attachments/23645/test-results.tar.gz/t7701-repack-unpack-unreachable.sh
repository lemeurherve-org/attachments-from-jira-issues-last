ok 1 - -A with -d option leaves unreachable objects unpacked
ok 2 - -A without -d option leaves unreachable objects packed
ok 3 - unpacked objects receive timestamp of pack file
ok 4 - do not bother loosening old objects
# passed all 4 test(s)
1..4
