ok 1 - setup
ok 2 - custom commands
ok 3 - custom commands override built-ins
ok 4 - difftool ignores bad --tool values
ok 5 - difftool forwards arguments to diff
ok 6 - difftool honors --gui
ok 7 - difftool --gui last setting wins
ok 8 - difftool --gui works without configured diff.guitool
ok 9 - GIT_DIFF_TOOL variable
ok 10 - GIT_DIFF_TOOL overrides
ok 11 - GIT_DIFFTOOL_NO_PROMPT variable
ok 12 - GIT_DIFFTOOL_PROMPT variable
ok 13 - difftool.prompt config variable is false
ok 14 - difftool merge.prompt = false
ok 15 - difftool.prompt can overridden with -y
ok 16 - difftool.prompt can overridden with --prompt
ok 17 - difftool last flag wins
ok 18 - difftool + mergetool config variables
ok 19 - difftool.<tool>.path
ok 20 - difftool --extcmd=cat
ok 21 - difftool --extcmd cat
ok 22 - difftool -x cat
ok 23 - difftool --extcmd echo arg1
ok 24 - difftool --extcmd cat arg1
ok 25 - difftool --extcmd cat arg2
ok 26 - setup with 2 files different
ok 27 - say no to the first file
ok 28 - say no to the second file
ok 29 - difftool --tool-help
ok 30 - setup change in subdirectory
ok 31 - difftool -d
ok 32 - difftool --dir-diff
ok 33 - difftool --dir-diff ignores --prompt
ok 34 - difftool --dir-diff from subdirectory
# passed all 34 test(s)
1..34
