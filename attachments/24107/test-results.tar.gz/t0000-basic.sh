ok 1 - .git/objects should be empty after git init in an empty repo
ok 2 - .git/objects should have 3 subdirectories
ok 3 - success is reported like this
not ok 4 - pretend we have a known breakage # TODO known breakage
ok 5 - pretend we have a fully passing test suite
ok 6 - pretend we have a partially passing test suite
ok 7 - pretend we have a known breakage
ok 8 - pretend we have fixed a known breakage
ok 9 - pretend we have fixed one of two known breakages (run in sub test-lib)
ok 10 - pretend we have a pass, fail, and known breakage
ok 11 - pretend we have a mix of all possible results
ok 12 - test runs if prerequisite is satisfied
ok 13 # skip unmet prerequisite causes test to be skipped (missing DONTHAVEIT)
ok 14 - test runs if prerequisites are satisfied
ok 15 # skip unmet prerequisites causes test to be skipped (missing DONTHAVEIT of HAVEIT,DONTHAVEIT)
ok 16 # skip unmet prerequisites causes test to be skipped (missing DONTHAVEIT of DONTHAVEIT,HAVEIT)
ok 17 - test runs if lazy prereq is satisfied
ok 18 # skip missing lazy prereqs skip tests (missing !LAZY_TRUE)
ok 19 - negative lazy prereqs checked
ok 20 # skip missing negative lazy prereqs will skip (missing LAZY_FALSE)
ok 21 - tests clean up after themselves
ok 22 - tests clean up even on failures
ok 23 - git update-index without --add should fail adding
ok 24 - git update-index with --add should succeed
ok 25 - writing tree out with git write-tree
ok 26 - validate object ID of a known tree
ok 27 - git update-index without --remove should fail removing
ok 28 - git update-index with --remove should be able to remove
ok 29 - git write-tree should be able to write an empty tree
ok 30 - validate object ID of a known tree
ok 31 - adding various types of objects with git update-index --add
ok 32 - showing stage with git ls-files --stage
ok 33 - validate git ls-files output for a known tree
ok 34 - writing tree out with git write-tree
ok 35 - validate object ID for a known tree
ok 36 - showing tree with git ls-tree
ok 37 # skip git ls-tree output for a known tree (missing SYMLINKS)
ok 38 - showing tree with git ls-tree -r
ok 39 - git ls-tree -r output for a known tree
ok 40 - showing tree with git ls-tree -r -t
ok 41 # skip git ls-tree -r output for a known tree (missing SYMLINKS)
ok 42 - writing partial tree out with git write-tree --prefix
ok 43 - validate object ID for a known tree
ok 44 - writing partial tree out with git write-tree --prefix
ok 45 - validate object ID for a known tree
ok 46 - put invalid objects into the index
ok 47 - writing this tree without --missing-ok
ok 48 - writing this tree with --missing-ok
ok 49 - git read-tree followed by write-tree should be idempotent
ok 50 - validate git diff-files output for a know cache/work tree state
ok 51 - git update-index --refresh should succeed
ok 52 - no diff after checkout and git update-index --refresh
ok 53 - git commit-tree records the correct tree in a commit
ok 54 - git commit-tree records the correct parent in a commit
ok 55 - git commit-tree omits duplicated parent in a commit
ok 56 - update-index D/F conflict
ok 57 - very long name in the index handled sanely
# still have 1 known breakage(s)
# passed all remaining 56 test(s)
1..57
