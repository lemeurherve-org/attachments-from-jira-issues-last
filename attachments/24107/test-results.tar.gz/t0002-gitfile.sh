ok 1 - initial setup
ok 2 - bad setup: invalid .git file format
ok 3 - bad setup: invalid .git file path
ok 4 - final setup + check rev-parse --git-dir
ok 5 - check hash-object
ok 6 - check cat-file
ok 7 - check update-index
ok 8 - check write-tree
ok 9 - check commit-tree
ok 10 - check rev-list
# passed all 10 test(s)
1..10
