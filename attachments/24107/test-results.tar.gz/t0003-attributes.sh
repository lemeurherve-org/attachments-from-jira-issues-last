ok 1 - setup
ok 2 - command line checks
ok 3 - attribute test
ok 4 - attribute matching is case sensitive when core.ignorecase=0
ok 5 - attribute matching is case insensitive when core.ignorecase=1
ok 6 - additional case insensitivity tests
ok 7 - unnormalized paths
ok 8 - relative paths
ok 9 - prefixes are not confused with leading directories
ok 10 - core.attributesfile
ok 11 - attribute test: read paths from stdin
ok 12 - attribute test: --all option
ok 13 - attribute test: --cached option
ok 14 - root subdir attribute test
ok 15 - negative patterns
ok 16 - patterns starting with exclamation
ok 17 - "**" test
ok 18 - "**" with no slashes test
ok 19 - setup bare
ok 20 - bare repository: check that .gitattribute is ignored
ok 21 - bare repository: check that --cached honors index
ok 22 - bare repository: test info/attributes
# passed all 22 test(s)
1..22
