ok 1 - sigchain works
# passed all 1 test(s)
1..1
