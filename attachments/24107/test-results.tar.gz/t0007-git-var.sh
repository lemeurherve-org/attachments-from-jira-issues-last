ok 1 - get GIT_AUTHOR_IDENT
ok 2 - get GIT_COMMITTER_IDENT
ok 3 - requested identites are strict
ok 4 - git var -l lists variables
ok 5 - git var -l lists config
ok 6 - listing and asking for variables are exclusive
# passed all 6 test(s)
1..6
