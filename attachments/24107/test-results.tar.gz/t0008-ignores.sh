ok 1 - setup
ok 2 - . corner-case
ok 3 - . corner-case with -q
ok 4 - . corner-case with --quiet
ok 5 - . corner-case with -v
ok 6 - . corner-case with --verbose
ok 7 - empty command line
ok 8 - empty command line with -q
ok 9 - empty command line with --quiet
ok 10 - empty command line with -v
ok 11 - empty command line with --verbose
ok 12 - --stdin with empty STDIN
ok 13 - --stdin with empty STDIN with -q
ok 14 - --stdin with empty STDIN with --quiet
ok 15 - --stdin with empty STDIN with -v
ok 16 - --stdin with empty STDIN with --verbose
ok 17 - -q with multiple args
ok 18 - --quiet with multiple args
ok 19 - -q -v
ok 20 - --quiet -v
ok 21 - -q --verbose
ok 22 - --quiet --verbose
ok 23 - --quiet with multiple args
ok 24 - erroneous use of --
ok 25 - erroneous use of -- with -q
ok 26 - erroneous use of -- with --quiet
ok 27 - erroneous use of -- with -v
ok 28 - erroneous use of -- with --verbose
ok 29 - --stdin with superfluous arg
ok 30 - --stdin with superfluous arg with -q
ok 31 - --stdin with superfluous arg with --quiet
ok 32 - --stdin with superfluous arg with -v
ok 33 - --stdin with superfluous arg with --verbose
ok 34 - --stdin -z with superfluous arg
ok 35 - --stdin -z with superfluous arg with -q
ok 36 - --stdin -z with superfluous arg with --quiet
ok 37 - --stdin -z with superfluous arg with -v
ok 38 - --stdin -z with superfluous arg with --verbose
ok 39 - -z without --stdin
ok 40 - -z without --stdin with -q
ok 41 - -z without --stdin with --quiet
ok 42 - -z without --stdin with -v
ok 43 - -z without --stdin with --verbose
ok 44 - -z without --stdin and superfluous arg
ok 45 - -z without --stdin and superfluous arg with -q
ok 46 - -z without --stdin and superfluous arg with --quiet
ok 47 - -z without --stdin and superfluous arg with -v
ok 48 - -z without --stdin and superfluous arg with --verbose
ok 49 - needs work tree
ok 50 - needs work tree with -q
ok 51 - needs work tree with --quiet
ok 52 - needs work tree with -v
ok 53 - needs work tree with --verbose
ok 54 - non-existent file at top-level not ignored
ok 55 - non-existent file at top-level not ignored with -q
ok 56 - non-existent file at top-level not ignored with --quiet
ok 57 - non-existent file at top-level not ignored with -v
ok 58 - non-existent file at top-level not ignored with --verbose
ok 59 - non-existent file at top-level ignored
ok 60 - non-existent file at top-level ignored with -q
ok 61 - non-existent file at top-level ignored with --quiet
ok 62 - non-existent file at top-level ignored with -v
ok 63 - non-existent file at top-level ignored with --verbose
ok 64 - existing untracked file at top-level not ignored
ok 65 - existing untracked file at top-level not ignored with -q
ok 66 - existing untracked file at top-level not ignored with --quiet
ok 67 - existing untracked file at top-level not ignored with -v
ok 68 - existing untracked file at top-level not ignored with --verbose
ok 69 - existing tracked file at top-level not ignored
ok 70 - existing tracked file at top-level not ignored with -q
ok 71 - existing tracked file at top-level not ignored with --quiet
ok 72 - existing tracked file at top-level not ignored with -v
ok 73 - existing tracked file at top-level not ignored with --verbose
ok 74 - existing untracked file at top-level ignored
ok 75 - existing untracked file at top-level ignored with -q
ok 76 - existing untracked file at top-level ignored with --quiet
ok 77 - existing untracked file at top-level ignored with -v
ok 78 - existing untracked file at top-level ignored with --verbose
ok 79 - non-existent file in subdir a/ not ignored
ok 80 - non-existent file in subdir a/ not ignored with -q
ok 81 - non-existent file in subdir a/ not ignored with --quiet
ok 82 - non-existent file in subdir a/ not ignored with -v
ok 83 - non-existent file in subdir a/ not ignored with --verbose
ok 84 - non-existent file in subdir a/ ignored
ok 85 - non-existent file in subdir a/ ignored with -q
ok 86 - non-existent file in subdir a/ ignored with --quiet
ok 87 - non-existent file in subdir a/ ignored with -v
ok 88 - non-existent file in subdir a/ ignored with --verbose
ok 89 - existing untracked file in subdir a/ not ignored
ok 90 - existing untracked file in subdir a/ not ignored with -q
ok 91 - existing untracked file in subdir a/ not ignored with --quiet
ok 92 - existing untracked file in subdir a/ not ignored with -v
ok 93 - existing untracked file in subdir a/ not ignored with --verbose
ok 94 - existing tracked file in subdir a/ not ignored
ok 95 - existing tracked file in subdir a/ not ignored with -q
ok 96 - existing tracked file in subdir a/ not ignored with --quiet
ok 97 - existing tracked file in subdir a/ not ignored with -v
ok 98 - existing tracked file in subdir a/ not ignored with --verbose
ok 99 - existing untracked file in subdir a/ ignored
ok 100 - existing untracked file in subdir a/ ignored with -q
ok 101 - existing untracked file in subdir a/ ignored with --quiet
ok 102 - existing untracked file in subdir a/ ignored with -v
ok 103 - existing untracked file in subdir a/ ignored with --verbose
ok 104 - sub-directory local ignore
ok 105 - sub-directory local ignore with --verbose
ok 106 - local ignore inside a sub-directory
ok 107 - local ignore inside a sub-directory with --verbose
ok 108 - nested include
ok 109 - nested include with -q
ok 110 - nested include with --quiet
ok 111 - nested include with -v
ok 112 - nested include with --verbose
ok 113 - ignored sub-directory
ok 114 - ignored sub-directory with -q
ok 115 - ignored sub-directory with --quiet
ok 116 - ignored sub-directory with -v
ok 117 - ignored sub-directory with --verbose
ok 118 - multiple files inside ignored sub-directory
ok 119 - multiple files inside ignored sub-directory with -v
ok 120 - cd to ignored sub-directory
ok 121 - cd to ignored sub-directory with -v
ok 122 # skip symlink (missing SYMLINKS)
ok 123 # skip symlink with -q (missing SYMLINKS)
ok 124 # skip symlink with --quiet (missing SYMLINKS)
ok 125 # skip symlink with -v (missing SYMLINKS)
ok 126 # skip symlink with --verbose (missing SYMLINKS)
ok 127 # skip beyond a symlink (missing SYMLINKS)
ok 128 # skip beyond a symlink with -q (missing SYMLINKS)
ok 129 # skip beyond a symlink with --quiet (missing SYMLINKS)
ok 130 # skip beyond a symlink with -v (missing SYMLINKS)
ok 131 # skip beyond a symlink with --verbose (missing SYMLINKS)
ok 132 # skip beyond a symlink from subdirectory (missing SYMLINKS)
ok 133 # skip beyond a symlink from subdirectory with -q (missing SYMLINKS)
ok 134 # skip beyond a symlink from subdirectory with --quiet (missing SYMLINKS)
ok 135 # skip beyond a symlink from subdirectory with -v (missing SYMLINKS)
ok 136 # skip beyond a symlink from subdirectory with --verbose (missing SYMLINKS)
ok 137 - submodule
ok 138 - submodule with -q
ok 139 - submodule with --quiet
ok 140 - submodule with -v
ok 141 - submodule with --verbose
ok 142 - submodule from subdirectory
ok 143 - submodule from subdirectory with -q
ok 144 - submodule from subdirectory with --quiet
ok 145 - submodule from subdirectory with -v
ok 146 - submodule from subdirectory with --verbose
ok 147 - global ignore not yet enabled
ok 148 - global ignore
ok 149 - global ignore with -v
ok 150 - --stdin
ok 151 - --stdin -q
ok 152 - --stdin -v
ok 153 - --stdin -z
ok 154 - --stdin -z -q
ok 155 - --stdin -z -v
ok 156 - -z --stdin
ok 157 - -z --stdin -q
ok 158 - -z --stdin -v
ok 159 - --stdin from subdirectory
ok 160 - --stdin from subdirectory with -v
ok 161 - --stdin -z from subdirectory
ok 162 - --stdin -z from subdirectory with -v
ok 163 - -z --stdin from subdirectory
ok 164 - -z --stdin from subdirectory with -v
# passed all 164 test(s)
1..164
