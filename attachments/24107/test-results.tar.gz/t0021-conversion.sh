ok 1 - setup
ok 2 - check
ok 3 - expanded_in_repo
ok 4 - filter shell-escaped filenames
ok 5 - required filter success
ok 6 - required filter smudge failure
ok 7 - required filter clean failure
# passed all 7 test(s)
1..7
