ok 1 - test help
ok 2 - OPT_BOOL() #1
ok 3 - OPT_BOOL() #2
ok 4 - OPT_BOOL() #3
ok 5 - OPT_BOOL() #4
ok 6 - OPT_BOOL() #5
ok 7 - OPT_BOOL() is idempotent #1
ok 8 - OPT_BOOL() is idempotent #2
ok 9 - OPT_BOOL() negation #1
ok 10 - OPT_BOOL() negation #2
ok 11 - OPT_BOOL() no negation #1
ok 12 - OPT_BOOL() no negation #2
ok 13 - OPT_BOOL() positivation
ok 14 - short options
ok 15 - long options
ok 16 - missing required value
ok 17 - intermingled arguments
ok 18 - unambiguously abbreviated option
ok 19 - unambiguously abbreviated option with "="
ok 20 - ambiguously abbreviated option
ok 21 - non ambiguous option (after two options it abbreviates)
ok 22 - detect possible typos
ok 23 - detect possible typos
ok 24 - keep some options as arguments
ok 25 - OPT_DATE() and OPT_SET_PTR() work
ok 26 - OPT_CALLBACK() and OPT_BIT() work
ok 27 - OPT_CALLBACK() and callback errors work
ok 28 - OPT_BIT() and OPT_SET_INT() work
ok 29 - OPT_NEGBIT() and OPT_SET_INT() work
ok 30 - OPT_BIT() works
ok 31 - OPT_NEGBIT() works
ok 32 - OPT_COUNTUP() with PARSE_OPT_NODASH works
ok 33 - OPT_NUMBER_CALLBACK() works
ok 34 - negation of OPT_NONEG flags is not ambiguous
ok 35 - --list keeps list of strings
ok 36 - --no-list resets list
# passed all 36 test(s)
1..36
