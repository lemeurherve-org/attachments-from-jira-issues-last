will test on a case insensitive filesystem
will test on a filesystem lacking symbolic links
ok 1 - detection of case insensitive filesystem during repo init
ok 2 - detection of filesystem w/o symlink support during repo init
ok 3 - setup case tests
not ok 4 - rename (case change) # TODO known breakage
ok 5 - merge (case change)
not ok 6 - add (with different case) # TODO known breakage
ok 7 - setup unicode normalization tests
ok 8 - rename (silent unicode normalization)
ok 9 - merge (silent unicode normalization)
# still have 2 known breakage(s)
# passed all remaining 7 test(s)
1..9
