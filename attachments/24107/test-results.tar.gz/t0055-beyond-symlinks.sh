ok 1 # skip setup (missing SYMLINKS)
ok 2 # skip update-index --add beyond symlinks (missing SYMLINKS)
ok 3 # skip add beyond symlinks (missing SYMLINKS)
# passed all 3 test(s)
1..3
