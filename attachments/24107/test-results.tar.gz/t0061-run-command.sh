ok 1 - start_command reports ENOENT
not ok 2 - run_command can run a command
#	
#		cat hello-script >hello.sh &&
#		chmod +x hello.sh &&
#		test-run-command run-command ./hello.sh >actual 2>err &&
#	
#		test_cmp hello-script actual &&
#		test_cmp empty err
#	
ok 3 # skip run_command reports EACCES (missing POSIXPERM)
ok 4 # skip unreadable directory in PATH (missing POSIXPERM)
# failed 1 among 4 test(s)
1..4
