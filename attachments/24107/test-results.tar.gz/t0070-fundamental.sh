ok 1 - character classes (isspace, isalpha etc.)
ok 2 - mktemp to nonexistent directory prints filename
ok 3 # skip mktemp to unwritable directory prints filename (missing POSIXPERM)
ok 4 - check for a bug in the regex routines
# passed all 4 test(s)
1..4
