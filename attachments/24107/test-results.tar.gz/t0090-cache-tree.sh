not ok 1 - initial commit has cache-tree # TODO known breakage
ok 2 - read-tree HEAD establishes cache-tree
ok 3 - git-add invalidates cache-tree
ok 4 - update-index invalidates cache-tree
ok 5 - write-tree establishes cache-tree
ok 6 - test-scrap-cache-tree works
ok 7 - second commit has cache-tree
ok 8 - reset --hard gives cache-tree
ok 9 - reset --hard without index gives cache-tree
not ok 10 - checkout gives cache-tree # TODO known breakage
# still have 2 known breakage(s)
# passed all remaining 8 test(s)
1..10
