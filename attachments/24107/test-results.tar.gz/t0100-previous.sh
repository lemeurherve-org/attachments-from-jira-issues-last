ok 1 - branch -d @{-1}
ok 2 - branch -d @{-12} when there is not enough switches yet
ok 3 - merge @{-1}
ok 4 - merge @{-1} when there is not enough switches yet
# passed all 4 test(s)
1..4
