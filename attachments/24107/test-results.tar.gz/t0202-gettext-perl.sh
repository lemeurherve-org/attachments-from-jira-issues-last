# run 1: Perl Git::I18N API (/usr/bin/perl /git/t/t0202/test.pl)
1..8
ok 1 - Testing Git::I18N with NO Perl gettext library
ok 2 - Git::I18N is located at /git/t/../perl/blib/lib/Git/I18N.pm
ok 3 - sanity: Git::I18N has 1 export(s)
ok 4 - sanity: Git::I18N exports everything by default
ok 5 - sanity: __ has a $ prototype
ok 6 - Passing a string through __() in the C locale works
ok 7 # skip GETTEXT_LOCALE must be set by lib-gettext.sh for exhaustive Git::I18N tests
ok 8 # skip GETTEXT_LOCALE must be set by lib-gettext.sh for exhaustive Git::I18N tests
# test_external test Perl Git::I18N API was ok
# test_external_without_stderr test no stderr: Perl Git::I18N API was ok
