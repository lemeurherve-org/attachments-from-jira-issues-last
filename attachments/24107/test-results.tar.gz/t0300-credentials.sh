ok 1 - setup helper scripts
ok 2 - credential_fill invokes helper
ok 3 - credential_fill invokes multiple helpers
ok 4 - credential_fill stops when we get a full response
ok 5 - credential_fill continues through partial response
ok 6 - credential_fill passes along metadata
ok 7 - credential_approve calls all helpers
ok 8 - do not bother storing password-less credential
ok 9 - credential_reject calls all helpers
ok 10 - usernames can be preserved
ok 11 - usernames can be overridden
ok 12 - do not bother completing already-full credential
ok 13 - empty helper list falls back to internal getpass
ok 14 - internal getpass does not ask for known username
ok 15 - respect configured credentials
ok 16 - match configured credential
ok 17 - do not match configured credential
ok 18 - pull username from config
ok 19 - http paths can be part of context
# passed all 19 test(s)
1..19
