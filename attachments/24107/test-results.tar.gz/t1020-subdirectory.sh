ok 1 - setup
ok 2 - update-index and ls-files
ok 3 - cat-file
ok 4 - diff-files
ok 5 - write-tree
ok 6 - checkout-index
ok 7 - read-tree
ok 8 - alias expansion
ok 9 # skip !alias expansion (missing NOT_MINGW)
ok 10 - GIT_PREFIX for !alias
ok 11 - GIT_PREFIX for built-ins
ok 12 - no file/rev ambiguity check inside .git
ok 13 - no file/rev ambiguity check inside a bare repo
ok 14 # skip detection should not be fooled by a symlink (missing SYMLINKS)
# passed all 14 test(s)
1..14
