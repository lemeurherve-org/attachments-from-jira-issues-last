ok 1 # skip setup (missing SYMLINKS)
ok 2 # skip rerere in workdir (missing SYMLINKS)
ok 3 # skip rerere in workdir (relative) (missing SYMLINKS)
# passed all 3 test(s)
1..3
