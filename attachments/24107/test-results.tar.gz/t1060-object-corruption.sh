not ok 1 - setup corrupt repo
#	
#		git init bit-error &&
#		(
#			cd bit-error &&
#			test_commit content &&
#			corrupt_byte HEAD:content.t 10
#		)
#	
ok 2 - setup repo with missing object
ok 3 - setup repo with misnamed object
not ok 4 - streaming a corrupt blob fails
#	
#		(
#			cd bit-error &&
#			test_must_fail git cat-file blob HEAD:content.t
#		)
#	
not ok 5 - read-tree -u detects bit-errors in blobs
#	
#		(
#			cd bit-error &&
#			rm -f content.t &&
#			test_must_fail git read-tree --reset -u HEAD
#		)
#	
ok 6 - read-tree -u detects missing objects
not ok 7 - clone --no-local --bare detects corruption
#	
#		test_must_fail git clone --no-local --bare bit-error corrupt-transport
#	
ok 8 - clone --no-local --bare detects missing object
ok 9 - clone --no-local --bare detects misnamed object
not ok 10 - clone --local detects corruption
#	
#		test_must_fail git clone --local bit-error corrupt-checkout
#	
ok 11 - error detected during checkout leaves repo intact
ok 12 - clone --local detects missing objects
not ok 13 - clone --local detects misnamed objects # TODO known breakage
# still have 1 known breakage(s)
# failed 5 among remaining 12 test(s)
1..13
