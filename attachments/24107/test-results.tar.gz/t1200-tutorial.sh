ok 1 - blob
ok 2 - blob 557db03
ok 3 - git diff-files -p
ok 4 - git diff
ok 5 - tree
ok 6 - git diff-index -p HEAD
ok 7 - git diff HEAD
ok 8 - git whatchanged -p --root
ok 9 - git tag my-first-tag
ok 10 - git checkout -b mybranch
ok 11 - git branch
ok 12 - git resolve now fails
ok 13 - git show-branch
ok 14 - git resolve
ok 15 - git resolve output
ok 16 - git show-branch (part 2)
ok 17 - git show-branch (part 3)
ok 18 - rewind to "Some fun." and "Some work."
ok 19 - git show-branch (part 4)
ok 20 - manual merge
ok 21 - git ls-files --stage
ok 22 - git ls-files --unmerged
ok 23 - git-merge-index
ok 24 - git ls-files --stage (part 2)
ok 25 - git repack
ok 26 - git prune-packed
ok 27 - -> only packed objects
# passed all 27 test(s)
1..27
