ok 1 - modify same key
ok 2 - add key in same section
ok 3 - add key in different section
ok 4 - make sure git config escapes section names properly
ok 5 - do not crash on special long config line
# passed all 5 test(s)
1..5
