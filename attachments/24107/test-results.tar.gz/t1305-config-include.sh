ok 1 - include file by absolute path
ok 2 - include file by relative path
ok 3 - chained relative paths
ok 4 - include paths get tilde-expansion
ok 5 - include options can still be examined
ok 6 - listing includes option and expansion
ok 7 - single file lookup does not expand includes by default
ok 8 - single file list does not expand includes by default
ok 9 - writing config file does not expand includes
ok 10 - config modification does not affect includes
ok 11 - missing include files are ignored
ok 12 - absolute includes from command line work
ok 13 - relative includes from command line fail
ok 14 - include cycles are detected
# passed all 14 test(s)
1..14
