ok 1 - read config: xdg file exists and ~/.gitconfig doesn't
ok 2 - read config: xdg file exists and ~/.gitconfig exists
ok 3 - read with --get: xdg file exists and ~/.gitconfig doesn't
ok 4 - "$XDG_CONFIG_HOME overrides $HOME/.config/git
ok 5 - read with --get: xdg file exists and ~/.gitconfig exists
ok 6 - read with --list: xdg file exists and ~/.gitconfig doesn't
ok 7 - read with --list: xdg file exists and ~/.gitconfig exists
ok 8 - Setup
ok 9 - Exclusion of a file in the XDG ignore file
ok 10 - $XDG_CONFIG_HOME overrides $HOME/.config/git/ignore
ok 11 - Exclusion in both XDG and local ignore files
ok 12 - Exclusion in a non-XDG global ignore file
ok 13 - Checking XDG ignore file when HOME is unset
ok 14 - Checking attributes in the XDG attributes file
ok 15 - Checking XDG attributes when HOME is unset
ok 16 - $XDG_CONFIG_HOME overrides $HOME/.config/git/attributes
ok 17 - Checking attributes in both XDG and local attributes files
ok 18 - Checking attributes in a non-XDG global attributes file
ok 19 - write: xdg file exists and ~/.gitconfig doesn't
ok 20 - write: xdg file exists and ~/.gitconfig exists
ok 21 - write: ~/.config/git/ exists and config file doesn't
# passed all 21 test(s)
1..21
