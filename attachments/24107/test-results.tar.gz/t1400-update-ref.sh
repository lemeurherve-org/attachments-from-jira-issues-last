ok 1 - setup
ok 2 - create refs/heads/master
ok 3 - create refs/heads/master
ok 4 - fail to delete refs/heads/master with stale ref
ok 5 - delete refs/heads/master
ok 6 - delete refs/heads/master without oldvalue verification
ok 7 - fail to create refs/heads/gu/fixes
ok 8 - create refs/heads/master (by HEAD)
ok 9 - create refs/heads/master (by HEAD)
ok 10 - fail to delete refs/heads/master (by HEAD) with stale ref
ok 11 - delete refs/heads/master (by HEAD)
ok 12 - create refs/heads/master (by HEAD)
ok 13 - pack refs
ok 14 - move refs/heads/master (by HEAD)
ok 15 - delete refs/heads/master (by HEAD) should remove both packed and loose refs/heads/master
ok 16 - delete symref without dereference
ok 17 - delete symref without dereference when the referred ref is packed
ok 18 - (not) create HEAD with old sha1
ok 19 - (not) prior created .git/refs/heads/master
ok 20 - create HEAD
ok 21 - (not) change HEAD with wrong SHA1
ok 22 - (not) changed .git/refs/heads/master
ok 23 - create refs/heads/master (logged by touch)
ok 24 - update refs/heads/master (logged by touch)
ok 25 - set refs/heads/master (logged by touch)
ok 26 - verifying refs/heads/master's log
ok 27 - enable core.logAllRefUpdates
ok 28 - create refs/heads/master (logged by config)
ok 29 - update refs/heads/master (logged by config)
ok 30 - set refs/heads/master (logged by config)
ok 31 - verifying refs/heads/master's log
ok 32 - Query "master@{May 25 2005}" (before history)
ok 33 - Query master@{2005-05-25} (before history)
ok 34 - Query "master@{May 26 2005 23:31:59}" (1 second before history)
ok 35 - Query "master@{May 26 2005 23:32:00}" (exactly history start)
ok 36 - Query "master@{May 26 2005 23:32:30}" (first non-creation change)
ok 37 - Query "master@{2005-05-26 23:33:01}" (middle of history with gap)
ok 38 - Query "master@{2005-05-26 23:38:00}" (middle of history)
ok 39 - Query "master@{2005-05-26 23:43:00}" (exact end of history)
ok 40 - Query "master@{2005-05-28}" (past end of history)
ok 41 - creating initial files
ok 42 - git commit logged updates
ok 43 - git cat-file blob master:F (expect OTHER)
ok 44 - git cat-file blob master@{2005-05-26 23:30}:F (expect TEST)
ok 45 - git cat-file blob master@{2005-05-26 23:42}:F (expect OTHER)
# passed all 45 test(s)
1..45
