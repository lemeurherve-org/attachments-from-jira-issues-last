ok 1 - symbolic-ref writes HEAD
ok 2 - symbolic-ref reads HEAD
ok 3 - symbolic-ref refuses non-ref for HEAD
ok 4 - symbolic-ref refuses bare sha1
ok 5 - symbolic-ref deletes HEAD
ok 6 - symbolic-ref deletes dangling HEAD
ok 7 - symbolic-ref fails to delete missing FOO
ok 8 - symbolic-ref fails to delete real ref
# passed all 8 test(s)
1..8
