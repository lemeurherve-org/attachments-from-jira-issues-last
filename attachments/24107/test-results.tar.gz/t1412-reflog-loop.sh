ok 1 - setup commits
ok 2 - setup reflog with alternating commits
ok 3 - reflog shows all entries
# passed all 3 test(s)
1..3
