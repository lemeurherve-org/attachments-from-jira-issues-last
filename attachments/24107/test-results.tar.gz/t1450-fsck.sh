ok 1 - setup
ok 2 - loose objects borrowed from alternate are not missing
ok 3 - HEAD is part of refs, valid objects appear valid
ok 4 - setup: helpers for corruption tests
ok 5 - object with bad sha1
ok 6 - branch pointing to non-commit
ok 7 - email without @ is okay
ok 8 - email with embedded > is not okay
ok 9 - missing < email delimiter is reported nicely
ok 10 - missing email is reported nicely
ok 11 - > in name is reported
ok 12 - tag pointing to nonexistent
ok 13 - tag pointing to something else than its type
ok 14 - cleaned up
ok 15 - rev-list --verify-objects
ok 16 - rev-list --verify-objects with bad sha1
ok 17 - fsck notices blob entry pointing to null sha1
ok 18 - fsck notices submodule entry pointing to null sha1
ok 19 - fsck notices "." and ".." in trees
ok 20 - fsck notices ".git" in trees
# passed all 20 test(s)
1..20
