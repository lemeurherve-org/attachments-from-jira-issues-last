ok 1 - test --parseopt help output
ok 2 - test --parseopt
ok 3 - test --parseopt with mixed options and arguments
ok 4 - test --parseopt with --
ok 5 - test --parseopt --stop-at-non-option
ok 6 - test --parseopt --keep-dashdash
ok 7 - test --parseopt --keep-dashdash --stop-at-non-option with --
ok 8 - test --parseopt --keep-dashdash --stop-at-non-option without --
# passed all 8 test(s)
1..8
