ok 1 - setup
ok 2 - @{-1} works
ok 3 - @{-1}~2 works
ok 4 - @{-1}^2 works
ok 5 - @{-1}@{1} works
ok 6 - @{-2} works
ok 7 - @{-3} fails
# passed all 7 test(s)
1..7
