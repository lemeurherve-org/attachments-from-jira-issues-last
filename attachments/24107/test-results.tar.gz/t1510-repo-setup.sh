ok 1 - #0: nonbare repo, no explicit configuration
ok 2 - #1: GIT_WORK_TREE without explicit GIT_DIR is accepted
ok 3 - #2: worktree defaults to cwd with explicit GIT_DIR
ok 4 - #2b: relative GIT_DIR
ok 5 - #3: setup
ok 6 - #3: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 7 - #3: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 8 - #3: explicit GIT_WORK_TREE from parent of worktree
ok 9 - #3: explicit GIT_WORK_TREE from nephew of worktree
ok 10 - #3: chdir_to_toplevel uses worktree, not git dir
ok 11 - #3: chdir_to_toplevel uses worktree (from subdir)
ok 12 - #4: core.worktree without GIT_DIR set is accepted
ok 13 - #5: core.worktree + GIT_WORK_TREE is accepted
ok 14 - #6: setting GIT_DIR brings core.worktree to life
ok 15 - #6b: GIT_DIR set, core.worktree relative
ok 16 - #6c: GIT_DIR set, core.worktree=../wt (absolute)
ok 17 - #6d: GIT_DIR set, core.worktree=../wt (relative)
ok 18 - #6e: GIT_DIR set, core.worktree=../.. (absolute)
ok 19 - #6f: GIT_DIR set, core.worktree=../.. (relative)
ok 20 - #7: setup
ok 21 - #7: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 22 - #7: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 23 - #7: explicit GIT_WORK_TREE from parent of worktree
ok 24 - #7: explicit GIT_WORK_TREE from nephew of worktree
ok 25 - #7: chdir_to_toplevel uses worktree, not git dir
ok 26 - #7: chdir_to_toplevel uses worktree (from subdir)
ok 27 - #8: gitfile, easy case
ok 28 - #9: GIT_WORK_TREE accepted with gitfile
ok 29 - #10: GIT_DIR can point to gitfile
ok 30 - #10b: relative GIT_DIR can point to gitfile
ok 31 - #11: setup
ok 32 - #11: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 33 - #11: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 34 - #11: explicit GIT_WORK_TREE from parent of worktree
ok 35 - #11: explicit GIT_WORK_TREE from nephew of worktree
ok 36 - #11: chdir_to_toplevel uses worktree, not git dir
ok 37 - #11: chdir_to_toplevel uses worktree (from subdir)
ok 38 - #12: core.worktree with gitfile is accepted
ok 39 - #13: core.worktree+GIT_WORK_TREE accepted (with gitfile)
ok 40 - #14: core.worktree with GIT_DIR pointing to gitfile
ok 41 - #14b: core.worktree is relative to actual git dir
ok 42 - #15: setup
ok 43 - #15: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 44 - #15: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 45 - #15: explicit GIT_WORK_TREE from parent of worktree
ok 46 - #15: explicit GIT_WORK_TREE from nephew of worktree
ok 47 - #15: chdir_to_toplevel uses worktree, not git dir
ok 48 - #15: chdir_to_toplevel uses worktree (from subdir)
ok 49 - #16a: implicitly bare repo (cwd inside .git dir)
ok 50 - #16b: bare .git (cwd inside .git dir)
ok 51 - #16c: bare .git has no worktree
ok 52 - #16d: bareness preserved across alias
ok 53 - #16e: bareness preserved by --bare
ok 54 - #17: GIT_WORK_TREE without explicit GIT_DIR is accepted (bare case)
ok 55 - #18: bare .git named by GIT_DIR has no worktree
ok 56 - #19: setup
ok 57 - #19: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 58 - #19: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 59 - #19: explicit GIT_WORK_TREE from parent of worktree
ok 60 - #19: explicit GIT_WORK_TREE from nephew of worktree
ok 61 - #19: chdir_to_toplevel uses worktree, not git dir
ok 62 - #19: chdir_to_toplevel uses worktree (from subdir)
ok 63 - #20a: core.worktree without GIT_DIR accepted (inside .git)
ok 64 - #20b/c: core.worktree and core.bare conflict
ok 65 - #21: setup, core.worktree warns before overriding core.bare
ok 66 - #21: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 67 - #21: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 68 - #21: explicit GIT_WORK_TREE from parent of worktree
ok 69 - #21: explicit GIT_WORK_TREE from nephew of worktree
ok 70 - #21: chdir_to_toplevel uses worktree, not git dir
ok 71 - #21: chdir_to_toplevel uses worktree (from subdir)
ok 72 - #22a: core.worktree = GIT_DIR = .git dir
ok 73 - #22b: core.worktree child of .git, GIT_DIR=.git
ok 74 - #22c: core.worktree = .git/.., GIT_DIR=.git
ok 75 - #22.2: core.worktree and core.bare conflict
ok 76 - #23: setup
ok 77 - #23: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 78 - #23: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 79 - #23: explicit GIT_WORK_TREE from parent of worktree
ok 80 - #23: explicit GIT_WORK_TREE from nephew of worktree
ok 81 - #23: chdir_to_toplevel uses worktree, not git dir
ok 82 - #23: chdir_to_toplevel uses worktree (from subdir)
ok 83 - #24: bare repo has no worktree (gitfile case)
ok 84 - #25: GIT_WORK_TREE accepted if GIT_DIR unset (bare gitfile case)
ok 85 - #26: bare repo has no worktree (GIT_DIR -> gitfile case)
ok 86 - #27: setup
ok 87 - #27: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 88 - #27: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 89 - #27: explicit GIT_WORK_TREE from parent of worktree
ok 90 - #27: explicit GIT_WORK_TREE from nephew of worktree
ok 91 - #27: chdir_to_toplevel uses worktree, not git dir
ok 92 - #27: chdir_to_toplevel uses worktree (from subdir)
ok 93 - #28: core.worktree and core.bare conflict (gitfile case)
ok 94 - #29: setup
ok 95 - #29: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 96 - #29: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 97 - #29: explicit GIT_WORK_TREE from parent of worktree
ok 98 - #29: explicit GIT_WORK_TREE from nephew of worktree
ok 99 - #29: chdir_to_toplevel uses worktree, not git dir
ok 100 - #29: chdir_to_toplevel uses worktree (from subdir)
ok 101 - #30: core.worktree and core.bare conflict (gitfile version)
ok 102 - #31: setup
ok 103 - #31: explicit GIT_WORK_TREE and GIT_DIR at toplevel
ok 104 - #31: explicit GIT_WORK_TREE and GIT_DIR in subdir
ok 105 - #31: explicit GIT_WORK_TREE from parent of worktree
ok 106 - #31: explicit GIT_WORK_TREE from nephew of worktree
ok 107 - #31: chdir_to_toplevel uses worktree, not git dir
ok 108 - #31: chdir_to_toplevel uses worktree (from subdir)
# passed all 108 test(s)
1..108
