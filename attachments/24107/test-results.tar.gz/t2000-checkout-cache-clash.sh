ok 1 - git update-index --add various paths.
ok 2 - git checkout-index without -f should fail on conflicting work tree.
ok 3 - git checkout-index with -f should succeed.
ok 4 - git checkout-index conflicting paths.
ok 5 # skip checkout-index -f twice with --prefix (missing SYMLINKS)
# passed all 5 test(s)
1..5
