ok 1 - git update-index --add path0/file0
ok 2 - writing tree out with git write-tree
ok 3 - git update-index --add path1/file1
ok 4 - writing tree out with git write-tree
ok 5 - read previously written tree and checkout.
ok 6 # skip git update-index --add a symlink. (missing SYMLINKS)
ok 7 - writing tree out with git write-tree
ok 8 - read previously written tree and checkout.
ok 9 - checking out conflicting path with -f
# passed all 9 test(s)
1..9
