ok 1 - preparation
ok 2 - without -u, git checkout-index smudges stat information.
ok 3 - with -u, git checkout-index picks up stat information from new files.
# passed all 3 test(s)
1..3
