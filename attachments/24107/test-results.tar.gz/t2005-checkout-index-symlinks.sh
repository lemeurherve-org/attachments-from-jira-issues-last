ok 1 - preparation
ok 2 - the checked-out symlink must be a file
ok 3 - the file must be the blob we added during the setup
# passed all 3 test(s)
1..3
