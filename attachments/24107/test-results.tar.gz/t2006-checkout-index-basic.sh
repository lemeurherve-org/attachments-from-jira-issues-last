ok 1 - checkout-index --gobbledegook
ok 2 - checkout-index -h in broken repository
# passed all 2 test(s)
1..2
