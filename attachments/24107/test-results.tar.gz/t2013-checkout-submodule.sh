ok 1 - setup
ok 2 - "reset <submodule>" updates the index
ok 3 - "checkout <submodule>" updates the index only
ok 4 - "checkout <submodule>" honors diff.ignoreSubmodules
ok 5 - "checkout <submodule>" honors submodule.*.ignore from .gitmodules
ok 6 - "checkout <submodule>" honors submodule.*.ignore from .git/config
# passed all 6 test(s)
1..6
