ok 1 - setup
ok 2 - create a commit where dir a/b changed to file
ok 3 - checkout commit with dir must not remove untracked a/b
ok 4 # skip create a commit where dir a/b changed to symlink (missing SYMLINKS)
ok 5 # skip checkout commit with dir must not remove untracked a/b (missing SYMLINKS)
# passed all 5 test(s)
1..5
