ok 1 - setup
ok 2 - checking out paths out of a tree does not clobber unrelated paths
ok 3 - do not touch unmerged entries matching $path but not in $tree
# passed all 3 test(s)
1..3
