ok 1 - setup
ok 2 - git merge master
ok 3 - -m restores 2-way conflicted+resolved file
ok 4 - -m restores 3-way conflicted+resolved file
# passed all 4 test(s)
1..4
