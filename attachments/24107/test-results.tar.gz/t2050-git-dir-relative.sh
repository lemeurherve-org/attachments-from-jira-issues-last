ok 1 - Setting up post-commit hook
ok 2 - post-commit hook used ordinarily
ok 3 - post-commit-hook created and used from top dir
ok 4 - post-commit-hook from sub dir
# passed all 4 test(s)
1..4
