ok 1 - update-index --add
ok 2 - update-index --again
ok 3 - update-index --remove --again
ok 4 - first commit
ok 5 - update-index again
ok 6 - update-index --update from subdir
ok 7 - update-index --update with pathspec
# passed all 7 test(s)
1..7
