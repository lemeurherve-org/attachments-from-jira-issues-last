ok 1 - preparation
ok 2 - modify the symbolic link
ok 3 - the index entry must still be a symbolic link
# passed all 3 test(s)
1..3
