ok 1 - setup
ok 2 - do not switch branches with dirty file
# passed all 2 test(s)
1..2
