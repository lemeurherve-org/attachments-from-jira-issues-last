ok 1 - intent to add
ok 2 - check result of "add -N"
ok 3 - intent to add is just an ordinary empty blob
ok 4 - intent to add does not clobber existing paths
ok 5 - i-t-a entry is simply ignored
ok 6 - can commit with an unrelated i-t-a entry in index
ok 7 - can "commit -a" with an i-t-a entry
ok 8 - cache-tree invalidates i-t-a paths
# passed all 8 test(s)
1..8
