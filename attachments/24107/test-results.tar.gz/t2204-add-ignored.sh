ok 1 - setup
ok 2 - no complaints for unignored file
ok 3 - no complaints for unignored dir/file
ok 4 - no complaints for unignored dir
ok 5 - no complaints for unignored d*
ok 6 - complaints for ignored ign
ok 7 - complaints for ignored ign output
ok 8 - complaints for ignored ign with unignored file
ok 9 - complaints for ignored ign with unignored file output
ok 10 - complaints for ignored dir/ign
ok 11 - complaints for ignored dir/ign output
ok 12 - complaints for ignored dir/ign with unignored file
ok 13 - complaints for ignored dir/ign with unignored file output
ok 14 - complaints for ignored dir/sub
ok 15 - complaints for ignored dir/sub output
ok 16 - complaints for ignored dir/sub with unignored file
ok 17 - complaints for ignored dir/sub with unignored file output
ok 18 - complaints for ignored dir/sub/ign
ok 19 - complaints for ignored dir/sub/ign output
ok 20 - complaints for ignored dir/sub/ign with unignored file
ok 21 - complaints for ignored dir/sub/ign with unignored file output
ok 22 - complaints for ignored sub/file
ok 23 - complaints for ignored sub/file output
ok 24 - complaints for ignored sub/file with unignored file
ok 25 - complaints for ignored sub/file with unignored file output
ok 26 - complaints for ignored sub
ok 27 - complaints for ignored sub output
ok 28 - complaints for ignored sub with unignored file
ok 29 - complaints for ignored sub with unignored file output
ok 30 - complaints for ignored sub/file
ok 31 - complaints for ignored sub/file output
ok 32 - complaints for ignored sub/file with unignored file
ok 33 - complaints for ignored sub/file with unignored file output
ok 34 - complaints for ignored sub/ign
ok 35 - complaints for ignored sub/ign output
ok 36 - complaints for ignored sub/ign with unignored file
ok 37 - complaints for ignored sub/ign with unignored file output
ok 38 - complaints for ignored sub in dir
ok 39 - complaints for ignored sub in dir output
ok 40 - complaints for ignored sub/file in dir
ok 41 - complaints for ignored sub/file in dir output
ok 42 - complaints for ignored sub/ign in dir
ok 43 - complaints for ignored sub/ign in dir output
ok 44 - complaints for ignored ign in sub
ok 45 - complaints for ignored ign in sub output
ok 46 - complaints for ignored file in sub
ok 47 - complaints for ignored file in sub output
# passed all 47 test(s)
1..47
