ok 1 - git ls-files --others with various exclude options.
ok 2 - git ls-files --others with \r\n line endings.
ok 3 - setup skip-worktree gitignore
ok 4 - git ls-files --others with various exclude options.
ok 5 - restore gitignore
ok 6 - git status honors core.excludesfile
ok 7 - trailing slash in exclude allows directory match(1)
ok 8 - trailing slash in exclude allows directory match (2)
ok 9 - trailing slash in exclude forces directory match (1)
ok 10 - trailing slash in exclude forces directory match (2)
ok 11 - negated exclude matches can override previous ones
ok 12 - excluded directory overrides content patterns
ok 13 - negated directory doesn't affect content patterns
ok 14 - subdirectory ignore (setup)
ok 15 - subdirectory ignore (toplevel)
ok 16 - subdirectory ignore (l1/l2)
ok 17 - subdirectory ignore (l1)
ok 18 - show/hide empty ignored directory (setup)
ok 19 - show empty ignored directory with --directory
ok 20 - hide empty ignored directory with --no-empty-directory
ok 21 - show/hide empty ignored sub-directory (setup)
ok 22 - show empty ignored sub-directory with --directory
ok 23 - hide empty ignored sub-directory with --no-empty-directory
ok 24 - pattern matches prefix completely
ok 25 - ls-files with "**" patterns
ok 26 - ls-files with "**" patterns and no slashes
# passed all 26 test(s)
1..26
