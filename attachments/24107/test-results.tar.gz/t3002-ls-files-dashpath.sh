ok 1 - setup
ok 2 - git ls-files without path restriction.
ok 3 - git ls-files with path restriction.
ok 4 - git ls-files with path restriction with --.
ok 5 - git ls-files with path restriction with -- --.
ok 6 - git ls-files with no path restriction.
# passed all 6 test(s)
1..6
