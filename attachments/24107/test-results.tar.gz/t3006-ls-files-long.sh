ok 1 - setup
ok 2 - overly-long path by itself is not a problem
ok 3 - overly-long path does not replace another by mistake
# passed all 3 test(s)
1..3
