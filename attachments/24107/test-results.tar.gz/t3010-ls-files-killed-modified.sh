ok 1 - git update-index --add to add various paths.
ok 2 - git ls-files -k to show killed files.
ok 3 - validate git ls-files -k output.
ok 4 - git ls-files -m to show modified files.
ok 5 - validate git ls-files -m output.
# passed all 5 test(s)
1..5
