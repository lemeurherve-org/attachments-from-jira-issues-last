ok 1 - setup
ok 2 - git ls-files --error-unmatch should fail with unmatched path.
ok 3 - git ls-files --error-unmatch should succeed eith matched paths.
# passed all 3 test(s)
1..3
