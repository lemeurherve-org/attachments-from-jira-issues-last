ok 1 - setup 1
ok 2 - setup 2
ok 3 - setup 3
ok 4 - setup 4
ok 5 - setup 5
ok 6 - setup 6
ok 7 - setup 7
ok 8 - setup 8
ok 9 - setup 9
ok 10 - merge-recursive simple
ok 11 - merge-recursive result
ok 12 - fail if the index has unresolved entries
ok 13 - merge-recursive remove conflict
ok 14 - merge-recursive remove conflict
ok 15 - merge-recursive d/f simple
ok 16 - merge-recursive result
ok 17 - merge-recursive d/f conflict
ok 18 - merge-recursive d/f conflict result
ok 19 - merge-recursive d/f conflict the other way
ok 20 - merge-recursive d/f conflict result the other way
ok 21 - merge-recursive d/f conflict
ok 22 - merge-recursive d/f conflict result
ok 23 - merge-recursive d/f conflict
ok 24 - merge-recursive d/f conflict result
ok 25 - reset and 3-way merge
ok 26 - reset and bind merge
ok 27 - merge removes empty directories
not ok 28 - merge-recursive simple w/submodule # TODO known breakage
not ok 29 - merge-recursive simple w/submodule result # TODO known breakage
ok 30 - merge-recursive copy vs. rename
# still have 2 known breakage(s)
# passed all remaining 28 test(s)
1..30
