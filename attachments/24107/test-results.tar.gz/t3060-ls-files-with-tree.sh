ok 1 - setup
ok 2 - git -ls-files --with-tree should succeed from subdir
ok 3 - git -ls-files --with-tree should add entries from named tree.
# passed all 3 test(s)
1..3
