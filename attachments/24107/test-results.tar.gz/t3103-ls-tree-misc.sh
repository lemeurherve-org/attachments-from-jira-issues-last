ok 1 - setup
ok 2 - ls-tree fails with non-zero exit code on broken tree
# passed all 2 test(s)
1..2
