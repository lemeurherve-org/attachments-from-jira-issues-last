ok 1 - prepare a trivial repository
ok 2 - git branch --help should not have created a bogus branch
ok 3 - branch -h in broken repository
ok 4 - git branch abc should create a branch
ok 5 - git branch a/b/c should create a branch
ok 6 - git branch HEAD should fail
ok 7 - git branch -l d/e/f should create a branch and a log
ok 8 - git branch -d d/e/f should delete a branch and a log
ok 9 - git branch j/k should work after branch j has been deleted
ok 10 - git branch l should work after branch l/m has been deleted
ok 11 - git branch -m dumps usage
ok 12 - git branch -m m m/m should work
ok 13 - git branch -m n/n n should work
ok 14 - git branch -m o/o o should fail when o/p exists
ok 15 - git branch -m q r/q should fail when r exists
ok 16 - git branch -M foo bar should fail when bar is checked out
ok 17 - git branch -M baz bam should succeed when baz is checked out
ok 18 - git branch -M master should work when master is checked out
ok 19 - git branch -M master master should work when master is checked out
ok 20 - git branch -M master2 master2 should work when master is checked out
ok 21 - git branch -v -d t should work
ok 22 - git branch -v -m t s should work
ok 23 - git branch -m -d t s should fail
ok 24 - git branch --list -d t should fail
ok 25 - git branch --column
ok 26 - git branch --column with an extremely long branch name
ok 27 - git branch with column.*
ok 28 - git branch --column -v should fail
ok 29 - git branch -v with column.ui ignored
ok 30 - git branch -m q q2 without config should succeed
ok 31 - git branch -m s/s s should work when s/t is deleted
ok 32 - config information was renamed, too
ok 33 - deleting a symref
ok 34 - deleting a dangling symref
ok 35 - renaming a symref is not allowed
ok 36 # skip git branch -m u v should fail when the reflog for u is a symlink (missing SYMLINKS)
ok 37 - test tracking setup via --track
ok 38 - test tracking setup (non-wildcard, matching)
ok 39 - test tracking setup (non-wildcard, not matching)
ok 40 - test tracking setup via config
ok 41 - test overriding tracking setup via --no-track
ok 42 - no tracking without .fetch entries
ok 43 - test tracking setup via --track but deeper
ok 44 - test deleting branch deletes branch config
ok 45 - test deleting branch without config
ok 46 - test --track without .fetch entries
ok 47 - branch from non-branch HEAD w/autosetupmerge=always
ok 48 - branch from non-branch HEAD w/--track causes failure
ok 49 - branch from tag w/--track causes failure
ok 50 - --set-upstream-to fails on multiple branches
ok 51 - --set-upstream-to fails on detached HEAD
ok 52 - --set-upstream-to fails on a missing dst branch
ok 53 - --set-upstream-to fails on a missing src branch
ok 54 - --set-upstream-to fails on a non-ref
ok 55 - use --set-upstream-to modify HEAD
ok 56 - use --set-upstream-to modify a particular branch
ok 57 - --unset-upstream should fail if given a non-existent branch
ok 58 - test --unset-upstream on HEAD
ok 59 - --unset-upstream should fail on multiple branches
ok 60 - --unset-upstream should fail on detached HEAD
ok 61 - test --unset-upstream on a particular branch
ok 62 - --set-upstream shows message when creating a new branch that exists as remote-tracking
ok 63 - --set-upstream with two args only shows the deprecation message
ok 64 - --set-upstream with one arg only shows the deprecation message if the branch existed
ok 65 - git checkout -b g/h/i -l should create a branch and a log
ok 66 - checkout -b makes reflog by default
ok 67 - checkout -b does not make reflog when core.logAllRefUpdates = false
ok 68 - checkout -b with -l makes reflog when core.logAllRefUpdates = false
ok 69 - avoid ambiguous track
ok 70 - autosetuprebase local on a tracked local branch
ok 71 - autosetuprebase always on a tracked local branch
ok 72 - autosetuprebase remote on a tracked local branch
ok 73 - autosetuprebase never on a tracked local branch
ok 74 - autosetuprebase local on a tracked remote branch
ok 75 - autosetuprebase never on a tracked remote branch
ok 76 - autosetuprebase remote on a tracked remote branch
ok 77 - autosetuprebase always on a tracked remote branch
ok 78 - autosetuprebase unconfigured on a tracked remote branch
ok 79 - autosetuprebase unconfigured on a tracked local branch
ok 80 - autosetuprebase unconfigured on untracked local branch
ok 81 - autosetuprebase unconfigured on untracked remote branch
ok 82 - autosetuprebase never on an untracked local branch
ok 83 - autosetuprebase local on an untracked local branch
ok 84 - autosetuprebase remote on an untracked local branch
ok 85 - autosetuprebase always on an untracked local branch
ok 86 - autosetuprebase never on an untracked remote branch
ok 87 - autosetuprebase local on an untracked remote branch
ok 88 - autosetuprebase remote on an untracked remote branch
ok 89 - autosetuprebase always on an untracked remote branch
ok 90 - autosetuprebase always on detached HEAD
ok 91 - detect misconfigured autosetuprebase (bad value)
ok 92 - detect misconfigured autosetuprebase (no value)
ok 93 - attempt to delete a branch without base and unmerged to HEAD
ok 94 - attempt to delete a branch merged to its base
ok 95 - attempt to delete a branch merged to its base
ok 96 - use set-upstream on the current branch
ok 97 - use --edit-description
ok 98 - detect typo in branch name when using --edit-description
ok 99 - refuse --edit-description on unborn branch for now
ok 100 - --merged catches invalid object names
# passed all 100 test(s)
1..100
