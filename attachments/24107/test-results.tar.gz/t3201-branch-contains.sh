ok 1 - setup
ok 2 - branch --contains=master
ok 3 - branch --contains master
ok 4 - branch --contains=side
ok 5 - branch --contains with pattern implies --list
ok 6 - side: branch --merged
ok 7 - branch --merged with pattern implies --list
ok 8 - side: branch --no-merged
ok 9 - master: branch --merged
ok 10 - master: branch --no-merged
ok 11 - branch --no-merged with pattern implies --list
ok 12 - implicit --list conflicts with modification options
# passed all 12 test(s)
1..12
