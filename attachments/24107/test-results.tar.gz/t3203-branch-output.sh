ok 1 - make commits
ok 2 - make branches
ok 3 - make remote branches
ok 4 - git branch shows local branches
ok 5 - git branch --list shows local branches
ok 6 - git branch --list pattern shows matching local branches
ok 7 - git branch -r shows remote branches
ok 8 - git branch -a shows local and remote branches
ok 9 - git branch -v shows branch summaries
ok 10 - git branch --list -v pattern shows branch summaries
ok 11 - git branch -v pattern does not show branch summaries
ok 12 - git branch shows detached HEAD properly
# passed all 12 test(s)
1..12
