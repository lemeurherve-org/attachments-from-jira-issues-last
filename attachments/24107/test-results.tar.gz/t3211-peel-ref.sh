ok 1 - create annotated tag in refs/tags
ok 2 - create annotated tag outside of refs/tags
ok 3 - set up expected show-ref output
ok 4 - refs are peeled outside of refs/tags (loose)
ok 5 - refs are peeled outside of refs/tags (packed)
ok 6 - create old-style pack-refs without fully-peeled
ok 7 - refs are peeled outside of refs/tags (old packed)
# passed all 7 test(s)
1..7
