ok 1 - setup: create 100 commits
ok 2 - test notes in 2/38-fanout
ok 3 - verify notes in 2/38-fanout
ok 4 - test notes in 2/2/36-fanout
ok 5 - verify notes in 2/2/36-fanout
ok 6 - test notes in 2/2/2/34-fanout
ok 7 - verify notes in 2/2/2/34-fanout
ok 8 - test same notes in no fanout and 2/38-fanout
ok 9 - verify same notes in no fanout and 2/38-fanout
ok 10 - test same notes in no fanout and 2/2/36-fanout
ok 11 - verify same notes in no fanout and 2/2/36-fanout
ok 12 - test same notes in 2/38-fanout and 2/2/36-fanout
ok 13 - verify same notes in 2/38-fanout and 2/2/36-fanout
ok 14 - test same notes in 2/2/2/34-fanout and 2/2/36-fanout
ok 15 - verify same notes in 2/2/2/34-fanout and 2/2/36-fanout
ok 16 - test notes in no fanout concatenated with 2/38-fanout
ok 17 - verify notes in no fanout concatenated with 2/38-fanout
ok 18 - test notes in no fanout concatenated with 2/2/36-fanout
ok 19 - verify notes in no fanout concatenated with 2/2/36-fanout
ok 20 - test notes in 2/38-fanout concatenated with 2/2/36-fanout
ok 21 - verify notes in 2/38-fanout concatenated with 2/2/36-fanout
ok 22 - test notes in 2/2/36-fanout concatenated with 2/2/2/34-fanout
ok 23 - verify notes in 2/2/36-fanout concatenated with 2/2/2/34-fanout
# passed all 23 test(s)
1..23
