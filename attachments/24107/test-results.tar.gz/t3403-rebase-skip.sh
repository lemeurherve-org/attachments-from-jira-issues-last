ok 1 - setup
ok 2 - rebase with git am -3 (default)
ok 3 - rebase --skip can not be used with other options
ok 4 - rebase --skip with am -3
ok 5 - rebase moves back to skip-reference
ok 6 - checkout skip-merge
ok 7 - rebase with --merge
ok 8 - rebase --skip with --merge
ok 9 - merge and reference trees equal
ok 10 - moved back to branch correctly
# passed all 10 test(s)
1..10
