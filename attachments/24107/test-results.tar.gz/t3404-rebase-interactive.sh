ok 1 - setup
ok 2 - rebase -i with the exec command
ok 3 - rebase -i with the exec command runs from tree root
ok 4 - rebase -i with the exec command checks tree cleanness
ok 5 - rebase -i with exec of inexistent command
ok 6 - no changes are a nop
ok 7 - test the [branch] option
ok 8 - test --onto <branch>
ok 9 - rebase on top of a non-conflicting commit
ok 10 - reflog for the branch shows state before rebase
ok 11 - exchange two commits
ok 12 - stop on conflicting pick
ok 13 - abort
ok 14 - abort with error when new base cannot be checked out
ok 15 - retain authorship
ok 16 - squash
ok 17 - retain authorship when squashing
ok 18 - -p handles "no changes" gracefully
not ok 19 - exchange two commits with -p # TODO known breakage
ok 20 - preserve merges with -p
ok 21 - edit ancestor with -p
ok 22 - --continue tries to commit
ok 23 - verbose flag is heeded, even after --continue
ok 24 - multi-squash only fires up editor once
ok 25 - multi-fixup does not fire up editor
ok 26 - commit message used after conflict
ok 27 - commit message retained after conflict
ok 28 - squash and fixup generate correct log messages
ok 29 - squash ignores comments
ok 30 - squash ignores blank lines
ok 31 - squash works as expected
ok 32 - interrupted squash works as expected
ok 33 - interrupted squash works as expected (case 2)
ok 34 - ignore patch if in upstream
ok 35 - --continue tries to commit, even for "edit"
ok 36 - aborted --continue does not squash commits after "edit"
ok 37 - auto-amend only edited commits after "edit"
ok 38 - clean error after failed "exec"
ok 39 - rebase a detached HEAD
ok 40 - rebase a commit violating pre-commit
ok 41 - rebase with a file named HEAD in worktree
ok 42 - do "noop" when there is nothing to cherry-pick
ok 43 - submodule rebase setup
ok 44 - submodule rebase -i
ok 45 - submodule conflict setup
ok 46 - rebase -i continue with only submodule staged
ok 47 - rebase -i continue with unstaged submodule
ok 48 - avoid unnecessary reset
ok 49 - reword
ok 50 - rebase -i can copy notes
ok 51 - rebase -i can copy notes over a fixup
ok 52 - rebase while detaching HEAD
ok 53 - always cherry-pick with --no-ff
ok 54 - set up commits with funny messages
ok 55 - rebase-i history with funny messages
ok 56 - prepare for rebase -i --exec
ok 57 - running "git rebase -i --exec git show HEAD"
ok 58 - running "git rebase --exec git show HEAD -i"
ok 59 - running "git rebase -ix git show HEAD"
ok 60 - rebase -ix with several <CMD>
ok 61 - rebase -ix with several instances of --exec
ok 62 - rebase -ix with --autosquash
ok 63 - rebase --exec without -i shows error message
not ok 64 - rebase -i --exec without <CMD>
#	
#		git reset --hard execute &&
#		test_must_fail git rebase -i --exec 2>tmp &&
#		sed -e "1d" tmp >actual &&
#		test_must_fail git rebase -h >expected &&
#		test_cmp expected actual &&
#		git checkout master
#	
ok 65 - rebase -i --root re-order and drop commits
ok 66 - rebase -i --root retain root commit author and message
ok 67 - rebase -i --root temporary sentinel commit
ok 68 - rebase -i --root fixup root commit
ok 69 - rebase --edit-todo does not works on non-interactive rebase
ok 70 - rebase --edit-todo can be used to modify todo
ok 71 - rebase -i respects core.commentchar
# still have 1 known breakage(s)
# failed 1 among remaining 70 test(s)
1..71
