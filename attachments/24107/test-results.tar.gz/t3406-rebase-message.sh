ok 1 - setup
ok 2 - rebase -m
ok 3 - rebase --stat
ok 4 - rebase w/config rebase.stat
ok 5 - rebase -n overrides config rebase.stat config
ok 6 - rebase --onto outputs the invalid ref
# passed all 6 test(s)
1..6
