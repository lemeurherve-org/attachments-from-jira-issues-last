ok 1 - setup
ok 2 - rebase --abort
ok 3 - rebase --abort after --skip
ok 4 - rebase --abort after --continue
ok 5 - rebase --abort does not update reflog
ok 6 - rebase --abort can not be used with other options
ok 7 - rebase --merge --abort
ok 8 - rebase --merge --abort after --skip
ok 9 - rebase --merge --abort after --continue
ok 10 - rebase --merge --abort does not update reflog
ok 11 - rebase --abort can not be used with other options
# passed all 11 test(s)
1..11
