ok 1 - setup for merge-preserving rebase
ok 2 - rebase -p fakes interactive rebase
ok 3 - --continue works after a conflict
ok 4 - rebase -p preserves no-ff merges
ok 5 - rebase -p works when base inside second parent
# passed all 5 test(s)
1..5
