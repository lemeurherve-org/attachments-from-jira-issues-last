ok 1 - setup
ok 2 - auto fixup (option)
ok 3 - auto fixup (config)
ok 4 - auto squash (option)
ok 5 - auto squash (config)
ok 6 - misspelled auto squash
ok 7 - auto squash that matches 2 commits
ok 8 - auto squash that matches a commit after the squash
ok 9 - auto squash that matches a sha1
ok 10 - auto squash that matches longer sha1
ok 11 - use commit --fixup
ok 12 - use commit --squash
# passed all 12 test(s)
1..12
