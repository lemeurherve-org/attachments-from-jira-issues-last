ok 1 - setup
ok 2 - interactive rebase --continue works with touched file
ok 3 - non-interactive rebase --continue works with touched file
ok 4 - rebase --continue can not be used with other options
ok 5 - rebase --continue remembers merge strategy and options
ok 6 - rebase --continue remembers --rerere-autoupdate
# passed all 6 test(s)
1..6
