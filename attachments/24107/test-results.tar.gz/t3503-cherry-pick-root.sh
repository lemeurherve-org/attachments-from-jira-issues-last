ok 1 - setup
ok 2 - cherry-pick a root commit
ok 3 - revert a root commit
ok 4 - cherry-pick a root commit with an external strategy
ok 5 - revert a root commit with an external strategy
ok 6 - cherry-pick two root commits
# passed all 6 test(s)
1..6
