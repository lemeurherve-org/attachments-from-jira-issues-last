ok 1 - setup
ok 2 - conflicting merge
ok 3 - fixup
ok 4 - cherry-pick conflict
ok 5 - reconfigure
ok 6 - cherry-pick conflict without rerere
# passed all 6 test(s)
1..6
