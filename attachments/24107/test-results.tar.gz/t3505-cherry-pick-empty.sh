ok 1 - setup
ok 2 - cherry-pick an empty commit
ok 3 - index lockfile was removed
ok 4 - cherry-pick a commit with an empty message
ok 5 - index lockfile was removed
ok 6 - cherry-pick a commit with an empty message with --allow-empty-message
ok 7 - cherry pick an empty non-ff commit without --allow-empty
ok 8 - cherry pick an empty non-ff commit with --allow-empty
ok 9 - cherry pick with --keep-redundant-commits
ok 10 - cherry-pick a commit that becomes no-op (prep)
ok 11 - cherry-pick a no-op without --keep-redundant
ok 12 - cherry-pick a no-op with --keep-redundant
# passed all 12 test(s)
1..12
