ok 1 - setup
ok 2 - cherry-pick first..fourth works
ok 3 - cherry-pick three one two works
ok 4 - cherry-pick three one two: fails
ok 5 - output to keep user entertained during multi-pick
ok 6 - cherry-pick --strategy resolve first..fourth works
ok 7 - output during multi-pick indicates merge strategy
ok 8 - cherry-pick --ff first..fourth works
ok 9 - cherry-pick -n first..fourth works
ok 10 - revert first..fourth works
ok 11 - revert ^first fourth works
ok 12 - revert fourth fourth~1 fourth~2 works
ok 13 - cherry-pick -3 fourth works
ok 14 - cherry-pick --stdin works
# passed all 14 test(s)
1..14
