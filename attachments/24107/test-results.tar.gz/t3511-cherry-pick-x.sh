ok 1 - setup
ok 2 - cherry-pick -x inserts blank line after one line subject
ok 3 - cherry-pick -s inserts blank line after one line subject
ok 4 - cherry-pick -s inserts blank line after non-conforming footer
ok 5 - cherry-pick -x inserts blank line when conforming footer not found
ok 6 - cherry-pick -s inserts blank line when conforming footer not found
ok 7 - cherry-pick -x -s inserts blank line when conforming footer not found
ok 8 - cherry-pick -s adds sob when last sob doesnt match committer
ok 9 - cherry-pick -x -s adds sob when last sob doesnt match committer
ok 10 - cherry-pick -s refrains from adding duplicate trailing sob
ok 11 - cherry-pick -x -s adds sob even when trailing sob exists for committer
ok 12 - cherry-pick -x treats "(cherry picked from..." line as part of footer
ok 13 - cherry-pick -s treats "(cherry picked from..." line as part of footer
ok 14 - cherry-pick -x -s treats "(cherry picked from..." line as part of footer
# passed all 14 test(s)
1..14
