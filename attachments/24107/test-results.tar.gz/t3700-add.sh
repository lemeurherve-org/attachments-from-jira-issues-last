ok 1 - Test of git add
ok 2 - Post-check that foo is in the index
ok 3 - Test that "git add -- -q" works
ok 4 - git add: Test that executable bit is not used if core.filemode=0
ok 5 # skip git add: filemode=0 should not get confused by symlink (missing SYMLINKS)
ok 6 - git update-index --add: Test that executable bit is not used...
ok 7 # skip git add: filemode=0 should not get confused by symlink (missing SYMLINKS)
ok 8 # skip git update-index --add: Test that executable bit is not used... (missing SYMLINKS)
ok 9 - .gitignore test setup
ok 10 - .gitignore is honored
ok 11 - error out when attempting to add ignored ones without -f
ok 12 - error out when attempting to add ignored ones without -f
ok 13 - add ignored ones with -f
ok 14 - add ignored ones with -f
ok 15 - add ignored ones with -f
ok 16 - .gitignore with subdirectory
ok 17 - check correct prefix detection
ok 18 - git add with filemode=0, symlinks=0, and unmerged entries
ok 19 - git add with filemode=0, symlinks=0 prefers stage 2 over stage 1
ok 20 - git add --refresh
ok 21 - git add --refresh with pathspec
ok 22 # skip git add should fail atomically upon an unreadable file (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
ok 23 # skip git add --ignore-errors (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
ok 24 # skip git add (add.ignore-errors) (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
ok 25 # skip git add (add.ignore-errors = false) (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
ok 26 # skip --no-ignore-errors overrides config (missing SANITY,POSIXPERM of POSIXPERM,SANITY)
ok 27 # skip git add 'fo\[ou\]bar' ignores foobar (missing BSLASHPSPEC)
ok 28 - git add to resolve conflicts on otherwise ignored path
ok 29 - "add non-existent" should fail
ok 30 - git add --dry-run of existing changed file
ok 31 - git add --dry-run of non-existing file
ok 32 - git add --dry-run of an existing file output
ok 33 - git add --dry-run --ignore-missing of non-existing file
ok 34 - git add --dry-run --ignore-missing of non-existing file output
# passed all 34 test(s)
1..34
