ok 1 - setup
not ok 2 - add :/
#	
#		cat >expected <<-EOF &&
#		add 'anothersub/foo'
#		add 'expected'
#		add 'sub/actual'
#		add 'sub/foo'
#		EOF
#		(cd sub && git add -n :/ >actual) &&
#		test_cmp expected sub/actual
#	
not ok 3 - add :/anothersub
#	
#		(cd sub && git add -n :/anothersub >actual) &&
#		test_cmp expected sub/actual
#	
ok 4 - add :/non-existent
ok 5 # skip a file with the same (long) magic name exists (missing COLON_DIR)
ok 6 # skip a file with the same (short) magic name exists (missing COLON_DIR)
# failed 2 among 6 test(s)
1..6
