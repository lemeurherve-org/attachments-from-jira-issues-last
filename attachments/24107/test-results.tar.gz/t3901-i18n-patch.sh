ok 1 - setup
not ok 2 - format-patch output (ISO-8859-1)
#	
#		git config i18n.logoutputencoding ISO8859-1 &&
#	
#		git format-patch --stdout master..HEAD^ >out-l1 &&
#		git format-patch --stdout HEAD^ >out-l2 &&
#		grep "^Content-Type: text/plain; charset=ISO8859-1" out-l1 &&
#		grep "^From: =?ISO8859-1?q?=C1=E9=ED=20=F3=FA?=" out-l1 &&
#		grep "^Content-Type: text/plain; charset=ISO8859-1" out-l2 &&
#		grep "^From: =?ISO8859-1?q?=C1=E9=ED=20=F3=FA?=" out-l2
#	
not ok 3 - format-patch output (UTF-8)
#	
#		git config i18n.logoutputencoding UTF-8 &&
#	
#		git format-patch --stdout master..HEAD^ >out-u1 &&
#		git format-patch --stdout HEAD^ >out-u2 &&
#		grep "^Content-Type: text/plain; charset=UTF-8" out-u1 &&
#		grep "^From: =?UTF-8?q?=C3=81=C3=A9=C3=AD=20=C3=B3=C3=BA?=" out-u1 &&
#		grep "^Content-Type: text/plain; charset=UTF-8" out-u2 &&
#		grep "^From: =?UTF-8?q?=C3=81=C3=A9=C3=AD=20=C3=B3=C3=BA?=" out-u2
#	
not ok 4 - rebase (U/U)
#	
#		# We want the result of rebase in UTF-8
#		git config i18n.commitencoding UTF-8 &&
#	
#		# The test is about logoutputencoding not affecting the
#		# final outcome -- it is used internally to generate the
#		# patch and the log.
#	
#		git config i18n.logoutputencoding UTF-8 &&
#	
#		# The result will be committed by GIT_COMMITTER_NAME --
#		# we want UTF-8 encoded name.
#		. "$TEST_DIRECTORY"/t3901-utf8.txt &&
#		git checkout -b test &&
#		git rebase master &&
#	
#		check_encoding 2
#	
not ok 5 - rebase (U/L)
#	
#		git config i18n.commitencoding UTF-8 &&
#		git config i18n.logoutputencoding ISO8859-1 &&
#		. "$TEST_DIRECTORY"/t3901-utf8.txt &&
#	
#		git reset --hard side &&
#		git rebase master &&
#	
#		check_encoding 2
#	
ok 6 # skip rebase (L/L) (missing NOT_MINGW)
ok 7 # skip rebase (L/U) (missing NOT_MINGW)
not ok 8 - cherry-pick(U/U)
#	
#		# Both the commitencoding and logoutputencoding is set to UTF-8.
#	
#		git config i18n.commitencoding UTF-8 &&
#		git config i18n.logoutputencoding UTF-8 &&
#		. "$TEST_DIRECTORY"/t3901-utf8.txt &&
#	
#		git reset --hard master &&
#		git cherry-pick side^ &&
#		git cherry-pick side &&
#		git revert HEAD &&
#	
#		check_encoding 3
#	
ok 9 # skip cherry-pick(L/L) (missing NOT_MINGW)
not ok 10 - cherry-pick(U/L)
#	
#		# Commitencoding is set to UTF-8 but logoutputencoding is ISO-8859-1
#	
#		git config i18n.commitencoding UTF-8 &&
#		git config i18n.logoutputencoding ISO8859-1 &&
#		. "$TEST_DIRECTORY"/t3901-utf8.txt &&
#	
#		git reset --hard master &&
#		git cherry-pick side^ &&
#		git cherry-pick side &&
#		git revert HEAD &&
#	
#		check_encoding 3
#	
ok 11 # skip cherry-pick(L/U) (missing NOT_MINGW)
not ok 12 - rebase --merge (U/U)
#	
#		git config i18n.commitencoding UTF-8 &&
#		git config i18n.logoutputencoding UTF-8 &&
#		. "$TEST_DIRECTORY"/t3901-utf8.txt &&
#	
#		git reset --hard side &&
#		git rebase --merge master &&
#	
#		check_encoding 2
#	
not ok 13 - rebase --merge (U/L)
#	
#		git config i18n.commitencoding UTF-8 &&
#		git config i18n.logoutputencoding ISO8859-1 &&
#		. "$TEST_DIRECTORY"/t3901-utf8.txt &&
#	
#		git reset --hard side &&
#		git rebase --merge master &&
#	
#		check_encoding 2
#	
not ok 14 - rebase --merge (L/L)
#	
#		# In this test we want ISO-8859-1 encoded commits as the result
#		git config i18n.commitencoding ISO8859-1 &&
#		git config i18n.logoutputencoding ISO8859-1 &&
#		. "$TEST_DIRECTORY"/t3901-8859-1.txt &&
#	
#		git reset --hard side &&
#		git rebase --merge master &&
#	
#		check_encoding 2 8859
#	
not ok 15 - rebase --merge (L/U)
#	
#		# This is pathological -- use UTF-8 as intermediate form
#		# to get ISO-8859-1 results.
#		git config i18n.commitencoding ISO8859-1 &&
#		git config i18n.logoutputencoding UTF-8 &&
#		. "$TEST_DIRECTORY"/t3901-8859-1.txt &&
#	
#		git reset --hard side &&
#		git rebase --merge master &&
#	
#		check_encoding 2 8859
#	
# failed 10 among 15 test(s)
1..15
