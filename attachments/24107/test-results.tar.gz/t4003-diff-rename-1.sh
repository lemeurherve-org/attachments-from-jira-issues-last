ok 1 - prepare reference tree
ok 2 - prepare work tree
ok 3 - validate output from rename/copy detection (#1)
ok 4 - prepare work tree again
ok 5 - validate output from rename/copy detection (#2)
ok 6 - prepare work tree once again
ok 7 - validate output from rename/copy detection (#3)
# passed all 7 test(s)
1..7
