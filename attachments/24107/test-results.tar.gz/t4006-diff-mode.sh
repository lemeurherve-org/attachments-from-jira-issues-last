ok 1 - setup
ok 2 - chmod
ok 3 - prepare binary file
# passed all 3 test(s)
1..3
