ok 1 - set up terminal for tests
ok 2 - setup
ok 3 - format-patch --ignore-if-in-upstream
ok 4 - format-patch --ignore-if-in-upstream
ok 5 - format-patch doesn't consider merge commits
ok 6 - format-patch result applies
ok 7 - format-patch --ignore-if-in-upstream result applies
ok 8 - commit did not screw up the log message
ok 9 - format-patch did not screw up the log message
ok 10 - replay did not screw up the log message
ok 11 - extra headers
ok 12 - extra headers without newlines
ok 13 - extra headers with multiple To:s
ok 14 - additional command line cc (ascii)
not ok 15 - additional command line cc (rfc822) # TODO known breakage
ok 16 - command line headers
ok 17 - configuration headers and command line headers
ok 18 - command line To: header (ascii)
not ok 19 - command line To: header (rfc822) # TODO known breakage
not ok 20 - command line To: header (rfc2047) # TODO known breakage
ok 21 - configuration To: header (ascii)
not ok 22 - configuration To: header (rfc822) # TODO known breakage
not ok 23 - configuration To: header (rfc2047) # TODO known breakage
ok 24 - --no-to overrides config.to
ok 25 - --no-to and --to replaces config.to
ok 26 - --no-cc overrides config.cc
ok 27 - --no-add-header overrides config.headers
ok 28 - multiple files
ok 29 - reroll count
ok 30 - reroll count (-v)
ok 31 - no threading
ok 32 - thread
ok 33 - thread in-reply-to
ok 34 - thread cover-letter
ok 35 - thread cover-letter in-reply-to
ok 36 - thread explicit shallow
ok 37 - thread deep
ok 38 - thread deep in-reply-to
ok 39 - thread deep cover-letter
ok 40 - thread deep cover-letter in-reply-to
ok 41 - thread via config
ok 42 - thread deep via config
ok 43 - thread config + override
ok 44 - thread config + --no-thread
ok 45 - excessive subject
ok 46 - cover-letter inherits diff options
ok 47 - shortlog of cover-letter wraps overly-long onelines
ok 48 - format-patch respects -U
ok 49 - format-patch -p suppresses stat
ok 50 - format-patch from a subdirectory (1)
ok 51 - format-patch from a subdirectory (2)
ok 52 - format-patch from a subdirectory (3)
ok 53 - format-patch --in-reply-to
ok 54 - format-patch --signoff
ok 55 - format-patch --notes --signoff
ok 56 - options no longer allowed for format-patch
ok 57 - format-patch --numstat should produce a patch
ok 58 - format-patch -- <path>
ok 59 - format-patch --ignore-if-in-upstream HEAD
ok 60 - format-patch --signature
ok 61 - format-patch with format.signature config
ok 62 - format-patch --signature overrides format.signature
ok 63 - format-patch --no-signature ignores format.signature
ok 64 - format-patch --signature --cover-letter
ok 65 - format.signature="" suppresses signatures
ok 66 - format-patch --no-signature suppresses signatures
ok 67 - format-patch --signature="" suppresses signatures
ok 68 # skip format-patch --stdout paginates (missing TTY)
ok 69 # skip format-patch --stdout pagination can be disabled (missing TTY)
ok 70 - format-patch handles multi-line subjects
ok 71 - format-patch handles multi-line encoded subjects
ok 72 - format-patch wraps extremely long subject (ascii)
not ok 73 - format-patch wraps extremely long subject (rfc2047)
#	
#		rm -rf patches/ &&
#		echo content >>file &&
#		git add file &&
#		git commit -m "$M512" &&
#		git format-patch --stdout -1 >patch &&
#		sed -n "/^Subject/p; /^ /p; /^$/q" <patch >subject &&
#		test_cmp expect subject
#	
ok 74 - format-patch quotes dot in from-headers
ok 75 - format-patch quotes double-quote in from-headers
not ok 76 - format-patch uses rfc2047-encoded from-headers when necessary
#	
#		check_author "Föo Bar"
#	
not ok 77 - rfc2047-encoded from-headers leave no rfc822 specials
#	
#		check_author "Föo B. Bar"
#	
ok 78 - format-patch wraps moderately long from-header (ascii)
ok 79 - format-patch wraps extremely long from-header (ascii)
ok 80 - format-patch wraps extremely long from-header (rfc822)
not ok 81 - format-patch wraps extremely long from-header (rfc2047)
#	
#		check_author "Foö Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar Foo Bar"
#	
ok 82 - subject lines do not have 822 atom-quoting
ok 83 - subject prefixes have space prepended
ok 84 - empty subject prefix does not have extra space
ok 85 - signoff: commit with no body
ok 86 - signoff: commit with only subject
ok 87 - signoff: commit with only subject that does not end with NL
ok 88 - signoff: no existing signoffs
ok 89 - signoff: no existing signoffs and no trailing NL
ok 90 - signoff: some random signoff
ok 91 - signoff: misc conforming footer elements
ok 92 - signoff: some random signoff-alike
ok 93 - signoff: not really a signoff
ok 94 - signoff: not really a signoff (2)
ok 95 - signoff: valid S-o-b paragraph in the middle
ok 96 - signoff: the same signoff at the end
ok 97 - signoff: the same signoff at the end, no trailing NL
ok 98 - signoff: the same signoff NOT at the end
ok 99 - signoff: detect garbage in non-conforming footer
ok 100 - signoff: footer begins with non-signoff without @ sign
ok 101 - format patch ignores color.ui
ok 102 - cover letter using branch description (1)
ok 103 - cover letter using branch description (2)
ok 104 - cover letter using branch description (3)
ok 105 - cover letter using branch description (4)
ok 106 - cover letter using branch description (5)
ok 107 - cover letter using branch description (6)
ok 108 - cover letter with nothing
ok 109 - cover letter auto
ok 110 - cover letter auto user override
# still have 5 known breakage(s)
# failed 4 among remaining 105 test(s)
1..110
