ok 1 - setup
ok 2 - GIT_EXTERNAL_DIFF environment
ok 3 - GIT_EXTERNAL_DIFF environment should apply only to diff
ok 4 - GIT_EXTERNAL_DIFF environment and --no-ext-diff
ok 5 # skip typechange diff (missing SYMLINKS)
ok 6 - diff.external
ok 7 - diff.external should apply only to diff
ok 8 - diff.external and --no-ext-diff
ok 9 - diff attribute
ok 10 - diff attribute should apply only to diff
ok 11 - diff attribute and --no-ext-diff
ok 12 - diff attribute
ok 13 - diff attribute should apply only to diff
ok 14 - diff attribute and --no-ext-diff
ok 15 - GIT_EXTERNAL_DIFF trumps diff.external
ok 16 - attributes trump GIT_EXTERNAL_DIFF and diff.external
ok 17 - no diff with -diff
ok 18 - force diff with "diff"
ok 19 - GIT_EXTERNAL_DIFF with more than one changed files
ok 20 - GIT_EXTERNAL_DIFF generates pretty paths
ok 21 - external diff with autocrlf = true
ok 22 - diff --cached
# passed all 22 test(s)
1..22
