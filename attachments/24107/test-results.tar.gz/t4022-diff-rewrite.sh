ok 1 - setup
ok 2 - detect rewrite
ok 3 - show deletion diff without -D
ok 4 - suppress deletion diff with -D
ok 5 - show deletion diff with -B
ok 6 - suppress deletion diff with -B -D
ok 7 - prepare a file that ends with an incomplete line
ok 8 - rewrite the middle 90% of sequence file and terminate with newline
ok 9 - confirm that sequence file is considered a rewrite
ok 10 - no newline at eof is on its own line without -B
ok 11 - no newline at eof is on its own line with -B
# passed all 11 test(s)
1..11
