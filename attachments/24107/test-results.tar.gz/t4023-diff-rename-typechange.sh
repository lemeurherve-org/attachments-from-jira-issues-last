ok 1 # skip setup (missing SYMLINKS)
ok 2 # skip cross renames to be detected for regular files (missing SYMLINKS)
ok 3 # skip cross renames to be detected for typechange (missing SYMLINKS)
ok 4 # skip moves and renames (missing SYMLINKS)
# passed all 4 test(s)
1..4
