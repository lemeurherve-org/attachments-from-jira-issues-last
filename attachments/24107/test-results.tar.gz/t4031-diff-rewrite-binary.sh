ok 1 - create binary file with changes
ok 2 - vanilla diff is binary
ok 3 - rewrite diff is binary
ok 4 - rewrite diff can show binary patch
ok 5 - rewrite diff --numstat shows binary changes
ok 6 - diff --stat counts binary rewrite as 0 lines
ok 7 - setup textconv
ok 8 - rewrite diff respects textconv
# passed all 8 test(s)
1..8
