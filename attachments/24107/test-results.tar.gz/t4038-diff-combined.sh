ok 1 - setup
ok 2 - check combined output (1)
ok 3 - check combined output (2)
ok 4 - diagnose truncated file
ok 5 - setup for --cc --raw
ok 6 - check --cc --raw with four trees
ok 7 - check --cc --raw with forty trees
ok 8 - setup combined ignore spaces
ok 9 - check combined output (no ignore space)
ok 10 - check combined output (ignore space at eol)
ok 11 - check combined output (ignore space change)
ok 12 - check combined output (ignore all spaces)
ok 13 - combine diff coalesce simple
ok 14 - combine diff coalesce tricky
not ok 15 - combine diff coalesce three parents # TODO known breakage
# still have 1 known breakage(s)
# passed all remaining 14 test(s)
1..15
