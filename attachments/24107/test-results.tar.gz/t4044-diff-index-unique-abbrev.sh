ok 1 - setup
ok 2 - diff does not produce ambiguous index line
# passed all 2 test(s)
1..2
