ok 1 - setup
ok 2 - diff-files -0
ok 3 - diff-files -1
ok 4 - diff-files -2
ok 5 - diff-files -3
# passed all 5 test(s)
1..5
