ok 1 - setup
ok 2 - mode-only change show as a 0-line change
ok 3 - binary changes do not count in lines
ok 4 - exclude unmerged entries from total file count
# passed all 4 test(s)
1..4
