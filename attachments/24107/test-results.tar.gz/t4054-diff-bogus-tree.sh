ok 1 - create bogus tree
ok 2 - create tree with matching file
ok 3 - raw diff shows null sha1 (addition)
ok 4 - raw diff shows null sha1 (removal)
ok 5 - raw diff shows null sha1 (modification)
ok 6 - raw diff shows null sha1 (other direction)
ok 7 - raw diff shows null sha1 (reverse)
ok 8 - raw diff shows null sha1 (index)
ok 9 - patch fails due to bogus sha1 (addition)
ok 10 - patch fails due to bogus sha1 (removal)
ok 11 - patch fails due to bogus sha1 (modification)
ok 12 - patch fails due to bogus sha1 (other direction)
ok 13 - patch fails due to bogus sha1 (reverse)
ok 14 - patch fails due to bogus sha1 (index)
# passed all 14 test(s)
1..14
