ok 1 - apply diff between 0 and 1
ok 2 - apply diff between 0 and 2
ok 3 - apply diff between 0 and 3
ok 4 - apply diff between 1 and 0
ok 5 - apply diff between 1 and 2
ok 6 - apply diff between 1 and 3
ok 7 - apply diff between 2 and 0
ok 8 - apply diff between 2 and 1
ok 9 - apply diff between 2 and 3
ok 10 - apply diff between 3 and 0
ok 11 - apply diff between 3 and 1
ok 12 - apply diff between 3 and 2
# passed all 12 test(s)
1..12
