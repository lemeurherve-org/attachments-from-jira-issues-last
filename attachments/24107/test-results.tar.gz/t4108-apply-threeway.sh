ok 1 - setup
ok 2 - apply without --3way
ok 3 - apply with --3way
ok 4 - apply with --3way with rerere enabled
ok 5 - apply -3 with add/add conflict setup
ok 6 - apply -3 with add/add conflict
ok 7 - apply -3 with add/add conflict (dirty working tree)
# passed all 7 test(s)
1..7
