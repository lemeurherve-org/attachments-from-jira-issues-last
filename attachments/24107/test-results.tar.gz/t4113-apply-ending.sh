ok 1 - setup
ok 2 - apply at the end
ok 3 - apply at the beginning
# passed all 3 test(s)
1..3
