ok 1 # skip setup (missing SYMLINKS)
ok 2 # skip apply symlink patch (missing SYMLINKS)
ok 3 # skip apply --index symlink patch (missing SYMLINKS)
# passed all 3 test(s)
1..3
