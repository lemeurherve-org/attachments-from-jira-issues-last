ok 1 - setup
ok 2 - apply --reject is incompatible with --3way
ok 3 - apply without --reject should fail
ok 4 - apply without --reject should fail
ok 5 - apply with --reject should fail but update the file
ok 6 - apply with --reject should fail but update the file
ok 7 - the same test with --verbose
ok 8 - apply cleanly with --verbose
# passed all 8 test(s)
1..8
