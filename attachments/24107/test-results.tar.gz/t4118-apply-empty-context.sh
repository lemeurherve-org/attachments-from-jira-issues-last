ok 1 - setup
ok 2 - apply --numstat
ok 3 - apply --apply
# passed all 3 test(s)
1..3
