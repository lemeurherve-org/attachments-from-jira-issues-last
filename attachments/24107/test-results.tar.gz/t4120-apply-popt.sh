filemode disabled on the filesystem
ok 1 - setup
ok 2 - apply git diff with -p2
ok 3 - apply with too large -p
ok 4 - apply (-p2) traditional diff with funny filenames
ok 5 - apply with too large -p and fancy filename
ok 6 - apply (-p2) diff, mode change only
ok 7 # skip file mode was changed (missing FILEMODE)
ok 8 - apply (-p2) diff, rename
# passed all 8 test(s)
1..8
