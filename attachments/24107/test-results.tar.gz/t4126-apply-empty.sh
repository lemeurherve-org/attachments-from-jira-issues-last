ok 1 - setup
ok 2 - apply empty
ok 3 - apply --index empty
ok 4 - apply create
ok 5 - apply --index create
# passed all 5 test(s)
1..5
