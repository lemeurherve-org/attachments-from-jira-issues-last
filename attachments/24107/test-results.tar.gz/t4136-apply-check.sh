ok 1 - setup
ok 2 - apply --check exits non-zero with unrecognized input
# passed all 2 test(s)
1..2
