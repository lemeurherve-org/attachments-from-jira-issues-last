ok 1 - setup
ok 2 - pretty
ok 3 - pretty (tformat)
ok 4 - pretty (shortcut)
ok 5 - format
ok 6 - format %w(11,1,2)
ok 7 - format %w(,1,2)
ok 8 - oneline
ok 9 - diff-filter=A
ok 10 - diff-filter=M
ok 11 - diff-filter=D
ok 12 - diff-filter=R
ok 13 - diff-filter=C
ok 14 - git log --follow
ok 15 - git log --no-walk <commits> sorts by commit time
ok 16 - git log --no-walk=sorted <commits> sorts by commit time
ok 17 - git log --no-walk=unsorted <commits> leaves list of commits as given
ok 18 - git show <commits> leaves list of commits as given
ok 19 - setup case sensitivity tests
ok 20 - log --grep
ok 21 - log --grep option parsing
ok 22 - log -i --grep
ok 23 - log --grep -i
ok 24 - log -F -E --grep=<ere> uses ere
ok 25 - simple log --graph
ok 26 - set up merge history
ok 27 - log --graph with merge
ok 28 - log --raw --graph -m with merge
ok 29 - diff-tree --graph
ok 30 - log --graph with full output
ok 31 - set up more tangled history
ok 32 - log --graph with merge
ok 33 - log.decorate configuration
ok 34 - reflog is expected format
ok 35 - whatchanged is expected format
ok 36 - log.abbrevCommit configuration
ok 37 - show added path under "--follow -M"
ok 38 - log --graph with diff and stats
ok 39 - dotdot is a parent directory
# passed all 39 test(s)
1..39
