ok 1 - setup
ok 2 - No mailmap
ok 3 - default .mailmap
ok 4 - mailmap.file set
ok 5 - mailmap.file override
ok 6 - mailmap.file non-existent
ok 7 - name entry after email entry
ok 8 - name entry after email entry, case-insensitive
ok 9 - No mailmap files, but configured
ok 10 - setup mailmap blob tests
ok 11 - mailmap.blob set
ok 12 - mailmap.blob overrides .mailmap
ok 13 - mailmap.file overrides mailmap.blob
ok 14 - mailmap.blob can be missing
ok 15 - mailmap.blob defaults to off in non-bare repo
ok 16 - mailmap.blob defaults to HEAD:.mailmap in bare repo
ok 17 - cleanup after mailmap.blob tests
ok 18 - Shortlog output (complex mapping)
ok 19 - Log output (complex mapping)
ok 20 - Log output with --use-mailmap
ok 21 - Log output with log.mailmap
ok 22 - Grep author with --use-mailmap
ok 23 - Grep author with log.mailmap
ok 24 - Only grep replaced author with --use-mailmap
ok 25 - Blame output (complex mapping)
# passed all 25 test(s)
1..25
