ok 1 - setup
ok 2 - patch-id output is well-formed
ok 3 - patch-id detects equality
ok 4 - patch-id detects inequality
ok 5 - patch-id supports git-format-patch output
ok 6 - whitespace is irrelevant in footer
ok 7 - patch-id supports git-format-patch MIME output
ok 8 - patch-id handles no-nl-at-eof markers
# passed all 8 test(s)
1..8
