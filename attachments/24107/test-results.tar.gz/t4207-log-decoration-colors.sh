ok 1 - setup
ok 2 - Commit Decorations Colored Correctly
# passed all 2 test(s)
1..2
