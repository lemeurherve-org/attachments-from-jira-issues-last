ok 1 - setup
not ok 2 - "git log :/" should not be ambiguous
#	
#		git log :/
#	
not ok 3 - "git log :/a" should be ambiguous (applied both rev and worktree)
#	
#		: >a &&
#		test_must_fail git log :/a 2>error &&
#		grep ambiguous error
#	
not ok 4 - "git log :/a -- " should not be ambiguous
#	
#		git log :/a --
#	
ok 5 - "git log -- :/a" should not be ambiguous
ok 6 - "git log :" should be ambiguous
ok 7 - git log -- :
not ok 8 - git log HEAD -- :/
#	
#		cat >expected <<-EOF &&
#		24b24cf initial
#		EOF
#		(cd sub && git log --oneline HEAD -- :/ >../actual) &&
#		test_cmp expected actual
#	
# failed 4 among 8 test(s)
1..8
