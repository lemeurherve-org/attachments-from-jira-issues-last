ok 1 - setup
ok 2 - log --grep
ok 3 - log --grep --regexp-ignore-case
ok 4 - log --grep -i
ok 5 - log --author --regexp-ignore-case
ok 6 - log --author -i
ok 7 - log -G (nomatch)
ok 8 - log -G (match)
ok 9 - log -G --regexp-ignore-case (nomatch)
ok 10 - log -G -i (nomatch)
ok 11 - log -G --regexp-ignore-case (match)
ok 12 - log -G -i (match)
ok 13 - log -G --textconv (missing textconv tool)
ok 14 - log -G --no-textconv (missing textconv tool)
ok 15 - log -S (nomatch)
ok 16 - log -S (match)
ok 17 - log -S --regexp-ignore-case (match)
ok 18 - log -S -i (match)
ok 19 - log -S --regexp-ignore-case (nomatch)
ok 20 - log -S -i (nomatch)
ok 21 - log -S --textconv (missing textconv tool)
ok 22 - log -S --no-textconv (missing textconv tool)
# passed all 22 test(s)
1..22
