ok 1 - create commits in different encodings
not ok 2 - log --grep searches in log output encoding (utf8)
#	
#		cat >expect <<-\EOF &&
#		latin1
#		utf8
#		EOF
#		git log --encoding=utf8 --format=%s --grep=$utf8_e >actual &&
#		test_cmp expect actual
#	
ok 3 # skip log --grep searches in log output encoding (latin1) (missing NOT_MINGW)
ok 4 # skip log --grep does not find non-reencoded values (utf8) (missing NOT_MINGW)
ok 5 - log --grep does not find non-reencoded values (latin1)
# failed 1 among 5 test(s)
1..5
