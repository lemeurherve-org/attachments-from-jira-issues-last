ok 1 - setup
ok 2 - git log with broken author email
ok 3 - git log --format with broken author email
# passed all 3 test(s)
1..3
