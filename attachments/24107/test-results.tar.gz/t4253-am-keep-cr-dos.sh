ok 1 - setup repository with dos files
ok 2 - am with dos files without --keep-cr
ok 3 - am with dos files with --keep-cr
ok 4 - am with dos files config am.keepcr
ok 5 - am with dos files config am.keepcr overridden by --no-keep-cr
ok 6 - am with dos files with --keep-cr continue
ok 7 - am with unix files config am.keepcr overridden by --no-keep-cr
# passed all 7 test(s)
1..7
