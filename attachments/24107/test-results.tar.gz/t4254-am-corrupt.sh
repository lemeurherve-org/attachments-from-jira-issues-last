ok 1 - setup
ok 2 - try to apply corrupted patch
ok 3 - compare diagnostic; ensure file is still here
# passed all 3 test(s)
1..3
