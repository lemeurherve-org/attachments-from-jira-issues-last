ok 1 - setup
ok 2 - file add A, !B
ok 3 - file add !A, B
ok 4 - file add A, B (same)
ok 5 - file add A, B (different)
ok 6 - file change A, !B
ok 7 - file change !A, B
ok 8 - file change A, B (same)
ok 9 - file change A, B (different)
ok 10 - file change A, B (mixed)
ok 11 - file remove A, !B
ok 12 - file remove !A, B
ok 13 - file remove A, B (same)
ok 14 - file change A, remove B
ok 15 - file remove A, change B
ok 16 - tree add A, B (same)
ok 17 - tree add A, B (different)
ok 18 - tree unchanged A, removed B
ok 19 - turn file to tree
ok 20 - turn tree to file
# passed all 20 test(s)
1..20
