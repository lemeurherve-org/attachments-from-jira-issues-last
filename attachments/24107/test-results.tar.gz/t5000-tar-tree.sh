ok 1 - populate workdir
ok 2 - add ignored file
ok 3 - add files to repository
ok 4 - create bare clone
ok 5 - remove ignored file
ok 6 - git archive
ok 7 - git tar-tree
ok 8 - git archive vs. git tar-tree
ok 9 - git archive on large files
ok 10 - git archive in a bare repo
ok 11 - git archive vs. the same in a bare repo
ok 12 - git archive with --output
ok 13 - git archive --remote
ok 14 - validate file modification time
ok 15 - git get-tar-commit-id
ok 16 - extract tar archive
ok 17 - validate filenames
ok 18 - validate file contents
ok 19 - git tar-tree with prefix
ok 20 - extract tar archive with prefix
ok 21 - validate filenames with prefix
ok 22 - validate file contents with prefix
ok 23 - create archives with substfiles
ok 24 - extract substfiles
ok 25 - validate substfile contents
ok 26 - extract substfiles from archive with prefix
ok 27 - validate substfile contents from archive with prefix
ok 28 - git archive with --output, override inferred format
ok 29 - git archive --list outside of a git repo
ok 30 - clients cannot access unreachable commits
ok 31 - git-archive --prefix=olde-
ok 32 - setup tar filters
ok 33 - archive --list mentions user filter
ok 34 - archive --list shows only enabled remote filters
not ok 35 - invoke tar filter by format
#	
#		git archive --format=tar.foo HEAD >config.tar.foo &&
#		tr ab ba <config.tar.foo >config.tar &&
#		test_cmp b.tar config.tar &&
#		git archive --format=bar HEAD >config.bar &&
#		tr ab ba <config.bar >config.tar &&
#		test_cmp b.tar config.tar
#	
ok 36 - invoke tar filter by extension
ok 37 - default output format remains tar
ok 38 - extension matching requires dot
not ok 39 - only enabled filters are available remotely
#	
#		test_must_fail git archive --remote=. --format=tar.foo HEAD \
#			>remote.tar.foo &&
#		git archive --remote=. --format=bar >remote.bar HEAD &&
#		test_cmp remote.bar config.bar
#	
ok 40 - git archive --format=tgz
ok 41 - git archive --format=tar.gz
ok 42 - infer tgz from .tgz filename
ok 43 - infer tgz from .tar.gz filename
ok 44 - extract tgz file
ok 45 - remote tar.gz is allowed by default
ok 46 - remote tar.gz can be disabled
# failed 2 among 46 test(s)
1..46
