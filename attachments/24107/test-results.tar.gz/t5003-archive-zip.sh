ok 1 - populate workdir
ok 2 # skip add symlink (missing UNZIP_SYMLINKS,SYMLINKS of SYMLINKS,UNZIP_SYMLINKS)
ok 3 - prepare file list
ok 4 - add ignored file
ok 5 - add files to repository
ok 6 - setup export-subst
ok 7 - create bare clone
ok 8 - remove ignored file
ok 9 - git archive --format=zip
ok 10 -  extract ZIP archive
ok 11 -  validate filenames
ok 12 -  validate file contents
ok 13 - git archive --format=zip in a bare repo
ok 14 - git archive --format=zip vs. the same in a bare repo
ok 15 - git archive --format=zip with --output
ok 16 - git archive with --output, inferring format
ok 17 - git archive --format=zip with prefix
ok 18 -  extract ZIP archive
ok 19 -  validate filenames
ok 20 -  validate file contents
ok 21 - git archive -0 --format=zip on large files
ok 22 -  extract ZIP archive
ok 23 -  validate filenames
ok 24 -  validate file contents
ok 25 - git archive --format=zip on large files
ok 26 -  extract ZIP archive
ok 27 -  validate filenames
ok 28 -  validate file contents
# passed all 28 test(s)
1..28
