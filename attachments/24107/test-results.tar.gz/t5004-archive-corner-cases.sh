ok 1 - create commit with empty tree
ok 2 - tar archive of empty tree is empty
ok 3 - tar archive of empty tree with prefix
ok 4 - zip archive of empty tree is empty
ok 5 - zip archive of empty tree with prefix
ok 6 - archive complains about pathspec on empty tree
ok 7 - create a commit with an empty subtree
ok 8 - archive empty subtree with no pathspec
ok 9 - archive empty subtree by direct pathspec
# passed all 9 test(s)
1..9
