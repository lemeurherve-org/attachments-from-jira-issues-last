ok 1 - setup
ok 2 - pack without delta
ok 3 - pack-objects with bogus arguments
ok 4 - unpack without delta
ok 5 - check unpack without delta
ok 6 - pack with REF_DELTA
ok 7 - unpack with REF_DELTA
ok 8 - check unpack with REF_DELTA
ok 9 - pack with OFS_DELTA
ok 10 - unpack with OFS_DELTA
ok 11 - check unpack with OFS_DELTA
ok 12 - compare delta flavors
ok 13 - use packed objects
ok 14 - use packed deltified (REF_DELTA) objects
ok 15 - use packed deltified (OFS_DELTA) objects
ok 16 - survive missing objects/pack directory
ok 17 - verify pack
ok 18 - verify pack -v
ok 19 - verify-pack catches mismatched .idx and .pack files
not ok 20 - verify-pack catches a corrupted pack signature
#	cat test-1-${packname_1}.pack >test-3.pack &&
#	     echo | dd of=test-3.pack count=1 bs=1 conv=notrunc seek=2 &&
#	     if git verify-pack test-3.idx
#	     then false
#	     else :;
#	     fi
not ok 21 - verify-pack catches a corrupted pack version
#	cat test-1-${packname_1}.pack >test-3.pack &&
#	     echo | dd of=test-3.pack count=1 bs=1 conv=notrunc seek=7 &&
#	     if git verify-pack test-3.idx
#	     then false
#	     else :;
#	     fi
not ok 22 - verify-pack catches a corrupted type/size of the 1st packed object data
#	cat test-1-${packname_1}.pack >test-3.pack &&
#	     echo | dd of=test-3.pack count=1 bs=1 conv=notrunc seek=12 &&
#	     if git verify-pack test-3.idx
#	     then false
#	     else :;
#	     fi
not ok 23 - verify-pack catches a corrupted sum of the index file itself
#	l=`wc -c <test-3.idx` &&
#	     l=`expr $l - 20` &&
#	     cat test-1-${packname_1}.pack >test-3.pack &&
#	     printf "%20s" "" | dd of=test-3.idx count=20 bs=1 conv=notrunc seek=$l &&
#	     if git verify-pack test-3.pack
#	     then false
#	     else :;
#	     fi
ok 24 - build pack index for an existing pack
ok 25 - unpacking with --strict
ok 26 - index-pack with --strict
ok 27 - honor pack.packSizeLimit
ok 28 - verify resulting packs
ok 29 - tolerate packsizelimit smaller than biggest object
ok 30 - verify resulting packs
ok 31 - fake a SHA1 hash collision
ok 32 - make sure index-pack detects the SHA1 collision
ok 33 - make sure index-pack detects the SHA1 collision (large blobs)
# failed 4 among 33 test(s)
1..33
