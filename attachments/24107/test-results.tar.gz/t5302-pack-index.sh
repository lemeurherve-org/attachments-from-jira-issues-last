ok 1 - setup
ok 2 - pack-objects with index version 1
ok 3 - pack-objects with index version 2
ok 4 - both packs should be identical
ok 5 - index v1 and index v2 should be different
ok 6 - index-pack with index version 1
ok 7 - index-pack with index version 2
ok 8 - index-pack results should match pack-objects ones
ok 9 - index-pack --verify on index version 1
ok 10 - index-pack --verify on index version 2
ok 11 - pack-objects --index-version=2, is not accepted
ok 12 - index v2: force some 64-bit offsets with pack-objects
ok 13 - index v2: verify a pack with some 64-bit offsets
ok 14 - 64-bit offsets: should be different from previous index v2 results
ok 15 - index v2: force some 64-bit offsets with index-pack
ok 16 - 64-bit offsets: index-pack result should match pack-objects one
ok 17 - index-pack --verify on 64-bit offset v2 (cheat)
ok 18 - index-pack --verify on 64-bit offset v2
ok 19 - [index v1] 1) stream pack to repository
not ok 20 - [index v1] 2) create a stealth corruption in a delta base reference
#	# This test assumes file_101 is a delta smaller than 16 bytes.
#	     # It should be against file_100 but we substitute its base for file_099
#	     sha1_101=`git hash-object file_101` &&
#	     sha1_099=`git hash-object file_099` &&
#	     offs_101=`index_obj_offset 1.idx $sha1_101` &&
#	     nr_099=`index_obj_nr 1.idx $sha1_099` &&
#	     chmod +w ".git/objects/pack/pack-${pack1}.pack" &&
#	     dd of=".git/objects/pack/pack-${pack1}.pack" seek=$(($offs_101 + 1)) \
#	        if=".git/objects/pack/pack-${pack1}.idx" \
#	        skip=$((4 + 256 * 4 + $nr_099 * 24)) \
#	        bs=1 count=20 conv=notrunc &&
#	     git cat-file blob $sha1_101 > file_101_foo1
not ok 21 - [index v1] 3) corrupted delta happily returned wrong data
#	test -f file_101_foo1 && ! cmp file_101 file_101_foo1
not ok 22 - [index v1] 4) confirm that the pack is actually corrupted
#	test_must_fail git fsck --full $commit
ok 23 - [index v1] 5) pack-objects happily reuses corrupted data
not ok 24 - [index v1] 6) newly created pack is BAD !
#	test_must_fail git verify-pack -v "test-4-${pack1}.pack"
ok 25 - [index v2] 1) stream pack to repository
not ok 26 - [index v2] 2) create a stealth corruption in a delta base reference
#	# This test assumes file_101 is a delta smaller than 16 bytes.
#	     # It should be against file_100 but we substitute its base for file_099
#	     sha1_101=`git hash-object file_101` &&
#	     sha1_099=`git hash-object file_099` &&
#	     offs_101=`index_obj_offset 1.idx $sha1_101` &&
#	     nr_099=`index_obj_nr 1.idx $sha1_099` &&
#	     chmod +w ".git/objects/pack/pack-${pack1}.pack" &&
#	     dd of=".git/objects/pack/pack-${pack1}.pack" seek=$(($offs_101 + 1)) \
#	        if=".git/objects/pack/pack-${pack1}.idx" \
#	        skip=$((8 + 256 * 4 + $nr_099 * 20)) \
#	        bs=1 count=20 conv=notrunc &&
#	     git cat-file blob $sha1_101 > file_101_foo2
not ok 27 - [index v2] 3) corrupted delta happily returned wrong data
#	test -f file_101_foo2 && ! cmp file_101 file_101_foo2
not ok 28 - [index v2] 4) confirm that the pack is actually corrupted
#	test_must_fail git fsck --full $commit
not ok 29 - [index v2] 5) pack-objects refuses to reuse corrupted data
#	test_must_fail git pack-objects test-5 <obj-list &&
#	     test_must_fail git pack-objects --no-reuse-object test-6 <obj-list
not ok 30 - [index v2] 6) verify-pack detects CRC mismatch
#	rm -f .git/objects/pack/* &&
#	     git index-pack --index-version=2 --stdin < "test-1-${pack1}.pack" &&
#	     git verify-pack ".git/objects/pack/pack-${pack1}.pack" &&
#	     obj=`git hash-object file_001` &&
#	     nr=`index_obj_nr ".git/objects/pack/pack-${pack1}.idx" $obj` &&
#	     chmod +w ".git/objects/pack/pack-${pack1}.idx" &&
#	     printf xxxx | dd of=".git/objects/pack/pack-${pack1}.idx" conv=notrunc \
#	        bs=1 count=4 seek=$((8 + 256 * 4 + `wc -l <obj-list` * 20 + $nr * 4)) &&
#	     ( while read obj
#	       do git cat-file -p $obj >/dev/null || exit 1
#	       done <obj-list ) &&
#	     test_must_fail git verify-pack ".git/objects/pack/pack-${pack1}.pack"
#	
ok 31 - running index-pack in the object store
# failed 9 among 31 test(s)
1..31
