ok 1 - initial setup validation
not ok 2 - create corruption in header of first object
#	do_corrupt_object $blob_1 0 < zero &&
#	     test_must_fail git cat-file blob $blob_1 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_2 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_3 > /dev/null
ok 3 - ... but having a loose copy allows for full recovery
not ok 4 - ... and loose copy of first delta allows for partial recovery
#	git prune-packed &&
#	     test_must_fail git cat-file blob $blob_2 > /dev/null &&
#	     mv ${pack}.idx tmp &&
#	     git hash-object -t blob -w file_2 &&
#	     mv tmp ${pack}.idx &&
#	     test_must_fail git cat-file blob $blob_1 > /dev/null &&
#	     git cat-file blob $blob_2 > /dev/null &&
#	     git cat-file blob $blob_3 > /dev/null
ok 5 - create corruption in data of first object
ok 6 - ... but having a loose copy allows for full recovery
ok 7 - ... and loose copy of second object allows for partial recovery
not ok 8 - create corruption in header of first delta
#	create_new_pack &&
#	     git prune-packed &&
#	     do_corrupt_object $blob_2 0 < zero &&
#	     git cat-file blob $blob_1 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_2 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_3 > /dev/null
ok 9 - ... but having a loose copy allows for full recovery
ok 10 - ... and then a repack "clears" the corruption
ok 11 - create corruption in data of first delta
ok 12 - ... but having a loose copy allows for full recovery
ok 13 - ... and then a repack "clears" the corruption
not ok 14 - corruption in delta base reference of first delta (OBJ_REF_DELTA)
#	create_new_pack &&
#	     git prune-packed &&
#	     do_corrupt_object $blob_2 2 < zero &&
#	     git cat-file blob $blob_1 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_2 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_3 > /dev/null
ok 15 - ... but having a loose copy allows for full recovery
ok 16 - ... and then a repack "clears" the corruption
not ok 17 - corruption #0 in delta base reference of first delta (OBJ_OFS_DELTA)
#	create_new_pack --delta-base-offset &&
#	     git prune-packed &&
#	     do_corrupt_object $blob_2 2 < zero &&
#	     git cat-file blob $blob_1 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_2 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_3 > /dev/null
ok 18 - ... but having a loose copy allows for full recovery
ok 19 - ... and then a repack "clears" the corruption
not ok 20 - corruption #1 in delta base reference of first delta (OBJ_OFS_DELTA)
#	create_new_pack --delta-base-offset &&
#	     git prune-packed &&
#	     printf "\001" | do_corrupt_object $blob_2 2 &&
#	     git cat-file blob $blob_1 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_2 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_3 > /dev/null
ok 21 - ... but having a loose copy allows for full recovery
ok 22 - ... and then a repack "clears" the corruption
not ok 23 - ... and a redundant pack allows for full recovery too
#	do_corrupt_object $blob_2 2 < zero &&
#	     git cat-file blob $blob_1 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_2 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_3 > /dev/null &&
#	     mv ${pack}.idx tmp &&
#	     git hash-object -t blob -w file_1 &&
#	     git hash-object -t blob -w file_2 &&
#	     printf "$blob_1\n$blob_2\n" | git pack-objects .git/objects/pack/pack &&
#	     git prune-packed &&
#	     mv tmp ${pack}.idx &&
#	     git cat-file blob $blob_1 > /dev/null &&
#	     git cat-file blob $blob_2 > /dev/null &&
#	     git cat-file blob $blob_3 > /dev/null
not ok 24 - corrupting header to have too small output buffer fails unpack
#	create_new_pack &&
#	     git prune-packed &&
#	     printf "\262\001" | do_corrupt_object $blob_1 0 &&
#	     test_must_fail git cat-file blob $blob_1 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_2 > /dev/null &&
#	     test_must_fail git cat-file blob $blob_3 > /dev/null
# failed 8 among 24 test(s)
1..24
