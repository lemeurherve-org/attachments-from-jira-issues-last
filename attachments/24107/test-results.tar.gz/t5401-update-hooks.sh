ok 1 - setup
ok 2 - push
ok 3 - updated as expected
ok 4 - hooks ran
ok 5 - pre-receive hook input
ok 6 - update hook arguments
ok 7 - post-receive hook input
ok 8 - post-update hook arguments
ok 9 - all hook stdin is /dev/null
ok 10 - all *-receive hook args are empty
ok 11 - send-pack produced no output
ok 12 - send-pack stderr contains hook messages
# passed all 12 test(s)
1..12
