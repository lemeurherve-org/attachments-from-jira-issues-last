ok 1 - setup
ok 2 - post-merge does not run for up-to-date 
ok 3 - post-merge runs as expected 
ok 4 - post-merge from normal merge receives the right argument 
ok 5 - post-merge from squash merge runs as expected 
ok 6 - post-merge from squash merge receives the right argument 
# passed all 6 test(s)
1..6
