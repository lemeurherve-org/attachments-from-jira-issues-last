ok 1 - setup
ok 2 - non forced push should die not segfault
ok 3 - forced push should succeed
# passed all 3 test(s)
1..3
