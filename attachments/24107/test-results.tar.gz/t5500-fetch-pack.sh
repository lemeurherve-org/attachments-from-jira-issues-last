ok 1 - setup
ok 2 - 1st pull
ok 3 - post 1st pull setup
ok 4 - 2nd pull
ok 5 - 3rd pull
ok 6 - single branch clone
ok 7 - single branch object count
ok 8 - single given branch clone
ok 9 - clone shallow depth 1
ok 10 - clone shallow
ok 11 - clone shallow depth count
ok 12 - clone shallow object count
ok 13 - clone shallow object count (part 2)
ok 14 - fsck in shallow repo
ok 15 - simple fetch in shallow repo
ok 16 - no changes expected
ok 17 - fetch same depth in shallow repo
ok 18 - no changes expected
ok 19 - add two more
ok 20 - pull in shallow repo
ok 21 - clone shallow object count
ok 22 - add two more (part 2)
ok 23 - deepening pull in shallow repo
ok 24 - clone shallow object count
ok 25 - deepening fetch in shallow repo
ok 26 - clone shallow object count
ok 27 - pull in shallow repo with missing merge base
ok 28 - additional simple shallow deepenings
ok 29 - clone shallow depth count
ok 30 - clone shallow object count
ok 31 - fetch --no-shallow on full repo
ok 32 - fetch --depth --no-shallow
ok 33 - turn shallow to complete repository
ok 34 - clone shallow without --no-single-branch
ok 35 - clone shallow object count
ok 36 - clone shallow with --branch
ok 37 - clone shallow object count
ok 38 - clone shallow with detached HEAD
ok 39 - shallow clone pulling tags
ok 40 - shallow cloning single tag
ok 41 - clone shallow with packed refs
ok 42 - setup tests for the --stdin parameter
ok 43 - fetch refs from cmdline
ok 44 - fetch refs from stdin
ok 45 - fetch mixed refs from cmdline and stdin
ok 46 - test duplicate refs from stdin
ok 47 - set up tests of missing reference
ok 48 - test lonely missing ref
ok 49 - test missing ref after existing
ok 50 - test missing ref before existing
ok 51 - test --all, --depth, and explicit head
ok 52 - test --all, --depth, and explicit tag
# passed all 52 test(s)
1..52
