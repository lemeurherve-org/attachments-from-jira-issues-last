ok 1 - setup
not ok 2 - pushing into a repository using a ref namespace
#	
#		(
#			cd original &&
#			git push pushee-namespaced master &&
#			git ls-remote pushee-namespaced >actual &&
#			printf "$commit1\trefs/heads/master\n" >expected &&
#			test_cmp expected actual &&
#			git push pushee-namespaced --tags &&
#			git ls-remote pushee-namespaced >actual &&
#			printf "$commit0\trefs/tags/0\n" >>expected &&
#			printf "$commit1\trefs/tags/1\n" >>expected &&
#			test_cmp expected actual &&
#			# Verify that the GIT_NAMESPACE environment variable works as well
#			GIT_NAMESPACE=namespace git ls-remote "ext::git %s ../pushee" >actual &&
#			test_cmp expected actual &&
#			# Verify that --namespace overrides GIT_NAMESPACE
#			GIT_NAMESPACE=garbage git ls-remote pushee-namespaced >actual &&
#			test_cmp expected actual &&
#			# Try a namespace with no content
#			git ls-remote "ext::git --namespace=garbage %s ../pushee" >actual &&
#			test_cmp /dev/null actual &&
#			git ls-remote pushee-unnamespaced >actual &&
#			sed -e "s|refs/|refs/namespaces/namespace/refs/|" expected >expected.unnamespaced &&
#			test_cmp expected.unnamespaced actual
#		)
#	
ok 3 - pulling from a repository using a ref namespace
ok 4 - mirroring a repository using a ref namespace
# failed 1 among 4 test(s)
1..4
