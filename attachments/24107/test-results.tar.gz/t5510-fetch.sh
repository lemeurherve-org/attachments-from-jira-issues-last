ok 1 - setup
ok 2 - clone and setup child repos
ok 3 - fetch test
ok 4 - fetch test for-merge
ok 5 - fetch --prune on its own works as expected
ok 6 - fetch --prune with a branch name keeps branches
ok 7 - fetch --prune with a namespace keeps other namespaces
ok 8 - fetch --prune --tags does not delete the remote-tracking branches
ok 9 - fetch --prune --tags with branch does not delete other remote-tracking branches
ok 10 - fetch tags when there is no tags
ok 11 - fetch following tags
ok 12 - fetch uses remote ref names to describe new refs
ok 13 - fetch must not resolve short tag name
ok 14 - fetch can now resolve short remote name
ok 15 - create bundle 1
ok 16 - header of bundle looks right
ok 17 - create bundle 2
ok 18 - unbundle 1
ok 19 - bundle 1 has only 3 files 
ok 20 - unbundle 2
ok 21 - bundle does not prerequisite objects
ok 22 - bundle should be able to create a full history
not ok 23 - fetch via rsync
#	
#		git pack-refs &&
#		mkdir rsynced &&
#		(cd rsynced &&
#		 git init --bare &&
#		 git fetch "rsync:$(pwd)/../.git" master:refs/heads/master &&
#		 git gc --prune &&
#		 test $(git rev-parse master) = $(cd .. && git rev-parse master) &&
#		 git fsck --full)
#	
not ok 24 - push via rsync
#	
#		mkdir rsynced2 &&
#		(cd rsynced2 &&
#		 git init) &&
#		(cd rsynced &&
#		 git push "rsync:$(pwd)/../rsynced2/.git" master) &&
#		(cd rsynced2 &&
#		 git gc --prune &&
#		 test $(git rev-parse master) = $(cd .. && git rev-parse master) &&
#		 git fsck --full)
#	
not ok 25 - push via rsync
#	
#		mkdir rsynced3 &&
#		(cd rsynced3 &&
#		 git init) &&
#		git push --all "rsync:$(pwd)/rsynced3/.git" &&
#		(cd rsynced3 &&
#		 test $(git rev-parse master) = $(cd .. && git rev-parse master) &&
#		 git fsck --full)
#	
ok 26 - fetch with a non-applying branch.<name>.merge
ok 27 - fetch from GIT URL with a non-applying branch.<name>.merge [1]
ok 28 - fetch from GIT URL with a non-applying branch.<name>.merge [2]
ok 29 - fetch from GIT URL with a non-applying branch.<name>.merge [3]
ok 30 - quoting of a strangely named repo
ok 31 - bundle should record HEAD correctly
ok 32 - explicit fetch should not update tracking
ok 33 - explicit pull should not update tracking
ok 34 - configured fetch updates tracking
ok 35 - pushing nonexistent branch by mistake should not segv
ok 36 - auto tag following fetches minimum
ok 37 - refuse to fetch into the current branch
ok 38 - fetch into the current branch with --update-head-ok
ok 39 - fetch --dry-run
ok 40 - should be able to fetch with duplicate refspecs
ok 41 - all boundary commits are excluded
# failed 3 among 41 test(s)
1..41
