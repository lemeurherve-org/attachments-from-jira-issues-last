ok 1 - setup
ok 2 - alice works and pushes
ok 3 - bob fetches from alice, works and pushes
ok 4 - clean-up in case the previous failed
ok 5 - alice works and pushes again
ok 6 - bob works and pushes
ok 7 - alice works and pushes yet again
ok 8 - bob works and pushes again
# passed all 8 test(s)
1..8
