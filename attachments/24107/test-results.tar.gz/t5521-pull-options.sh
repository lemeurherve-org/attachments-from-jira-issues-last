ok 1 - setup
ok 2 - git pull -q
ok 3 - git pull -q --rebase
ok 4 - git pull
ok 5 - git pull --rebase
ok 6 - git pull -v
ok 7 - git pull -v --rebase
ok 8 - git pull -v -q
ok 9 - git pull -q -v
ok 10 - git pull --force
ok 11 - git pull --all
# passed all 11 test(s)
1..11
