ok 1 # skip setup (missing SYMLINKS)
ok 2 # skip pulling from real subdir (missing SYMLINKS)
ok 3 # skip pulling from symlinked subdir (missing SYMLINKS)
ok 4 # skip pushing from symlinked subdir (missing SYMLINKS)
# passed all 4 test(s)
1..4
