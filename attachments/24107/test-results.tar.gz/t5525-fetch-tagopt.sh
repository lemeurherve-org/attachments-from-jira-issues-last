ok 1 - setup
ok 2 - fetch with tagopt=--no-tags does not get tag
ok 3 - fetch --tags with tagopt=--no-tags gets tag
ok 4 - fetch --no-tags with tagopt=--tags does not get tag
ok 5 - fetch with tagopt=--tags gets tag
# passed all 5 test(s)
1..5
