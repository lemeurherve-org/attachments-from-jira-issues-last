ok 1 - setup bare remotes
ok 2 - "upstream" pushes to configured upstream
ok 3 - "upstream" does not push on unconfigured remote
ok 4 - "upstream" does not push on unconfigured branch
ok 5 - "upstream" does not push when remotes do not match
ok 6 - push from/to new branch with upstream, matching and simple
ok 7 - push from/to new branch with current creates remote branch
ok 8 - push to existing branch, with no upstream configured
ok 9 - push to existing branch, upstream configured with same name
ok 10 - push to existing branch, upstream configured with different name
# passed all 10 test(s)
1..10
