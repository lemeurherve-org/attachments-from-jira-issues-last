ok 1 - setup
ok 2 - push
ok 3 - push if submodule has no remote
ok 4 - push fails if submodule commit not on remote
ok 5 - push succeeds after commit was pushed to remote
ok 6 - push fails when commit on multiple branches if one branch has no remote
ok 7 - push succeeds if submodule has no remote and is on the first superproject commit
ok 8 - push unpushed submodules when not needed
ok 9 - push unpushed submodules when not needed 2
ok 10 - push unpushed submodules recursively
ok 11 - push unpushable submodule recursively fails
# passed all 11 test(s)
1..11
