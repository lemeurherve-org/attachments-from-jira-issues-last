ok 1 - setup remote repo
ok 2 - setup local repo
ok 3 - fetch through proxy works
# passed all 3 test(s)
1..3
