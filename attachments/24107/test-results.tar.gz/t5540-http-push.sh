1..0 # SKIP Network testing disabled (define GIT_TEST_HTTPD to enable)
