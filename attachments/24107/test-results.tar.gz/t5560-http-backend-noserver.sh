ok 1 - setup repository
ok 2 - direct refs/heads/master not found
ok 3 - static file is ok
ok 4 - no export by default
ok 5 - export if git-daemon-export-ok
ok 6 - static file if http.getanyfile true is ok
ok 7 - static file if http.getanyfile false fails
ok 8 - http.uploadpack default enabled
ok 9 - http.uploadpack true
ok 10 - http.uploadpack false
ok 11 - http.receivepack default disabled
ok 12 - http.receivepack true
ok 13 - http.receivepack false
ok 14 - http-backend blocks bad PATH_INFO
# passed all 14 test(s)
1..14
