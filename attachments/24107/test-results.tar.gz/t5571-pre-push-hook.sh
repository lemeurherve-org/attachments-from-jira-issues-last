ok 1 - setup
ok 2 - push with failing hook
ok 3 - --no-verify bypasses hook
ok 4 - push with hook
ok 5 - add a branch
ok 6 - push to default
ok 7 - push non-branches
ok 8 - push delete
ok 9 - push to URL
# passed all 9 test(s)
1..9
