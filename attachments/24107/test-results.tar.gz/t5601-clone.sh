ok 1 - setup
ok 2 - clone with excess parameters (1)
ok 3 - clone with excess parameters (2)
ok 4 - output from clone
ok 5 - clone does not keep pack
ok 6 - clone checks out files
ok 7 - clone respects GIT_WORK_TREE
ok 8 - clone creates intermediate directories
ok 9 - clone creates intermediate directories for bare repo
ok 10 - clone --mirror
ok 11 - clone --mirror with detached HEAD
ok 12 - clone --bare with detached HEAD
ok 13 - clone --bare names the local repository <name>.git
ok 14 - clone --mirror does not repeat tags
ok 15 - clone to destination with trailing /
ok 16 - clone to destination with extra trailing /
ok 17 - clone to an existing empty directory
ok 18 - clone to an existing non-empty directory
ok 19 - clone to an existing path
ok 20 - clone a void
ok 21 - clone respects global branch.autosetuprebase
ok 22 - respect url-encoding of file://
ok 23 - do not query-string-decode + in URLs
ok 24 - do not respect url-encoding of non-url path
ok 25 - clone separate gitdir
ok 26 - clone separate gitdir: output
ok 27 - clone from .git file
ok 28 - fetch from .git gitfile
ok 29 - fetch from gitfile parent
ok 30 - clone separate gitdir where target already exists
ok 31 - clone --reference from original
ok 32 - clone with more than one --reference
ok 33 - clone from original with relative alternate
ok 34 - clone checking out a tag
# passed all 34 test(s)
1..34
