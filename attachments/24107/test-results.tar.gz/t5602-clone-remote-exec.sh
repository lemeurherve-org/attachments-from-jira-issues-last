ok 1 - setup
not ok 2 - clone calls git upload-pack unqualified with no -u option
#	
#		(
#			GIT_SSH=./not_ssh &&
#			export GIT_SSH &&
#			test_must_fail git clone localhost:/path/to/repo junk
#		) &&
#		echo "localhost git-upload-pack '/path/to/repo'" >expected &&
#		test_cmp expected not_ssh_output
#	
not ok 3 - clone calls specified git upload-pack with -u option
#	
#		(
#			GIT_SSH=./not_ssh &&
#			export GIT_SSH &&
#			test_must_fail git clone -u ./something/bin/git-upload-pack localhost:/path/to/repo junk
#		) &&
#		echo "localhost ./something/bin/git-upload-pack '/path/to/repo'" >expected &&
#		test_cmp expected not_ssh_output
#	
# failed 2 among 3 test(s)
1..3
