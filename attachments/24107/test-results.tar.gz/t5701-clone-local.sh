ok 1 - preparing origin repository
ok 2 - local clone without .git suffix
ok 3 - local clone with .git suffix
ok 4 - local clone from x
ok 5 - local clone from x.git that does not exist
ok 6 - With -no-hardlinks, local will make a copy
ok 7 - Even without -l, local will make a hardlink
ok 8 - local clone of repo with nonexistent ref in HEAD
ok 9 - bundle clone without .bundle suffix
ok 10 - bundle clone with .bundle suffix
ok 11 - bundle clone from b4
ok 12 - bundle clone from b4.bundle that does not exist
ok 13 - bundle clone with nonexistent HEAD
ok 14 - clone empty repository
ok 15 - clone empty repository, and then push should not segfault.
ok 16 - cloning non-existent directory fails
ok 17 - cloning non-git directory fails
ok 18 - cloning file:// does not hardlink
ok 19 - cloning a local path with --no-local does not hardlink
# passed all 19 test(s)
1..19
