ok 1 - clone -c sets config in cloned repo
ok 2 - clone -c can set multi-keys
ok 3 - clone -c without a value is boolean true
ok 4 - clone -c config is available during clone
# passed all 4 test(s)
1..4
