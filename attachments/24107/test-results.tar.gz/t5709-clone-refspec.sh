ok 1 - setup
ok 2 - by default all branches will be kept updated
ok 3 - by default no tags will be kept updated
ok 4 - --single-branch while HEAD pointing at master
ok 5 - --single-branch while HEAD pointing at side
ok 6 - --single-branch with explicit --branch side
ok 7 - --single-branch with explicit --branch with tag fetches updated tag
ok 8 - --single-branch with --mirror
ok 9 - --single-branch with explicit --branch and --mirror
ok 10 - --single-branch with detached
# passed all 10 test(s)
1..10
