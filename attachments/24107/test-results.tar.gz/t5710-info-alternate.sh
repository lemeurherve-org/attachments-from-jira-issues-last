ok 1 - preparing first repository
ok 2 - preparing second repository
ok 3 - preparing third repository
ok 4 - creating too deep nesting
ok 5 - validity of third repository
ok 6 - validity of fourth repository
ok 7 - breaking of loops
ok 8 - that info/alternates is necessary
ok 9 - that relative alternate is possible for current dir
ok 10 - that relative alternate is only possible for current dir
# passed all 10 test(s)
1..10
