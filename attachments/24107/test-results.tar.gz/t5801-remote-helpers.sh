ok 1 - setup repository
not ok 2 - cloning from local repo
#	
#		git clone "testgit::${PWD}/server" local &&
#		test_cmp server/file local/file
#	
ok 3 - create new commit on remote
not ok 4 - pulling from local repo
#	
#		(cd local && git pull) &&
#		test_cmp server/file local/file
#	
not ok 5 - pushing to local repo
#	
#		(cd local &&
#		echo content >>file &&
#		git commit -a -m three &&
#		git push) &&
#		compare_refs local HEAD server HEAD
#	
not ok 6 - fetch new branch
#	
#		(cd server &&
#		 git reset --hard &&
#		 git checkout -b new &&
#		 echo content >>file &&
#		 git commit -a -m five
#		) &&
#		(cd local &&
#		 git fetch origin new
#		) &&
#		compare_refs server HEAD local FETCH_HEAD
#	
not ok 7 - fetch multiple branches
#	
#		(cd local &&
#		 git fetch
#		) &&
#		compare_refs server master local refs/remotes/origin/master &&
#		compare_refs server new local refs/remotes/origin/new
#	
not ok 8 - push when remote has extra refs
#	
#		(cd local &&
#		 git reset --hard origin/master &&
#		 echo content >>file &&
#		 git commit -a -m six &&
#		 git push
#		) &&
#		compare_refs local master server master
#	
not ok 9 - push new branch by name
#	
#		(cd local &&
#		 git checkout -b new-name  &&
#		 echo content >>file &&
#		 git commit -a -m seven &&
#		 git push origin new-name
#		) &&
#		compare_refs local HEAD server refs/heads/new-name
#	
not ok 10 - push new branch with old:new refspec # TODO known breakage
not ok 11 - cloning without refspec
#	
#		GIT_REMOTE_TESTGIT_REFSPEC="" \
#		git clone "testgit::${PWD}/server" local2 &&
#		compare_refs local2 HEAD server HEAD
#	
not ok 12 - pulling without refspecs
#	
#		(cd local2 &&
#		git reset --hard &&
#		GIT_REMOTE_TESTGIT_REFSPEC="" git pull) &&
#		compare_refs local2 HEAD server HEAD
#	
not ok 13 - pushing without refspecs # TODO known breakage
not ok 14 - pulling with straight refspec
#	
#		(cd local2 &&
#		GIT_REMOTE_TESTGIT_REFSPEC="*:*" git pull) &&
#		compare_refs local2 HEAD server HEAD
#	
not ok 15 - pushing with straight refspec # TODO known breakage
not ok 16 - pulling without marks
#	
#		(cd local2 &&
#		GIT_REMOTE_TESTGIT_NO_MARKS=1 git pull) &&
#		compare_refs local2 HEAD server HEAD
#	
not ok 17 - pushing without marks # TODO known breakage
not ok 18 - push all with existing object
#	
#		(cd local &&
#		git branch dup2 master &&
#		git push origin --all
#		) &&
#		compare_refs local dup2 server dup2
#	
not ok 19 - push ref with existing object
#	
#		(cd local &&
#		git branch dup master &&
#		git push origin dup
#		) &&
#		compare_refs local dup server dup
#	
not ok 20 - push signed tag
#	
#		(cd local &&
#		git checkout master &&
#		git tag -s -m signed-tag signed-tag &&
#		git push origin signed-tag
#		) &&
#		compare_refs local signed-tag^{} server signed-tag^{} &&
#		test_must_fail compare_refs local signed-tag server signed-tag
#	
not ok 21 - push signed tag with signed-tags capability
#	
#		(cd local &&
#		git checkout master &&
#		git tag -s -m signed-tag signed-tag-2 &&
#		GIT_REMOTE_TESTGIT_SIGNED_TAGS=1 git push origin signed-tag-2
#		) &&
#		compare_refs local signed-tag-2 server signed-tag-2
#	
not ok 22 - push messages
#	
#		(cd local &&
#		git checkout -b new_branch master &&
#		echo new >>file &&
#		git commit -a -m new &&
#		git push origin new_branch &&
#		git fetch origin &&
#		echo new >>file &&
#		git commit -a -m new &&
#		git push origin new_branch 2> msg &&
#		! grep "\[new branch\]" msg
#		)
#	
# still have 4 known breakage(s)
# failed 16 among remaining 18 test(s)
1..22
