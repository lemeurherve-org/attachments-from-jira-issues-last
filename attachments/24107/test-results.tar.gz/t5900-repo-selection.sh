ok 1 - find .git dir in worktree
ok 2 - automagically add .git suffix
ok 3 - automagically add .git suffix to worktree
ok 4 - prefer worktree foo over bare foo.git
ok 5 - prefer bare foo over bare foo.git
ok 6 - disambiguate with full foo.git
ok 7 - we are not fooled by non-git foo directory
ok 8 - prefer inner .git over outer bare
# passed all 8 test(s)
1..8
