ok 1 - setup
ok 2 - without grafts
ok 3 - with grafts
ok 4 - without grafts, with pathlimit
ok 5 - with grafts, with pathlimit
ok 6 - without grafts
ok 7 - with grafts
ok 8 - without grafts, with pathlimit
ok 9 - with grafts, with pathlimit
ok 10 - without grafts
ok 11 - with grafts
ok 12 - without grafts, with pathlimit
ok 13 - with grafts, with pathlimit
# passed all 13 test(s)
1..13
