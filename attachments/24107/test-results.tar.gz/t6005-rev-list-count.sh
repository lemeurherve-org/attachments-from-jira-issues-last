ok 1 - setup
ok 2 - no options
ok 3 - --max-count
ok 4 - --max-count all forms
ok 5 - --skip
ok 6 - --skip --max-count
# passed all 6 test(s)
1..6
