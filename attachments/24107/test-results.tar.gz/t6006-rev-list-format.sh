ok 1 - set up terminal for tests
ok 2 - setup
ok 3 - format percent
ok 4 - format hash
ok 5 - format tree
ok 6 - format parents
ok 7 - format author
ok 8 - format committer
ok 9 - format encoding
ok 10 - format subject
ok 11 - format body
ok 12 - format raw-body
ok 13 - format colors
ok 14 - format advanced-colors
ok 15 - %C(auto) does not enable color by default
ok 16 - %C(auto) enables colors for color.diff
ok 17 - %C(auto) enables colors for color.ui
ok 18 - %C(auto) respects --color
ok 19 - %C(auto) respects --no-color
ok 20 # skip %C(auto) respects --color=auto (stdout is tty) (missing TTY)
ok 21 - %C(auto) respects --color=auto (stdout not tty)
ok 22 - setup complex body
ok 23 - format complex-encoding
ok 24 - format complex-subject
ok 25 - format complex-body
ok 26 - %x00 shows NUL
ok 27 - %ad respects --date=
ok 28 - empty email
ok 29 - del LF before empty (1)
ok 30 - del LF before empty (2)
ok 31 - add LF before non-empty (1)
ok 32 - add LF before non-empty (2)
ok 33 - add SP before non-empty (1)
ok 34 - add SP before non-empty (2)
ok 35 - --abbrev
ok 36 - %H is not affected by --abbrev-commit
ok 37 - %h is not affected by --abbrev-commit
ok 38 - "%h %gD: %gs" is same as git-reflog
ok 39 - "%h %gD: %gs" is same as git-reflog (with date)
ok 40 - "%h %gD: %gs" is same as git-reflog (with --abbrev)
ok 41 - %gd shortens ref name
ok 42 - reflog identity
ok 43 - oneline with empty message
ok 44 - single-character name is parsed correctly
# passed all 44 test(s)
1..44
