ok 1 - setup
ok 2 - one is ancestor of others and should not be shown
ok 3 - setup roots, merges and octopuses
ok 4 - rev-list roots
ok 5 - rev-list no merges
ok 6 - rev-list no octopuses
ok 7 - rev-list no roots
ok 8 - rev-list merges
ok 9 - rev-list octopus
ok 10 - rev-list ordinary commits
ok 11 - rev-list --merges --no-merges yields empty set
ok 12 - rev-list override and infinities
ok 13 - dodecapus
ok 14 - ancestors with the same commit time
# passed all 14 test(s)
1..14
