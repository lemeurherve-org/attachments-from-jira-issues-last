ok 1 - setup
ok 2 - verify number of revisions
ok 3 - corrupt second commit object
ok 4 - rev-list should fail
ok 5 - git repack _MUST_ fail
ok 6 - first commit is still available
# passed all 6 test(s)
1..6
