ok 1 - setup
ok 2 - log --full-history
ok 3 - log --full-history -- file
ok 4 - log --full-history --topo-order -- file
ok 5 - log --full-history --date-order -- file
not ok 6 - log --simplify-merges -- file # TODO known breakage
ok 7 - log -- file
ok 8 - log --topo-order -- file
ok 9 - log --first-parent -- another-file
# still have 1 known breakage(s)
# passed all remaining 8 test(s)
1..9
