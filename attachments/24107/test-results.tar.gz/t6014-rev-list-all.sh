ok 1 - setup
ok 2 - rev-list --all lists detached HEAD
ok 3 - repack does not lose detached HEAD
# passed all 3 test(s)
1..3
