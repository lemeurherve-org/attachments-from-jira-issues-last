ok 1 - setup
ok 2 - rev-list D..M
ok 3 - rev-list --ancestry-path D..M
ok 4 - rev-list D..M -- M.t
ok 5 - rev-list --ancestry-patch D..M -- M.t
ok 6 - setup criss-cross
ok 7 - criss-cross: rev-list --ancestry-path cb..bc
ok 8 - criss-cross: rev-list --ancestry-path --all ^cb
# passed all 8 test(s)
1..8
