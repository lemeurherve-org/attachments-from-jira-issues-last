ok 1 - prepare repository
ok 2 - Criss-cross merge
ok 3 - Criss-cross merge result
ok 4 - Criss-cross merge fails (-s resolve)
# passed all 4 test(s)
1..4
