ok 1 - setup
ok 2 - merge -s recursive up-to-date
ok 3 - merge -s recursive fast-forward
ok 4 - merge -s ours up-to-date
ok 5 - merge -s ours fast-forward
ok 6 - merge -s subtree up-to-date
ok 7 - merge fast-forward octopus
# passed all 7 test(s)
1..7
