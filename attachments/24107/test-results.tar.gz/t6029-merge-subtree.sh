ok 1 - setup
ok 2 - subtree available and works like recursive
ok 3 - setup
ok 4 - initial merge
ok 5 - merge update
ok 6 - initial ambiguous subtree
ok 7 - merge using explicit
ok 8 - merge2 using explicit
# passed all 8 test(s)
1..8
