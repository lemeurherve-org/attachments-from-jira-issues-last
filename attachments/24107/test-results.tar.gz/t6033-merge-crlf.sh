ok 1 - setup
ok 2 - Check "ours" is CRLF
ok 3 - Check that conflict file is CRLF
# passed all 3 test(s)
1..3
