ok 1 - setup
ok 2 - merge white into red (A->B,M->N)
ok 3 - merge blue into white (A->B, mod A, A untracked)
# passed all 3 test(s)
1..3
