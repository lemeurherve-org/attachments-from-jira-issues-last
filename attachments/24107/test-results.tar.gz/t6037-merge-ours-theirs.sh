ok 1 - setup
ok 2 - plain recursive - should conflict
ok 3 - recursive favouring theirs
ok 4 - recursive favouring ours
ok 5 - binary file with -Xours/-Xtheirs
ok 6 - pull passes -X to underlying merge
# passed all 6 test(s)
1..6
