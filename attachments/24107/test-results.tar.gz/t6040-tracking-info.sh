ok 1 - setup
ok 2 - branch -v
ok 3 - branch -vv
ok 4 - checkout
ok 5 - checkout with local tracked branch
ok 6 - status
ok 7 - fail to track lightweight tags
ok 8 - fail to track annotated tags
ok 9 - setup tracking with branch --set-upstream on existing branch
ok 10 - --set-upstream does not change branch
ok 11 - --set-upstream @{-1}
# passed all 11 test(s)
1..11
