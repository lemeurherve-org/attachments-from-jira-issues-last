ok 1 - create commits with glob characters
ok 2 - vanilla pathspec matches literally
ok 3 - star pathspec globs
ok 4 - bracket pathspec globs and matches literal brackets
ok 5 - no-glob option matches literally (vanilla)
ok 6 - no-glob option matches literally (star)
ok 7 - no-glob option matches literally (bracket)
ok 8 - no-glob environment variable works
# passed all 8 test(s)
1..8
