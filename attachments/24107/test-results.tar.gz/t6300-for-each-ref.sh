ok 1 - Create sample commit with known timestamp
ok 2 - Create upstream config
ok 3 - basic atom: head refname
ok 4 - basic atom: head upstream
ok 5 - basic atom: head objecttype
ok 6 - basic atom: head objectsize
ok 7 - basic atom: head objectname
ok 8 - basic atom: head tree
ok 9 - basic atom: head parent
ok 10 - basic atom: head numparent
ok 11 - basic atom: head object
ok 12 - basic atom: head type
ok 13 - basic atom: head author
ok 14 - basic atom: head authorname
ok 15 - basic atom: head authoremail
ok 16 - basic atom: head authordate
ok 17 - basic atom: head committer
ok 18 - basic atom: head committername
ok 19 - basic atom: head committeremail
ok 20 - basic atom: head committerdate
ok 21 - basic atom: head tag
ok 22 - basic atom: head tagger
ok 23 - basic atom: head taggername
ok 24 - basic atom: head taggeremail
ok 25 - basic atom: head taggerdate
ok 26 - basic atom: head creator
ok 27 - basic atom: head creatordate
ok 28 - basic atom: head subject
ok 29 - basic atom: head contents:subject
ok 30 - basic atom: head body
ok 31 - basic atom: head contents:body
ok 32 - basic atom: head contents:signature
ok 33 - basic atom: head contents
ok 34 - basic atom: tag refname
ok 35 - basic atom: tag upstream
ok 36 - basic atom: tag objecttype
ok 37 - basic atom: tag objectsize
ok 38 - basic atom: tag objectname
ok 39 - basic atom: tag tree
ok 40 - basic atom: tag parent
ok 41 - basic atom: tag numparent
ok 42 - basic atom: tag object
ok 43 - basic atom: tag type
ok 44 - basic atom: tag author
ok 45 - basic atom: tag authorname
ok 46 - basic atom: tag authoremail
ok 47 - basic atom: tag authordate
ok 48 - basic atom: tag committer
ok 49 - basic atom: tag committername
ok 50 - basic atom: tag committeremail
ok 51 - basic atom: tag committerdate
ok 52 - basic atom: tag tag
ok 53 - basic atom: tag tagger
ok 54 - basic atom: tag taggername
ok 55 - basic atom: tag taggeremail
ok 56 - basic atom: tag taggerdate
ok 57 - basic atom: tag creator
ok 58 - basic atom: tag creatordate
ok 59 - basic atom: tag subject
ok 60 - basic atom: tag contents:subject
ok 61 - basic atom: tag body
ok 62 - basic atom: tag contents:body
ok 63 - basic atom: tag contents:signature
ok 64 - basic atom: tag contents
ok 65 - Check invalid atoms names are errors
ok 66 - Check format specifiers are ignored in naming date atoms
ok 67 - Check valid format specifiers for date fields
ok 68 - Check invalid format specifiers are errors
ok 69 - Check unformatted date fields output
ok 70 - Check format "default" formatted date fields output
ok 71 - Check format "relative" date fields output
ok 72 - Check format "short" date fields output
ok 73 - Check format "local" date fields output
ok 74 - Check format "iso8601" date fields output
ok 75 - Check format "rfc2822" date fields output
ok 76 - Verify ascending sort
ok 77 - Verify descending sort
ok 78 - Quoting style: shell
ok 79 - Quoting style: perl
ok 80 - Quoting style: python
ok 81 - Quoting style: tcl
ok 82 - more than one quoting style: --perl --shell
ok 83 - more than one quoting style: -s --python
ok 84 - more than one quoting style: --python --tcl
ok 85 - more than one quoting style: --tcl --perl
ok 86 - Check short refname format
ok 87 - Check short upstream format
ok 88 - Check short objectname format
ok 89 - Check for invalid refname format
ok 90 - Check ambiguous head and tag refs (strict)
ok 91 - Check ambiguous head and tag refs (loose)
ok 92 - Check ambiguous head and tag refs II (loose)
ok 93 - an unusual tag with an incomplete line
ok 94 - create tag with subject and body content
ok 95 - basic atom: refs/tags/subject-body subject
ok 96 - basic atom: refs/tags/subject-body body
ok 97 - basic atom: refs/tags/subject-body contents
ok 98 - create tag with multiline subject
ok 99 - basic atom: refs/tags/multiline subject
ok 100 - basic atom: refs/tags/multiline contents:subject
ok 101 - basic atom: refs/tags/multiline body
ok 102 - basic atom: refs/tags/multiline contents:body
ok 103 - basic atom: refs/tags/multiline contents:signature
ok 104 - basic atom: refs/tags/multiline contents
ok 105 - create signed tags
ok 106 - basic atom: refs/tags/signed-empty subject
ok 107 - basic atom: refs/tags/signed-empty contents:subject
ok 108 - basic atom: refs/tags/signed-empty body
ok 109 - basic atom: refs/tags/signed-empty contents:body
ok 110 - basic atom: refs/tags/signed-empty contents:signature
ok 111 - basic atom: refs/tags/signed-empty contents
ok 112 - basic atom: refs/tags/signed-short subject
ok 113 - basic atom: refs/tags/signed-short contents:subject
ok 114 - basic atom: refs/tags/signed-short body
ok 115 - basic atom: refs/tags/signed-short contents:body
ok 116 - basic atom: refs/tags/signed-short contents:signature
ok 117 - basic atom: refs/tags/signed-short contents
ok 118 - basic atom: refs/tags/signed-long subject
ok 119 - basic atom: refs/tags/signed-long contents:subject
ok 120 - basic atom: refs/tags/signed-long body
ok 121 - basic atom: refs/tags/signed-long contents:body
ok 122 - basic atom: refs/tags/signed-long contents:signature
ok 123 - basic atom: refs/tags/signed-long contents
ok 124 - Verify sort with multiple keys
# passed all 124 test(s)
1..124
