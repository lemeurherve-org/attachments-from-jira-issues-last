ok 1 - setup
ok 2 - rewrite identically
ok 3 - result is really identical
ok 4 - rewrite bare repository identically
ok 5 - result is really identical
not ok 6 - correct GIT_DIR while using -d
#	
#		mkdir drepo &&
#		( cd drepo &&
#		git init &&
#		test_commit drepo &&
#		git filter-branch -d "$TRASHDIR/dfoo" \
#			--index-filter "cp \"$TRASHDIR\"/dfoo/backup-refs \"$TRASHDIR\"" \
#		) &&
#		grep drepo "$TRASHDIR/backup-refs"
#	
not ok 7 - tree-filter works with -d
#	
#		git init drepo-tree &&
#		(
#			cd drepo-tree &&
#			test_commit one &&
#			git filter-branch -d "$TRASHDIR/dfoo" \
#				--tree-filter "echo changed >one.t" &&
#			echo changed >expect &&
#			git cat-file blob HEAD:one.t >actual &&
#			test_cmp expect actual &&
#			test_cmp one.t actual
#		)
#	
ok 8 - Fail if commit filter fails
ok 9 - rewrite, renaming a specific file
ok 10 - test that the file was renamed
ok 11 - rewrite, renaming a specific directory
ok 12 - test that the directory was renamed
ok 13 - rewrite one branch, keeping a side branch
ok 14 - common ancestor is still common (unchanged)
ok 15 - filter subdirectory only
ok 16 - subdirectory filter result looks okay
ok 17 - more setup
ok 18 - use index-filter to move into a subdirectory
ok 19 - stops when msg filter fails
ok 20 - author information is preserved
ok 21 - remove a certain author's commits
ok 22 - barf on invalid name
ok 23 - "map" works in commit filter
ok 24 - Name needing quotes
ok 25 - Subdirectory filter with disappearing trees
ok 26 - Tag name filtering retains tag message
ok 27 - Tag name filtering strips gpg signature
ok 28 - Tag name filtering allows slashes in tag names
ok 29 - Prune empty commits
ok 30 - --remap-to-ancestor with filename filters
ok 31 - automatic remapping to ancestor with filename filters
ok 32 - setup submodule
ok 33 - rewrite submodule with another content
ok 34 - replace submodule revision
# failed 2 among 34 test(s)
1..34
