ok 1 - listing all tags in an empty tree should succeed
ok 2 - listing all tags in an empty tree should output nothing
ok 3 - looking for a tag in an empty tree should fail
ok 4 - creating a tag in an empty tree should fail
ok 5 - creating a tag for HEAD in an empty tree should fail
ok 6 - creating a tag for an unknown revision should fail
ok 7 - creating a tag using default HEAD should succeed
ok 8 - listing all tags if one exists should succeed
ok 9 - listing all tags if one exists should output that tag
ok 10 - listing a tag using a matching pattern should succeed
ok 11 - listing a tag using a matching pattern should output that tag
ok 12 - listing tags using a non-matching pattern should suceed
ok 13 - listing tags using a non-matching pattern should output nothing
ok 14 - trying to create a tag with the name of one existing should fail
ok 15 - trying to create a tag with a non-valid name should fail
ok 16 - creating a tag using HEAD directly should succeed
ok 17 - --force can create a tag with the name of one existing
ok 18 - --force is moot with a non-existing tag name
Deleted tag 'newtag' (was 86e17e4)
Deleted tag 'forcetag' (was 86e17e4)
ok 19 - trying to delete an unknown tag should fail
ok 20 - trying to delete tags without params should succeed and do nothing
ok 21 - deleting two existing tags in one command should succeed
ok 22 - creating a tag with the name of another deleted one should succeed
ok 23 - trying to delete two tags, existing and not, should fail in the 2nd
ok 24 - trying to delete an already deleted tag should fail
ok 25 - listing all tags should print them ordered
ok 26 - listing tags with substring as pattern must print those matching
ok 27 - listing tags with a suffix as pattern must print those matching
ok 28 - listing tags with a prefix as pattern must print those matching
ok 29 - listing tags using a name as pattern must print that one matching
ok 30 - listing tags using a name as pattern must print that one matching
ok 31 - listing tags with ? in the pattern should print those matching
ok 32 - listing tags using v.* should print nothing because none have v.
ok 33 - listing tags using v* should print only those having v
ok 34 - tag -l can accept multiple patterns
ok 35 - listing tags in column
ok 36 - listing tags in column with column.*
ok 37 - listing tag with -n --column should fail
ok 38 - listing tags -n in column with column.ui ignored
ok 39 - a non-annotated tag created without parameters should point to HEAD
ok 40 - trying to verify an unknown tag should fail
ok 41 - trying to verify a non-annotated and non-signed tag should fail
ok 42 - trying to verify many non-annotated or unknown tags, should fail
ok 43 - creating an annotated tag with -m message should succeed
ok 44 - creating an annotated tag with -F messagefile should succeed
ok 45 - creating an annotated tag with -F - should succeed
ok 46 - trying to create a tag with a non-existing -F file should fail
ok 47 - trying to create tags giving both -m or -F options should fail
ok 48 - creating a tag with an empty -m message should succeed
ok 49 - creating a tag with an empty -F messagefile should succeed
ok 50 - extra blanks in the message for an annotated tag should be removed
ok 51 - creating a tag with blank -m message with spaces should succeed
ok 52 - creating a tag with blank -F messagefile with spaces should succeed
ok 53 - creating a tag with -F file of spaces and no newline should succeed
ok 54 - creating a tag using a -F messagefile with #comments should succeed
ok 55 - creating a tag with a #comment in the -m message should succeed
ok 56 - creating a tag with #comments in the -F messagefile should succeed
ok 57 - creating a tag with a file of #comment and no newline should succeed
ok 58 - listing the one-line message of a non-signed tag should succeed
ok 59 - listing the zero-lines message of a non-signed tag should succeed
ok 60 - listing many message lines of a non-signed tag should succeed
ok 61 - annotations for blobs are empty
ok 62 - trying to verify an annotated non-signed tag should fail
ok 63 - trying to verify a file-annotated non-signed tag should fail
ok 64 - trying to verify two annotated non-signed tags should fail
ok 65 - creating a signed tag with -m message should succeed
ok 66 - sign with a given key id
ok 67 - sign with an unknown id (1)
ok 68 - sign with an unknown id (2)
ok 69 - -u implies signed tag
ok 70 - creating a signed tag with -F messagefile should succeed
ok 71 - creating a signed tag with -F - should succeed
ok 72 - -s implies annotated tag
ok 73 - trying to create a signed tag with non-existing -F file should fail
ok 74 - verifying a signed tag should succeed
ok 75 - verifying two signed tags in one command should succeed
ok 76 - verifying many signed and non-signed tags should fail
ok 77 - verifying a forged tag should fail
ok 78 - creating a signed tag with an empty -m message should succeed
ok 79 - creating a signed tag with an empty -F messagefile should succeed
ok 80 - extra blanks in the message for a signed tag should be removed
ok 81 - creating a signed tag with a blank -m message should succeed
ok 82 - creating a signed tag with blank -F file with spaces should succeed
ok 83 - creating a signed tag with spaces and no newline should succeed
ok 84 - creating a signed tag with a -F file with #comments should succeed
ok 85 - creating a signed tag with #commented -m message should succeed
ok 86 - creating a signed tag with #commented -F messagefile should succeed
ok 87 - creating a signed tag with a #comment and no newline should succeed
ok 88 - listing the one-line message of a signed tag should succeed
ok 89 - listing the zero-lines message of a signed tag should succeed
ok 90 - listing many message lines of a signed tag should succeed
ok 91 - creating a signed tag pointing to a tree should succeed
ok 92 - creating a signed tag pointing to a blob should succeed
ok 93 - creating a signed tag pointing to another tag should succeed
ok 94 - creating a signed tag with rfc1991
ok 95 - reediting a signed tag body omits signature
ok 96 - verifying rfc1991 signature
ok 97 - list tag with rfc1991 signature
ok 98 - verifying rfc1991 signature without --rfc1991
ok 99 - list tag with rfc1991 signature without --rfc1991
ok 100 - reediting a signed tag body omits signature
ok 101 - git tag -s fails if gpg is misconfigured
ok 102 - verify signed tag fails when public key is not present
ok 103 - git tag -a fails if tag annotation is empty
ok 104 - message in editor has initial comment
ok 105 - message in editor has initial comment: first line
ok 106 - message in editor has initial comment: remainder
ok 107 - overwriting an annoted tag should use its previous body
ok 108 - filename for the message is relative to cwd
ok 109 - filename for the message is relative to cwd
ok 110 - creating second commit and tag
ok 111 - creating third commit without tag
ok 112 - checking that first commit is in all tags (hash)
ok 113 - checking that first commit is in all tags (tag)
ok 114 - checking that first commit is in all tags (relative)
ok 115 - checking that second commit only has one tag
ok 116 - checking that third commit has no tags
ok 117 - creating simple branch
ok 118 - checking that branch head only has one tag
ok 119 - merging original branch into this branch
ok 120 - checking that original branch head has one tag now
ok 121 - checking that initial commit is in all tags
ok 122 - mixing incompatibles modes and options is forbidden
ok 123 - --points-at cannot be used in non-list mode
ok 124 - --points-at finds lightweight tags
ok 125 - --points-at finds annotated tags of commits
ok 126 - --points-at finds annotated tags of tags
ok 127 - multiple --points-at are OR-ed together
# passed all 127 test(s)
1..127
