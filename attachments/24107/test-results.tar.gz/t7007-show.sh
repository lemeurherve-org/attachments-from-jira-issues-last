ok 1 - setup
ok 2 - showing a tag that point at a missing object
ok 3 - set up a bit of history
ok 4 - showing two commits
ok 5 - showing a range walks (linear)
ok 6 - showing a range walks (Y shape, ^ first)
ok 7 - showing a range walks (Y shape, ^ last)
ok 8 - showing with -N walks
ok 9 - showing annotated tag
ok 10 - showing annotated tag plus commit
ok 11 - showing range
ok 12 - -s suppresses diff
ok 13 - --quiet suppresses diff
# passed all 13 test(s)
1..13
