ok 1 - setup
ok 2 - update-index
ok 3 - update-index
ok 4 - update-index --remove
ok 5 - update-index --remove
ok 6 - ls-files --delete
ok 7 - ls-files --delete
ok 8 - ls-files --modified
ok 9 - ls-files --modified
ok 10 - grep with skip-worktree file
ok 11 - diff-index does not examine skip-worktree absent entries
ok 12 - diff-index does not examine skip-worktree dirty entries
ok 13 - diff-files does not examine skip-worktree absent entries
ok 14 - diff-files does not examine skip-worktree dirty entries
ok 15 - git-rm succeeds on skip-worktree absent entries
ok 16 - commit on skip-worktree absent entries
ok 17 - commit on skip-worktree dirty entries
# passed all 17 test(s)
1..17
