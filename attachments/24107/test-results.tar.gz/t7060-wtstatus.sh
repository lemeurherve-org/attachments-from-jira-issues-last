ok 1 - setup
ok 2 - A/A conflict
ok 3 - Report path with conflict
ok 4 - Report new path with conflict
ok 5 - M/D conflict does not segfault
ok 6 - rename & unmerged setup
ok 7 - rename & unmerged status
ok 8 - git diff-index --cached shows 2 added + 1 unmerged
ok 9 - git diff-index --cached -M shows 2 added + 1 unmerged
ok 10 - git diff-index --cached -C shows 2 copies + 1 unmerged
ok 11 - status when conflicts with add and rm advice (deleted by them)
ok 12 - prepare for conflicts
ok 13 - status when conflicts with add and rm advice (both deleted)
ok 14 - status when conflicts with only rm advice (both deleted)
# passed all 14 test(s)
1..14
