ok 1 - status untracked directory with --ignored
ok 2 - status untracked directory with --ignored -u
ok 3 - status prefixed untracked directory with --ignored
ok 4 - status prefixed untracked sub-directory with --ignored -u
ok 5 - status ignored directory with --ignore
ok 6 - status ignored directory with --ignore -u
ok 7 - status empty untracked directory with --ignore
ok 8 - status empty untracked directory with --ignore -u
ok 9 - status untracked directory with ignored files with --ignore
ok 10 - status untracked directory with ignored files with --ignore -u
ok 11 - status ignored tracked directory with --ignore
ok 12 - status ignored tracked directory with --ignore -u
ok 13 - status ignored tracked directory and ignored file with --ignore
ok 14 - status ignored tracked directory and ignored file with --ignore -u
ok 15 - status ignored tracked directory and uncommitted file with --ignore
ok 16 - status ignored tracked directory and uncommitted file with --ignore -u
ok 17 - status ignored tracked directory with uncommitted file in untracked subdir with --ignore
ok 18 - status ignored tracked directory with uncommitted file in untracked subdir with --ignore -u
ok 19 - status ignored tracked directory with uncommitted file in tracked subdir with --ignore
ok 20 - status ignored tracked directory with uncommitted file in tracked subdir with --ignore -u
# passed all 20 test(s)
1..20
