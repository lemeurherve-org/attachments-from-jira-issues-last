ok 1 - status with hash collisions
# passed all 1 test(s)
1..1
