ok 1 - creating initial files
ok 2 - creating second files
ok 3 - resetting tree HEAD^
ok 4 - checking initial files exist after rewind
ok 5 - checking lack of path1/path2/COPYING
ok 6 - checking lack of path1/COPYING
ok 7 - checking lack of COPYING
ok 8 - checking checking lack of path1/COPYING-TOO
ok 9 - checking lack of path1/path2
ok 10 - checking lack of path1
# passed all 10 test(s)
1..10
