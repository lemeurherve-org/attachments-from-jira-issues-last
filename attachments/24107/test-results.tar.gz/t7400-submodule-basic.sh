ok 1 - setup - initial commit
ok 2 - setup - repository in init subdirectory
ok 3 - setup - commit with gitlink
ok 4 - setup - hide init subdirectory
ok 5 - setup - repository to add submodules to
ok 6 - submodule add
ok 7 - submodule add to .gitignored path fails
ok 8 - submodule add to .gitignored path with --force
ok 9 - submodule add --branch
ok 10 - submodule add with ./ in path
ok 11 - submodule add with // in path
ok 12 - submodule add with /.. in path
ok 13 - submodule add with ./, /.. and // in path
ok 14 - setup - add an example entry to .gitmodules
ok 15 - status should fail for unmapped paths
ok 16 - setup - map path in .gitmodules
ok 17 - status should only print one line
ok 18 - setup - fetch commit name from submodule
ok 19 - status should initially be "missing"
ok 20 - init should register submodule url in .git/config
ok 21 - init should fail with unknown submodule
ok 22 - update should fail with unknown submodule
ok 23 - status should fail with unknown submodule
ok 24 - sync should fail with unknown submodule
ok 25 - update should fail when path is used by a file
ok 26 - update should fail when path is used by a nonempty directory
ok 27 - update should work when path is an empty dir
ok 28 - status should be "up-to-date" after update
ok 29 - status should be "modified" after submodule commit
ok 30 - the --cached sha1 should be rev1
ok 31 - git diff should report the SHA1 of the new submodule commit
ok 32 - update should checkout rev1
ok 33 - status should be "up-to-date" after update
ok 34 - checkout superproject with subproject already present
ok 35 - apply submodule diff
ok 36 - update --init
ok 37 - do not add files from a submodule
ok 38 - gracefully add submodule with a trailing slash
ok 39 - ls-files gracefully handles trailing slash
ok 40 - moving to a commit without submodule does not leave empty dir
ok 41 - submodule <invalid-subcommand> fails
ok 42 - add submodules without specifying an explicit path
ok 43 - add should fail when path is used by a file
ok 44 - add should fail when path is used by an existing directory
ok 45 - use superproject as upstream when path is relative and no url is set there
ok 46 - set up for relative path tests
ok 47 - ../subrepo works with URL - ssh://hostname/repo
ok 48 - ../subrepo works with port-qualified URL - ssh://hostname:22/repo
ok 49 - ../subrepo path works with local path - //somewhere else/repo
ok 50 - ../subrepo works with file URL - file:///tmp/repo
not ok 51 - ../subrepo works with helper URL- helper:://hostname/repo
#	
#		(
#			cd reltest &&
#			cp pristine-.git-config .git/config &&
#			cp pristine-.gitmodules .gitmodules &&
#			git config remote.origin.url helper:://hostname/repo &&
#			git submodule init &&
#			test "$(git config submodule.sub.url)" = helper:://hostname/subrepo
#		)
#	
ok 52 - ../subrepo works with scp-style URL - user@host:repo
ok 53 - ../subrepo works with scp-style URL - user@host:path/to/repo
ok 54 - ../subrepo works with relative local path - foo
ok 55 - ../subrepo works with relative local path - foo/bar
ok 56 - ../subrepo works with relative local path - ./foo
ok 57 - ../subrepo works with relative local path - ./foo/bar
ok 58 - ../subrepo works with relative local path - ../foo
ok 59 - ../subrepo works with relative local path - ../foo/bar
ok 60 - ../bar/a/b/c works with relative local path - ../foo/bar.git
ok 61 - moving the superproject does not break submodules
ok 62 - submodule add --name allows to replace a submodule with another at the same path
ok 63 - submodule add with an existing name fails unless forced
ok 64 - set up a second submodule
ok 65 - submodule deinit should remove the whole submodule section from .git/config
ok 66 - submodule deinit . deinits all initialized submodules
ok 67 - submodule deinit deinits a submodule when its work tree is missing or empty
ok 68 - submodule deinit fails when the submodule contains modifications unless forced
ok 69 - submodule deinit fails when the submodule contains untracked files unless forced
ok 70 - submodule deinit fails when the submodule HEAD does not match unless forced
ok 71 - submodule deinit is silent when used on an uninitialized submodule
ok 72 - submodule deinit fails when submodule has a .git directory even when forced
# failed 1 among 72 test(s)
1..72
