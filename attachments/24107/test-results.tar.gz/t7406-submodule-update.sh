ok 1 - setup a submodule tree
ok 2 - submodule update detaching the HEAD 
ok 3 - submodule update does not fetch already present commits
ok 4 - submodule update should fail due to local changes
ok 5 - submodule update should throw away changes with --force 
ok 6 - submodule update --force forcibly checks out submodules
ok 7 - submodule update --remote should fetch upstream changes
ok 8 - local config should override .gitmodules branch
ok 9 - submodule update --rebase staying on master
ok 10 - submodule update --merge staying on master
ok 11 - submodule update - rebase in .git/config
ok 12 - submodule update - checkout in .git/config but --rebase given
ok 13 - submodule update - merge in .git/config
ok 14 - submodule update - checkout in .git/config but --merge given
ok 15 - submodule update - checkout in .git/config
ok 16 - submodule init picks up rebase
ok 17 - submodule init picks up merge
ok 18 - submodule update --merge  - ignores --merge  for new submodules
ok 19 - submodule update --rebase - ignores --rebase for new submodules
ok 20 - submodule update ignores update=merge config for new submodules
ok 21 - submodule update ignores update=rebase config for new submodules
ok 22 - submodule init picks up update=none
ok 23 - submodule update - update=none in .git/config
ok 24 - submodule update - update=none in .git/config but --checkout given
ok 25 - submodule update --init skips submodule with update=none
ok 26 - submodule update continues after checkout error
ok 27 - submodule update continues after recursive checkout error
ok 28 - submodule update exit immediately in case of merge conflict
ok 29 - submodule update exit immediately after recursive rebase error
ok 30 - add different submodules to the same path
ok 31 - submodule add places git-dir in superprojects git-dir
ok 32 - submodule update places git-dir in superprojects git-dir
ok 33 - submodule add places git-dir in superprojects git-dir recursive
ok 34 - submodule update places git-dir in superprojects git-dir recursive
ok 35 - submodule add properly re-creates deeper level submodules
ok 36 - submodule update properly revives a moved submodule
ok 37 # skip submodule update can handle symbolic links in pwd (missing SYMLINKS)
# passed all 37 test(s)
1..37
