ok 1 - submodule on detached working tree
ok 2 - submodule on detached working pointed by core.worktree
# passed all 2 test(s)
1..2
