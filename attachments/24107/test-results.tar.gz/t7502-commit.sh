ok 1 - output summary format
ok 2 - output summary format: root-commit
ok 3 - output summary format for commit with an empty diff
ok 4 - output summary format for merges
ok 5 - the basics
ok 6 - partial
ok 7 - partial modification in a subdirectory
ok 8 - partial removal
ok 9 - sign off
ok 10 - multiple -m
ok 11 - verbose
ok 12 - verbose respects diff config
ok 13 - prepare file with comment line and trailing newlines
ok 14 - cleanup commit messages (verbatim option,-t)
ok 15 - cleanup commit messages (verbatim option,-F)
ok 16 - cleanup commit messages (verbatim option,-m)
ok 17 - cleanup commit messages (whitespace option,-F)
ok 18 - cleanup commit messages (strip option,-F)
ok 19 - cleanup commit messages (strip option,-F,-e)
ok 20 - cleanup commit messages (strip option,-F,-e): output
ok 21 - cleanup commit message (fail on invalid cleanup mode option)
ok 22 - cleanup commit message (fail on invalid cleanup mode configuration)
ok 23 - cleanup commit message (no config and no option uses default)
ok 24 - cleanup commit message (option overrides default)
ok 25 - cleanup commit message (config overrides default)
ok 26 - cleanup commit message (option overrides config)
ok 27 - cleanup commit message (default, -m)
ok 28 - cleanup commit message (whitespace option, -m)
ok 29 - cleanup commit message (whitespace config, -m)
ok 30 - message shows author when it is not equal to committer
ok 31 # skip message shows committer when it is automatic (missing AUTOIDENT)
ok 32 - do not fire editor when committer is bogus
ok 33 - do not fire editor in the presence of conflicts
ok 34 # skip a SIGTERM should break locks (missing EXECKEEPSPID)
ok 35 - Hand committing of a redundant merge removes dups
ok 36 - A single-liner subject with a token plus colon is not a footer
ok 37 - commit -s places sob on third line after two empty lines
ok 38 - commit
ok 39 - commit
ok 40 - commit --status
ok 41 - commit --no-status
ok 42 - commit with commit.status = yes
ok 43 - commit with commit.status = no
ok 44 - commit --status with commit.status = yes
ok 45 - commit --no-status with commit.status = yes
ok 46 - commit --status with commit.status = no
ok 47 - commit --no-status with commit.status = no
ok 48 - commit
ok 49 - commit
ok 50 - commit --status
ok 51 - commit --no-status
ok 52 - commit with commit.status = yes
ok 53 - commit with commit.status = no
ok 54 - commit --status with commit.status = yes
ok 55 - commit --no-status with commit.status = yes
ok 56 - commit --status with commit.status = no
ok 57 - commit --no-status with commit.status = no
ok 58 - commit --status with custom comment character
# passed all 58 test(s)
1..58
