ok 1 - with no hook
ok 2 - with hook (-m)
ok 3 - with hook (-m editor)
ok 4 - with hook (-t)
ok 5 - with hook (-F)
ok 6 - with hook (-F editor)
ok 7 - with hook (-C)
ok 8 - with hook (editor)
ok 9 - with hook (--amend)
ok 10 - with hook (-c)
ok 11 - with hook (merge)
ok 12 - with failing hook
ok 13 - with failing hook (--no-verify)
ok 14 - with failing hook (merge)
# passed all 14 test(s)
1..14
