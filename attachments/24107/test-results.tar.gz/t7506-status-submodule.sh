ok 1 - setup
ok 2 - status clean
ok 3 - commit --dry-run -a clean
ok 4 - status with modified file in submodule
ok 5 - status with modified file in submodule (porcelain)
ok 6 - status with added file in submodule
ok 7 - status with added file in submodule (porcelain)
ok 8 - status with untracked file in submodule
ok 9 - status -uno with untracked file in submodule
ok 10 - status with untracked file in submodule (porcelain)
ok 11 - status with added and untracked file in submodule
ok 12 - status with added and untracked file in submodule (porcelain)
ok 13 - status with modified file in modified submodule
ok 14 - status with modified file in modified submodule (porcelain)
ok 15 - status with added file in modified submodule
ok 16 - status with added file in modified submodule (porcelain)
ok 17 - status with untracked file in modified submodule
ok 18 - status with untracked file in modified submodule (porcelain)
ok 19 - status with added and untracked file in modified submodule
ok 20 - status with added and untracked file in modified submodule (porcelain)
ok 21 - setup .git file for sub
ok 22 - status with added file in modified submodule with .git file
ok 23 - rm submodule contents
ok 24 - status clean (empty submodule dir)
ok 25 - status -a clean (empty submodule dir)
ok 26 - status with merge conflict in .gitmodules
ok 27 - diff with merge conflict in .gitmodules
ok 28 - diff --submodule with merge conflict in .gitmodules
# passed all 28 test(s)
1..28
