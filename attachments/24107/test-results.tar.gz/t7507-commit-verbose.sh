ok 1 - setup
ok 2 - initial commit shows verbose diff
ok 3 - second commit
ok 4 - verbose diff is stripped out
ok 5 - verbose diff is stripped out (mnemonicprefix)
ok 6 - diff in message is retained without -v
not ok 7 - diff in message is retained with -v # TODO known breakage
# still have 1 known breakage(s)
# passed all remaining 6 test(s)
1..7
