ok 1 - create signed commits
ok 2 - show signatures
ok 3 - detect fudged signature
ok 4 - detect fudged signature with NUL
ok 5 - amending already signed commit
# passed all 5 test(s)
1..5
