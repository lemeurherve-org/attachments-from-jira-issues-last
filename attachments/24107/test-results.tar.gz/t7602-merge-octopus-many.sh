ok 1 - setup
ok 2 - merge c1 with c2, c3, c4, ... c29
ok 3 - merge output uses pretty names
ok 4 - merge reduces irrelevant remote heads
ok 5 - merge fast-forward output uses pretty names
# passed all 5 test(s)
1..5
