Browser
=======

  * Screen size: 1280x1024
  * User Agent
      - Type:     Browser
      - Name:     Firefox
      - Family:   FIREFOX
      - Producer: Mozilla Foundation
      - Version:  25.0
      - Raw:      `Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0`
  * Operating System
      - Name:     Windows 7
      - Family:   WINDOWS
      - Producer: Microsoft Corporation.
      - Version:  6.1

