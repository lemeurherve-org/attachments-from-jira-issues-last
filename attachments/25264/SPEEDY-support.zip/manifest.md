Support Bundle Manifest
=======================

Generated on 2014-02-10 03:25:52 -0500

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/PRDJENK201/checksums.md5`

      - `nodes/slave/VDIQTPTaskW704/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/PRDJENK201/environment.txt`

      - `nodes/slave/VDIQTPTaskW704/environment.txt`

