Jenkins
=======

Version details
---------------

  * Version: `1.532.2.2 (Jenkins Enterprise by CloudBees 13.11)`
  * Mode:    WAR
  * Servlet container
      - Specification: 2.5
      - Name:          `Winstone Servlet Engine v0.9.10`
  * Java
      - Home:           `E:\Java\jdk1.7.0_40\jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_40
      - Maximum memory:   507.00 MB (531628032)
      - Allocated memory: 507.00 MB (531628032)
      - Free memory:      122.81 MB (128771848)
      - In-use memory:    384.19 MB (402856184)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.0-b56
  * Operating system
      - Name:         Windows Server 2008 R2
      - Architecture: amd64
      - Version:      6.1
  * Process ID: 6132 (0x17f4)
  * Process started: 2014-02-28 11:28:55.278-0500
  * Process uptime: 3 hr 13 min
  * JVM startup parameters:
      - Boot classpath: `E:\Java\jdk1.7.0_40\jre\lib\resources.jar;E:\Java\jdk1.7.0_40\jre\lib\rt.jar;E:\Java\jdk1.7.0_40\jre\lib\sunrsasign.jar;E:\Java\jdk1.7.0_40\jre\lib\jsse.jar;E:\Java\jdk1.7.0_40\jre\lib\jce.jar;E:\Java\jdk1.7.0_40\jre\lib\charsets.jar;E:\Java\jdk1.7.0_40\jre\lib\jfr.jar;E:\Java\jdk1.7.0_40\jre\classes;E:\introscope9550A\wily\Agent.jar`
      - Classpath: `E:\Jenkins\jenkins.war;E:/introscope9550A/wily/Agent.jar`
      - Library path: `E:\Java\jdk1.7.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.7.0_40\bin;E:\AccuRev\601\bin;.`
      - arg[0]: `-javaagent:E:/introscope9550A/wily/Agent.jar`
      - arg[1]: `-Dintroscope.agent.customProcessName=Jenkins`
      - arg[2]: `-Dintroscope.agent.agentName=Jenkins`
      - arg[3]: `-Dcom.wily.introscope.agentProfile=E:/introscope9550A/wily/core/config/IntroscopeAgent-FULL-TEST.profile`
      - arg[4]: `-Xrs`
      - arg[5]: `-Xms512m`
      - arg[6]: `-Xmx512m`
      - arg[7]: `-XX:MaxPermSize=256m`
      - arg[8]: `-XX:+HeapDumpOnOutOfMemoryError`
      - arg[9]: `-Xloggc:E:\Jenkins/verbosegc.log`
      - arg[10]: `-XX:+UseGCLogFileRotation`
      - arg[11]: `-XX:NumberOfGCLogFiles=3`
      - arg[12]: `-XX:GCLogFileSize=5M`
      - arg[13]: `-XX:+PrintGCDetails`
      - arg[14]: `-XX:+PrintGCDateStamps`
      - arg[15]: `-XX:-TraceClassUnloading`
      - arg[16]: `-Dhudson.DNSMultiCast.disabled=true`
      - arg[17]: `-Dhudson.model.DownloadService.never=true`
      - arg[18]: `-Dhudson.model.UpdateCenter.never=true`
      - arg[19]: `-Dhudson.security.ExtendedReadPermission=true`
      - arg[20]: `-Dhudson.Util.noSymLink=true`
      - arg[21]: `-Djava.io.tmpdir=E:\TEMP`
      - arg[22]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

License details
---------------

 * Jenkins Instance ID: `7f39f8e105287bba9badb473fce57b63`
 * Expires:             Dec 18, 2016
 * Issued to:           Auto-Owners Insurance
 * Organization:        Hudson Customer:version=2,company=Auto-Owners Insurance,serverKey=7f39f8e105287bba9badb473fce57b63,executors=5
 * Entitlements:
     - Jenkins Enterprise license with 5 executors


Important configuration
---------------

  * Security realm: LDAP
  * Authorization strategy: Role-based matrix authorization strategy

Active Plugins
--------------

  * accurev:0.6.18 *(update available)* 'Jenkins Accurev plugin'
  * active-directory:1.33 'Jenkins Active Directory plugin'
  * analysis-collector:1.38 *(update available)* 'Static Analysis Collector Plug-in'
  * analysis-core:1.54 *(update available)* 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * any-buildstep:0.1 'Any Build Step Plugin'
  * artifactdeployer:0.28 'Jenkins Artifact Deployer Plug-in'
  * artifactory:2.2.1 'Jenkins Artifactory Plugin'
  * async-http-client:1.7.8 'Async Http Client'
  * build-cause-run-condition:0.1 'Build Cause Run Condition Plugin'
  * build-failure-analyzer:1.5.1 'Build Failure Analyzer'
  * build-flow-plugin:0.10 'CloudBees Build Flow plugin'
  * build-name-setter:1.3 'build-name-setter'
  * build-pipeline-plugin:1.4.2 'Build Pipeline Plugin'
  * build-timeout:1.12.2 'Jenkins build timeout plugin'
  * build-user-vars-plugin:1.1 'Jenkins user build vars plugin'
  * build-view-column:0.2 'Build View Column Plugin'
  * buildgraph-view:1.1.1 'buildgraph-view'
  * buildtriggerbadge:1.1 'Build Trigger Badge Plugin'
  * bulk-builder:1.5 'Bulk Builder'
  * categorized-view:1.1 'categorized-view'
  * checkstyle:3.38 *(update available)* 'Checkstyle Plug-in'
  * clone-workspace-scm:0.6 'Jenkins Clone Workspace SCM Plug-in'
  * cloudbees-aborted-builds:1.5 'CloudBees Restart Aborted Builds Plugin'
  * cloudbees-consolidated-build-view:1.1 'CloudBees Consolidated Build View Plugin'
  * cloudbees-credentials:3.2 'CloudBees Credentials Plugin'
  * cloudbees-even-scheduler:3.3 'CloudBees Even Scheduler Plugin'
  * cloudbees-folder:4.2.1 'CloudBees Folders Plugin'
  * cloudbees-folders-plus:2.5 'CloudBees Folders Plus Plugin'
  * cloudbees-ha:4.2 'CloudBees High Availability Management plugin'
  * cloudbees-jsync-archiver:5.1 'CloudBees Fast Archiving Plugin'
  * cloudbees-label-throttling-plugin:3.3 'CloudBees Label Throttling Plugin'
  * cloudbees-license:5.3 'CloudBees License Manager'
  * cloudbees-nodes-plus:1.6 'CloudBees Nodes Plus Plugin'
  * cloudbees-plugin-usage:1.3 'CloudBees Plugin Usage Plugin'
  * cloudbees-quiet-start:1.0 'CloudBees Quiet Start Plugin'
  * cloudbees-secure-copy:3.6 'CloudBees Secure Copy Plugin'
  * cloudbees-ssh-slaves:0.1-beta-3 'CloudBees SSH Slaves Plugin'
  * cloudbees-support:2.1 'CloudBees Support Plugin'
  * cloudbees-template:4.4 'CloudBees Template Plugin'
  * cloudbees-update-center-plugin:4.11 'CloudBees Update Center Plugin'
  * cloudbees-view-creation-filter:1.0 'CloudBees View Creation Filter Plugin'
  * cloudbees-wasted-minutes-tracker:3.6 'CloudBees Wasted Minutes Tracker Plugin'
  * cobertura:1.9.3 'Jenkins Cobertura Plugin'
  * compact-columns:1.10 'Compact Columns'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * config-autorefresh-plugin:1.0 'Config AutoRefresh Plugin'
  * config-file-provider:2.7.1 'Config File Provider Plugin'
  * configurationslicing:1.38.3 'Configuration Slicing plugin'
  * copyartifact:1.30 'Copy Artifact Plugin'
  * credentials:1.10 'Credentials Plugin'
  * cron_column:1.003 'Hudson Cron Column Plugin'
  * dashboard-view:2.9.2 'Dashboard View'
  * delivery-pipeline-plugin:0.6.10 'Delivery Pipeline Plugin'
  * disk-usage:0.23 'Jenkins disk-usage plugin'
  * email-ext:2.37.2.1 'Jenkins Email Extension Plugin'
  * emma:1.29 'Jenkins Emma plugin'
  * envinject:1.89 'Environment Injector Plugin'
  * Exclusion:0.10 'Jenkins Exclusion Plug-in'
  * external-monitor-job:1.1 *(update available)* 'External Monitor Job Type Plugin'
  * extra-columns:1.13 'Extra Columns Plugin'
  * findbugs:4.51 'FindBugs Plug-in'
  * flexible-publish:0.12 'Flexible Publish Plugin'
  * git:2.0 *(update available)* 'Jenkins GIT plugin'
  * git-client:1.4.6 *(update available)* 'Jenkins GIT client plugin'
  * global-build-stats:1.3 'Hudson global-build-stats plugin'
  * groovy:1.15 'Hudson Groovy builder'
  * heavy-job:1.1 'Heavy Job Plugin'
  * hp-application-automation-tools-plugin:1.0.2 *(update available)* 'HP Application Automation Tools'
  * infradna-backup:3.10 'CloudBees Back-up Plugin'
  * ivy:1.23.2 'Ivy Plugin'
  * javadoc:1.1 'Javadoc Plugin'
  * jobConfigHistory:2.5 'Jenkins Job Configuration History Plugin'
  * jquery:1.7.2-1 'Jenkins jQuery plugin'
  * ldap:1.8 'LDAP Plugin'
  * log-parser:1.0.8 'Log Parser Plugin'
  * mailer:1.8 'Jenkins Mailer Plugin'
  * maven-plugin:2.0 *(update available)* 'Maven Integration plugin'
  * monitoring:1.49.0 'Monitoring'
  * msbuild:1.21 'Jenkins MSBuild Plugin'
  * mstest:0.7 'JENKINS MSTest plugin'
  * mstestrunner:1.0.1 'Jenkins MSTestRunner plugin'
  * nectar-license:5.4 'Jenkins Enterprise License Entitlement Check'
  * nectar-rbac:4.5 'CloudBees Role-Based Access Control Plugin'
  * nectar-vmware:4.0 'CloudBees VMWare Autoscaling Plugin'
  * next-executions:1.0.6 'next-executions'
  * node-iterator-api:1.1 *(update available)* 'Node Iterator API Plugin'
  * nunit:0.15 'Jenkins NUnit plugin'
  * parameterized-trigger:2.22 'Jenkins Parameterized Trigger plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * powershell:1.2 'Hudson PowerShell plugin'
  * PrioritySorter:2.6 'Jenkins Priority Sorter Plugin'
  * promoted-builds:2.15 'Jenkins promoted builds plugin'
  * publish-over-ssh:1.11 'Publish Over SSH'
  * radiatorviewplugin:1.18 'Radiator View Plugin'
  * rebuild:1.21 'Rebuilder'
  * run-condition:1.0 'Run Condition Plugin'
  * run-condition-extras:0.1 'Jenkins Run Condition Extras Plugin'
  * scm-api:0.2 'SCM API Plugin'
  * show-build-parameters:1.0 'Show Build Parameters plugin'
  * sidebar-link:1.6 'Sidebar Link'
  * skip-plugin:3.5 'CloudBees Skip Next Build Plugin'
  * ssh-agent:1.4.1 'SSH Agent Plugin'
  * ssh-credentials:1.6.1 'SSH Credentials Plugin'
  * ssh-slaves:1.6 'Jenkins SSH Slaves plugin'
  * support-core:1.8 'Support Core Plugin'
  * tasks:4.38 *(update available)* 'Task Scanner Plug-in'
  * text-finder-run-condition:0.1 'Text Finder Run Condition Plugin'
  * throttle-concurrents:1.8.1 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.5.8 'Timestamper'
  * tmpcleaner:1.1 'Jenkins java.io.tmpdir cleaner plugin'
  * token-macro:1.9 *(update available)* 'Token Macro Plugin'
  * versioncolumn:0.2 'Jenkins Version Column plugin'
  * view-job-filters:1.26 'View Job Filters'
  * warnings:4.38 *(update available)* 'Warnings Plug-in'
  * was-builder:1.6.1 'WAS Builder Plugin'
  * wikitext:3.6 'CloudBees WikiText Security Plugin'
  * ws-cleanup:0.20 'Jenkins Workspace Cleanup Plugin'

Node statistics
---------------

  * Total number of nodes
      - Sample size:        767
      - Average:            4.0
      - Standard deviation: 0.0
      - Minimum:            4.0
      - Maximum:            4.0
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of nodes online
      - Sample size:        767
      - Average:            3.9960886571056062
      - Standard deviation: 0.10832372170111776
      - Minimum:            1.0
      - Maximum:            4.0
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of executors
      - Sample size:        767
      - Average:            6.9921773142112125
      - Standard deviation: 0.21664744340223552
      - Minimum:            1.0
      - Maximum:            7.0
      - 95th percentile:    7.0
      - 99th percentile:    7.0
  * Total number of executors in use
      - Sample size:        767
      - Average:            0.3650586701434159
      - Standard deviation: 0.6718739355907225
      - Minimum:            0.0
      - Maximum:            2.0
      - 95th percentile:    2.0
      - 99th percentile:    2.0


Job statistics
--------------

  * All jobs
      - Number of jobs: 374
      - Number of builds per job: 0.25935828877005346 [n=374, s=1.4]
  * Jobs that `Back up Jenkins`
      - Number of jobs: 1
      - Number of builds per job: 2 [n=1]
  * Jobs that `Monitor an external job`
      - Number of jobs: 0
      - Number of builds per job: N/A
  * Jobs that `Build an Ivy project`
      - Number of jobs: 0
      - Number of builds per job: N/A
  * Jobs that `Build a free-style software project`
      - Number of jobs: 368
      - Number of builds per job: 0.1793478260869565 [n=368, s=1.3]
  * Jobs that `Build Flow`
      - Number of jobs: 0
      - Number of builds per job: N/A
  * Jobs that `Build multi-configuration project`
      - Number of jobs: 1
      - Number of builds per job: 5 [n=1]
  * Jobs that `Build a maven2/3 project`
      - Number of jobs: 0
      - Number of builds per job: N/A

Container statistics
--------------------

  * All containers
      - Number of containers: 224
      - Number of items per container: 2.8080357142857144 [n=224, s=5.2]
  * Container type: `Build » Template_Folder_Type_ZIP`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build » Template_Folder_Project_JAR`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build an Ivy project`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build » Template_Folder_Type_ClaimCenter`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Deploy » Environment Folder`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build multi-configuration project`
      - Number of containers: 1
      - Number of items per container: 4 [n=1]
  * Container type: `Build » Template_Folder_Type_JEE`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build » Template_Folder_Project_JEE`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build » Template_Folder_Type_.NET`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build » Template_Folder_Department`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build a maven2/3 project`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build » Template_Folder_Project_BAR`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build » Template_Folder_Type_JAR`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Folder`
      - Number of containers: 223
      - Number of items per container: 2.802690582959641 [n=223, s=5.2]
  * Container type: `Build » Template_Folder_Type_BAR`
      - Number of containers: 0
      - Number of items per container: N/A
