CloudBees Support Bundle Manifest
=================================

Generated on 2014-02-28 02:42:11 -0500

Requested components:

  * About Jenkins

      - `about.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/Deploy-101/checksums.md5`

      - `nodes/slave/Java-002/checksums.md5`

      - `nodes/slave/dotNET-005/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

