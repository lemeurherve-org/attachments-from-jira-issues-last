Build Nodes
===========

  * master (Jenkins)
      - Description:    `the master Jenkins node`
      - Executors:      1
      - Remote FS root: `E:\Jenkins`
      - Labels:         (none)
      - Usage:          Leave this machine for tied jobs only
      - Java
          + Home:           `E:\Java\jdk1.7.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_40
          + Maximum memory:   507.00 MB (531628032)
          + Allocated memory: 507.00 MB (531628032)
          + Free memory:      110.47 MB (115833824)
          + In-use memory:    396.53 MB (415794208)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.0-b56
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 6132 (0x17f4)
      - Process started: 2014-02-28 11:28:55.278-0500
      - Process uptime: 3 hr 13 min
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.7.0_40\jre\lib\resources.jar;E:\Java\jdk1.7.0_40\jre\lib\rt.jar;E:\Java\jdk1.7.0_40\jre\lib\sunrsasign.jar;E:\Java\jdk1.7.0_40\jre\lib\jsse.jar;E:\Java\jdk1.7.0_40\jre\lib\jce.jar;E:\Java\jdk1.7.0_40\jre\lib\charsets.jar;E:\Java\jdk1.7.0_40\jre\lib\jfr.jar;E:\Java\jdk1.7.0_40\jre\classes;E:\introscope9550A\wily\Agent.jar`
          + Classpath: `E:\Jenkins\jenkins.war;E:/introscope9550A/wily/Agent.jar`
          + Library path: `E:\Java\jdk1.7.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.7.0_40\bin;E:\AccuRev\601\bin;.`
          + arg[0]: `-javaagent:E:/introscope9550A/wily/Agent.jar`
          + arg[1]: `-Dintroscope.agent.customProcessName=Jenkins`
          + arg[2]: `-Dintroscope.agent.agentName=Jenkins`
          + arg[3]: `-Dcom.wily.introscope.agentProfile=E:/introscope9550A/wily/core/config/IntroscopeAgent-FULL-TEST.profile`
          + arg[4]: `-Xrs`
          + arg[5]: `-Xms512m`
          + arg[6]: `-Xmx512m`
          + arg[7]: `-XX:MaxPermSize=256m`
          + arg[8]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[9]: `-Xloggc:E:\Jenkins/verbosegc.log`
          + arg[10]: `-XX:+UseGCLogFileRotation`
          + arg[11]: `-XX:NumberOfGCLogFiles=3`
          + arg[12]: `-XX:GCLogFileSize=5M`
          + arg[13]: `-XX:+PrintGCDetails`
          + arg[14]: `-XX:+PrintGCDateStamps`
          + arg[15]: `-XX:-TraceClassUnloading`
          + arg[16]: `-Dhudson.DNSMultiCast.disabled=true`
          + arg[17]: `-Dhudson.model.DownloadService.never=true`
          + arg[18]: `-Dhudson.model.UpdateCenter.never=true`
          + arg[19]: `-Dhudson.security.ExtendedReadPermission=true`
          + arg[20]: `-Dhudson.Util.noSymLink=true`
          + arg[21]: `-Djava.io.tmpdir=E:\TEMP`
          + arg[22]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

  * Java-002 (Dumb Slave)
      - Description:    `JEE Build Slave`
      - Executors:      2
      - Remote FS root: `E:\Jenkins`
      - Labels:         Java Broker Coverity
      - Usage:          Utilize this slave as much as possible
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.33
      - Java
          + Home:           `E:\Java\jdk1.7.0_51\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 355.50 MB (372768768)
          + Free memory:      296.84 MB (311261696)
          + In-use memory:    58.66 MB (61507072)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 2996 (0xbb4)
      - Process started: 2014-02-20 09:25:41.287-0500
      - Process uptime: 8 days 5 hr
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.7.0_51\jre\lib\resources.jar;E:\Java\jdk1.7.0_51\jre\lib\rt.jar;E:\Java\jdk1.7.0_51\jre\lib\sunrsasign.jar;E:\Java\jdk1.7.0_51\jre\lib\jsse.jar;E:\Java\jdk1.7.0_51\jre\lib\jce.jar;E:\Java\jdk1.7.0_51\jre\lib\charsets.jar;E:\Java\jdk1.7.0_51\jre\lib\jfr.jar;E:\Java\jdk1.7.0_51\jre\classes`
          + Classpath: `E:\Jenkins\slave.jar`
          + Library path: `E:\Java\jdk1.7.0_51\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.7.0_51\bin;E:\Accurev\601\bin;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Djava.io.tmpdir=E:\TEMP`

  * dotNET-005 (Dumb Slave)
      - Description:    `.NET Build Slave`
      - Executors:      2
      - Remote FS root: `E:\Jenkins`
      - Labels:         .NET
      - Usage:          Utilize this slave as much as possible
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.33
      - Java
          + Home:           `E:\Java\jdk1.7.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_40
          + Maximum memory:   494.94 MB (518979584)
          + Allocated memory: 31.06 MB (32571392)
          + Free memory:      18.92 MB (19838672)
          + In-use memory:    12.14 MB (12732720)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.0-b56
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 4764 (0x129c)
      - Process started: 2014-02-20 09:28:39.367-0500
      - Process uptime: 8 days 5 hr
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.7.0_40\jre\lib\resources.jar;E:\Java\jdk1.7.0_40\jre\lib\rt.jar;E:\Java\jdk1.7.0_40\jre\lib\sunrsasign.jar;E:\Java\jdk1.7.0_40\jre\lib\jsse.jar;E:\Java\jdk1.7.0_40\jre\lib\jce.jar;E:\Java\jdk1.7.0_40\jre\lib\charsets.jar;E:\Java\jdk1.7.0_40\jre\lib\jfr.jar;E:\Java\jdk1.7.0_40\jre\classes`
          + Classpath: `E:\Jenkins\slave.jar`
          + Library path: `E:\Java\jdk1.7.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.7.0_40\bin;E:\AccuRev\601\bin;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\ManagementStudio\;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\PrivateAssemblies\;C:\Program Files (x86)\Microsoft SQL Server\110\DTS\Binn\;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Djava.io.tmpdir=E:\TEMP`

  * Deploy-101 (Dumb Slave)
      - Description:    `WIA Deploy Server`
      - Executors:      2
      - Remote FS root: `E:\Jenkins`
      - Labels:         WIA
      - Usage:          Utilize this slave as much as possible
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.33
      - Java
          + Home:           `E:\Java\jdk1.7.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_40
          + Maximum memory:   455.00 MB (477102080)
          + Allocated memory: 37.00 MB (38797312)
          + Free memory:      20.02 MB (20992288)
          + In-use memory:    16.98 MB (17805024)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.0-b56
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 5440 (0x1540)
      - Process started: 2014-02-27 10:04:59.354-0500
      - Process uptime: 1 day 4 hr
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.7.0_40\jre\lib\resources.jar;E:\Java\jdk1.7.0_40\jre\lib\rt.jar;E:\Java\jdk1.7.0_40\jre\lib\sunrsasign.jar;E:\Java\jdk1.7.0_40\jre\lib\jsse.jar;E:\Java\jdk1.7.0_40\jre\lib\jce.jar;E:\Java\jdk1.7.0_40\jre\lib\charsets.jar;E:\Java\jdk1.7.0_40\jre\lib\jfr.jar;E:\Java\jdk1.7.0_40\jre\classes`
          + Classpath: `E:\Jenkins\slave.jar`
          + Library path: `E:\Java\jdk1.7.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.7.0_40\bin;E:\AccuRev\601\bin;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Djava.io.tmpdir=E:\TEMP`

