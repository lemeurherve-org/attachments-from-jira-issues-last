Build Nodes
===========

  * master (Jenkins)
      - Description:    `the master Jenkins node`
      - Executors:      1
      - Remote FS root: `E:\Jenkins`
      - Labels:         (none)
      - Usage:          Leave this machine for tied jobs only
      - Java
          + Home:           `E:\IBM\java_1.7_64\jre`
          + Vendor:           IBM Corporation
          + Version:          1.7.0
          + Maximum memory:   512.00 MB (536870912)
          + Allocated memory: 512.00 MB (536870912)
          + Free memory:      225.21 MB (236150312)
          + In-use memory:    286.79 MB (300720600)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    IBM J9 VM
          + Vendor:  IBM Corporation
          + Version: 2.6
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 7212 (0x1c2c)
      - Process started: 2014-03-31 13:04:55.283-0400
      - Process uptime: 1 day 21 hr
      - JVM startup parameters:
          + Boot classpath: `E:\IBM\java_1.7_64\jre\bin\compressedrefs\jclSC170\vm.jar;E:\IBM\java_1.7_64\jre\lib\se-service.jar;E:\IBM\java_1.7_64\jre\lib\math.jar;E:\IBM\java_1.7_64\jre\lib\jlm.jar;E:\IBM\java_1.7_64\jre\lib\ibmorb.jar;E:\IBM\java_1.7_64\jre\lib\ibmorbapi.jar;E:\IBM\java_1.7_64\jre\lib\ibmcfw.jar;E:\IBM\java_1.7_64\jre\lib\ibmpkcs.jar;E:\IBM\java_1.7_64\jre\lib\ibmcertpathfw.jar;E:\IBM\java_1.7_64\jre\lib\ibmjgssfw.jar;E:\IBM\java_1.7_64\jre\lib\ibmjssefw.jar;E:\IBM\java_1.7_64\jre\lib\ibmsaslfw.jar;E:\IBM\java_1.7_64\jre\lib\ibmjcefw.jar;E:\IBM\java_1.7_64\jre\lib\ibmjgssprovider.jar;E:\IBM\java_1.7_64\jre\lib\ibmjsseprovider2.jar;E:\IBM\java_1.7_64\jre\lib\ibmcertpathprovider.jar;E:\IBM\java_1.7_64\jre\lib\xmldsigfw.jar;E:\IBM\java_1.7_64\jre\lib\xml.jar;E:\IBM\java_1.7_64\jre\lib\charsets.jar;E:\IBM\java_1.7_64\jre\lib\resources.jar;E:\IBM\java_1.7_64\jre\lib\rt.jar;E:\introscope9550A\wily\Agent.jar`
          + Classpath: `E:\Jenkins\jenkins.war;E:/introscope9550A/wily/Agent.jar;E:/introscope9550A/wily/Agent.jar`
          + Library path: `E:\IBM\java_1.7_64\jre\bin\compressedrefs;E:\IBM\java_1.7_64\jre\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\IBM\java_1.7_64\bin;E:\AccuRev\601\bin;.`
          + arg[0]: `-Xoptionsfile=E:\IBM\java_1.7_64\jre\bin\compressedrefs\options.default`
          + arg[1]: `-Xlockword:mode=default,noLockword=java/lang/String,noLockword=java/util/MapEntry,noLockword=java/util/HashMap$Entry,noLockword=org/apache/harmony/luni/util/ModifiedMap$Entry,noLockword=java/util/Hashtable$Entry,noLockword=java/lang/invoke/MethodType,noLockword=java/lang/invoke/MethodHandle,noLockword=java/lang/invoke/CollectHandle,noLockword=java/lang/invoke/ConstructorHandle,noLockword=java/lang/invoke/ConvertHandle,noLockword=java/lang/invoke/ArgumentConversionHandle,noLockword=java/lang/invoke/AsTypeHandle,noLockword=java/lang/invoke/ExplicitCastHandle,noLockword=java/lang/invoke/FilterReturnHandle,noLockword=java/lang/invoke/DirectHandle,noLockword=java/lang/invoke/ReceiverBoundHandle,noLockword=java/lang/invoke/DynamicInvokerHandle,noLockword=java/lang/invoke/FieldHandle,noLockword=java/lang/invoke/FieldGetterHandle,noLockword=java/lang/invoke/FieldSetterHandle,noLockword=java/lang/invoke/StaticFieldGetterHandle,noLockword=java/lang/invoke/StaticFieldSetterHandle,noLockword=java/lang/invoke/IndirectHandle,noLockword=java/lang/invoke/InterfaceHandle,noLockword=java/lang/invoke/VirtualHandle,noLockword=java/lang/invoke/InvokeExactHandle,noLockword=java/lang/invoke/InvokeGenericHandle,noLockword=java/lang/invoke/VarargsCollectorHandle,noLockword=java/lang/invoke/ThunkTuple`
          + arg[2]: `-Xjcl:jclse7b_26`
          + arg[3]: `-Dcom.ibm.oti.vm.bootstrap.library.path=E:\IBM\java_1.7_64\jre\bin\compressedrefs;E:\IBM\java_1.7_64\jre\bin`
          + arg[4]: `-Dsun.boot.library.path=E:\IBM\java_1.7_64\jre\bin\compressedrefs;E:\IBM\java_1.7_64\jre\bin`
          + arg[5]: `-Djava.library.path=E:\IBM\java_1.7_64\jre\bin\compressedrefs;E:\IBM\java_1.7_64\jre\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\IBM\java_1.7_64\bin;E:\AccuRev\601\bin;.`
          + arg[6]: `-Djava.home=E:\IBM\java_1.7_64\jre`
          + arg[7]: `-Djava.ext.dirs=E:\IBM\java_1.7_64\jre\lib\ext`
          + arg[8]: `-Duser.dir=E:\Jenkins`
          + arg[9]: `-Djava.runtime.version=pwa6470sr4fp1ifx-20130423_02 (SR4 FP1+IV38579+IV38399+IV40208)`
          + arg[10]: `-Djava.class.path=.`
          + arg[11]: `-javaagent:E:/introscope9550A/wily/Agent.jar`
          + arg[12]: `-Dintroscope.agent.customProcessName=Jenkins`
          + arg[13]: `-Dintroscope.agent.agentName=Jenkins`
          + arg[14]: `-Dcom.wily.introscope.agentProfile=E:/introscope9550A/wily/core/config/IntroscopeAgent-FULL-TEST.profile`
          + arg[15]: `-Xrs`
          + arg[16]: `-Xms512m`
          + arg[17]: `-Xmx512m`
          + arg[18]: `-Xverbosegclog:E:\Jenkins/verbosegc_%Y.%m.%d_%H.%M.%S.xml`
          + arg[19]: `-Djavax.net.ssl.trustStore=E:\Jenkins/trust.jks`
          + arg[20]: `-Dhudson.DNSMultiCast.disabled=true`
          + arg[21]: `-Dhudson.model.DownloadService.never=true`
          + arg[22]: `-Dhudson.model.UpdateCenter.never=true`
          + arg[23]: `-Dhudson.security.ExtendedReadPermission=true`
          + arg[24]: `-Dhudson.Util.noSymLink=true`
          + arg[25]: `-Dhudson.plugins.tmpcleaner.TmpCleanWork.minutes=30`
          + arg[26]: `-Djava.io.tmpdir=E:\TEMP`
          + arg[27]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`
          + arg[28]: `-Djava.class.path=E:\Jenkins\jenkins.war`
          + arg[29]: `-Dsun.java.command=E:\Jenkins\jenkins.war --prefix=/jenkins --handlerCountMax=40 --handlerCountMaxIdle=40 --httpPort=8080`
          + arg[30]: `-Dsun.java.launcher=SUN_STANDARD`

  * Java-002 (Dumb Slave)
      - Description:    `JEE Build Slave`
      - Executors:      2
      - Remote FS root: `E:\Jenkins`
      - Labels:         Java Broker Coverity Isolation
      - Usage:          Utilize this slave as much as possible
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.33
      - Java
          + Home:           `E:\Java\jdk1.6.0_45\jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_45
          + Maximum memory:   910.25 MB (954466304)
          + Allocated memory: 19.38 MB (20316160)
          + Free memory:      4.61 MB (4832416)
          + In-use memory:    14.77 MB (15483744)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.45-b01
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 7376 (0x1cd0)
      - Process started: 2014-03-20 13:30:39.398-0400
      - Process uptime: 12 days
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.6.0_45\jre\lib\resources.jar;E:\Java\jdk1.6.0_45\jre\lib\rt.jar;E:\Java\jdk1.6.0_45\jre\lib\sunrsasign.jar;E:\Java\jdk1.6.0_45\jre\lib\jsse.jar;E:\Java\jdk1.6.0_45\jre\lib\jce.jar;E:\Java\jdk1.6.0_45\jre\lib\charsets.jar;E:\Java\jdk1.6.0_45\jre\lib\modules\jdk.boot.jar;E:\Java\jdk1.6.0_45\jre\classes`
          + Classpath: `E:\Jenkins\slave.jar`
          + Library path: `E:\Java\jdk1.6.0_45\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.6.0_45\bin;E:\Accurev\601\bin;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Djruby.native.verbose=true`
          + arg[2]: `-Djava.io.tmpdir=E:\TEMP`

  * dotNET-005 (Dumb Slave)
      - Description:    `.NET Build Slave`
      - Executors:      2
      - Remote FS root: `E:\Jenkins`
      - Labels:         .NET
      - Usage:          Utilize this slave as much as possible
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.33
      - Java
          + Home:           `E:\IBM\java_1.7_64\jre`
          + Vendor:           IBM Corporation
          + Version:          1.7.0
          + Maximum memory:   512.00 MB (536870912)
          + Allocated memory: 14.81 MB (15532032)
          + Free memory:      7.25 MB (7600768)
          + In-use memory:    7.56 MB (7931264)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    IBM J9 VM
          + Vendor:  IBM Corporation
          + Version: 2.6
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 1372 (0x55c)
      - Process started: 2014-03-19 11:15:29.371-0400
      - Process uptime: 13 days
      - JVM startup parameters:
          + Boot classpath: `E:\IBM\java_1.7_64\jre\bin\compressedrefs\jclSC170\vm.jar;E:\IBM\java_1.7_64\jre\lib\se-service.jar;E:\IBM\java_1.7_64\jre\lib\math.jar;E:\IBM\java_1.7_64\jre\lib\jlm.jar;E:\IBM\java_1.7_64\jre\lib\ibmorb.jar;E:\IBM\java_1.7_64\jre\lib\ibmorbapi.jar;E:\IBM\java_1.7_64\jre\lib\ibmcfw.jar;E:\IBM\java_1.7_64\jre\lib\ibmpkcs.jar;E:\IBM\java_1.7_64\jre\lib\ibmcertpathfw.jar;E:\IBM\java_1.7_64\jre\lib\ibmjgssfw.jar;E:\IBM\java_1.7_64\jre\lib\ibmjssefw.jar;E:\IBM\java_1.7_64\jre\lib\ibmsaslfw.jar;E:\IBM\java_1.7_64\jre\lib\ibmjcefw.jar;E:\IBM\java_1.7_64\jre\lib\ibmjgssprovider.jar;E:\IBM\java_1.7_64\jre\lib\ibmjsseprovider2.jar;E:\IBM\java_1.7_64\jre\lib\ibmcertpathprovider.jar;E:\IBM\java_1.7_64\jre\lib\xmldsigfw.jar;E:\IBM\java_1.7_64\jre\lib\xml.jar;E:\IBM\java_1.7_64\jre\lib\charsets.jar;E:\IBM\java_1.7_64\jre\lib\resources.jar;E:\IBM\java_1.7_64\jre\lib\rt.jar`
          + Classpath: `E:\Jenkins\slave.jar`
          + Library path: `E:\IBM\java_1.7_64\jre\bin\compressedrefs;E:\IBM\java_1.7_64\jre\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\IBM\java_1.7_64\bin;E:\AccuRev\601\bin;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\ManagementStudio\;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\PrivateAssemblies\;C:\Program Files (x86)\Microsoft SQL Server\110\DTS\Binn\;E:\IBM\java_1.7_64\bin;.`
          + arg[0]: `-Xoptionsfile=E:\IBM\java_1.7_64\jre\bin\compressedrefs\options.default`
          + arg[1]: `-Xlockword:mode=default,noLockword=java/lang/String,noLockword=java/util/MapEntry,noLockword=java/util/HashMap$Entry,noLockword=org/apache/harmony/luni/util/ModifiedMap$Entry,noLockword=java/util/Hashtable$Entry,noLockword=java/lang/invoke/MethodType,noLockword=java/lang/invoke/MethodHandle,noLockword=java/lang/invoke/CollectHandle,noLockword=java/lang/invoke/ConstructorHandle,noLockword=java/lang/invoke/ConvertHandle,noLockword=java/lang/invoke/ArgumentConversionHandle,noLockword=java/lang/invoke/AsTypeHandle,noLockword=java/lang/invoke/ExplicitCastHandle,noLockword=java/lang/invoke/FilterReturnHandle,noLockword=java/lang/invoke/DirectHandle,noLockword=java/lang/invoke/ReceiverBoundHandle,noLockword=java/lang/invoke/DynamicInvokerHandle,noLockword=java/lang/invoke/FieldHandle,noLockword=java/lang/invoke/FieldGetterHandle,noLockword=java/lang/invoke/FieldSetterHandle,noLockword=java/lang/invoke/StaticFieldGetterHandle,noLockword=java/lang/invoke/StaticFieldSetterHandle,noLockword=java/lang/invoke/IndirectHandle,noLockword=java/lang/invoke/InterfaceHandle,noLockword=java/lang/invoke/VirtualHandle,noLockword=java/lang/invoke/InvokeExactHandle,noLockword=java/lang/invoke/InvokeGenericHandle,noLockword=java/lang/invoke/VarargsCollectorHandle,noLockword=java/lang/invoke/ThunkTuple`
          + arg[2]: `-Xjcl:jclse7b_26`
          + arg[3]: `-Dcom.ibm.oti.vm.bootstrap.library.path=E:\IBM\java_1.7_64\jre\bin\compressedrefs;E:\IBM\java_1.7_64\jre\bin`
          + arg[4]: `-Dsun.boot.library.path=E:\IBM\java_1.7_64\jre\bin\compressedrefs;E:\IBM\java_1.7_64\jre\bin`
          + arg[5]: `-Djava.library.path=E:\IBM\java_1.7_64\jre\bin\compressedrefs;E:\IBM\java_1.7_64\jre\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\IBM\java_1.7_64\bin;E:\AccuRev\601\bin;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\ManagementStudio\;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\PrivateAssemblies\;C:\Program Files (x86)\Microsoft SQL Server\110\DTS\Binn\;E:\IBM\java_1.7_64\bin;.`
          + arg[6]: `-Djava.home=E:\IBM\java_1.7_64\jre`
          + arg[7]: `-Djava.ext.dirs=E:\IBM\java_1.7_64\jre\lib\ext`
          + arg[8]: `-Duser.dir=E:\Jenkins`
          + arg[9]: `-Djava.runtime.version=pwa6470sr4fp1ifx-20130423_02 (SR4 FP1+IV38579+IV38399+IV40208)`
          + arg[10]: `-Djava.class.path=.`
          + arg[11]: `-Xrs`
          + arg[12]: `-Djava.io.tmpdir=E:\TEMP`
          + arg[13]: `-Djava.class.path=E:\Jenkins\slave.jar`
          + arg[14]: `-Dsun.java.command=E:\Jenkins\slave.jar -jnlpUrl http://tstjenk001.aoins.com:8080/jenkins/computer/dotNET-005/slave-agent.jnlp -secret f2f33c81994fef7d1ad4e4ae51ec699eaee5a0f513e2b28494856a112bb11663`
          + arg[15]: `-Dsun.java.launcher=SUN_STANDARD`

  * WebSphere-101 (Dumb Slave)
      - Description:    `WIA Deploy Server`
      - Executors:      2
      - Remote FS root: `E:\Jenkins`
      - Labels:         WebSphere
      - Usage:          Utilize this slave as much as possible
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.33
      - Java
          + Home:           `E:\IBM\WAS85\java_1.7_64\jre`
          + Vendor:           IBM Corporation
          + Version:          1.7.0
          + Maximum memory:   512.00 MB (536870912)
          + Allocated memory: 20.38 MB (21364736)
          + Free memory:      7.15 MB (7494776)
          + In-use memory:    13.23 MB (13869960)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    IBM J9 VM
          + Vendor:  IBM Corporation
          + Version: 2.6
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 3656 (0xe48)
      - Process started: 2014-03-19 12:42:14.137-0400
      - Process uptime: 13 days
      - JVM startup parameters:
          + Boot classpath: `E:\IBM\WAS85\java_1.7_64\jre\bin\compressedrefs\jclSC170\vm.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\se-service.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\math.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\jlm.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmorb.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmorbapi.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmcfw.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmpkcs.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmcertpathfw.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmjgssfw.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmjssefw.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmsaslfw.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmjcefw.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmjgssprovider.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmjsseprovider2.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\ibmcertpathprovider.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\xmldsigfw.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\xml.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\charsets.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\resources.jar;E:\IBM\WAS85\java_1.7_64\jre\lib\rt.jar`
          + Classpath: `E:\Jenkins\slave.jar`
          + Library path: `E:\IBM\WAS85\java_1.7_64\jre\bin\compressedrefs;E:\IBM\WAS85\java_1.7_64\jre\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\IBM\WAS85\java_1.7_64\bin;E:\AccuRev\601\bin;.`
          + arg[0]: `-Xoptionsfile=E:\IBM\WAS85\java_1.7_64\jre\bin\compressedrefs\options.default`
          + arg[1]: `-Xlockword:mode=default,noLockword=java/lang/String,noLockword=java/util/MapEntry,noLockword=java/util/HashMap$Entry,noLockword=org/apache/harmony/luni/util/ModifiedMap$Entry,noLockword=java/util/Hashtable$Entry,noLockword=java/lang/invoke/MethodType,noLockword=java/lang/invoke/MethodHandle,noLockword=java/lang/invoke/CollectHandle,noLockword=java/lang/invoke/ConstructorHandle,noLockword=java/lang/invoke/ConvertHandle,noLockword=java/lang/invoke/ArgumentConversionHandle,noLockword=java/lang/invoke/AsTypeHandle,noLockword=java/lang/invoke/ExplicitCastHandle,noLockword=java/lang/invoke/FilterReturnHandle,noLockword=java/lang/invoke/DirectHandle,noLockword=java/lang/invoke/ReceiverBoundHandle,noLockword=java/lang/invoke/DynamicInvokerHandle,noLockword=java/lang/invoke/FieldHandle,noLockword=java/lang/invoke/FieldGetterHandle,noLockword=java/lang/invoke/FieldSetterHandle,noLockword=java/lang/invoke/StaticFieldGetterHandle,noLockword=java/lang/invoke/StaticFieldSetterHandle,noLockword=java/lang/invoke/IndirectHandle,noLockword=java/lang/invoke/InterfaceHandle,noLockword=java/lang/invoke/VirtualHandle,noLockword=java/lang/invoke/InvokeExactHandle,noLockword=java/lang/invoke/InvokeGenericHandle,noLockword=java/lang/invoke/VarargsCollectorHandle,noLockword=java/lang/invoke/ThunkTuple`
          + arg[2]: `-Xjcl:jclse7b_26`
          + arg[3]: `-Dcom.ibm.oti.vm.bootstrap.library.path=E:\IBM\WAS85\java_1.7_64\jre\bin\compressedrefs;E:\IBM\WAS85\java_1.7_64\jre\bin`
          + arg[4]: `-Dsun.boot.library.path=E:\IBM\WAS85\java_1.7_64\jre\bin\compressedrefs;E:\IBM\WAS85\java_1.7_64\jre\bin`
          + arg[5]: `-Djava.library.path=E:\IBM\WAS85\java_1.7_64\jre\bin\compressedrefs;E:\IBM\WAS85\java_1.7_64\jre\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\IBM\WAS85\java_1.7_64\bin;E:\AccuRev\601\bin;.`
          + arg[6]: `-Djava.home=E:\IBM\WAS85\java_1.7_64\jre`
          + arg[7]: `-Djava.ext.dirs=E:\IBM\WAS85\java_1.7_64\jre\lib\ext`
          + arg[8]: `-Duser.dir=E:\Jenkins`
          + arg[9]: `-Djava.runtime.version=pwa6470sr4fp1ifx-20130423_02 (SR4 FP1+IV38579+IV38399+IV40208)`
          + arg[10]: `-Djava.class.path=.`
          + arg[11]: `-Xrs`
          + arg[12]: `-Djava.io.tmpdir=E:\TEMP`
          + arg[13]: `-Djava.class.path=E:\Jenkins\slave.jar`
          + arg[14]: `-Dsun.java.command=E:\Jenkins\slave.jar -jnlpUrl http://tstjenk001.aoins.com:8080/jenkins/computer/WebSphere-101/slave-agent.jnlp -secret 26040bcbd863ada707b4b6db3f5dca483c36238fca498f215f01431adeac0c8a`
          + arg[15]: `-Dsun.java.launcher=SUN_STANDARD`

