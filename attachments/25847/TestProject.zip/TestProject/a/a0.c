#include "a0.h"

void totot(double value)
{
    (void)value;
}


void count(int value)
{
    void * a = (void* )value;
    a = 0;
}
