#ifndef A0_H
#define A0_H
#include <stdio.h>

void count(int value);

void totot(double value);

#endif
