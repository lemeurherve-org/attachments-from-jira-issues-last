#include "a0.h"
#include "a1.h"

void add(int two, int one)
{
    count(two);
    totot(one);
}
