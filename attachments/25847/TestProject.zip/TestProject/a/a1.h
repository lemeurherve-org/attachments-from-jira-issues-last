#ifndef A1_H
#define A1_H
#include <stdio.h>

void add(int two, int one);

#endif
