#include "c0.h"

void some_function()
{
    void* a = 0;
    a = 0;
}
