#ifndef C0_H
#define C0_H
#include <stdio.h>

void some_function();
#endif
