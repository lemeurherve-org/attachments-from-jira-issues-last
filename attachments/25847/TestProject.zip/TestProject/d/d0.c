#include <c/c0.h>


void a()
{
    some_function();
}
