package de.logiball.ci.testfailure.test;

import org.junit.Test;

public class TesterrorTest {

	@Test
	public void testFirst() {
		throw new RuntimeException("testFirst has unexpected error");
	}

	@Test
	public void testSecond() {
		throw new RuntimeException("testSecond has unexpected error");
	}

}
