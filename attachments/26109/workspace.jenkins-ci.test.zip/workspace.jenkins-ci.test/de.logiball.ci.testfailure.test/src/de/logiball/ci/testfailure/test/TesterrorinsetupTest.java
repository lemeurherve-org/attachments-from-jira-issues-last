package de.logiball.ci.testfailure.test;

import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

public class TesterrorinsetupTest {

	@BeforeClass
	public static void beforeClass() {
		throw new RuntimeException("beforeClass has unexpected error");
	}

	@Test
	public void testFirst() {
		assertTrue("dummy true", true);
	}

	@Test
	public void testSecond() {
		assertTrue("dummy true", true);
	}
}
