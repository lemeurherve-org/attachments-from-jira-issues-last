package de.logiball.ci.testfailure.test;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TestfailureTest {

	@Test
	public void testFirst() {
		assertTrue("dummy true", false);
	}

	@Test
	public void testSecond() {
		assertTrue("dummy true", false);
	}

}
