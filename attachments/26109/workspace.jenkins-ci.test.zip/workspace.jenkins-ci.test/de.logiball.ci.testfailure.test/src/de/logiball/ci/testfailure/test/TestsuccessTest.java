package de.logiball.ci.testfailure.test;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TestsuccessTest {

	@Test
	public void testFirstSuccess() {
		assertTrue("dummy true", true);
	}

	@Test
	public void testSecondSuccess() {
		assertTrue("dummy true", true);
	}

}
