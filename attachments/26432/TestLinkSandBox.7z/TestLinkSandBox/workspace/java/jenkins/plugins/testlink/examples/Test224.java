package jenkins.plugins.testlink.examples;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test224
{

	@Test
	public void test224() 
	{
		System.out.println("test224 Start");
		Assert.assertTrue( 2*2 == 4 );
		System.out.println("test224 Stop");
	}
	
}
