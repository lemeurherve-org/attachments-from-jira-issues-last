package jenkins.plugins.testlink.examples;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test225
{

	@Test
	public void test225() 
	{
		System.out.println("test225 Start");
		Assert.assertTrue( 2*2 == 5 );
		System.out.println("test225 Stop");
	}
	
}
