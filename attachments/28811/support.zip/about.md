Jenkins
=======

Version details
---------------

  * Version: `1.604`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-6-openjdk-amd64/jre`
      - Vendor:           Sun Microsystems Inc.
      - Version:          1.6.0_34
      - Maximum memory:   910.62 MB (954859520)
      - Allocated memory: 488.33 MB (512053248)
      - Free memory:      144.63 MB (151656184)
      - In-use memory:    343.70 MB (360397064)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.6
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.0
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Sun Microsystems Inc.
      - Version: 23.25-b01
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.2.0-4-amd64
      - Distribution: Debian GNU/Linux 7.8 (wheezy)
  * Process ID: 2425 (0x979)
  * Process started: 2015-03-16 13:35:22.638+0000
  * Process uptime: 9 days 14 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/netx.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/plugin.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64/server:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64:/usr/lib/jvm/java-6-openjdk-amd64/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Dhudson.matrix.MatrixConfiguration.useShortWorkspaceName=true`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`

Active Plugins
--------------

  * analysis-collector:1.43 'Static Analysis Collector Plug-in'
  * analysis-core:1.71 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * build-name-setter:1.3 'build-name-setter'
  * build-timeout:1.14.1 'Jenkins build timeout plugin'
  * copyartifact:1.35 'Copy Artifact Plugin'
  * credentials:1.22 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * ec2:1.26 'Amazon EC2 plugin'
  * email-ext:2.39 'Email Extension Plugin'
  * envinject:1.91.1 'Environment Injector Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.3.5 'Jenkins GIT plugin'
  * git-client:1.16.1 'Jenkins GIT client plugin'
  * git-parameter:0.4.0 'Git Parameter Plug-In'
  * github:1.11 'GitHub plugin'
  * github-api:1.63 'GitHub API Plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * junit:1.5 'JUnit Plugin'
  * locale:1.2 'Locale plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 'Matrix Project Plugin'
  * maven-plugin:2.8 *(update available)* 'Maven Integration plugin'
  * metrics:3.0.9 'Metrics Plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * s3:0.7 'Jenkins S3 publisher plugin'
  * scm-api:0.2 'SCM API Plugin'
  * scp:1.8 'Hudson SCP publisher plugin'
  * script-security:1.13 'Script Security Plugin'
  * ssh-agent:1.5 'SSH Agent Plugin'
  * ssh-credentials:1.10 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.5 'Jenkins Subversion Plug-in'
  * support-core:2.20 'Support Core Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * warnings:4.47 'Warnings Plug-in'
  * windows-slaves:1.0 'Windows Slaves Plugin'
