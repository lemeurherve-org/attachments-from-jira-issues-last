Item statistics
===============

  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 37
    - Number of builds per job: 12.72972972972973 [n=37, s=20.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 8
    - Number of builds per job: 82.5 [n=8, s=200.0]
    - Number of items per container: 4.625 [n=8, s=1.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 2
    - Number of builds per job: 28.5 [n=2, s=20.0]

Total job statistics
======================

  * Number of jobs: 47
  * Number of builds per job: 25.27659574468085 [n=47, s=70.0]
