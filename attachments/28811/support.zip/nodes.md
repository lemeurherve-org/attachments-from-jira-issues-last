Node statistics
===============

  * Total number of nodes
      - Sample size:        55310
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of nodes online
      - Sample size:        55310
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of executors
      - Sample size:        55310
      - Average (mean):     15.0
      - Average (median):   15.0
      - Standard deviation: 0.0
      - Minimum:            15
      - Maximum:            15
      - 95th percentile:    15.0
      - 99th percentile:    15.0
  * Total number of executors in use
      - Sample size:        55310
      - Average (mean):     0.10311284046692606
      - Average (median):   0.0
      - Standard deviation: 0.4864973662333659
      - Minimum:            0
      - Maximum:            4
      - 95th percentile:    1.0
      - 99th percentile:    3.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      5
      - FS root:        `/var/lib/jenkins`
      - Labels:         debian debian7 x64 master
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/lib/jvm/java-6-openjdk-amd64/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_34
          + Maximum memory:   910.62 MB (954859520)
          + Allocated memory: 488.33 MB (512053248)
          + Free memory:      142.04 MB (148938528)
          + In-use memory:    346.29 MB (363114720)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.2.0-4-amd64
          + Distribution: Debian GNU/Linux 7.8 (wheezy)
      - Process ID: 2425 (0x979)
      - Process started: 2015-03-16 13:35:22.638+0000
      - Process uptime: 9 days 14 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/netx.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/plugin.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64/server:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64:/usr/lib/jvm/java-6-openjdk-amd64/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Dhudson.matrix.MatrixConfiguration.useShortWorkspaceName=true`

  * win2k8r2hetz (`hudson.slaves.DumbSlave`)
      - Description:    _Win2k8 R2 node at Hetzner_
      - Executors:      4
      - Remote FS root: `c:\Jenkins`
      - Labels:         windows windows8 windows2008r2 x86 x64
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.32
      - Java
          + Home:           `C:\Program Files\Java\jre7`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   7.08 GB (7603748864)
          + Allocated memory: 391.00 MB (409993216)
          + Free memory:      370.19 MB (388172864)
          + In-use memory:    20.81 MB (21820352)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Windows Server 2012
          + Architecture: amd64
          + Version:      6.2
      - Process ID: 1848 (0x738)
      - Process started: 2015-03-04 02:53:30.376+0100
      - Process uptime: 22 days
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre7\lib\resources.jar;C:\Program Files\Java\jre7\lib\rt.jar;C:\Program Files\Java\jre7\lib\sunrsasign.jar;C:\Program Files\Java\jre7\lib\jsse.jar;C:\Program Files\Java\jre7\lib\jce.jar;C:\Program Files\Java\jre7\lib\charsets.jar;C:\Program Files\Java\jre7\lib\jfr.jar;C:\Program Files\Java\jre7\classes`
          + Classpath: `c:\Jenkins\.\slave.jar`
          + Library path: `C:\Program Files\Java\jre7\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;c:\Perl64\site\bin;c:\Perl64\bin;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;;.`
          + arg[0]: `-Xrs`

  * Fedora16-ppc64-Power7-osuosl-karman (`hudson.slaves.DumbSlave`)
      - Description:    _karman.pg.osuosl.org - POWER7 PPC64 node running Fedora 16. Launch with "sudo -u jenkins -i launchslave.sh" on karman_
      - Executors:      4
      - Remote FS root: `/home/jenkins`
      - Labels:         ppc64 ppc fedora fedora20 linux
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_65
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 61.00 MB (63963136)
          + Free memory:      6.10 MB (6394480)
          + In-use memory:    54.90 MB (57568656)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.65-b04
      - Operating system
          + Name:         Linux
          + Architecture: ppc64
          + Version:      3.14.5-200.fc20.ppc64p7
      - Process ID: 18591 (0x489f)
      - Process started: 2015-03-16 06:35:33.956-0700
      - Process uptime: 9 days 14 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65-2.5.1.2.fc20.ppc64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/ppc64:/usr/lib64:/lib64:/lib:/usr/lib`

  * FreeBSD-x86_64-clang (`hudson.slaves.DumbSlave`)
      - Description:    _FreeBSD 10.1 x86&#95;64 with clang, owned by Christoph Moench-Tegeder_
      - Executors:      2
      - Remote FS root: `/usr/local/jenkins`
      - Labels:         freebsd freebsd10 clang x86_64 x64 unix
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/usr/local/openjdk7/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_76
          + Maximum memory:   878.50 MB (921174016)
          + Allocated memory: 57.50 MB (60293120)
          + Free memory:      21.38 MB (22416192)
          + In-use memory:    36.12 MB (37876928)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.76-b04
      - Operating system
          + Name:         FreeBSD
          + Architecture: amd64
          + Version:      10.1-RELEASE-p8
      - Process ID: 836 (0x344)
      - Process started: 2015-03-20 11:17:46.627+0100
      - Process uptime: 5 days 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/openjdk7/jre/lib/resources.jar:/usr/local/openjdk7/jre/lib/rt.jar:/usr/local/openjdk7/jre/lib/sunrsasign.jar:/usr/local/openjdk7/jre/lib/jsse.jar:/usr/local/openjdk7/jre/lib/jce.jar:/usr/local/openjdk7/jre/lib/charsets.jar:/usr/local/openjdk7/jre/lib/jfr.jar:/usr/local/openjdk7/jre/classes`
          + Classpath: `/usr/local/jenkins/slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/lib:/usr/lib:/usr/local/lib`

