User
====

Authentication
--------------

  * Authenticated: true
  * Name: ringerc
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@40fb8f87: Username: hudson.security.HudsonPrivateSecurityRealm$Details@7f5d1f01; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@166c8: RemoteIpAddress: 58.7.95.34; SessionId: cch8dipljb5c1mr9oyp4qk0mj; Granted Authorities: authenticated`

