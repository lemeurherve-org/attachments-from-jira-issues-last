Jenkins
=======

Version details
---------------

  * Version: `1.596.2`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/opt/jdk/1.7.0_40/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_40
      - Maximum memory:   1.71 GB (1836056576)
      - Allocated memory: 753.50 MB (790102016)
      - Free memory:      167.70 MB (175850248)
      - In-use memory:    585.80 MB (614251768)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.0-b56
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-279.14.1.el6.x86_64
  * Process ID: 30959 (0x78ef)
  * Process started: 2015-03-30 14:22:00.631-0400
  * Process uptime: 1 day 1 hr
  * JVM startup parameters:
      - Boot classpath: `/opt/jdk/1.7.0_40/jre/lib/resources.jar:/opt/jdk/1.7.0_40/jre/lib/rt.jar:/opt/jdk/1.7.0_40/jre/lib/sunrsasign.jar:/opt/jdk/1.7.0_40/jre/lib/jsse.jar:/opt/jdk/1.7.0_40/jre/lib/jce.jar:/opt/jdk/1.7.0_40/jre/lib/charsets.jar:/opt/jdk/1.7.0_40/jre/lib/jfr.jar:/opt/jdk/1.7.0_40/jre/classes`
      - Classpath: `/opt/jenkins/current/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djavax.net.ssl.trustStore=/opt/jenkins/etc/cacerts`
      - arg[1]: `-Djavax.net.ssl.trustStorePassword=<confidential>`
      - arg[2]: `-XX:MaxPermSize=256m`

Important configuration
---------------

  * Security realm: `de.theit.jenkins.crowd.CrowdSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`

Active Plugins
--------------

  * analysis-core:1.54 *(update available)* 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.1 *(update available)* 'OWASP Markup Formatter Plugin'
  * artifactory:2.1.8 *(update available)* 'Jenkins Artifactory Plugin'
  * build-name-setter:1.3 'build-name-setter'
  * build-timeout:1.12.2 *(update available)* 'Jenkins build timeout plugin'
  * checkstyle:3.38 *(update available)* 'Checkstyle Plug-in'
  * clone-workspace-scm:0.6 'Jenkins Clone Workspace SCM Plug-in'
  * cobertura:1.9.3 *(update available)* 'Jenkins Cobertura Plugin'
  * copyartifact:1.28 *(update available)* 'Copy Artifact Plugin'
  * credentials:1.22 'Credentials Plugin'
  * crowd2:1.8 'Crowd 2 Integration'
  * cvs:2.11 *(update available)* 'Jenkins CVS Plug-in'
  * deploy:1.9 *(update available)* 'Deploy to container Plugin'
  * description-setter:1.8 *(update available)* 'Jenkins description setter plugin'
  * disk-usage:0.23 *(update available)* 'Jenkins disk-usage plugin'
  * email-ext:2.36 *(update available)* 'Jenkins Email Extension Plugin'
  * envinject:1.89 *(update available)* 'Environment Injector Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:1.4.0 *(update available)* 'Jenkins GIT plugin'
  * git-client:1.0.7 *(update available)* 'Jenkins GIT client plugin'
  * git-server:1.1 *(update available)* 'Git server plugin'
  * greenballs:1.13 *(update available)* 'Green Balls'
  * groovy:1.14 *(update available)* 'Hudson Groovy builder'
  * groovy-postbuild:1.8 *(update available)* 'Groovy Postbuild'
  * javadoc:1.1 *(update available)* 'Javadoc Plugin'
  * jira:1.38 *(update available)* 'Jenkins JIRA plugin'
  * job-poll-action-plugin:1.0 'Job Poll Action Plugin'
  * junit:1.2-beta-4 *(update available)* 'JUnit Plugin'
  * ldap:1.6 *(update available)* 'LDAP Plugin'
  * mailer:1.11 *(update available)* 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.1 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 'Matrix Project Plugin'
  * maven-plugin:2.7.1 *(update available)* 'Maven Integration plugin'
  * metrics:3.0.9 'Metrics Plugin'
  * msbuild:1.21 *(update available)* 'Jenkins MSBuild Plugin'
  * pam-auth:1.1 *(update available)* 'PAM Authentication plugin'
  * project-description-setter:1.1 'Project Description Setter'
  * promoted-builds:2.14 *(update available)* 'Jenkins promoted builds plugin'
  * repository-connector:0.8.2 *(update available)* 'Repository Connector'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.13 'Script Security Plugin'
  * scriptler:2.6.1 *(update available)* 'Scriptler'
  * seleniumhq:0.4 'Hudson Seleniumhq plugin'
  * ssh-credentials:1.10 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.5 'Jenkins Subversion Plug-in'
  * support-core:2.20 'Support Core Plugin'
  * thinBackup:1.7.4 'ThinBackup'
  * token-macro:1.9 *(update available)* 'Token Macro Plugin'
  * typhon:1.0.0-SNAPSHOT (private-09/10/2013 13:48-jenkins) 'Typhon'
  * vulcan:1.2.0-SNAPSHOT (private-10/09/2014 10:56-jenkins) 'Vulcan'
  * windows-slaves:1.0 'Windows Slaves Plugin'
  * ws-cleanup:0.19 *(update available)* 'Jenkins Workspace Cleanup Plugin'
