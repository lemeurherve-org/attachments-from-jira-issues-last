Browser
=======

  * Screen size: 1366x768
  * User Agent
      - Type:     Browser
      - Name:     Chrome
      - Family:   CHROME
      - Producer: Google Inc.
      - Version:  39.0.2171.95
      - Raw:      `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36`
  * Operating System
      - Name:     Linux
      - Family:   LINUX
      - Producer: 
      - Version:  

