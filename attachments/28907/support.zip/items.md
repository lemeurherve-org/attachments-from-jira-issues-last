Item statistics
===============

  * `hudson.maven.MavenModule`
    - Number of items: 28
    - Number of builds per job: 98.82142857142857 [n=28, s=2.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 10
    - Number of builds per job: 99.5 [n=10, s=2.0]
    - Number of items per container: 2.8 [n=10, s=2.0]

Total job statistics
======================

  * Number of jobs: 38
  * Number of builds per job: 99.0 [n=38, s=2.0]
