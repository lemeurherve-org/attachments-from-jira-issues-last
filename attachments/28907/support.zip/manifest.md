Support Bundle Manifest
=======================

Generated on 2015-03-31 04:16:44 -0400

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/halcyon/checksums.md5`

      - `nodes/slave/scm2/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/halcyon/metrics.json`

      - `nodes/slave/scm2/metrics.json`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/halcyon/system.properties`

      - `nodes/slave/scm2/system.properties`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/halcyon/thread-dump.txt`

      - `nodes/slave/scm2/thread-dump.txt`

