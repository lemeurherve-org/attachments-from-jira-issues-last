Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      24
      - FS root:        `/var/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/opt/jdk/1.7.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_40
          + Maximum memory:   1.71 GB (1836056576)
          + Allocated memory: 753.50 MB (790102016)
          + Free memory:      158.09 MB (165767016)
          + In-use memory:    595.41 MB (624335000)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.0-b56
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-279.14.1.el6.x86_64
      - Process ID: 30959 (0x78ef)
      - Process started: 2015-03-30 14:22:00.631-0400
      - Process uptime: 1 day 1 hr
      - JVM startup parameters:
          + Boot classpath: `/opt/jdk/1.7.0_40/jre/lib/resources.jar:/opt/jdk/1.7.0_40/jre/lib/rt.jar:/opt/jdk/1.7.0_40/jre/lib/sunrsasign.jar:/opt/jdk/1.7.0_40/jre/lib/jsse.jar:/opt/jdk/1.7.0_40/jre/lib/jce.jar:/opt/jdk/1.7.0_40/jre/lib/charsets.jar:/opt/jdk/1.7.0_40/jre/lib/jfr.jar:/opt/jdk/1.7.0_40/jre/classes`
          + Classpath: `/opt/jenkins/current/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djavax.net.ssl.trustStore=/opt/jenkins/etc/cacerts`
          + arg[1]: `-Djavax.net.ssl.trustStorePassword=<confidential>`
          + arg[2]: `-XX:MaxPermSize=256m`

  * halcyon (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/var/jenkins`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * scm2 (`hudson.slaves.DumbSlave`)
      - Description:    _Exclusive for building Vulcan Services_
      - Executors:      1
      - Remote FS root: `/var/jenkins_slave`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

