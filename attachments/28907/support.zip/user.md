User
====

Authentication
--------------

  * Authenticated: true
  * Name: ngrobisa
  * Authorities 
      - `authenticated`
      - <confidential>
  * Raw: `de.theit.jenkins.crowd.CrowdAuthenticationToken@4c0c8af4: Username: de.theit.jenkins.crowd.CrowdUser@29a43fe6; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated, <confidential>...`

