Jenkins
=======

Version details
---------------

  * Version: `1.609.1`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-8-oracle/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_45
      - Maximum memory:   1.32 GB (1420820480)
      - Allocated memory: 707.00 MB (741343232)
      - Free memory:      391.80 MB (410830744)
      - In-use memory:    315.20 MB (330512488)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.45-b02
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.13.0-53-generic
      - Distribution: Ubuntu 14.04.2 LTS
  * Process ID: 10287 (0x282f)
  * Process started: 2015-05-30 06:59:28.044-0600
  * Process uptime: 1 hr 53 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Xmx1524m`
      - arg[2]: `-XX:MaxPermSize=768m`

Important configuration
---------------

  * Security realm: `hudson.security.PAMSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`

Active Plugins
--------------

  * analysis-core:1.71 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * bitbucket:1.1.0 'Jenkins Bitbucket Plugin'
  * blink1:1.1 'BLINK(1) Notifier'
  * build-name-setter:1.3 'build-name-setter'
  * build-timeout:1.14.1 'Jenkins build timeout plugin'
  * cloudbees-folder:4.8 'CloudBees Folders Plugin'
  * configurationslicing:1.40 'Configuration Slicing plugin'
  * credentials:1.22 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * depgraph-view:0.11 'Dependency Graph Viewer Plugin'
  * description-setter:1.10 'Jenkins description setter plugin'
  * elastic-axis:1.2 'elastic-axis'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * file-leak-detector:1.3 'CloudBees File Leak Detector Plugin'
  * findbugs:4.60 'FindBugs Plug-in'
  * git:2.3.6-SNAPSHOT (private-6c1c49fe-mwaite) 'Jenkins GIT plugin'
  * git-client:1.17.2-SNAPSHOT (private-cbea8e3e-mwaite) 'Jenkins GIT client plugin'
  * git-parameter:0.4.0 'Git Parameter Plug-In'
  * git-server:1.6 'Git server plugin'
  * git-userContent:1.4 '/userContent in Git plugin'
  * github:1.11.3 'GitHub plugin'
  * github-api:1.68 'GitHub API Plugin'
  * gravatar:2.1 'Jenkins Gravatar plugin'
  * hgca:1.4-SNAPSHOT (private-08/29/2014 18:52-mwaite) 'Hudson Generic Changelog Annotator Plugin'
  * htmlpublisher:1.4 'HTML Publisher plugin'
  * implied-labels:0.4 'Implied Labels Plugin'
  * jacoco:1.0.19 'Jenkins JaCoCo plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.6 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * log-parser:1.0.8 'Log Parser Plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 'Matrix Project Plugin'
  * maven-plugin:2.9 'Maven Integration plugin'
  * metrics:3.0.10 'Metrics Plugin'
  * multi-branch-project-plugin:0.2.2 'Multi-Branch Project Plugin'
  * multiple-scms:0.4 'Jenkins Multiple SCMs plugin'
  * nested-view:1.14 'Nested View Plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * pegdown-formatter:1.3 'PegDown Formatter Plugin'
  * platformlabeler:1.1 'Hudson platformlabeler plugin'
  * pollscm:1.2 'Jenkins Poll SCM plugin'
  * preSCMbuildstep:0.3 'Pre SCM BuildStep Plugin'
  * project-description-setter:1.1 'Project Description Setter'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.14 'Script Security Plugin'
  * sidebar-link:1.7 'Sidebar Link'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.5 'Jenkins Subversion Plug-in'
  * support-core:2.22 'Support Core Plugin'
  * swarm:1.24 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * token-macro:1.10 'Token Macro Plugin'
  * tool-labels-plugin:3.0 'Tool Labels Plugin for Jenkins'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * valgrind:0.25 'Jenkins Valgrind Plug-in'
  * view-job-filters:1.26 'View Job Filters'
  * warnings:4.47 'Warnings Plug-in'
  * windows-slaves:1.0 'Windows Slaves Plugin'
  * xshell:0.10 'Jenkins cross-platform shell plugin'
  * xunit:1.96 'xUnit plugin'
  * xvnc:1.21 'Jenkins Xvnc plugin'
