Current build queue has 10 item(s).
---------------
 * Name of item: git-fast-my-multi-master
    - In queue for: 59 min
    - Is blocked: true
    - Why in queue: Build #1 is already in progress (ETA:N/A)
    - Current queue trigger cause: Started by an SCM change

 * Name of item: JENKINS-20258-checkout-to-subdir-and-prune » tropicana
    - In queue for: 13 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on tropicana
    - Current queue trigger cause: Started by upstream project "JENKINS-20258-checkout-to-subdir-and-prune" build number 768

 * Name of item: JENKINS-20258-checkout-to-subdir-and-prune » debian6x86
    - In queue for: 13 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on debian6x86
    - Current queue trigger cause: Started by upstream project "JENKINS-20258-checkout-to-subdir-and-prune" build number 768

 * Name of item: git-client-my-multi-master » java-7,debian6x86
    - In queue for: 23 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on debian6x86
    - Current queue trigger cause: Started by upstream project "git-client-my-multi-master" build number 346

 * Name of item: git-client-my-multi-master » java-7,tropicana
    - In queue for: 23 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on tropicana
    - Current queue trigger cause: Started by upstream project "git-client-my-multi-master" build number 346

 * Name of item: git-client-my-multi-master » java-7,centos7x64
    - In queue for: 23 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on centos7x64
    - Current queue trigger cause: Started by upstream project "git-client-my-multi-master" build number 346

 * Name of item: JENKINS-22119-bitbucket-credentialed-clone-fails » centos7x64
    - In queue for: 26 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on centos7x64
    - Current queue trigger cause: Started by upstream project "JENKINS-22119-bitbucket-credentialed-clone-fails" build number 96

 * Name of item: JENKINS-22119-bitbucket-credentialed-clone-fails » tropicana
    - In queue for: 26 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on tropicana
    - Current queue trigger cause: Started by upstream project "JENKINS-22119-bitbucket-credentialed-clone-fails" build number 96

 * Name of item: JENKINS-26660-submodule-checkout-does-not-clean-deleted-submodules » centos7x64
    - In queue for: 34 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on centos7x64
    - Current queue trigger cause: Started by upstream project "JENKINS-26660-submodule-checkout-does-not-clean-deleted-submodules" build number 30

 * Name of item: JENKINS-26660-submodule-checkout-does-not-clean-deleted-submodules » tropicana
    - In queue for: 34 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on tropicana
    - Current queue trigger cause: Started by upstream project "JENKINS-26660-submodule-checkout-does-not-clean-deleted-submodules" build number 30

