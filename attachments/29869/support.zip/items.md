Item statistics
===============

  * `com.github.mjdetullio.jenkins.plugins.multibranch.FreeStyleMultiBranchProject`
    - Number of items: 3
    - Number of builds per job: 0.0 [n=3, s=0.0]
    - Number of items per container: 7.0 [n=3, s=3.0]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 629
    - Number of builds per job: 6.246422893481717 [n=629, s=4.6]
  * `hudson.matrix.MatrixProject`
    - Number of items: 45
    - Number of builds per job: 7.266666666666667 [n=45, s=5.0]
    - Number of items per container: 13.977777777777778 [n=45, s=8.0]
  * `hudson.maven.MavenModule`
    - Number of items: 1
    - Number of builds per job: 10 [n=1]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 1
    - Number of builds per job: 10 [n=1]
    - Number of items per container: 1 [n=1]
  * `hudson.model.FreeStyleProject`
    - Number of items: 117
    - Number of builds per job: 7.034188034188034 [n=117, s=4.9]

Total job statistics
======================

  * Number of jobs: 796
  * Number of builds per job: 6.405778894472362 [n=796, s=4.7]
