Node statistics
===============

  * Total number of nodes
      - Sample size:        455
      - Average (mean):     12.0
      - Average (median):   12.0
      - Standard deviation: 0.0
      - Minimum:            12
      - Maximum:            12
      - 95th percentile:    12.0
      - 99th percentile:    12.0
  * Total number of nodes online
      - Sample size:        455
      - Average (mean):     11.989010989010989
      - Average (median):   12.0
      - Standard deviation: 0.23440361546924787
      - Minimum:            7
      - Maximum:            12
      - 95th percentile:    12.0
      - 99th percentile:    12.0
  * Total number of executors
      - Sample size:        455
      - Average (mean):     29.984615384615385
      - Average (median):   30.0
      - Standard deviation: 0.48066654274398696
      - Minimum:            20
      - Maximum:            32
      - 95th percentile:    30.0
      - 99th percentile:    30.0
  * Total number of executors in use
      - Sample size:        455
      - Average (mean):     12.371428571428572
      - Average (median):   13.0
      - Standard deviation: 8.396326626455437
      - Minimum:            0
      - Maximum:            30
      - 95th percentile:    24.19999999999999
      - 99th percentile:    29.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      4
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   1.32 GB (1420820480)
          + Allocated memory: 707.00 MB (741343232)
          + Free memory:      374.37 MB (392557840)
          + In-use memory:    332.63 MB (348785392)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-53-generic
          + Distribution: Ubuntu 14.04.2 LTS
      - Process ID: 10287 (0x282f)
      - Process started: 2015-05-30 06:59:28.044-0600
      - Process uptime: 1 hr 53 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Xmx1524m`
          + arg[2]: `-XX:MaxPermSize=768m`

  * alan-pc (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 8_
      - Executors:      2
      - Remote FS root: `C:\J`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.43
      - Java
          + Home:           `C:\Program Files\Java\jdk1.8.0_05\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_05
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 173.00 MB (181403648)
          + Free memory:      75.85 MB (79539368)
          + In-use memory:    97.15 MB (101864280)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.5-b02
      - Operating system
          + Name:         Windows 8.1
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 3248 (0xcb0)
      - Process started: 2015-05-02 21:03:30.330-0600
      - Process uptime: 27 days
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jdk1.8.0_05\jre\lib\resources.jar;C:\Program Files\Java\jdk1.8.0_05\jre\lib\rt.jar;C:\Program Files\Java\jdk1.8.0_05\jre\lib\sunrsasign.jar;C:\Program Files\Java\jdk1.8.0_05\jre\lib\jsse.jar;C:\Program Files\Java\jdk1.8.0_05\jre\lib\jce.jar;C:\Program Files\Java\jdk1.8.0_05\jre\lib\charsets.jar;C:\Program Files\Java\jdk1.8.0_05\jre\lib\jfr.jar;C:\Program Files\Java\jdk1.8.0_05\jre\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\Program Files\Java\jdk1.8.0_05\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;tools;C:\Program Files\Java\jdk1.8.0_05\bin;C:\Python27;C:\Program Files (x86)\Microsoft Visual Studio 11.0\Common7\IDE\CommonExtensions\Microsoft\TestWindow;C:\Program Files (x86)\Microsoft SDKs\F#\3.0\Framework\v4.0\;C:\Program Files (x86)\Microsoft Visual Studio 11.0\VSTSDB\Deploy;C:\Program Files (x86)\Microsoft Visual Studio 11.0\Common7\IDE\;C:\Program Files (x86)\Microsoft Visual Studio 11.0\VC\BIN;C:\Program Files (x86)\Microsoft Visual Studio 11.0\Common7\Tools;C:\Windows\Microsoft.NET\Framework\v4.0.30319;C:\Windows\Microsoft.NET\Framework\v3.5;C:\Program Files (x86)\Microsoft Visual Studio 11.0\VC\VCPackages;C:\Program Files (x86)\HTML Help Workshop;C:\Program Files (x86)\Microsoft Visual Studio 11.0\Team Tools\Performance Tools;C:\Program Files (x86)\Windows Kits\8.0\bin\x86;C:\Program Files (x86)\Microsoft SDKs\Windows\v8.0A\bin\NETFX 4.0 Tools;C:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\Bin\;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;c:\Program Files (x86)\Microsoft SQL Server\100\Tools\Binn\;c:\Program Files\Microsoft SQL Server\100\Tools\Binn\;c:\Program Files\Microsoft SQL Server\100\DTS\Binn\;C:\Program Files (x86)\Windows Kits\8.0\Windows Performance Toolkit\;C:\Program Files\Java\jdk1.7.0_60\bin;C:\apache-ant-1.9.2\bin;C:\apache-maven-3.1.0\bin;C:\Python27;C:\Python27\scripts;C:\emacs-24.3\bin;C:\Program Files (x86)\Git\bin;C:\Program Files (x86)\Git\bin;.`

  * centos66 (`hudson.slaves.DumbSlave`)
      - Description:    _CentOS 6.6 (Red Hat 6.6)_
      - Executors:      2
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         git-1.7.1 6.6 CentOS CentOS-6.6 i386 i386-CentOS i386-CentOS-6.6
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.50
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_79
          + Maximum memory:   487.25 MB (510918656)
          + Allocated memory: 15.25 MB (15990784)
          + Free memory:      2.68 MB (2806288)
          + In-use memory:    12.57 MB (13184496)
          + PermGen used:     11.34 MB (11889760)
          + PermGen max:      64.00 MB (67108864)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK Client VM
          + Vendor:  Oracle Corporation
          + Version: 24.79-b02
      - Operating system
          + Name:         Linux
          + Architecture: i386
          + Version:      2.6.32-504.12.2.el6.i686
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-ia32:base-4.0-noarch:core-4.0-ia32:core-4.0-noarch:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 32299 (0x7e2b)
      - Process started: 2015-05-30 06:59:39.920-0600
      - Process uptime: 1 hr 0 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.79/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/i386:/lib:/usr/lib`

  * centos7x64 (`hudson.slaves.DumbSlave`)
      - Description:    _CentOS 7 x64_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.50
      - Java
          + Home:           `/usr/java/jdk1.8.0_45/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   830.50 MB (870842368)
          + Allocated memory: 47.00 MB (49283072)
          + Free memory:      23.48 MB (24621440)
          + In-use memory:    23.52 MB (24661632)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.4.2.el7.x86_64
          + Distribution: "CentOS Linux release 7.1.1503 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 29408 (0x72e0)
      - Process started: 2015-05-30 06:59:37.875-0600
      - Process uptime: 1 hr 53 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_45/jre/lib/resources.jar:/usr/java/jdk1.8.0_45/jre/lib/rt.jar:/usr/java/jdk1.8.0_45/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_45/jre/lib/jsse.jar:/usr/java/jdk1.8.0_45/jre/lib/jce.jar:/usr/java/jdk1.8.0_45/jre/lib/charsets.jar:/usr/java/jdk1.8.0_45/jre/lib/jfr.jar:/usr/java/jdk1.8.0_45/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * debian6x86 (`hudson.slaves.DumbSlave`)
      - Description:    _Debian Squeeze i386_
      - Executors:      2
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         Ubuntu x86 git-1.7.1
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.50
      - Java
          + Home:           `/usr/lib/jvm/java-7-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_80
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 15.50 MB (16252928)
          + Free memory:      4.65 MB (4875744)
          + In-use memory:    10.85 MB (11377184)
          + PermGen used:     13.28 MB (13927344)
          + PermGen max:      64.00 MB (67108864)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 24.80-b11
      - Operating system
          + Name:         Linux
          + Architecture: i386
          + Version:      2.6.32-5-686
          + Distribution: Debian GNU/Linux 6.0.10 (squeeze)
      - Process ID: 9670 (0x25c6)
      - Process started: 2015-05-30 06:59:37.486-0600
      - Process uptime: 1 hr 0 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-7-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-7-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-7-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-7-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/i386:/lib:/usr/lib`

  * debian8 (`hudson.slaves.DumbSlave`)
      - Description:    _Debian 8 (Testing)_
      - Executors:      6
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.50
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   1.71 GB (1836580864)
          + Allocated memory: 108.50 MB (113770496)
          + Free memory:      45.15 MB (47339104)
          + In-use memory:    63.35 MB (66431392)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-4-amd64
          + Distribution: Debian GNU/Linux 8.0 (jessie)
      - Process ID: 14342 (0x3806)
      - Process started: 2015-05-30 06:59:37.394-0600
      - Process uptime: 1 hr 53 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.io.tmpdir=/home/jenkins/tmp/`

  * family-win7-a (`hudson.slaves.DumbSlave`)
      - Description:    _Alan's Windows 7 Computer_
      - Executors:      2
      - Remote FS root: `C:\E\J1`
      - Labels:         visual-studio-2010
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.43
      - Java
          + Home:           `C:\E\Program Files\Java\jre1.8.0_40`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 51.25 MB (53739520)
          + Free memory:      22.66 MB (23759112)
          + In-use memory:    28.59 MB (29980408)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Windows 7
          + Architecture: x86
          + Version:      6.1
      - Process ID: 3560 (0xde8)
      - Process started: 2015-05-30 02:07:54.039-0600
      - Process uptime: 6 hr 45 min
      - JVM startup parameters:
          + Boot classpath: `C:\E\Program Files\Java\jre1.8.0_40\lib\resources.jar;C:\E\Program Files\Java\jre1.8.0_40\lib\rt.jar;C:\E\Program Files\Java\jre1.8.0_40\lib\sunrsasign.jar;C:\E\Program Files\Java\jre1.8.0_40\lib\jsse.jar;C:\E\Program Files\Java\jre1.8.0_40\lib\jce.jar;C:\E\Program Files\Java\jre1.8.0_40\lib\charsets.jar;C:\E\Program Files\Java\jre1.8.0_40\lib\jfr.jar;C:\E\Program Files\Java\jre1.8.0_40\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\ProgramData\Oracle\Java\javapath;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;tools;C:\Program Files\Microsoft Visual Studio 10.0\VSTSDB\Deploy;C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\;c:\Program Files\Microsoft Visual Studio 10.0\VC\BIN;C:\Program Files\Microsoft Visual Studio 10.0\Common7\Tools;C:\Windows\Microsoft.NET\Framework\v4.0.30319;C:\Windows\Microsoft.NET\Framework\v3.5;c:\Program Files\Microsoft Visual Studio 10.0\VC\VCPackages;C:\Program Files\HTML Help Workshop;C:\Program Files\Microsoft Visual Studio 10.0\Team Tools\Performance Tools;C:\Program Files\Microsoft SDKs\Windows\v7.0A\bin\NETFX 4.0 Tools;C:\Program Files\Microsoft SDKs\Windows\v7.0A\bin;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Python27;C:\Python27\Scripts;C:\E\emacs-24.1\bin;C:\E\Program Files\Java\jdk1.8.0_40\bin;C:\E\apache-ant-1.8.4\bin;C:\Program Files\Microsoft SQL Server\100\Tools\Binn\;C:\Program Files\Microsoft SQL Server\100\DTS\Binn\;C:\Program Files\Common Files\HP\Digital Imaging\bin;C:\Program Files\HP\Digital Imaging\bin\Qt\Qt 4.3.3;C:\E\apache-maven-3.1.1\bin;C:\E\Program Files\Git\cmd;C:\E\Program Files\Git\bin;C:\E\Program Files\Git\bin;.`

  * jessie64a (`hudson.slaves.DumbSlave`)
      - Description:    _Debian Jessie (Testing)_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.50
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   615.50 MB (645398528)
          + Allocated memory: 77.50 MB (81264640)
          + Free memory:      55.66 MB (58366760)
          + In-use memory:    21.84 MB (22897880)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-4-amd64
          + Distribution: Debian GNU/Linux 8.0 (jessie)
      - Process ID: 22438 (0x57a6)
      - Process started: 2015-05-30 06:59:37.273-0600
      - Process uptime: 1 hr 0 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * markwaite (`hudson.slaves.DumbSlave`)
      - Description:    _Debian Wheezy i386_
      - Executors:      2
      - Remote FS root: `/home/mwaite/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.50
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   245.56 MB (257490944)
          + Allocated memory: 15.95 MB (16728064)
          + Free memory:      4.14 MB (4344624)
          + In-use memory:    11.81 MB (12383440)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: i386
          + Version:      3.2.0-4-686-pae
          + Distribution: Debian GNU/Linux 7.8 (wheezy)
      - Process ID: 6446 (0x192e)
      - Process started: 2015-05-30 06:59:38.180-0600
      - Process uptime: 1 hr 0 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/i386:/lib:/usr/lib`

  * tropicana (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 7_
      - Executors:      2
      - Remote FS root: `D:\J`
      - Labels:         visual-studio-2010
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `D:\Program Files\Java\jdk1.8.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   853.50 MB (894959616)
          + Allocated memory: 239.50 MB (251133952)
          + Free memory:      192.79 MB (202154024)
          + In-use memory:    46.71 MB (48979928)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Windows 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 2220 (0x8ac)
      - Process started: 2015-05-30 06:59:51.898-0600
      - Process uptime: 1 hr 53 min
      - JVM startup parameters:
          + Boot classpath: `D:\Program Files\Java\jdk1.8.0_40\jre\lib\resources.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\rt.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\sunrsasign.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\jsse.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\jce.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\charsets.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\jfr.jar;D:\Program Files\Java\jdk1.8.0_40\jre\classes`
          + Classpath: `D:\J\slave.jar`
          + Library path: `D:\Program Files\Java\jdk1.8.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\ProgramData\Oracle\Java\javapath;%JAVA_HOME%\bin;D:\Python27\;D:\Python27\Scripts;D:\Python27;C:\Program Files (x86)\AMD APP\bin\x86_64;C:\Program Files (x86)\AMD APP\bin\x86;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\ATI Technologies\ATI.ACE\Core-Static;C:\Program Files (x86)\Windows Kits\8.0\Windows Performance Toolkit\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft\Web Platform Installer\;C:\Program Files (x86)\Microsoft ASP.NET\ASP.NET Web Pages\v1.0\;C:\Program Files\Microsoft Windows Performance Toolkit\;D:\Program Files (x86)\QuickTime\QTSystem\;;.`
          + arg[0]: `-Xrs`

  * waite2011 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows Home Server 2011_
      - Executors:      2
      - Remote FS root: `J:\Jenkins`
      - Labels:         visual-studio-2010
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `D:\Program Files\Java\jdk1.8.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   907.00 MB (951058432)
          + Allocated memory: 155.00 MB (162529280)
          + Free memory:      114.33 MB (119886192)
          + In-use memory:    40.67 MB (42643088)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 4316 (0x10dc)
      - Process started: 2015-05-29 17:19:23.692-0600
      - Process uptime: 15 hr
      - JVM startup parameters:
          + Boot classpath: `D:\Program Files\Java\jdk1.8.0_40\jre\lib\resources.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\rt.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\sunrsasign.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\jsse.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\jce.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\charsets.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\jfr.jar;D:\Program Files\Java\jdk1.8.0_40\jre\classes`
          + Classpath: `bin\slave.jar`
          + Library path: `D:\Program Files\Java\jdk1.8.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;tools;J:\Jenkins\bin;D:\Program Files\Java\jdk1.8.0_40\bin;C:\Program Files (x86)\Microsoft Visual Studio 10.0\VSTSDB\Deploy;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\;C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\BIN;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\Tools;C:\Windows\Microsoft.NET\Framework\v4.0.30319;C:\Windows\Microsoft.NET\Framework\v3.5;C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\VCPackages;C:\Program Files (x86)\HTML Help Workshop;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Team Tools\Performance Tools;c:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\bin\NETFX 4.0 Tools;c:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\bin;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\Microsoft SQL Server\100\Tools\Binn\;C:\Program Files\Microsoft SQL Server\100\Tools\Binn\;C:\Program Files\Microsoft SQL Server\100\DTS\Binn\;D:\Python27;D:\Python27\Scripts;D:\Program Files (x86)\NUnit 2.6.2\bin;D:\apache-maven-3.1.1\bin;D:\Program Files\Java\jdk1.8.0_40\bin;D:\emacs-24.1\bin;D:\Program Files (x86)\Git\bin;D:\apache-ant-1.8.4\bin;.`

  * wheezy64b (`hudson.slaves.DumbSlave`)
      - Description:    _Debian Wheezy x64_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.50
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   448.00 MB (469762048)
          + Allocated memory: 84.00 MB (88080384)
          + Free memory:      55.68 MB (58382504)
          + In-use memory:    28.32 MB (29697880)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.2.0-4-amd64
          + Distribution: Debian GNU/Linux 7.8 (wheezy)
      - Process ID: 4736 (0x1280)
      - Process started: 2015-05-30 06:59:37.642-0600
      - Process uptime: 1 hr 53 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

