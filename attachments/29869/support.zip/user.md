User
====

Authentication
--------------

  * Authenticated: true
  * Name: mwaite
  * Authorities 
      - `plugdev`
      - `mwaite`
      - `dip`
      - `adm`
      - `sudo`
      - `sambashare`
      - `cdrom`
      - `lpadmin`
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@b166f37e: Username: org.acegisecurity.userdetails.User@0: Username: mwaite; Password: [PROTECTED]; Enabled: true; AccountNonExpired: true; credentialsNonExpired: true; AccountNonLocked: true; Granted Authorities: plugdev, mwaite, dip, adm, sudo, sambashare, cdrom, lpadmin, authenticated; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@7798: RemoteIpAddress: 172.16.16.108; SessionId: null; Granted Authorities: plugdev, mwaite, dip, adm, sudo, sambashare, cdrom, lpadmin, authenticated`

