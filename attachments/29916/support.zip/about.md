Jenkins
=======

Version details
---------------

  * Version: `1.616`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-8-oracle/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_45
      - Maximum memory:   864.00 MB (905969664)
      - Allocated memory: 407.00 MB (426770432)
      - Free memory:      202.58 MB (212416168)
      - In-use memory:    204.42 MB (214354264)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.45-b02
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.13.0-53-generic
      - Distribution: Ubuntu 14.04.2 LTS
  * Process ID: 1421 (0x58d)
  * Process started: 2015-06-07 11:30:13.261+0200
  * Process uptime: 1 min 24 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`

Active Plugins
--------------

  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * associated-files:0.2.1 'Associated Files Plugin'
  * config-file-provider:2.8.1 'Config File Provider Plugin'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * credentials:1.22 'Credentials Plugin'
  * credentials-binding:1.4 'Credentials Binding Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.4 'Dashboard View'
  * durable-task:1.5 'Durable Task Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.3.5 'Jenkins GIT plugin'
  * git-client:1.17.1 'Jenkins GIT client plugin'
  * git-server:1.6 'Git server plugin'
  * gradle:1.24 'Jenkins Gradle plugin'
  * groovy:1.25 'Hudson Groovy builder'
  * groovy-postbuild:2.2 'Groovy Postbuild'
  * groovy-remote:0.2 'Groovy Remote Control Plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * job-node-stalker:1.0.3 'Job Node Stalker'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.6 'JUnit Plugin'
  * junit-attachments:1.3 'JUnit Attachments Plugin'
  * ldap:1.11 'LDAP Plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 'Matrix Project Plugin'
  * maven-plugin:2.9 'Maven Integration plugin'
  * metadata:1.1.0b 'Metadata plugin'
  * metrics:3.0.11 'Metrics Plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * parallel-test-executor:1.7 'Jenkins Parallel Test Executor Plugin'
  * parameterized-trigger:2.26 'Jenkins Parameterized Trigger plugin'
  * plain-credentials:1.1 'Plain Credentials Plugin'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.14 'Script Security Plugin'
  * scriptler:2.7 'Scriptler'
  * semantic-versioning-plugin:1.7 'Semantic Versioning Plugin'
  * slave-setup:1.8 'Jenkins Slave SetupPlugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.5 'Jenkins Subversion Plug-in'
  * support-core:2.24 'Support Core Plugin'
  * swarm:1.24 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * windows-slaves:1.0 'Windows Slaves Plugin'
  * workflow-aggregator:1.8 'Workflow: Aggregator'
  * workflow-api:1.8 'Workflow: API'
  * workflow-basic-steps:1.8 'Workflow: Basic Steps'
  * workflow-cps:1.8 'Workflow: Groovy CPS Execution'
  * workflow-cps-global-lib:1.8 'Workflow: Global Shared Library for CPS workflow'
  * workflow-durable-task-step:1.8 'Workflow: Durable Task Step'
  * workflow-job:1.8 'Workflow: Job'
  * workflow-scm-step:1.8 'Workflow: SCM Step'
  * workflow-step-api:1.8 'Workflow: Step API'
  * workflow-support:1.8 'Workflow: Execution Support'
