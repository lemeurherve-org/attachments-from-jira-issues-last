Browser
=======

  * Screen size: 1920x1200
  * User Agent
      - Type:     Browser
      - Name:     Firefox
      - Family:   FIREFOX
      - Producer: Mozilla Foundation
      - Version:  38.0
      - Raw:      `Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:38.0) Gecko/20100101 Firefox/38.0`
  * Operating System
      - Name:     Linux (Ubuntu)
      - Family:   LINUX
      - Producer: Canonical Ltd.
      - Version:  

