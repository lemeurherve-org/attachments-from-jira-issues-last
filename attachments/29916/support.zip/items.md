Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 15
    - Number of builds per job: 132.8 [n=15, s=300.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 12
    - Number of builds per job: 13.333333333333334 [n=12, s=10.0]

Total job statistics
======================

  * Number of jobs: 27
  * Number of builds per job: 79.70370370370371 [n=27, s=200.0]
