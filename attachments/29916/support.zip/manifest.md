Support Bundle Manifest
=======================

Generated on 2015-06-07 11:31:37.096+0200

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-06-07_09.30.01.log`

      - `nodes/master/logs/all_2015-06-07_09.30.18.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `nodes/slave/allezhop/jenkins.log`

      - `nodes/slave/allezhop/logs/all_memory_buffer.log`

      - `nodes/slave/testnode/jenkins.log`

      - `nodes/slave/testnode/logs/all_memory_buffer.log`

      - `nodes/slave/vestibule.fritz.box-192.168.178.33/launchLogs/slave.log`

      - `nodes/slave/vestibule.fritz.box-192.168.178.33/launchLogs/slave.log.1`

      - `nodes/slave/vestibule.fritz.box/launchLogs/slave.log`

      - `nodes/slave/vestibule.fritz.box/launchLogs/slave.log.1`

      - `nodes/slave/vestibule.fritz.box/launchLogs/slave.log.2`

      - `nodes/slave/vestibule.fritz.box/launchLogs/slave.log.3`

      - `nodes/slave/vestibule.fritz.box/launchLogs/slave.log.4`

      - `nodes/slave/vestibule.fritz.box/launchLogs/slave.log.5`

      - `nodes/slave/vestibule/launchLogs/slave.log`

      - `nodes/slave/vestibule/launchLogs/slave.log.1`

      - `nodes/slave/vestibule/launchLogs/slave.log.2`

      - `nodes/slave/vestibule/launchLogs/slave.log.3`

      - `nodes/slave/vestibule/launchLogs/slave.log.4`

      - `nodes/slave/vestibule/launchLogs/slave.log.5`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Out of order build detection.log`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/allezhop/checksums.md5`

      - `nodes/slave/testnode/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Administrative monitors

  * Build queue

      - `buildqueue.md`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/allezhop/environment.txt`

      - `nodes/slave/testnode/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/allezhop/gnuplot`

      - `load-stats/label/allezhop/hour.csv`

      - `load-stats/label/allezhop/min.csv`

      - `load-stats/label/allezhop/sec10.csv`

      - `load-stats/label/linux/gnuplot`

      - `load-stats/label/linux/hour.csv`

      - `load-stats/label/linux/min.csv`

      - `load-stats/label/linux/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/remote/gnuplot`

      - `load-stats/label/remote/hour.csv`

      - `load-stats/label/remote/min.csv`

      - `load-stats/label/remote/sec10.csv`

      - `load-stats/label/slave/gnuplot`

      - `load-stats/label/slave/hour.csv`

      - `load-stats/label/slave/min.csv`

      - `load-stats/label/slave/sec10.csv`

      - `load-stats/label/testnode/gnuplot`

      - `load-stats/label/testnode/hour.csv`

      - `load-stats/label/testnode/min.csv`

      - `load-stats/label/testnode/sec10.csv`

      - `load-stats/label/wan/gnuplot`

      - `load-stats/label/wan/hour.csv`

      - `load-stats/label/wan/min.csv`

      - `load-stats/label/wan/sec10.csv`

      - `load-stats/label/x86/gnuplot`

      - `load-stats/label/x86/hour.csv`

      - `load-stats/label/x86/min.csv`

      - `load-stats/label/x86/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/allezhop/metrics.json`

      - `nodes/slave/testnode/metrics.json`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/allezhop/system.properties`

      - `nodes/slave/testnode/system.properties`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/allezhop/thread-dump.txt`

      - `nodes/slave/testnode/thread-dump.txt`

