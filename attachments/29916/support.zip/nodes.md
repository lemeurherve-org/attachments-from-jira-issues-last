Node statistics
===============

  * Total number of nodes
      - Sample size:        5
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 0.0
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of nodes online
      - Sample size:        5
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        5
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        5
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/lib/jenkins`
      - Labels:         linux
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   864.00 MB (905969664)
          + Allocated memory: 407.00 MB (426770432)
          + Free memory:      200.71 MB (210458656)
          + In-use memory:    206.29 MB (216311776)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-53-generic
          + Distribution: Ubuntu 14.04.2 LTS
      - Process ID: 1421 (0x58d)
      - Process started: 2015-06-07 11:30:13.261+0200
      - Process uptime: 1 min 24 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`

  * allezhop (`hudson.slaves.DumbSlave`)
      - Description:    _Test slave_
      - Executors:      4
      - Remote FS root: `/var/lib/jenkins-slave`
      - Labels:         slave remote linux x86 wan
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * testnode (`hudson.slaves.DumbSlave`)
      - Description:    _Test slave_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins-slave`
      - Labels:         remote linux x86 wan
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

