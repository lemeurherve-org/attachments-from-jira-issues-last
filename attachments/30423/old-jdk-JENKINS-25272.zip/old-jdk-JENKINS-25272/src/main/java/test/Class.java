package test;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.util.Properties;
public class Class implements Driver{
    public Connection connect(String url, Properties info) throws SQLException {return null;}
    public boolean acceptsURL(String url) throws SQLException {return false;}
    public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) throws SQLException {return null;}
    public int getMajorVersion() {return 0;}
    public int getMinorVersion() {return 0;}
    public boolean jdbcCompliant() {return false;}
}
