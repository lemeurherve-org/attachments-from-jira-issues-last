Jenkins
=======

Version details
---------------

  * Version: `1.617`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_75
      - Maximum memory:   1.51 GB (1625817088)
      - Allocated memory: 511.00 MB (535822336)
      - Free memory:      340.88 MB (357437240)
      - In-use memory:    170.12 MB (178385096)
      - PermGen used:     77.55 MB (81319840)
      - PermGen max:      166.00 MB (174063616)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.75-b04
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.16.0-30-generic
      - Distribution: Ubuntu 14.10
  * Process ID: 1584 (0x630)
  * Process started: 2015-09-03 15:47:56.024+0200
  * Process uptime: 5 hr 21 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`

Active Plugins
--------------

  * active-directory:1.41 'Jenkins Active Directory plugin'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.1 *(update available)* 'OWASP Markup Formatter Plugin'
  * azure-slave-plugin:0.3.2 'Azure Slave Plugin'
  * bitbucket-oauth:0.4 'Bitbucket OAuth Plugin'
  * build-flow-plugin:0.18 'CloudBees Build Flow plugin'
  * build-name-setter:1.3 'build-name-setter'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * cppcheck:1.20 *(update available)* 'Jenkins Cppcheck Plug-in'
  * credentials:1.22 'Credentials Plugin'
  * credentials-binding:1.4 *(update available)* 'Credentials Binding Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * durable-task:1.5 *(update available)* 'Durable Task Plugin'
  * envinject:1.91.3 *(update available)* 'Environment Injector Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.4.0 'Jenkins GIT plugin'
  * git-client:1.18.0 *(update available)* 'Jenkins GIT client plugin'
  * git-parameter:0.4.0 'Git Parameter Plug-In'
  * greenballs:1.14 'Green Balls'
  * groovy-postbuild:2.2 *(update available)* 'Groovy Postbuild'
  * http_request:1.8.8 'HTTP Request Plugin'
  * javadoc:1.1 *(update available)* 'Javadoc Plugin'
  * jenkins-jira-issue-updater:1.12 *(update available)* 'Jenkins Jira Issue Updater'
  * jira:1.41 *(update available)* 'Jenkins JIRA plugin'
  * jobConfigHistory:2.11 *(update available)* 'Jenkins Job Configuration History Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * junit:1.7 *(update available)* 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * log-parser:1.0.8 'Log Parser Plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * mask-passwords:2.7.3 *(update available)* 'Mask Passwords Plugin'
  * matrix-auth:1.1 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:2.7.1 *(update available)* 'Maven Integration plugin'
  * metrics:3.0.11 'Metrics Plugin'
  * nodelabelparameter:1.5.1 'Node and Label parameter plugin'
  * pam-auth:1.1 *(update available)* 'PAM Authentication plugin'
  * Parameterized-Remote-Trigger:2.1.3 *(update available)* 'Parameterized Remote Trigger Plugin'
  * parameterized-trigger:2.26 *(update available)* 'Jenkins Parameterized Trigger plugin'
  * plain-credentials:1.1 'Plain Credentials Plugin'
  * postbuildscript:0.17 'Jenkins Post-Build Script Plug-in'
  * publish-over-cifs:0.3 'Publish Over CIFS'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.13 *(update available)* 'Script Security Plugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.9 *(update available)* 'Jenkins SSH Slaves plugin'
  * subversion:2.5 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.27 'Support Core Plugin'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.10 *(update available)* 'Jenkins Translation Assistance plugin'
  * violations:0.7.11 'Jenkins Violations plugin'
  * windows-slaves:1.0 *(update available)* 'Windows Slaves Plugin'
  * workflow-durable-task-step:1.8 *(update available)* 'Workflow: Durable Task Step'
  * workflow-step-api:1.8 *(update available)* 'Workflow: Step API'
  * ws-cleanup:0.26 *(update available)* 'Jenkins Workspace Cleanup Plugin'
