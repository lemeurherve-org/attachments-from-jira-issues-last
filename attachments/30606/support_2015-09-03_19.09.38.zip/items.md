Item statistics
===============

  * `com.cloudbees.plugins.flow.BuildFlow`
    - Number of items: 1
    - Number of builds per job: 141 [n=1]
  * `hudson.model.FreeStyleProject`
    - Number of items: 10
    - Number of builds per job: 95.7 [n=10, s=70.0]

Total job statistics
======================

  * Number of jobs: 11
  * Number of builds per job: 99.81818181818181 [n=11, s=70.0]
