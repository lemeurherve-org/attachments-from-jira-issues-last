Support Bundle Manifest
=======================

Generated on 2015-09-03 21:09:38.740+0200

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/Azure-Build-Test/checksums.md5`

      - `nodes/slave/Azure0903035539/checksums.md5`

      - `nodes/slave/vmtest1/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/Azure-Build-Test/environment.txt`

      - `nodes/slave/Azure0903035539/environment.txt`

      - `nodes/slave/vmtest1/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/Azure-Build-Test/networkInterface.md`

      - `nodes/slave/Azure0903035539/networkInterface.md`

      - `nodes/slave/vmtest1/networkInterface.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/Azure-Build-Test/system.properties`

      - `nodes/slave/Azure0903035539/system.properties`

      - `nodes/slave/vmtest1/system.properties`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/Azure-Build-Test/thread-dump.txt`

      - `nodes/slave/Azure0903035539/thread-dump.txt`

      - `nodes/slave/vmtest1/thread-dump.txt`

