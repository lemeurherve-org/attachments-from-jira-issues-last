Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_75
          + Maximum memory:   1.51 GB (1625817088)
          + Allocated memory: 511.00 MB (535822336)
          + Free memory:      333.21 MB (349401208)
          + In-use memory:    177.79 MB (186421128)
          + PermGen used:     77.60 MB (81372576)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.75-b04
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-30-generic
          + Distribution: Ubuntu 14.10
      - Process ID: 1584 (0x630)
      - Process started: 2015-09-03 15:47:56.024+0200
      - Process uptime: 5 hr 21 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`

  * Azure-Build-Test (`hudson.slaves.DumbSlave`)
      - Description:    _Azure machine used for build testings_
      - Executors:      1
      - Remote FS root: `C:\Build`
      - Labels:         debug
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * Azure0903035539 (`com.microsoftopentechnologies.azure.AzureSlave`)
      - Description:    _Build Server for our products_
      - Executors:      1
      - Remote FS root: `D:\Build`
      - Labels:         xx-windows
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `com.microsoftopentechnologies.azure.AzureCloudRetensionStrategy`
      - Status:         off-line

  * vmtest1 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `C:\build`
      - Labels:         local
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        (timeout with no cache available)

