Jenkins
=======

Version details
---------------

  * Version: `1.621`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_85
      - Maximum memory:   11.92 GB (12802064384)
      - Allocated memory: 11.92 GB (12802064384)
      - Free memory:      1.99 GB (2137369528)
      - In-use memory:    9.93 GB (10664694856)
      - PermGen used:     168.07 MB (176230784)
      - PermGen max:      256.00 MB (268435456)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.85-b03
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-573.3.1.el6.x86_64
  * Process ID: 9190 (0x23e6)
  * Process started: 2015-09-18 10:28:03.473-0400
  * Process uptime: 2 days 5 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-XX:MaxPermSize=256m`
      - arg[3]: `-Xms12288m`
      - arg[4]: `-Xmx12288m`
      - arg[5]: `-Dhttp.proxyHost=proxy-rtp-1.cisco.com`
      - arg[6]: `-Dhttp.proxyPort=80`
      - arg[7]: `-Dhttps.proxyHost=proxy-rtp-1.cisco.com`
      - arg[8]: `-Dhttps.proxyPort=80`
      - arg[9]: `-Dhttp.nonProxyHosts=*.cisco.com|localhost`
      - arg[10]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`

Active Plugins
--------------

  * active-directory:1.41 'Jenkins Active Directory plugin'
  * analysis-core:1.72 *(update available)* 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * artifactory:2.3.1 'Jenkins Artifactory Plugin'
  * async-http-client:1.7.8 'Async Http Client'
  * brakeman:0.7 'Brakeman Plugin'
  * build-flow-extensions-plugin:0.1.1 'Build Flow Extensions'
  * build-flow-plugin:0.18 'CloudBees Build Flow plugin'
  * build-keeper-plugin:1.3 'Build Keeper Plugin'
  * build-pipeline-plugin:1.4.7 *(update available)* 'Build Pipeline Plugin'
  * build-timeout:1.15 'Jenkins build timeout plugin'
  * build-view-column:0.2 'Build View Column Plugin'
  * buildgraph-view:1.1.1 'buildgraph-view'
  * claim:2.7 'Jenkins Claim Plugin'
  * clearcase:1.6 'Jenkins ClearCase Plug-in'
  * cloudbees-consolidated-build-view:1.3 'CloudBees Consolidated Build View Plugin'
  * cloudbees-folder:4.9 *(update available)* 'CloudBees Folders Plugin'
  * cloudbees-wasted-minutes-tracker:3.7 'CloudBees Wasted Minutes Tracker Plugin'
  * cobertura:1.9.7 'Jenkins Cobertura Plugin'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * copyartifact:1.35.2 *(update available)* 'Copy Artifact Plugin'
  * coverity:1.5.2 'Coverity plugin'
  * credentials:1.22 *(update available)* 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.6 'Dashboard View'
  * disk-usage:0.25 *(update available)* 'Jenkins disk-usage plugin'
  * doclinks:0.6 'Jenkins DocLinks plugin'
  * durable-task:1.6 'Durable Task Plugin'
  * email-ext:2.40.5 'Email Extension Plugin'
  * envinject:1.91.4 *(update available)* 'Environment Injector Plugin'
  * extended-read-permission:1.0 'Hudson Extended Read Permission Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * externalresource-dispatcher:1.1.0 'External Resource Dispatcher plugin'
  * fail-the-build-plugin:1.0 'Fail The Build Plugin'
  * findbugs:4.61 *(update available)* 'FindBugs Plug-in'
  * flexible-publish:0.15.2 'Flexible Publish Plugin'
  * fstrigger:0.39 'Jenkins Filesystem Trigger Plug-in'
  * ghprb:1.26.2 *(update available)* 'GitHub Pull Request Builder'
  * git:2.4.0 'Jenkins GIT plugin'
  * git-client:1.18.0 *(update available)* 'Jenkins GIT client plugin'
  * git-server:1.6 'Git server plugin'
  * github:1.12.1 *(update available)* 'GitHub plugin'
  * github-api:1.69 'GitHub API Plugin'
  * gitlab-hook:1.4.0 'Gitlab Hook Plugin'
  * gitlab-merge-request-jenkins:1.2.2 'Gitlab Merge Request Builder'
  * gitlab-plugin:1.1.25 *(update available)* 'GitLab Plugin'
  * greenballs:1.14 'Green Balls'
  * jacoco:1.0.19 'Jenkins JaCoCo plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jenkins-multijob-plugin:1.16 *(update available)* 'Jenkins Multijob plugin'
  * jobConfigHistory:2.12 'Jenkins Job Configuration History Plugin'
  * jobcopy-builder:1.3.0 'Jobcopy Builder plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * junit:1.8 *(update available)* 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * lockable-resources:1.7 'Lockable Resources plugin'
  * locks-and-latches:0.6 'Hudson Locks and Latches plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * mask-passwords:2.7.4 'Mask Passwords Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * maven-plugin:2.11 *(update available)* 'Maven Integration plugin'
  * mercurial:1.54 'Jenkins Mercurial plugin'
  * metadata:1.1.0b 'Metadata plugin'
  * metrics:3.0.11 'Metrics Plugin'
  * monitoring:1.56.0 *(update available)* 'Monitoring'
  * multi-branch-project-plugin:0.2.4 *(update available)* 'Multi-Branch Project Plugin'
  * multiple-scms:0.5 'Jenkins Multiple SCMs plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * nodelabelparameter:1.5.1 'Node and Label parameter plugin'
  * openid4java:0.9.8.0 'OpenID4Java API'
  * pam-auth:1.2 'PAM Authentication plugin'
  * parameterized-trigger:2.28 *(update available)* 'Jenkins Parameterized Trigger plugin'
  * plain-credentials:1.1 'Plain Credentials Plugin'
  * promoted-builds:2.21 *(update available)* 'Jenkins promoted builds plugin'
  * rake:1.8.0 'Jenkins Rake plugin'
  * robot:1.6.1 'Robot Framework plugin'
  * role-strategy:2.2.0 'Role-based Authorization Strategy'
  * ruby:1.2 'Hudson Ruby Plugin'
  * ruby-runtime:0.12 'ruby-runtime'
  * rubyMetrics:1.6.3 'RubyMetrics plugin for Jenkins'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.14 *(update available)* 'Script Security Plugin'
  * shelve-project-plugin:1.5 'Shelve Project Plugin'
  * ssh-agent:1.8 'SSH Agent Plugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.10 'Jenkins SSH Slaves plugin'
  * stash-pullrequest-builder:1.3.1 'Stash Pullrequest Builder Plugin'
  * stashNotifier:1.8 'Stash Notifier'
  * subversion:2.5.1 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.27 'Support Core Plugin'
  * suppress-stack-trace:1.4 'Stack Trace Suppression Plugin'
  * swarm:1.22 *(update available)* 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * thinBackup:1.7.4 'ThinBackup'
  * throttle-concurrents:1.8.4 'Jenkins Throttle Concurrent Builds Plug-in'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * unique-id:2.1.0 'Unique ID Library Plugin'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.48 *(update available)* 'Warnings Plug-in'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:1.9 *(update available)* 'Workflow: Aggregator'
  * workflow-api:1.9 *(update available)* 'Workflow: API'
  * workflow-basic-steps:1.9 *(update available)* 'Workflow: Basic Steps'
  * workflow-cps:1.9 *(update available)* 'Workflow: Groovy CPS Execution'
  * workflow-cps-global-lib:1.9 *(update available)* 'Workflow: Global Shared Library for CPS workflow'
  * workflow-durable-task-step:1.9 *(update available)* 'Workflow: Durable Task Step'
  * workflow-job:1.9 *(update available)* 'Workflow: Job'
  * workflow-scm-step:1.9 *(update available)* 'Workflow: SCM Step'
  * workflow-step-api:1.9 *(update available)* 'Workflow: Step API'
  * workflow-support:1.9 *(update available)* 'Workflow: Execution Support'
  * ws-cleanup:0.26 *(update available)* 'Jenkins Workspace Cleanup Plugin'
