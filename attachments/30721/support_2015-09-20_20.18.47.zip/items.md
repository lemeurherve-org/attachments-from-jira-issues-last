Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 33
    - Number of items per container: 10.121212121212121 [n=33, s=10.0]
  * `com.tikal.jenkins.plugins.multijob.MultiJobProject`
    - Number of items: 13
    - Number of builds per job: 47.92307692307692 [n=13, s=40.0]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 40
    - Number of builds per job: 4.7 [n=40, s=6.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 2
    - Number of builds per job: 28.5 [n=2, s=30.0]
    - Number of items per container: 20.0 [n=2, s=8.0]
  * `hudson.maven.MavenModule`
    - Number of items: 19
    - Number of builds per job: 7.894736842105263 [n=19, s=9.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 6
    - Number of builds per job: 13.333333333333334 [n=6, s=20.0]
    - Number of items per container: 3.1666666666666665 [n=6, s=3.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 295
    - Number of builds per job: 33.32203389830509 [n=295, s=65.0]

Total job statistics
======================

  * Number of jobs: 375
  * Number of builds per job: 29.141333333333332 [n=375, s=59.0]
