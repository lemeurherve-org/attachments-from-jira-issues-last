Node statistics
===============

  * Total number of nodes
      - Sample size:        12921
      - Average (mean):     20.0
      - Average (median):   20.0
      - Standard deviation: 0.0
      - Minimum:            20
      - Maximum:            20
      - 95th percentile:    20.0
      - 99th percentile:    20.0
  * Total number of nodes online
      - Sample size:        12921
      - Average (mean):     20.0
      - Average (median):   20.0
      - Standard deviation: 0.0
      - Minimum:            20
      - Maximum:            20
      - 95th percentile:    20.0
      - 99th percentile:    20.0
  * Total number of executors
      - Sample size:        12921
      - Average (mean):     76.0
      - Average (median):   76.0
      - Standard deviation: 0.0
      - Minimum:            76
      - Maximum:            76
      - 95th percentile:    76.0
      - 99th percentile:    76.0
  * Total number of executors in use
      - Sample size:        12921
      - Average (mean):     1.0252918287937742
      - Average (median):   1.0
      - Standard deviation: 0.15708646101134555
      - Minimum:            1
      - Maximum:            2
      - 95th percentile:    1.0
      - 99th percentile:    2.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_85
          + Maximum memory:   11.92 GB (12802064384)
          + Allocated memory: 11.92 GB (12802064384)
          + Free memory:      1.98 GB (2123687352)
          + In-use memory:    9.95 GB (10678377032)
          + PermGen used:     168.07 MB (176230784)
          + PermGen max:      256.00 MB (268435456)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.85-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.3.1.el6.x86_64
      - Process ID: 9190 (0x23e6)
      - Process started: 2015-09-18 10:28:03.473-0400
      - Process uptime: 2 days 5 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-XX:MaxPermSize=256m`
          + arg[3]: `-Xms12288m`
          + arg[4]: `-Xmx12288m`
          + arg[5]: `-Dhttp.proxyHost=proxy-rtp-1.cisco.com`
          + arg[6]: `-Dhttp.proxyPort=80`
          + arg[7]: `-Dhttps.proxyHost=proxy-rtp-1.cisco.com`
          + arg[8]: `-Dhttps.proxyPort=80`
          + arg[9]: `-Dhttp.nonProxyHosts=*.cisco.com|localhost`
          + arg[10]: `-DJENKINS_HOME=/var/lib/jenkins`

  * alecarls-dev.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.83.4 : null_
      - Executors:      2
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux x86_64 centos trustvisibility
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/java/jdk1.7.0_25/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   1.71 GB (1836187648)
          + Allocated memory: 87.31 MB (91553792)
          + Free memory:      63.98 MB (67085328)
          + In-use memory:    23.33 MB (24468464)
          + PermGen used:     30.83 MB (32322552)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.29.2.el6.x86_64
          + Distribution: "CentOS release 6.5 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 13663 (0x355f)
      - Process started: 2015-09-11 15:08:03.248-0400
      - Process uptime: 9 days 1 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.7.0_25/jre/lib/resources.jar:/usr/java/jdk1.7.0_25/jre/lib/rt.jar:/usr/java/jdk1.7.0_25/jre/lib/sunrsasign.jar:/usr/java/jdk1.7.0_25/jre/lib/jsse.jar:/usr/java/jdk1.7.0_25/jre/lib/jce.jar:/usr/java/jdk1.7.0_25/jre/lib/charsets.jar:/usr/java/jdk1.7.0_25/jre/lib/jfr.jar:/usr/java/jdk1.7.0_25/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * baddragon.cisco.com (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/Users/lab`
      - Labels:         darwin x86_64 ciscossl
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.52
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 58.50 MB (61341696)
          + Free memory:      37.27 MB (39079840)
          + In-use memory:    21.23 MB (22261856)
          + PermGen used:     13.45 MB (14106848)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86_64
          + Version:      10.9.5
      - Process ID: 60154 (0xeafa)
      - Process started: 2015-09-20 11:39:47.728-0400
      - Process uptime: 4 hr 38 min
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/Users/lab/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`

  * ciscossl-reg1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.59 : null_
      - Executors:      1
      - Remote FS root: `C:\Users\lab`
      - Labels:         swarm windows x64 windows
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `C:\Program Files\Java\jdk1.7.0_60\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_60
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 296.50 MB (310902784)
          + Free memory:      206.79 MB (216830896)
          + In-use memory:    89.71 MB (94071888)
          + PermGen used:     20.80 MB (21809536)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.60-b09
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 4480 (0x1180)
      - Process started: 2015-09-18 10:40:58.166-0400
      - Process uptime: 2 days 5 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jdk1.7.0_60\jre\lib\resources.jar;C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar;C:\Program Files\Java\jdk1.7.0_60\jre\lib\sunrsasign.jar;C:\Program Files\Java\jdk1.7.0_60\jre\lib\jsse.jar;C:\Program Files\Java\jdk1.7.0_60\jre\lib\jce.jar;C:\Program Files\Java\jdk1.7.0_60\jre\lib\charsets.jar;C:\Program Files\Java\jdk1.7.0_60\jre\lib\jfr.jar;C:\Program Files\Java\jdk1.7.0_60\jre\classes`
          + Classpath: `C:\Users\lab\swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `C:\Program Files\Java\jdk1.7.0_60\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\Git\cmd;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\Program Files (x86)\Microsoft SDKs\TypeScript\1.0\;C:\Program Files\Microsoft SQL Server\120\Tools\Binn\;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\Program Files (x86)\Puppet Labs\Puppet\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\Program Files\Java\jdk1.7.0_60\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;c:\JDK7\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\ProgramData\chocolatey\bin;C:\strawberry\c\bin;C:\strawberry\perl\site\bin;C:\strawberry\perl\bin;C:\ProgramData\chocolatey\bin;C:\Program Files (x86)\nasm;C:\Program Files (x86)\Java\j;C:\Program Files (x86)\Java\jdk1.7.0_76\bin;.`

  * corona-qa1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.222 : null_
      - Executors:      5
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-master
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_85
          + Maximum memory:   3.46 GB (3717201920)
          + Allocated memory: 239.00 MB (250609664)
          + Free memory:      203.17 MB (213034968)
          + In-use memory:    35.83 MB (37574696)
          + PermGen used:     41.26 MB (43261224)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.85-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
      - Process ID: 18098 (0x46b2)
      - Process started: 2015-09-11 16:46:08.323-0400
      - Process uptime: 8 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-reg1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.137 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-reg
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   4.34 GB (4658823168)
          + Allocated memory: 123.50 MB (129499136)
          + Free memory:      105.77 MB (110909448)
          + In-use memory:    17.73 MB (18589688)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
      - Process ID: 2228 (0x8b4)
      - Process started: 2015-09-16 21:02:04.210-0400
      - Process uptime: 3 days 19 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-reg2.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.170 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-reg
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   4.34 GB (4658823168)
          + Allocated memory: 117.00 MB (122683392)
          + Free memory:      79.23 MB (83078656)
          + In-use memory:    37.77 MB (39604736)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
      - Process ID: 18687 (0x48ff)
      - Process started: 2015-09-11 15:08:35.205-0400
      - Process uptime: 9 days 1 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-reg3.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.212 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-reg
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   4.34 GB (4658823168)
          + Allocated memory: 118.50 MB (124256256)
          + Free memory:      77.77 MB (81545040)
          + In-use memory:    40.73 MB (42711216)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
      - Process ID: 19761 (0x4d31)
      - Process started: 2015-09-11 15:09:17.347-0400
      - Process uptime: 9 days 1 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-reg4.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.213 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-reg
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   4.34 GB (4658823168)
          + Allocated memory: 126.50 MB (132644864)
          + Free memory:      77.06 MB (80801080)
          + In-use memory:    49.44 MB (51843784)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
      - Process ID: 10312 (0x2848)
      - Process started: 2015-09-11 15:18:53.079-0400
      - Process uptime: 9 days 0 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-reg5.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.111 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-reg
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   4.34 GB (4658823168)
          + Allocated memory: 116.50 MB (122159104)
          + Free memory:      63.23 MB (66303968)
          + In-use memory:    53.27 MB (55855136)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
      - Process ID: 28754 (0x7052)
      - Process started: 2015-09-11 15:26:33.611-0400
      - Process uptime: 9 days 0 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-reg6.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.109 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-reg
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   4.34 GB (4658823168)
          + Allocated memory: 122.00 MB (127926272)
          + Free memory:      76.30 MB (80009808)
          + In-use memory:    45.70 MB (47916464)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
      - Process ID: 2265 (0x8d9)
      - Process started: 2015-09-14 10:25:55.714-0400
      - Process uptime: 6 days 5 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-sandbox.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.219 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-sandbox
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   3.46 GB (3717201920)
          + Allocated memory: 196.50 MB (206045184)
          + Free memory:      174.94 MB (183442832)
          + In-use memory:    21.56 MB (22602352)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
      - Process ID: 32285 (0x7e1d)
      - Process started: 2015-09-11 16:47:35.208-0400
      - Process uptime: 8 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * do-corona.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.153.245 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-dt
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_45
          + Maximum memory:   3.46 GB (3717201920)
          + Allocated memory: 198.00 MB (207618048)
          + Free memory:      161.86 MB (169718952)
          + In-use memory:    36.14 MB (37899096)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.45-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.16.2.el6.x86_64
      - Process ID: 12544 (0x3100)
      - Process started: 2015-09-11 16:50:35.393-0400
      - Process uptime: 8 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.45-28.b13.el6_6.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * firedragon (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.154.215 : null_
      - Executors:      10
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux x86_64 centos ciscossl
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_85
          + Maximum memory:   6.99 GB (7506755584)
          + Allocated memory: 2.81 GB (3019374592)
          + Free memory:      874.67 MB (917160248)
          + In-use memory:    1.96 GB (2102214344)
          + PermGen used:     97.44 MB (102170552)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.85-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 25888 (0x6520)
      - Process started: 2015-09-11 15:17:51.900-0400
      - Process uptime: 9 days 1 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * freebird.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.82.91 : null_
      - Executors:      1
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux amd64 freebsd ciscossl
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/local/openjdk7/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   972.50 MB (1019740160)
          + Allocated memory: 60.88 MB (63832064)
          + Free memory:      32.90 MB (34500896)
          + In-use memory:    27.97 MB (29331168)
          + PermGen used:     33.02 MB (34618872)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.21-b01
      - Operating system
          + Name:         FreeBSD
          + Architecture: amd64
          + Version:      9.2-RELEASE-p15
      - Process ID: 1060 (0x424)
      - Process started: 2015-09-11 16:44:09.554-0400
      - Process uptime: 8 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/openjdk7/jre/lib/resources.jar:/usr/local/openjdk7/jre/lib/rt.jar:/usr/local/openjdk7/jre/lib/sunrsasign.jar:/usr/local/openjdk7/jre/lib/jsse.jar:/usr/local/openjdk7/jre/lib/jce.jar:/usr/local/openjdk7/jre/lib/charsets.jar:/usr/local/openjdk7/jre/lib/jfr.jar:/usr/local/openjdk7/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/lib:/usr/lib:/usr/local/lib`

  * jonatstr-onec.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.83.63 : null_
      - Executors:      9
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux x86_64 centos
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/java/jdk1.7.0_25/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   1.71 GB (1836187648)
          + Allocated memory: 98.62 MB (103415808)
          + Free memory:      34.38 MB (36053680)
          + In-use memory:    64.24 MB (67362128)
          + PermGen used:     41.41 MB (43420336)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.3.1.el6.x86_64
          + Distribution: "CentOS release 6.7 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 29631 (0x73bf)
      - Process started: 2015-09-18 10:50:16.351-0400
      - Process uptime: 2 days 5 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.7.0_25/jre/lib/resources.jar:/usr/java/jdk1.7.0_25/jre/lib/rt.jar:/usr/java/jdk1.7.0_25/jre/lib/sunrsasign.jar:/usr/java/jdk1.7.0_25/jre/lib/jsse.jar:/usr/java/jdk1.7.0_25/jre/lib/jce.jar:/usr/java/jdk1.7.0_25/jre/lib/charsets.jar:/usr/java/jdk1.7.0_25/jre/lib/jfr.jar:/usr/java/jdk1.7.0_25/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * mintdragon.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.154.105 : null_
      - Executors:      10
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux i386 centos ciscossl
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_85
          + Maximum memory:   910.25 MB (954466304)
          + Allocated memory: 58.00 MB (60817408)
          + Free memory:      8.30 MB (8706112)
          + In-use memory:    49.70 MB (52111296)
          + PermGen used:     29.99 MB (31444168)
          + PermGen max:      128.00 MB (134217728)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.85-b03
      - Operating system
          + Name:         Linux
          + Architecture: i386
          + Version:      2.6.32-504.8.1.el6.i686
          + Distribution: "CentOS release 6.7 (Final)"
          + LSB Modules:  `:base-4.0-ia32:base-4.0-noarch:core-4.0-ia32:core-4.0-noarch:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 26724 (0x6864)
      - Process started: 2015-09-11 15:08:03.043-0400
      - Process uptime: 9 days 1 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/local/lib:/usr/java/packages/lib/i386:/lib:/usr/lib`

  * rpidragon (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.29 : null_
      - Executors:      1
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux armv6l debian ciscossl
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/jdk-7-oracle-armhf/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_40
          + Maximum memory:   118.00 MB (123731968)
          + Allocated memory: 12.92 MB (13549568)
          + Free memory:      5.02 MB (5268656)
          + In-use memory:    7.90 MB (8280912)
          + PermGen used:     14.87 MB (15590136)
          + PermGen max:      64.00 MB (67108864)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 24.0-b56
      - Operating system
          + Name:         Linux
          + Architecture: arm
          + Version:      3.12.22+
          + Distribution: Debian GNU/Linux 7.5 (wheezy)
      - Process ID: 3927 (0xf57)
      - Process started: 2015-09-11 15:09:04.990-0400
      - Process uptime: 9 days 0 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/jdk-7-oracle-armhf/jre/lib/resources.jar:/usr/lib/jvm/jdk-7-oracle-armhf/jre/lib/rt.jar:/usr/lib/jvm/jdk-7-oracle-armhf/jre/lib/sunrsasign.jar:/usr/lib/jvm/jdk-7-oracle-armhf/jre/lib/jsse.jar:/usr/lib/jvm/jdk-7-oracle-armhf/jre/lib/jce.jar:/usr/lib/jvm/jdk-7-oracle-armhf/jre/lib/charsets.jar:/usr/lib/jvm/jdk-7-oracle-armhf/jre/lib/jfr.jar:/usr/lib/jvm/jdk-7-oracle-armhf/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/arm:/lib:/usr/lib`

  * sto-labsrv1 (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.183 : null_
      - Executors:      9
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux x86_64 redhat ciscossl-qa
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_85
          + Maximum memory:   3.49 GB (3748659200)
          + Allocated memory: 198.50 MB (208142336)
          + Free memory:      128.23 MB (134463496)
          + In-use memory:    70.27 MB (73678840)
          + PermGen used:     48.42 MB (50768976)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.85-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.1.1.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Workstation release 6.7 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 4381 (0x111d)
      - Process started: 2015-09-11 16:40:01.298-0400
      - Process uptime: 8 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * sto-labsrv2 (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.184 : null_
      - Executors:      9
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux x86_64 redhat ciscossl-qa
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_85
          + Maximum memory:   3.49 GB (3748659200)
          + Allocated memory: 198.50 MB (208142336)
          + Free memory:      133.06 MB (139522392)
          + In-use memory:    65.44 MB (68619944)
          + PermGen used:     47.97 MB (50302464)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.85-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.1.1.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Workstation release 6.7 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 3771 (0xebb)
      - Process started: 2015-09-11 16:41:28.921-0400
      - Process uptime: 8 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * trust-reg-1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.89 : null_
      - Executors:      10
      - Remote FS root: `/home/testuser`
      - Labels:         swarm linux x86_64 centos centos6 c3m-build
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/local/cisco/trust/java/jdk7/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_80
          + Maximum memory:   1.71 GB (1834483712)
          + Allocated memory: 105.50 MB (110624768)
          + Free memory:      56.19 MB (58916168)
          + In-use memory:    49.31 MB (51708600)
          + PermGen used:     42.06 MB (44104072)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.80-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.12.2.el6.x86_64
      - Process ID: 9018 (0x233a)
      - Process started: 2015-09-11 16:20:42.163-0400
      - Process uptime: 8 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/cisco/trust/java/jdk7/jre/lib/resources.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/rt.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/sunrsasign.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/jsse.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/jce.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/charsets.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/jfr.jar:/usr/local/cisco/trust/java/jdk7/jre/classes`
          + Classpath: `/home/testuser/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

