-----------
 * Name eth3
 ** Hardware Address - 0050569c4060
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:250:56ff:fe9c:4060%eth3
 ** InetAddress - /2001:420:27ff:fff6:250:56ff:fe9c:4060%eth3
 ** InetAddress - /172.18.151.212
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
