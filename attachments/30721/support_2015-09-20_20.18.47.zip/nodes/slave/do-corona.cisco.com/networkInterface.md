-----------
 * Name eth2
 ** Hardware Address - 005056877d76
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:250:56ff:fe87:7d76%eth2
 ** InetAddress - /2001:420:27ff:fff8:250:56ff:fe87:7d76%eth2
 ** InetAddress - /172.18.153.245
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
