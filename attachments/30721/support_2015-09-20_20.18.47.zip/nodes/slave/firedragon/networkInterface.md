-----------
 * Name eth0
 ** Hardware Address - bc16650b150c
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:be16:65ff:fe0b:150c%2
 ** InetAddress - /2001:420:27ff:fff9:be16:65ff:fe0b:150c%2
 ** InetAddress - /172.18.154.215
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%1
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
