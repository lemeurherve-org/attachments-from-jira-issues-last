-----------
 * Name lo0
 ** Index - 3
 ** InetAddress - /fe80:3:0:0:0:0:0:1
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** InetAddress - /127.0.0.1
 ** MTU - 16384
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name em0
 ** Hardware Address - 0050568b012b
 ** Index - 1
 ** InetAddress - /fe80:1:0:0:250:56ff:fe8b:12b
 ** InetAddress - /10.122.82.91
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
