-----------
 * Name vethd1c4d25
 ** Hardware Address - b6e751bd1601
 ** Index - 19
 ** InetAddress - /fe80:0:0:0:b4e7:51ff:febd:1601%19
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - b6e751bd1601
 ** Index - 5
 ** InetAddress - /fe80:0:0:0:c449:76ff:feea:663f%5
 ** InetAddress - /172.17.42.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth1
 ** Hardware Address - 005056873f36
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:250:56ff:fe87:3f36%3
 ** InetAddress - /10.0.1.111
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 0050568b020b
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:250:56ff:fe8b:20b%2
 ** InetAddress - /2001:420:27ff:fff4:250:56ff:fe8b:20b%2
 ** InetAddress - /10.122.83.63
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%1
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
