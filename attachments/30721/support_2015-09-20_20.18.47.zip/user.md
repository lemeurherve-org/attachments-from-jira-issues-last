User
====

Authentication
--------------

  * Authenticated: true
  * Name: jonatstr
  * Authorities 
      - `authenticated`
      - `ROLE_ENG`
      - `eng`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@e14721cf: Username: org.acegisecurity.userdetails.ldap.LdapUserDetailsImpl@d3646a; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@0: RemoteIpAddress: 10.82.246.102; SessionId: r3x8j332nce54mbjlbkkd2jv; Granted Authorities: authenticated, ROLE_ENG, eng`

