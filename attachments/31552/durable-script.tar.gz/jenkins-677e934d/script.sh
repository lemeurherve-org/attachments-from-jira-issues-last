#!/bin/sh -xe
/usr/local/jenkins/jobs/FreeBSD_HEAD_sparc64/workspace/freebsd-ci/scripts/build/build1.sh