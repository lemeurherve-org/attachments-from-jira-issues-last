Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 12
    - Number of items per container: 6.0 [n=12, s=10.0]
  * `hudson.maven.MavenModule`
    - Number of items: 373
    - Number of builds per job: 5.621983914209116 [n=373, s=13.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 76
    - Number of builds per job: 16.289473684210527 [n=76, s=30.0]
    - Number of items per container: 4.907894736842105 [n=76, s=10.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 23
    - Number of builds per job: 36.08695652173913 [n=23, s=90.0]

Total job statistics
======================

  * Number of jobs: 472
  * Number of builds per job: 8.82415254237288 [n=472, s=26.0]
