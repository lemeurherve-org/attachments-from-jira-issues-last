Support Bundle Manifest
=======================

Generated on 2016-02-02 16:56:59.052+0100

Requested components:

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Environment variables

      - `nodes/master/environment.txt`

  * System properties

      - `nodes/master/system.properties`

