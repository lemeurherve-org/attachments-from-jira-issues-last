Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      8
      - FS root:        `C:\Jenkins2`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  2.53.2
      - Java
          + Home:           `C:\tools\jdk1.7.0_51\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   5.21 GB (5592580096)
          + Allocated memory: 2.56 GB (2748317696)
          + Free memory:      831.24 MB (871621472)
          + In-use memory:    1.75 GB (1876696224)
          + PermGen used:     141.08 MB (147935528)
          + PermGen max:      512.00 MB (536870912)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 44228 (0xacc4)
      - Process started: 2016-02-01 17:37:28.414+0100
      - Process uptime: 23 hr
      - JVM startup parameters:
          + Boot classpath: `C:\tools\jdk1.7.0_51\jre\lib\resources.jar;C:\tools\jdk1.7.0_51\jre\lib\rt.jar;C:\tools\jdk1.7.0_51\jre\lib\sunrsasign.jar;C:\tools\jdk1.7.0_51\jre\lib\jsse.jar;C:\tools\jdk1.7.0_51\jre\lib\jce.jar;C:\tools\jdk1.7.0_51\jre\lib\charsets.jar;C:\tools\jdk1.7.0_51\jre\lib\jfr.jar;C:\tools\jdk1.7.0_51\jre\classes`
          + Classpath: `C:\tomcat\bin\bootstrap.jar;C:\tomcat\bin\tomcat-juli.jar`
          + Library path: `C:\tomcat\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\tools\svn;C:\Program Files\TortoiseSVN\bin;C:\tools\Graphviz 2.28\bin;C:\tools\zip;C:\tools\svn;C:\tools\unzip\bin;;.`
          + arg[0]: `-XX:PermSize=256M`
          + arg[1]: `-XX:MaxPermSize=512M`
          + arg[2]: `-DHUDSON_HOME=C:\hudson`
          + arg[3]: `exit`
          + arg[4]: `-Xms1000m`
          + arg[5]: `-Xmx6000m`

