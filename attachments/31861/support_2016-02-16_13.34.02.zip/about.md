Jenkins
=======

Version details
---------------

  * Version: `1.625.2`
  * Mode:    WAR
  * Url:     http://forge.mipih.net/ic/
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/ic/logiciels/jdk1.8.0_25/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_25
      - Maximum memory:   2,44 GB (2621440000)
      - Allocated memory: 2,44 GB (2621440000)
      - Free memory:      666,12 MB (698480352)
      - In-use memory:    1,79 GB (1922959648)
      - GC strategy:      G1
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.25-b02
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-431.17.1.el6.x86_64
      - Distribution: "Red Hat Enterprise Linux Server release 6.0 (Santiago)"
      - LSB Modules:  `:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
  * Process ID: 9826 (0x2662)
  * Process started: 2016-02-08 13:55:24.908+0100
  * Process uptime: 8 days 0 hr
  * JVM startup parameters:
      - Boot classpath: `/ic/logiciels/jdk1.8.0_25/jre/lib/resources.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/rt.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/sunrsasign.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/jsse.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/jce.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/charsets.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/jfr.jar:/ic/logiciels/jdk1.8.0_25/jre/classes`
      - Classpath: `/ic/scripts/../jenkins-1.625.2.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dhudson.TcpSlaveAgentListener.hostName=ic.mipih.net`
      - arg[1]: `-XX:+UseG1GC`
      - arg[2]: `-XX:+HeapDumpOnOutOfMemoryError`
      - arg[3]: `-XX:HeapDumpPath=/ic/jenkins-heapdump.hprof`
      - arg[4]: `-XX:OnError=t_alert_admin.sh "ERROR JVM sur le Jenkins de PROD --> A TRAITER EN URGENCE !"`
      - arg[5]: `-XX:OnOutOfMemoryError=t_alert_admin.sh "OOME sur le Jenkins de PROD --> A TRAITER EN URGENCE !"`
      - arg[6]: `-Dcom.sun.management.jmxremote.port=3334`
      - arg[7]: `-Dcom.sun.management.jmxremote.authenticate=false`
      - arg[8]: `-Dcom.sun.management.jmxremote.ssl=false`
      - arg[9]: `-Xmx2500m`
      - arg[10]: `-XX:+PrintGCTimeStamps`
      - arg[11]: `-Xloggc:/ic/.jenkins-gclog/gc.log`
      - arg[12]: `-XX:+PrintGCDetails`
      - arg[13]: `-Djava.io.tmpdir=/ic/tmp`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`

Active Plugins
--------------

  * ace-editor:1.0.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:1.41 'Jenkins Active Directory plugin'
  * ansicolor:0.4.2 'AnsiColor'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * audit-trail:2.2 'Audit Trail'
  * authentication-tokens:1.2 'Authentication Tokens API Plugin'
  * branch-api:1.1 'Branch API Plugin'
  * build-pipeline-plugin:1.4.9 'Build Pipeline Plugin'
  * build-timeout:1.16 'Jenkins build timeout plugin'
  * buildgraph-view:1.1.1 'buildgraph-view'
  * buildtriggerbadge:2.2 'Build Trigger Badge Plugin'
  * chucknorris:1.0 'ChuckNorris Plugin'
  * claim:2.8 'Jenkins Claim Plugin'
  * cloudbees-folder:5.1 'CloudBees Folders Plugin'
  * compact-columns:1.10 'Compact Columns'
  * computer-queue-plugin:1.4 'Computer-queue-plugin'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * config-file-provider:2.10.0 'Config File Provider Plugin'
  * configurationslicing:1.44 'Configuration Slicing plugin'
  * console-column-plugin:1.5 'Console Column Plugin'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * copyartifact:1.37 'Copy Artifact Plugin'
  * credentials:1.24 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.7 'Dashboard View'
  * docker-build-step:1.33 'docker-build-step'
  * docker-commons:1.3-SNAPSHOT-JENKINS-32792 *(update available)* 'Docker Commons Plugin'
  * docker-plugin:0.16.0 'Docker plugin'
  * docker-traceability:1.1 'CloudBees Docker Traceability'
  * docker-workflow:1.2 *(update available)* 'CloudBees Docker Workflow'
  * downstream-buildview:1.9 'Downstream build view'
  * durable-task:1.7 'Durable Task Plugin'
  * dynamicparameter:0.2.0 'Jenkins Dynamic Parameter Plug-in'
  * email-ext:2.40.5 *(update available)* 'Email Extension Plugin'
  * emma:1.29 'Jenkins Emma plugin'
  * emotional-hudson:1.3 'Emotional Hudson Plugin'
  * envinject:1.92.1 'Environment Injector Plugin'
  * export-natstar-pastel-comparator:1.0 'export-natstar-pastel-comparator'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * gerrit-trigger:2.18.3 'Gerrit Trigger'
  * git:2.4.2 'Jenkins Git plugin'
  * git-client:1.19.2 *(update available)* 'Jenkins Git client plugin'
  * git-server:1.6 'Git server plugin'
  * global-build-stats:1.3 'Hudson global-build-stats plugin'
  * gradle:1.24 'Jenkins Gradle plugin'
  * greenballs:1.15 'Green Balls'
  * groovy:1.29 'Groovy'
  * inodes-monitor:1.0-SNAPSHOT (private-5e18d8d6-tiste) 'Inodes Monitor Plugin'
  * jackson2-api:2.5.4 'Jackson 2 API Plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jenkins-flowdock-plugin:1.1.8 'Flowdock plugin'
  * job-dsl:1.42 *(update available)* 'Job DSL'
  * join:1.16 *(update available)* 'Join plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.10 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * ldapemail:0.8 'LDAP Email Plugin'
  * locale:1.2 'Locale plugin'
  * locks-and-latches:0.6 'Hudson Locks and Latches plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * mailer:1.16 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * marmotte-jenkins-plugin:10.1.0 'Marmotte :: Jenkins Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * matrixtieparent:1.2 'Matrix Tie Parent plugin'
  * maven-plugin:2.12.1 'Maven Integration plugin'
  * metrics:3.1.2.3 *(update available)* 'Metrics Plugin'
  * monitoring:1.58.0 'Monitoring'
  * msbuild:1.25 'Jenkins MSBuild Plugin'
  * mstest:0.19 'MSTest plugin'
  * mstestrunner:1.2.0 'Jenkins MSTestRunner plugin'
  * multiple-scms:0.5 'Jenkins Multiple SCMs plugin'
  * nested-view:1.14 'Nested View Plugin'
  * nodelabelparameter:1.7.1 'Node and Label parameter plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * parameterized-trigger:2.30 'Jenkins Parameterized Trigger plugin'
  * pipeline-utility-steps:1.0 *(update available)* 'Pipeline Utility Steps'
  * plot:1.9 'Plot plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * PrioritySorter:3.4 'Jenkins Priority Sorter Plugin'
  * publish-over-ssh:1.13 'Publish Over SSH'
  * radiatorviewplugin:1.25 'Radiator View Plugin'
  * rally-build-notifier:2.4 'rally-build-notifier'
  * random-string-parameter:1.0 'Random String Parameter Plugin'
  * rebuild:1.25 'Rebuilder'
  * release:2.5.4 'Jenkins Release Plugin'
  * role-strategy:2.2.0 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scis-ad:1.2 'Hudson Support Subscription Notification Plugin'
  * scm-api:1.0 'SCM API Plugin'
  * script-security:1.17 'Script Security Plugin'
  * scriptler:2.9 'Scriptler'
  * sonar:2.3 'Jenkins SonarQube Plugin'
  * ssh-agent:1.9 'SSH Agent Plugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.10 'Jenkins SSH Slaves plugin'
  * subversion:2.5.7 'Jenkins Subversion Plug-in'
  * support-core:2.30 *(update available)* 'Support Core Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * timestamper:1.7.4 'Timestamper'
  * token-macro:1.12.1 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * uno-choice:1.3 *(update available)* 'Active Choices Plug-in'
  * versioncolumn:0.2 'Jenkins Version Column plugin'
  * view-job-filters:1.27 'View Job Filters'
  * violations:0.7.11 'Jenkins Violations plugin'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:1.13 'Pipeline (formerly known as Workflow)'
  * workflow-api:1.13 'Pipeline: API'
  * workflow-basic-steps:1.13 'Pipeline: Basic Steps'
  * workflow-cps:1.13 'Pipeline: Groovy CPS Execution'
  * workflow-cps-global-lib:1.13 'Pipeline: Global Shared Library for CPS pipeline'
  * workflow-durable-task-step:1.13 'Pipeline: Durable Task Step'
  * workflow-job:1.13 'Pipeline: Job'
  * workflow-multibranch:1.13 'Pipeline: Multibranch'
  * workflow-scm-step:1.13 'Pipeline: SCM Step'
  * workflow-step-api:1.13 'Pipeline: Step API'
  * workflow-support:1.13 'Pipeline: Execution Support'
  * ws-cleanup:0.28 'Jenkins Workspace Cleanup Plugin'
