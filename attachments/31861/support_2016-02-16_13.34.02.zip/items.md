Item statistics
===============

  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 26
    - Number of builds per job: 105.5 [n=26, s=100.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 5
    - Number of builds per job: 55.2 [n=5, s=90.0]
    - Number of items per container: 5.2 [n=5, s=8.0]
  * `hudson.maven.MavenModule`
    - Number of items: 1
    - Number of builds per job: 99 [n=1]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 1
    - Number of builds per job: 100 [n=1]
    - Number of items per container: 1 [n=1]
  * `hudson.model.FreeStyleProject`
    - Number of items: 1405
    - Number of builds per job: 260.6754448398577 [n=1405, s=8876.04832803734]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 25
    - Number of builds per job: 29.88 [n=25, s=40.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 2
    - Number of items per container: 1.5 [n=2, s=2.0]

Total job statistics
======================

  * Number of jobs: 1463
  * Number of builds per job: 253.05126452494875 [n=1463, s=8698.298369021495]
