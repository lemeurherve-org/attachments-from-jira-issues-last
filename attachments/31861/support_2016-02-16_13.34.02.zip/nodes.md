Node statistics
===============

  * Total number of nodes
      - Sample size:        46242
      - Average (mean):     9.032924258827643
      - Average (median):   9.0
      - Standard deviation: 0.20967242672876943
      - Minimum:            8
      - Maximum:            23
      - 95th percentile:    9.0
      - 99th percentile:    10.0
  * Total number of nodes online
      - Sample size:        46242
      - Average (mean):     7.031149123471517
      - Average (median):   7.0
      - Standard deviation: 0.19695143058386766
      - Minimum:            6
      - Maximum:            21
      - 95th percentile:    7.0
      - 99th percentile:    8.0
  * Total number of executors
      - Sample size:        46242
      - Average (mean):     18.031149123471522
      - Average (median):   18.0
      - Standard deviation: 0.19695143058386771
      - Minimum:            17
      - Maximum:            32
      - 95th percentile:    18.0
      - 99th percentile:    19.0
  * Total number of executors in use
      - Sample size:        46242
      - Average (mean):     5.755204990683202
      - Average (median):   6.0
      - Standard deviation: 0.5805362643501059
      - Minimum:            0
      - Maximum:            17
      - 95th percentile:    7.0
      - 99th percentile:    7.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      4
      - FS root:        `/ic/.jenkins`
      - Labels:         master linux x64
      - Usage:          `NORMAL`
      - Slave Version:  2.53
      - Java
          + Home:           `/ic/logiciels/jdk1.8.0_25/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_25
          + Maximum memory:   2,44 GB (2621440000)
          + Allocated memory: 2,44 GB (2621440000)
          + Free memory:      721,92 MB (756989064)
          + In-use memory:    1,74 GB (1864450936)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.25-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.17.1.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.0 (Santiago)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 9826 (0x2662)
      - Process started: 2016-02-08 13:55:24.908+0100
      - Process uptime: 8 days 0 hr
      - JVM startup parameters:
          + Boot classpath: `/ic/logiciels/jdk1.8.0_25/jre/lib/resources.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/rt.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/sunrsasign.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/jsse.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/jce.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/charsets.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/jfr.jar:/ic/logiciels/jdk1.8.0_25/jre/classes`
          + Classpath: `/ic/scripts/../jenkins-1.625.2.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dhudson.TcpSlaveAgentListener.hostName=ic.mipih.net`
          + arg[1]: `-XX:+UseG1GC`
          + arg[2]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[3]: `-XX:HeapDumpPath=/ic/jenkins-heapdump.hprof`
          + arg[4]: `-XX:OnError=t_alert_admin.sh "ERROR JVM sur le Jenkins de PROD --> A TRAITER EN URGENCE !"`
          + arg[5]: `-XX:OnOutOfMemoryError=t_alert_admin.sh "OOME sur le Jenkins de PROD --> A TRAITER EN URGENCE !"`
          + arg[6]: `-Dcom.sun.management.jmxremote.port=3334`
          + arg[7]: `-Dcom.sun.management.jmxremote.authenticate=false`
          + arg[8]: `-Dcom.sun.management.jmxremote.ssl=false`
          + arg[9]: `-Xmx2500m`
          + arg[10]: `-XX:+PrintGCTimeStamps`
          + arg[11]: `-Xloggc:/ic/.jenkins-gclog/gc.log`
          + arg[12]: `-XX:+PrintGCDetails`
          + arg[13]: `-Djava.io.tmpdir=/ic/tmp`

  * aix-1 (`hudson.slaves.DumbSlave`)
      - Description:    _Esclave AIX_
      - Executors:      4
      - Remote FS root: `/ic/.jenkins`
      - Labels:         aix continuous_deployment
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/java7_64/jre`
          + Vendor:           IBM Corporation
          + Version:          1.7.0
          + Maximum memory:   300.00 MB (314572800)
          + Allocated memory: 118.88 MB (124649472)
          + Free memory:      75.66 MB (79334656)
          + In-use memory:    43.22 MB (45314816)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    IBM J9 VM
          + Vendor:  IBM Corporation
          + Version: 2.6
      - Operating system
          + Name:         AIX
          + Architecture: ppc64
          + Version:      6.1
      - Process ID: 17432660 (0x10a0054)
      - Process started: 2016-02-08 13:56:09.884+0100
      - Process uptime: 8 days 0 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/java7_64/jre/lib/ppc64/compressedrefs/jclSC170/vm.jar:/usr/java7_64/jre/lib/se-service.jar:/usr/java7_64/jre/lib/math.jar:/usr/java7_64/jre/lib/jlm.jar:/usr/java7_64/jre/lib/ibmorb.jar:/usr/java7_64/jre/lib/ibmorbapi.jar:/usr/java7_64/jre/lib/ibmcfw.jar:/usr/java7_64/jre/lib/ibmpkcs.jar:/usr/java7_64/jre/lib/ibmcertpathfw.jar:/usr/java7_64/jre/lib/ibmjgssfw.jar:/usr/java7_64/jre/lib/ibmjssefw.jar:/usr/java7_64/jre/lib/ibmsaslfw.jar:/usr/java7_64/jre/lib/ibmjcefw.jar:/usr/java7_64/jre/lib/ibmjgssprovider.jar:/usr/java7_64/jre/lib/ibmjsseprovider2.jar:/usr/java7_64/jre/lib/ibmcertpathprovider.jar:/usr/java7_64/jre/lib/xmldsigfw.jar:/usr/java7_64/jre/lib/xml.jar:/usr/java7_64/jre/lib/charsets.jar:/usr/java7_64/jre/lib/resources.jar:/usr/java7_64/jre/lib/rt.jar`
          + Classpath: `slave.jar`
          + Library path: `/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64/j9vm:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/../lib/ppc64:/usr/lib:/usr/lib`
          + arg[0]: `-Xoptionsfile=/usr/java7_64/jre/lib/ppc64/compressedrefs/options.default`
          + arg[1]: `-Xlockword:mode=default,noLockword=java/lang/String,noLockword=java/util/MapEntry,noLockword=java/util/HashMap$Entry,noLockword=org/apache/harmony/luni/util/ModifiedMap$Entry,noLockword=java/util/Hashtable$Entry,noLockword=java/lang/invoke/MethodType,noLockword=java/lang/invoke/MethodHandle,noLockword=java/lang/invoke/CollectHandle,noLockword=java/lang/invoke/ConstructorHandle,noLockword=java/lang/invoke/ConvertHandle,noLockword=java/lang/invoke/ArgumentConversionHandle,noLockword=java/lang/invoke/AsTypeHandle,noLockword=java/lang/invoke/ExplicitCastHandle,noLockword=java/lang/invoke/FilterReturnHandle,noLockword=java/lang/invoke/DirectHandle,noLockword=java/lang/invoke/ReceiverBoundHandle,noLockword=java/lang/invoke/DynamicInvokerHandle,noLockword=java/lang/invoke/FieldHandle,noLockword=java/lang/invoke/FieldGetterHandle,noLockword=java/lang/invoke/FieldSetterHandle,noLockword=java/lang/invoke/StaticFieldGetterHandle,noLockword=java/lang/invoke/StaticFieldSetterHandle,noLockword=java/lang/invoke/IndirectHandle,noLockword=java/lang/invoke/InterfaceHandle,noLockword=java/lang/invoke/VirtualHandle,noLockword=java/lang/invoke/InvokeExactHandle,noLockword=java/lang/invoke/InvokeGenericHandle,noLockword=java/lang/invoke/VarargsCollectorHandle,noLockword=java/lang/invoke/ThunkTuple`
          + arg[2]: `-Xjcl:jclse7b_26`
          + arg[3]: `-Dcom.ibm.oti.vm.bootstrap.library.path=/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64`
          + arg[4]: `-Dsun.boot.library.path=/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64`
          + arg[5]: `-Djava.library.path=/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64/j9vm:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/../lib/ppc64:/usr/lib:/usr/lib`
          + arg[6]: `-Djava.home=/usr/java7_64/jre`
          + arg[7]: `-Djava.ext.dirs=/usr/java7_64/jre/lib/ext`
          + arg[8]: `-Duser.dir=/ic/.jenkins`
          + arg[9]: `-Djava.runtime.version=pap6470sr5-20130619_01 (SR5)`
          + arg[10]: `-Djava.class.path=.`
          + arg[11]: `-Xmx300m`
          + arg[12]: `-Xgcpolicy:gencon`
          + arg[13]: `-Xverbosegclog:/ic/loggc/gc#.log,20,10000`
          + arg[14]: `-Djava.class.path=slave.jar`
          + arg[15]: `-Dsun.java.command=slave.jar`
          + arg[16]: `-Dsun.java.launcher=SUN_STANDARD`

  * docker-eb0368d76ff6-sv-t-vnl-ic-centos7-1.mipih.net (`com.nirima.jenkins.plugins.docker.DockerSwarmSlave`)
      - Description:    _Docker Node [docker-registry.mipih.net/forge/centos6-jenkins-slave:4 on docker]_
      - Executors:      1
      - Remote FS root: `/iclinux/.jenkins`
      - Labels:         rhel docker-rhel linux x64
      - Usage:          `NORMAL`
      - Launch method:  `com.nirima.jenkins.plugins.docker.launcher.DockerComputerSSHLauncher`
      - Availability:   `com.nirima.jenkins.plugins.docker.strategy.DockerOnceRetentionStrategy`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.71-1.b15.el6_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_71
          + Maximum memory:   622,50 MB (652738560)
          + Allocated memory: 299,50 MB (314048512)
          + Free memory:      76,10 MB (79793056)
          + In-use memory:    223,40 MB (234255456)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.71-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.3.0-1.el7.elrepo.x86_64
      - Process ID: 80 (0x50)
      - Process started: 2016-02-16 14:27:14.906+0100
      - Process uptime: 9 mn 42 s
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.71-1.b15.el6_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.71-1.b15.el6_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.71-1.b15.el6_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.71-1.b15.el6_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.71-1.b15.el6_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.71-1.b15.el6_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.71-1.b15.el6_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.71-1.b15.el6_7.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/iclinux/oracle-instantclient-11.2::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=500m`
          + arg[1]: `-Xmx700m`

  * rhel-ferrari (`hudson.slaves.DumbSlave`)
      - Description:    _Machine d'integration LINUX_
      - Executors:      1
      - Remote FS root: `/home/mipinst/.jenkins`
      - Labels:         linux x64 super-build super-release
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * rhel6-ssh-12 (`hudson.slaves.DumbSlave`)
      - Description:    _Machine d'integration RHEL_
      - Executors:      6
      - Remote FS root: `/iclinux/.jenkins`
      - Labels:         ssh linux x64 continuous_deployment acces_esx JENKINS-30084
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   676,69 MB (709558272)
          + Allocated memory: 95,60 MB (100245504)
          + Free memory:      66,19 MB (69405776)
          + In-use memory:    29,41 MB (30839728)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-71.18.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.0 (Santiago)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 33835 (0x842b)
      - Process started: 2016-02-08 13:56:17.334+0100
      - Process uptime: 8 j 0 h
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/iclinux/oracle-instantclient-11.2::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=500m`
          + arg[1]: `-Xmx700m`

  * rhel7-1 (`hudson.slaves.DumbSlave`)
      - Description:    _Machine d'integration RHEL_
      - Executors:      1
      - Remote FS root: `/iclinux/.jenkins`
      - Labels:         docker linux x64
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   622,50 MB (652738560)
          + Allocated memory: 83,50 MB (87556096)
          + Free memory:      47,98 MB (50310928)
          + In-use memory:    35,52 MB (37245168)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.2.0-1.el7.elrepo.x86_64
      - Process ID: 24817 (0x60f1)
      - Process started: 2016-02-08 13:56:09.504+0100
      - Process uptime: 8 j 0 h
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/iclinux/oracle-instantclient-11.2::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=500m`
          + arg[1]: `-Xmx700m`

  * windows7-3 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows7 - Selenium_
      - Executors:      1
      - Remote FS root: `c:\ic`
      - Labels:         windows selenium chrome seven x64 mdmia winN2J
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `C:\pgih\jdk\1.7.0-x64\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_45
          + Maximum memory:   910,50 MB (954728448)
          + Allocated memory: 64,50 MB (67633152)
          + Free memory:      36,45 MB (38223376)
          + In-use memory:    28,05 MB (29409776)
          + PermGen used:     55,49 MB (58186256)
          + PermGen max:      82,00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.45-b08
      - Operating system
          + Name:         Windows 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 1892 (0x764)
      - Process started: 2016-02-03 09:20:20.345+0100
      - Process uptime: 13 j
      - JVM startup parameters:
          + Boot classpath: `C:\pgih\jdk\1.7.0-x64\jre\lib\resources.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\rt.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\sunrsasign.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\jsse.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\jce.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\charsets.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\jfr.jar;C:\pgih\jdk\1.7.0-x64\jre\classes`
          + Classpath: `C:\ic\_slave.jar`
          + Library path: `C:\pgih\jdk\1.7.0-x64\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;%PGIHPATH%;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;;c:\pgih\svn\1.6\bin;c:\pgih\maven\3.2.1\bin;c:\pgih\jdk\1.6.0\bin;c:\pgih\jdk\1.7.0-x64\bin;c:\pgih\jdk\1.8.0-x64\bin;;.`

  * windows7-4 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 7_
      - Executors:      1
      - Remote FS root: `c:\ic`
      - Labels:         windows selenium chrome seven x64 mdmia winN2J
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `C:\pgih\jdk\1.8.0-x64\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_05
          + Maximum memory:   910,50 MB (954728448)
          + Allocated memory: 47,00 MB (49283072)
          + Free memory:      26,16 MB (27430656)
          + In-use memory:    20,84 MB (21852416)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.5-b02
      - Operating system
          + Name:         Windows 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 3192 (0xc78)
      - Process started: 2016-02-08 10:15:00.592+0100
      - Process uptime: 8 j 4 h
      - JVM startup parameters:
          + Boot classpath: `C:\pgih\jdk\1.8.0-x64\jre\lib\resources.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\rt.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\sunrsasign.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\jsse.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\jce.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\charsets.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\jfr.jar;C:\pgih\jdk\1.8.0-x64\jre\classes`
          + Classpath: `C:\ic\_slave.jar`
          + Library path: `C:\pgih\jdk\1.8.0-x64\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Microsoft Network Monitor 3\;;c:\pgih\svn\1.6\bin;c:\pgih\maven\3.2.1\bin;c:\pgih\jdk\1.6.0\bin;c:\pgih\jdk\1.7.0-x64\bin;c:\pgih\jdk\1.8.0-x64\bin;;.`

  * windows7-5 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 7_
      - Executors:      1
      - Remote FS root: `c:\ic`
      - Labels:         windows selenium chrome seven x64 mdmia winN2J
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

