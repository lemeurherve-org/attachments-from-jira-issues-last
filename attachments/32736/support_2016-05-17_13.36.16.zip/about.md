Jenkins
=======

Version details
---------------

  * Version: `1.651`
  * Mode:    WAR
  * Url:     https://triad-jenkins.cisco.com/
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.9`
  * Java
      - Home:           `/usr/local/cisco/trust/java/CiscoJ/jdk/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_60
      - Maximum memory:   9.50 GB (10201595904)
      - Allocated memory: 9.50 GB (10201595904)
      - Free memory:      1.96 GB (2101387032)
      - In-use memory:    7.54 GB (8100208872)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.60-b23
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-573.18.1.el6.x86_64
  * Process ID: 6294 (0x1896)
  * Process started: 2016-05-16 14:28:16.126-0400
  * Process uptime: 19 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/resources.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/rt.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/sunrsasign.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/jsse.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/jce.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/charsets.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/jfr.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/local/cisco/trust/java/CiscoJ/lib:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-Xms10240m`
      - arg[3]: `-Xmx10240m`
      - arg[4]: `-Dhttp.proxyHost=proxy.esl.cisco.com`
      - arg[5]: `-Dhttp.proxyPort=80`
      - arg[6]: `-Dhttps.proxyHost=proxy.esl.cisco.com`
      - arg[7]: `-Dhttps.proxyPort=80`
      - arg[8]: `-Dhttp.nonProxyHosts=*.cisco.com|localhost`
      - arg[9]: `-Dhudson.model.DirectoryBrowserSupport.CSP=sandbox allow-scripts; default-src 'none'; img-src 'self' data: ; style-src 'self' 'unsafe-inline' data: ; script-src 'self' 'unsafe-inline' 'unsafe-eval' ;`
      - arg[10]: `-Djdk.tls.ephemeralDHKeySize=2048`
      - arg[11]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`

Active Plugins
--------------

  * ace-editor:1.0.1 *(update available)* 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:1.41 *(update available)* 'Jenkins Active Directory plugin'
  * analysis-core:1.75 *(update available)* 'Static Analysis Utilities'
  * android-emulator:2.13.1 *(update available)* 'Android Emulator Plugin'
  * ant:1.2 *(update available)* 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * artifactory:2.4.7 'Jenkins Artifactory Plugin'
  * authentication-tokens:1.2 'Authentication Tokens API Plugin'
  * brakeman:0.7 'Brakeman Plugin'
  * build-flow-extensions-plugin:0.1.1 'Build Flow Extensions'
  * build-flow-plugin:0.18 *(update available)* 'CloudBees Build Flow plugin'
  * build-keeper-plugin:1.3 'Build Keeper Plugin'
  * build-pipeline-plugin:1.4.9 *(update available)* 'Build Pipeline Plugin'
  * build-timeout:1.15.1 *(update available)* 'Jenkins build timeout plugin'
  * build-view-column:0.2 'Build View Column Plugin'
  * buildgraph-view:1.1.1 *(update available)* 'buildgraph-view'
  * claim:2.8 'Jenkins Claim Plugin'
  * clearcase:1.6.2 'Jenkins ClearCase Plug-in'
  * cloudbees-consolidated-build-view:1.3 'CloudBees Consolidated Build View Plugin'
  * cloudbees-folder:5.1 *(update available)* 'CloudBees Folders Plugin'
  * cloudbees-wasted-minutes-tracker:3.7 'CloudBees Wasted Minutes Tracker Plugin'
  * cobertura:1.9.7 *(update available)* 'Jenkins Cobertura Plugin'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * copyartifact:1.37 *(update available)* 'Copy Artifact Plugin'
  * coverity:1.5.2 *(update available)* 'Coverity plugin'
  * credentials:1.24 *(update available)* 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.7 'Dashboard View'
  * docker-build-step:1.33 *(update available)* 'docker-build-step'
  * docker-commons:1.2 *(update available)* 'Docker Commons Plugin'
  * docker-plugin:0.16.0 'Docker plugin'
  * doclinks:0.6 *(update available)* 'Jenkins DocLinks plugin'
  * durable-task:1.7 *(update available)* 'Durable Task Plugin'
  * dynamic-axis:1.0.3 'Dynamic Axis'
  * email-ext:2.40.5 *(update available)* 'Email Extension Plugin'
  * envinject:1.92.1 'Environment Injector Plugin'
  * extended-read-permission:1.0 'Hudson Extended Read Permission Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * externalresource-dispatcher:1.1.0 'External Resource Dispatcher plugin'
  * fail-the-build-plugin:1.0 'Fail The Build Plugin'
  * findbugs:4.63 *(update available)* 'FindBugs Plug-in'
  * flexible-publish:0.15.2 'Flexible Publish Plugin'
  * fstrigger:0.39 'Jenkins Filesystem Trigger Plug-in'
  * ghprb:1.30.4 *(update available)* 'GitHub Pull Request Builder'
  * git:2.4.1 *(update available)* 'Jenkins Git plugin'
  * git-client:1.19.1 *(update available)* 'Jenkins Git client plugin'
  * git-server:1.6 'Git server plugin'
  * github:1.17.0 *(update available)* 'GitHub plugin'
  * github-api:1.72 *(update available)* 'GitHub API Plugin'
  * gitlab-hook:1.4.1.1 *(update available)* 'Gitlab Hook Plugin'
  * gitlab-merge-request-jenkins:2.0.0 'Gitlab Merge Request Builder'
  * gitlab-plugin:1.1.28 *(update available)* 'GitLab Plugin'
  * gradle:1.24 'Jenkins Gradle plugin'
  * greenballs:1.15 'Green Balls'
  * groovy:1.29 'Groovy'
  * jackson2-api:2.5.4 *(update available)* 'Jackson 2 API Plugin'
  * jacoco:1.0.19 *(update available)* 'Jenkins JaCoCo plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jenkins-multijob-plugin:1.20 *(update available)* 'Jenkins Multijob plugin'
  * jobConfigHistory:2.12 *(update available)* 'Jenkins Job Configuration History Plugin'
  * jobcopy-builder:1.3.0 'Jobcopy Builder plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2 *(update available)* 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.10 *(update available)* 'JUnit Plugin'
  * ldap:1.11 *(update available)* 'LDAP Plugin'
  * lockable-resources:1.7 *(update available)* 'Lockable Resources plugin'
  * locks-and-latches:0.6 'Hudson Locks and Latches plugin'
  * mailer:1.16 *(update available)* 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * mask-passwords:2.8 'Mask Passwords Plugin'
  * matrix-auth:1.2 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * maven-plugin:2.12.1 'Maven Integration plugin'
  * mercurial:1.54 'Jenkins Mercurial plugin'
  * metadata:1.1.0b 'Metadata plugin'
  * metrics:3.1.2.2 *(update available)* 'Metrics Plugin'
  * monitoring:1.57.0 *(update available)* 'Monitoring'
  * multi-branch-project-plugin:0.4.1 *(update available)* 'Multi-Branch Project Plugin'
  * multiple-scms:0.5 *(update available)* 'Jenkins Multiple SCMs plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * nodelabelparameter:1.7.1 *(update available)* 'Node and Label parameter plugin'
  * openid4java:0.9.8.0 'OpenID4Java API'
  * pam-auth:1.2 'PAM Authentication plugin'
  * parameterized-trigger:2.30 'Jenkins Parameterized Trigger plugin'
  * performance:1.13 'Performance plugin'
  * plain-credentials:1.1 'Plain Credentials Plugin'
  * port-allocator:1.8 'Jenkins Port Allocator Plug-in'
  * postbuild-task:1.8 'Hudson Post build task'
  * promoted-builds:2.24.1 *(update available)* 'Jenkins promoted builds plugin'
  * rake:1.8.0 'Jenkins Rake plugin'
  * robot:1.6.2 *(update available)* 'Robot Framework plugin'
  * role-strategy:2.2.0 'Role-based Authorization Strategy'
  * ruby:1.2 'Hudson Ruby Plugin'
  * ruby-runtime:0.12 'ruby-runtime'
  * rubyMetrics:1.6.3 'RubyMetrics plugin for Jenkins'
  * run-condition:1.0 'Run Condition Plugin'
  * rvm:0.4 'Rvm'
  * scm-api:1.0 *(update available)* 'SCM API Plugin'
  * script-security:1.16 *(update available)* 'Script Security Plugin'
  * shelve-project-plugin:1.5 'Shelve Project Plugin'
  * ssh-agent:1.9 *(update available)* 'SSH Agent Plugin'
  * ssh-credentials:1.11 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.10 *(update available)* 'Jenkins SSH Slaves plugin'
  * stashNotifier:1.9.0 *(update available)* 'Stash Notifier'
  * subversion:2.5.7 'Jenkins Subversion Plug-in'
  * support-core:2.29 *(update available)* 'Support Core Plugin'
  * suppress-stack-trace:1.4 'Stack Trace Suppression Plugin'
  * swarm:1.22 *(update available)* 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * thinBackup:1.7.4 'ThinBackup'
  * throttle-concurrents:1.8.4 *(update available)* 'Jenkins Throttle Concurrent Builds Plug-in'
  * token-macro:1.12.1 'Token Macro Plugin'
  * translation:1.12 *(update available)* 'Jenkins Translation Assistance plugin'
  * unique-id:2.1.1 'Unique ID Library Plugin'
  * valgrind:0.25 'Jenkins Valgrind Plug-in'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.51 *(update available)* 'Warnings Plug-in'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:1.13 *(update available)* 'Pipeline (formerly known as Workflow)'
  * workflow-api:1.13 *(update available)* 'Pipeline: API'
  * workflow-basic-steps:1.13 *(update available)* 'Pipeline: Basic Steps'
  * workflow-cps:1.13 *(update available)* 'Pipeline: Groovy CPS Execution'
  * workflow-cps-global-lib:1.13 *(update available)* 'Pipeline: Global Shared Library for CPS pipeline'
  * workflow-durable-task-step:1.13 *(update available)* 'Pipeline: Durable Task Step'
  * workflow-job:1.13 *(update available)* 'Pipeline: Job'
  * workflow-scm-step:1.13 *(update available)* 'Pipeline: SCM Step'
  * workflow-step-api:1.13 *(update available)* 'Pipeline: Step API'
  * workflow-support:1.13 *(update available)* 'Pipeline: Execution Support'
  * ws-cleanup:0.28 *(update available)* 'Jenkins Workspace Cleanup Plugin'
