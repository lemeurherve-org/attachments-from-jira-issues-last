Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 154
    - Number of items per container: 8.863636363636363 [n=154, s=12.0]
  * `com.cloudbees.plugins.flow.BuildFlow`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]
  * `com.github.mjdetullio.jenkins.plugins.multibranch.FreeStyleMultiBranchProject`
    - Number of items: 1
    - Number of items per container: 1 [n=1]
  * `com.tikal.jenkins.plugins.multijob.MultiJobProject`
    - Number of items: 54
    - Number of builds per job: 35.129629629629626 [n=54, s=40.0]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 381
    - Number of builds per job: 6.446194225721785 [n=381, s=10.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 39
    - Number of builds per job: 14.051282051282051 [n=39, s=20.0]
    - Number of items per container: 9.76923076923077 [n=39, s=10.0]
  * `hudson.maven.MavenModule`
    - Number of items: 23
    - Number of builds per job: 68.6086956521739 [n=23, s=200.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 5
    - Number of builds per job: 147.2 [n=5, s=300.0]
    - Number of items per container: 4.6 [n=5, s=3.0]
  * `hudson.model.ExternalJob`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]
  * `hudson.model.FreeStyleProject`
    - Number of items: 1129
    - Number of builds per job: 28.154118689105402 [n=1129, s=99.397775205153]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]

Total job statistics
======================

  * Number of jobs: 1634
  * Number of builds per job: 23.86842105263158 [n=1634, s=88.1798554190851]
