Node statistics
===============

  * Total number of nodes
      - Sample size:        4588
      - Average (mean):     33.00000000000001
      - Average (median):   33.0
      - Standard deviation: 7.105427357601002E-15
      - Minimum:            33
      - Maximum:            33
      - 95th percentile:    33.0
      - 99th percentile:    33.0
  * Total number of nodes online
      - Sample size:        4588
      - Average (mean):     33.0
      - Average (median):   33.0
      - Standard deviation: 0.0
      - Minimum:            33
      - Maximum:            33
      - 95th percentile:    33.0
      - 99th percentile:    33.0
  * Total number of executors
      - Sample size:        4588
      - Average (mean):     146.0
      - Average (median):   146.0
      - Standard deviation: 0.0
      - Minimum:            146
      - Maximum:            146
      - 95th percentile:    146.0
      - 99th percentile:    146.0
  * Total number of executors in use
      - Sample size:        4588
      - Average (mean):     5.000064176910406
      - Average (median):   5.0
      - Standard deviation: 0.012952107142464097
      - Minimum:            5
      - Maximum:            30
      - 95th percentile:    5.0
      - 99th percentile:    5.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/local/cisco/trust/java/CiscoJ/jdk/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_60
          + Maximum memory:   9.50 GB (10201595904)
          + Allocated memory: 9.50 GB (10201595904)
          + Free memory:      1.84 GB (1979216448)
          + In-use memory:    7.66 GB (8222379456)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.60-b23
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.18.1.el6.x86_64
      - Process ID: 6294 (0x1896)
      - Process started: 2016-05-16 14:28:16.126-0400
      - Process uptime: 19 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/resources.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/rt.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/sunrsasign.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/jsse.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/jce.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/charsets.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/lib/jfr.jar:/usr/local/cisco/trust/java/CiscoJ/jdk/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/local/cisco/trust/java/CiscoJ/lib:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-Xms10240m`
          + arg[3]: `-Xmx10240m`
          + arg[4]: `-Dhttp.proxyHost=proxy.esl.cisco.com`
          + arg[5]: `-Dhttp.proxyPort=80`
          + arg[6]: `-Dhttps.proxyHost=proxy.esl.cisco.com`
          + arg[7]: `-Dhttps.proxyPort=80`
          + arg[8]: `-Dhttp.nonProxyHosts=*.cisco.com|localhost`
          + arg[9]: `-Dhudson.model.DirectoryBrowserSupport.CSP=sandbox allow-scripts; default-src 'none'; img-src 'self' data: ; style-src 'self' 'unsafe-inline' data: ; script-src 'self' 'unsafe-inline' 'unsafe-eval' ;`
          + arg[10]: `-Djdk.tls.ephemeralDHKeySize=2048`
          + arg[11]: `-DJENKINS_HOME=/var/lib/jenkins`

  * corona-auto1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.212 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona corona-auto puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 206.50 MB (216530944)
          + Free memory:      87.88 MB (92150968)
          + In-use memory:    118.62 MB (124379976)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 2389 (0x955)
      - Process started: 2016-04-20 10:37:00.372-0400
      - Process uptime: 26 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-auto2.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.213 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona corona-auto puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 166.00 MB (174063616)
          + Free memory:      72.23 MB (75738472)
          + In-use memory:    93.77 MB (98325144)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 6767 (0x1a6f)
      - Process started: 2016-04-20 15:02:47.118-0400
      - Process uptime: 26 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-auto3.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.109 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona corona-auto puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 96.00 MB (100663296)
          + Free memory:      18.31 MB (19203720)
          + In-use memory:    77.69 MB (81459576)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 2896 (0xb50)
      - Process started: 2016-04-14 12:07:29.003-0400
      - Process uptime: 1 mo 2 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-auto4.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.216 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona corona-auto  puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 97.00 MB (101711872)
          + Free memory:      15.50 MB (16248336)
          + In-use memory:    81.50 MB (85463536)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 2823 (0xb07)
      - Process started: 2016-04-20 10:38:36.180-0400
      - Process uptime: 26 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-auto6.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.218 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona corona-auto puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 87.00 MB (91226112)
          + Free memory:      10.68 MB (11202480)
          + In-use memory:    76.32 MB (80023632)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 3013 (0xbc5)
      - Process started: 2016-04-15 12:01:45.441-0400
      - Process uptime: 1 mo 1 day
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-auto7.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.196 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona corona-auto puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 104.00 MB (109051904)
          + Free memory:      38.53 MB (40402936)
          + In-use memory:    65.47 MB (68648968)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 2734 (0xaae)
      - Process started: 2016-04-20 18:21:29.399-0400
      - Process uptime: 26 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-auto8.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.237 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona corona-auto  puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 94.00 MB (98566144)
          + Free memory:      42.05 MB (44093160)
          + In-use memory:    51.95 MB (54472984)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 2822 (0xb06)
      - Process started: 2016-04-20 18:21:59.406-0400
      - Process uptime: 26 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-perf1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.111 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona-perf corona  puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   4.32 GB (4642045952)
          + Allocated memory: 116.00 MB (121634816)
          + Free memory:      71.25 MB (74712128)
          + In-use memory:    44.75 MB (46922688)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 26556 (0x67bc)
      - Process started: 2016-05-10 09:52:31.052-0400
      - Process uptime: 6 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-perf2.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.209 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona-perf corona  puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   4.32 GB (4642045952)
          + Allocated memory: 111.00 MB (116391936)
          + Free memory:      67.57 MB (70855576)
          + In-use memory:    43.43 MB (45536360)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 2648 (0xa58)
      - Process started: 2016-04-15 13:35:11.420-0400
      - Process uptime: 1 mo 1 day
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-perf3.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.229 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona-perf corona  puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   4.32 GB (4642045952)
          + Allocated memory: 119.00 MB (124780544)
          + Free memory:      75.07 MB (78712280)
          + In-use memory:    43.93 MB (46068264)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 10002 (0x2712)
      - Process started: 2016-04-20 18:28:49.063-0400
      - Process uptime: 26 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-qa1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.222 : null_
      - Executors:      20
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos corona corona-master
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_85
          + Maximum memory:   3.46 GB (3717201920)
          + Allocated memory: 197.00 MB (206569472)
          + Free memory:      161.50 MB (169342968)
          + In-use memory:    35.50 MB (37226504)
          + PermGen used:     61.59 MB (64583424)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.85-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
      - Process ID: 3198 (0xc7e)
      - Process started: 2016-04-28 12:42:41.008-0400
      - Process uptime: 18 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-reg1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.137 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona corona-reg puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 81.00 MB (84934656)
          + Free memory:      31.79 MB (33329504)
          + In-use memory:    49.21 MB (51605152)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 2695 (0xa87)
      - Process started: 2016-04-23 09:20:21.089-0400
      - Process uptime: 24 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-soak1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.3 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona-soak corona puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 55.00 MB (57671680)
          + Free memory:      33.08 MB (34682016)
          + In-use memory:    21.92 MB (22989664)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 3228 (0xc9c)
      - Process started: 2016-04-15 12:02:41.520-0400
      - Process uptime: 1 mo 1 day
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * corona-soak2.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.104 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona corona-soak puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   4.32 GB (4642045952)
          + Allocated memory: 112.00 MB (117440512)
          + Free memory:      80.65 MB (84570752)
          + In-use memory:    31.35 MB (32869760)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 2714 (0xa9a)
      - Process started: 2016-04-14 11:32:15.983-0400
      - Process uptime: 1 mo 2 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * decompose-sandbox.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.151.183 : null_
      - Executors:      1
      - Remote FS root: `/home/gambit`
      - Labels:         swarm linux x86_64 centos centos7 corona-bleed puma
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 66.00 MB (69206016)
          + Free memory:      39.97 MB (41916328)
          + In-use memory:    26.03 MB (27289688)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-229.el7.x86_64
      - Process ID: 3209 (0xc89)
      - Process started: 2016-04-21 16:39:15.584-0400
      - Process uptime: 25 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
          + Classpath: `/home/gambit/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * firedragon (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.154.215 : null_
      - Executors:      10
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux x86_64 centos ciscossl
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_101
          + Maximum memory:   6.96 GB (7477395456)
          + Allocated memory: 422.50 MB (443023360)
          + Free memory:      276.31 MB (289731088)
          + In-use memory:    146.19 MB (153292272)
          + PermGen used:     92.35 MB (96839952)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.95-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 5320 (0x14c8)
      - Process started: 2016-04-28 12:49:13.046-0400
      - Process uptime: 18 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * freebird.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.82.91 : null_
      - Executors:      1
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux amd64 freebsd ciscossl
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/local/openjdk7/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   972.50 MB (1019740160)
          + Allocated memory: 60.88 MB (63832064)
          + Free memory:      35.08 MB (36785072)
          + In-use memory:    25.79 MB (27046992)
          + PermGen used:     25.42 MB (26651144)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.21-b01
      - Operating system
          + Name:         FreeBSD
          + Architecture: amd64
          + Version:      9.2-RELEASE-p15
      - Process ID: 1058 (0x422)
      - Process started: 2016-02-23 10:05:42.546-0500
      - Process uptime: 2 mo 23 days
      - JVM startup parameters:
          + Boot classpath: `/usr/local/openjdk7/jre/lib/resources.jar:/usr/local/openjdk7/jre/lib/rt.jar:/usr/local/openjdk7/jre/lib/sunrsasign.jar:/usr/local/openjdk7/jre/lib/jsse.jar:/usr/local/openjdk7/jre/lib/jce.jar:/usr/local/openjdk7/jre/lib/charsets.jar:/usr/local/openjdk7/jre/lib/jfr.jar:/usr/local/openjdk7/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/lib:/usr/lib:/usr/local/lib`

  * gmbt-reg2 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/home/lab`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53.3
      - Java
          + Home:           `/usr/local/cisco/trust/java/jdk7/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_80
          + Maximum memory:   853.50 MB (894959616)
          + Allocated memory: 56.00 MB (58720256)
          + Free memory:      34.15 MB (35813648)
          + In-use memory:    21.85 MB (22906608)
          + PermGen used:     13.76 MB (14423680)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.80-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.8.1.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 22216 (0x56c8)
      - Process started: 2016-05-16 14:29:01.321-0400
      - Process uptime: 19 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/cisco/trust/java/jdk7/jre/lib/resources.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/rt.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/sunrsasign.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/jsse.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/jce.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/charsets.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/jfr.jar:/usr/local/cisco/trust/java/jdk7/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * mintdragon.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.154.105 : null_
      - Executors:      10
      - Remote FS root: `/home/lab`
      - Labels:         swarm linux i386 centos ciscossl
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_95
          + Maximum memory:   910.25 MB (954466304)
          + Allocated memory: 78.75 MB (82575360)
          + Free memory:      8.84 MB (9267744)
          + In-use memory:    69.91 MB (73307616)
          + PermGen used:     109.07 MB (114369424)
          + PermGen max:      128.00 MB (134217728)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.95-b01
      - Operating system
          + Name:         Linux
          + Architecture: i386
          + Version:      2.6.32-573.18.1.el6.i686
          + Distribution: "CentOS release 6.7 (Final)"
          + LSB Modules:  `:base-4.0-ia32:base-4.0-noarch:core-4.0-ia32:core-4.0-noarch:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 3071 (0xbff)
      - Process started: 2016-02-24 07:23:43.197-0500
      - Process uptime: 2 mo 23 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.95/jre/classes`
          + Classpath: `/home/lab/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/local/lib:/usr/java/packages/lib/i386:/lib:/usr/lib`

  * sto-ccc-jenkins-slave (`hudson.slaves.DumbSlave`)
      - Description:    _sto-ccc jenkins-slave_
      - Executors:      10
      - Remote FS root: `/home/cloud-user`
      - Labels:         sto-ccc-node1
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53.3
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_101
          + Maximum memory:   643.81 MB (675086336)
          + Allocated memory: 30.31 MB (31784960)
          + Free memory:      21.99 MB (23060152)
          + In-use memory:    8.32 MB (8724808)
          + PermGen used:     15.52 MB (16276792)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.95-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-71-generic
          + Distribution: Ubuntu 14.04.4 LTS
      - Process ID: 19353 (0x4b99)
      - Process started: 2016-05-16 18:29:02.218+0000
      - Process uptime: 19 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

  * sto-ccc-jenkins-slave1 (`hudson.slaves.DumbSlave`)
      - Description:    _sto-ccc jenkins-slave1_
      - Executors:      10
      - Remote FS root: `/home/cloud-user`
      - Labels:         sto-ccc-node1
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53.3
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_101
          + Maximum memory:   643.81 MB (675086336)
          + Allocated memory: 30.31 MB (31784960)
          + Free memory:      16.43 MB (17231688)
          + In-use memory:    13.88 MB (14553272)
          + PermGen used:     15.20 MB (15936560)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.95-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-71-generic
          + Distribution: Ubuntu 14.04.4 LTS
      - Process ID: 25523 (0x63b3)
      - Process started: 2016-05-16 18:29:02.242+0000
      - Process uptime: 19 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

  * sto-labsrv1 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      9
      - Remote FS root: `/tftpboot/sto-labsrv1`
      - Labels:         linux x86_64 redhat ciscossl-qa
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53.3
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_85
          + Maximum memory:   3.49 GB (3748659200)
          + Allocated memory: 198.00 MB (207618048)
          + Free memory:      171.36 MB (179685272)
          + In-use memory:    26.64 MB (27932776)
          + PermGen used:     23.44 MB (24583048)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.85-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.7.1.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Workstation release 6.7 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 14825 (0x39e9)
      - Process started: 2016-05-16 14:29:01.125-0400
      - Process uptime: 19 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * sto-labsrv2 (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.18.152.184 : null_
      - Executors:      9
      - Remote FS root: `/tftpboot/sto-labsrv2`
      - Labels:         swarm linux x86_64 redhat ciscossl-qa
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_85
          + Maximum memory:   3.49 GB (3748659200)
          + Allocated memory: 211.00 MB (221249536)
          + Free memory:      100.86 MB (105763912)
          + In-use memory:    110.14 MB (115485624)
          + PermGen used:     115.54 MB (121148104)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.85-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.7.1.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Workstation release 6.7 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 13724 (0x359c)
      - Process started: 2016-02-23 15:52:46.331-0500
      - Process uptime: 2 mo 23 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
          + Classpath: `/tftpboot/sto-labsrv2/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * sto-labsrv3.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.144 : null_
      - Executors:      9
      - Remote FS root: `/home/jenkins`
      - Labels:         swarm linux x86_64 redhat ats-server
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.51-3.b16.el6_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_51
          + Maximum memory:   3.49 GB (3749183488)
          + Allocated memory: 109.00 MB (114294784)
          + Free memory:      67.87 MB (71165784)
          + In-use memory:    41.13 MB (43129000)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.51-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.7.1.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Workstation release 6.7 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 602 (0x25a)
      - Process started: 2016-04-22 11:59:36.272-0400
      - Process uptime: 24 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.51-3.b16.el6_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.51-3.b16.el6_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.51-3.b16.el6_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.51-3.b16.el6_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.51-3.b16.el6_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.51-3.b16.el6_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.51-3.b16.el6_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.51-3.b16.el6_7.x86_64/jre/classes`
          + Classpath: `/home/jenkins/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/opt/ats5.3.0/lib:/opt/security/lib:/lib:/usr/lib:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * trust-reg-1.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.89 : null_
      - Executors:      10
      - Remote FS root: `/home/testuser`
      - Labels:         swarm linux x86_64 centos centos6 c3m-build
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/local/cisco/trust/java/jdk8/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_60
          + Maximum memory:   1.71 GB (1834483712)
          + Allocated memory: 259.50 MB (272105472)
          + Free memory:      122.27 MB (128210800)
          + In-use memory:    137.23 MB (143894672)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.60-b23
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.18.1.el6.x86_64
          + Distribution: "CentOS release 6.7 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 2184 (0x888)
      - Process started: 2016-04-22 15:09:11.528-0400
      - Process uptime: 24 days
      - JVM startup parameters:
          + Boot classpath: `/usr/local/cisco/trust/java/jdk8/jre/lib/resources.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/rt.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/sunrsasign.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/jsse.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/jce.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/charsets.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/jfr.jar:/usr/local/cisco/trust/java/jdk8/jre/classes`
          + Classpath: `/home/testuser/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * trust-reg-11.cisco.com (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      3
      - Remote FS root: `/home/testuser`
      - Labels:         tam-build-act2 centos x86_64
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53.3
      - Java
          + Home:           `/usr/local/cisco/trust/java/jdk7/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_80
          + Maximum memory:   2.56 GB (2747793408)
          + Allocated memory: 160.50 MB (168296448)
          + Free memory:      137.65 MB (144336288)
          + In-use memory:    22.85 MB (23960160)
          + PermGen used:     21.87 MB (22933528)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.80-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-327.13.1.el7.x86_64
          + Distribution: "CentOS Linux release 7.2.1511 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 25328 (0x62f0)
      - Process started: 2016-05-16 14:29:02.984-0400
      - Process uptime: 19 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/cisco/trust/java/jdk7/jre/lib/resources.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/rt.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/sunrsasign.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/jsse.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/jce.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/charsets.jar:/usr/local/cisco/trust/java/jdk7/jre/lib/jfr.jar:/usr/local/cisco/trust/java/jdk7/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * trust-reg-2.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.210 : null_
      - Executors:      10
      - Remote FS root: `/home/testuser`
      - Labels:         swarm linux x86_64 centos centos6 c3m-build
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/local/cisco/trust/java/jdk8/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_60
          + Maximum memory:   1.71 GB (1834483712)
          + Allocated memory: 856.00 MB (897581056)
          + Free memory:      421.74 MB (442228600)
          + In-use memory:    434.26 MB (455352456)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.60-b23
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-573.18.1.el6.x86_64
          + Distribution: "CentOS release 6.7 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 27094 (0x69d6)
      - Process started: 2016-04-21 09:11:56.355-0400
      - Process uptime: 26 days
      - JVM startup parameters:
          + Boot classpath: `/usr/local/cisco/trust/java/jdk8/jre/lib/resources.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/rt.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/sunrsasign.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/jsse.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/jce.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/charsets.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/jfr.jar:/usr/local/cisco/trust/java/jdk8/jre/classes`
          + Classpath: `/home/testuser/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * trust-reg-4.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.58 : null_
      - Executors:      10
      - Remote FS root: `/home/testuser`
      - Labels:         swarm linux x86_64 centos centos7 c3m-build latest
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/local/cisco/trust/java/jdk8/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_60
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 826.50 MB (866648064)
          + Free memory:      225.67 MB (236637032)
          + In-use memory:    600.83 MB (630011032)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.60-b23
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-327.10.1.el7.x86_64
          + Distribution: "CentOS Linux release 7.2.1511 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 2689 (0xa81)
      - Process started: 2016-03-11 14:27:11.304-0500
      - Process uptime: 2 mo 6 days
      - JVM startup parameters:
          + Boot classpath: `/usr/local/cisco/trust/java/jdk8/jre/lib/resources.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/rt.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/sunrsasign.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/jsse.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/jce.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/charsets.jar:/usr/local/cisco/trust/java/jdk8/jre/lib/jfr.jar:/usr/local/cisco/trust/java/jdk8/jre/classes`
          + Classpath: `/home/testuser/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * trust-reg-5.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.200 : null_
      - Executors:      3
      - Remote FS root: `/Users/testuser`
      - Labels:         swarm darwin x86_64 darwin darwin14 c3m-build
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_66
          + Maximum memory:   1.78 GB (1908932608)
          + Allocated memory: 116.00 MB (121634816)
          + Free memory:      36.54 MB (38319104)
          + In-use memory:    79.46 MB (83315712)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.66-b17
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86_64
          + Version:      10.10.5
      - Process ID: 1289 (0x509)
      - Process started: 2016-02-08 12:31:20.280-0500
      - Process uptime: 3 mo 8 days
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/classes`
          + Classpath: `/Users/testuser/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/Users/testuser/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`

  * trust-reg-6.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.201 : null_
      - Executors:      3
      - Remote FS root: `/Users/testuser`
      - Labels:         swarm darwin x86_64 darwin darwin14 c3m-build
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_66
          + Maximum memory:   1.78 GB (1908932608)
          + Allocated memory: 113.00 MB (118489088)
          + Free memory:      25.53 MB (26772600)
          + In-use memory:    87.47 MB (91716488)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.66-b17
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86_64
          + Version:      10.10.5
      - Process ID: 351 (0x15f)
      - Process started: 2016-02-08 09:54:54.504-0800
      - Process uptime: 3 mo 8 days
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_66.jdk/Contents/Home/jre/classes`
          + Classpath: `/Users/testuser/swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `/Users/testuser/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`

  * trust-reg-7.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.212 : null_
      - Executors:      1
      - Remote FS root: `C:\Users\testuser`
      - Labels:         swarm windows x64 windows6 c3m-build
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `C:\Java\jdk8\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_92
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 131.50 MB (137887744)
          + Free memory:      51.16 MB (53643192)
          + In-use memory:    80.34 MB (84244552)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.92-b14
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 1252 (0x4e4)
      - Process started: 2016-05-13 07:54:54.579-0700
      - Process uptime: 3 days 22 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Java\jdk8\jre\lib\resources.jar;C:\Java\jdk8\jre\lib\rt.jar;C:\Java\jdk8\jre\lib\sunrsasign.jar;C:\Java\jdk8\jre\lib\jsse.jar;C:\Java\jdk8\jre\lib\jce.jar;C:\Java\jdk8\jre\lib\charsets.jar;C:\Java\jdk8\jre\lib\jfr.jar;C:\Java\jdk8\jre\classes`
          + Classpath: `C:\Users\testuser\swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `C:\Java\jdk8\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\tools\activetcl\bin;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\ProgramData\chocolatey\bin;C:\Program Files\Puppet Labs\Puppet\bin;C:\Program Files\Java\jdk1.7.0_79\bin;C:\Program Files\Java\jdk1.8.0_66\bin;C:\Program Files (x86)\nasm;C:\strawberry\c\bin;C:\strawberry\perl\site\bin;C:\strawberry\perl\bin;C:\Program Files (x86)\Gow\bin;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Windows\system32\config\systemprofile\.dnx\bin;C:\Program Files\Microsoft DNX\Dnvm\;C:\Program Files (x86)\Windows Kits\8.1\Windows Performance Toolkit\;C:\Program Files\Java\jdk1.8.0_72\bin;C:\Program Files (x86)\Subversion\bin;C:\Program Files\Java\jdk1.8.0_74\bin;C:\tools\python2;C:\Program Files\Java\jdk1.8.0_77\bin;C:\tools\Gradle\bin;C:\Program Files\Java\jdk1.8.0_92\bin;C:\Program Files (x86)\Git\cmd;C:\Users\testuser\.dnx\bin;.`

  * trust-reg-8.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.215 : null_
      - Executors:      1
      - Remote FS root: `C:\Users\testuser`
      - Labels:         swarm windows x64 windows6 c3m-build
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `C:\Java\jdk8\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_92
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 209.50 MB (219676672)
          + Free memory:      46.23 MB (48474304)
          + In-use memory:    163.27 MB (171202368)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.92-b14
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 1216 (0x4c0)
      - Process started: 2016-05-13 07:55:03.049-0700
      - Process uptime: 3 days 22 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Java\jdk8\jre\lib\resources.jar;C:\Java\jdk8\jre\lib\rt.jar;C:\Java\jdk8\jre\lib\sunrsasign.jar;C:\Java\jdk8\jre\lib\jsse.jar;C:\Java\jdk8\jre\lib\jce.jar;C:\Java\jdk8\jre\lib\charsets.jar;C:\Java\jdk8\jre\lib\jfr.jar;C:\Java\jdk8\jre\classes`
          + Classpath: `C:\Users\testuser\swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `C:\Java\jdk8\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\tools\activetcl\bin;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\ProgramData\chocolatey\bin;C:\Program Files\Puppet Labs\Puppet\bin;C:\Program Files\Java\jdk1.7.0_79\bin;C:\Program Files\Java\jdk1.8.0_66\bin;C:\Program Files (x86)\nasm;C:\strawberry\c\bin;C:\strawberry\perl\site\bin;C:\strawberry\perl\bin;C:\Program Files (x86)\Gow\bin;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Windows Kits\8.1\Windows Performance Toolkit\;C:\Program Files\Java\jdk1.8.0_72\bin;C:\Program Files (x86)\Subversion\bin;C:\Program Files\Java\jdk1.8.0_74\bin;C:\tools\python2;C:\Program Files\Java\jdk1.8.0_77\bin;C:\tools\Gradle\bin;C:\Program Files\Java\jdk1.8.0_92\bin;C:\Program Files (x86)\Git\cmd;.`

  * trust-reg-9.cisco.com (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.122.81.216 : null_
      - Executors:      1
      - Remote FS root: `C:\Users\testuser`
      - Labels:         swarm windows x64 windows6 c3m-build
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `C:\Java\jdk8\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_92
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 216.00 MB (226492416)
          + Free memory:      99.75 MB (104599728)
          + In-use memory:    116.25 MB (121892688)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.92-b14
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 1240 (0x4d8)
      - Process started: 2016-05-13 07:57:10.183-0700
      - Process uptime: 3 days 22 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Java\jdk8\jre\lib\resources.jar;C:\Java\jdk8\jre\lib\rt.jar;C:\Java\jdk8\jre\lib\sunrsasign.jar;C:\Java\jdk8\jre\lib\jsse.jar;C:\Java\jdk8\jre\lib\jce.jar;C:\Java\jdk8\jre\lib\charsets.jar;C:\Java\jdk8\jre\lib\jfr.jar;C:\Java\jdk8\jre\classes`
          + Classpath: `C:\Users\testuser\swarm-client-1.22-jar-with-dependencies.jar`
          + Library path: `C:\Java\jdk8\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\tools\activetcl\bin;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\ProgramData\chocolatey\bin;C:\Program Files\Puppet Labs\Puppet\bin;C:\Program Files\Java\jdk1.7.0_79\bin;C:\Program Files\Java\jdk1.8.0_66\bin;C:\Program Files (x86)\nasm;C:\strawberry\c\bin;C:\strawberry\perl\site\bin;C:\strawberry\perl\bin;C:\Program Files (x86)\Gow\bin;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Windows Kits\8.1\Windows Performance Toolkit\;C:\Program Files\Java\jdk1.8.0_72\bin;C:\Program Files (x86)\Subversion\bin;C:\Program Files\Java\jdk1.8.0_74\bin;C:\tools\python2;C:\Program Files\Java\jdk1.8.0_77\bin;C:\tools\Gradle\bin;C:\Program Files\Java\jdk1.8.0_92\bin;C:\Program Files (x86)\Git\cmd;.`

