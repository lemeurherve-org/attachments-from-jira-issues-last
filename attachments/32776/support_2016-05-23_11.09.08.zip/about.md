Jenkins
=======

Version details
---------------

  * Version: `2.5`
  * Mode:    WAR
  * Url:     https://builder.bozaro.ru/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_91
      - Maximum memory:   3,46 GB (3715629056)
      - Allocated memory: 1,14 GB (1221591040)
      - Free memory:      340,87 MB (357430928)
      - In-use memory:    824,13 MB (864160112)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.91-b14
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.4.0-21-generic
      - Distribution: Ubuntu 16.04 LTS
  * Process ID: 23545 (0x5bf9)
  * Process started: 2016-05-23 14:05:28.793+0300
  * Process uptime: 3 минуты 40 секунд
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.76 'Static Analysis Utilities'
  * ant:1.3 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * branch-api:1.8 'Branch API Plugin'
  * build-timeout:1.16 'Jenkins build timeout plugin'
  * cloudbees-folder:5.10 'Folders Plugin'
  * credentials:2.0 'Credentials Plugin'
  * credentials-binding:1.7 'Credentials Binding Plugin'
  * durable-task:1.10 'Durable Task Plugin'
  * email-ext:2.42 'Email Extension Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.4.4 'Jenkins Git plugin'
  * git-client:1.19.6 'Jenkins Git client plugin'
  * git-server:1.6 'Git server plugin'
  * github:1.19.1 'GitHub plugin'
  * github-api:1.75 'GitHub API Plugin'
  * github-branch-source:1.7 'GitHub Branch Source Plugin'
  * github-organization-folder:1.3 'GitHub Organization Folder Plugin'
  * gradle:1.24 'Jenkins Gradle plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.13 'JUnit Plugin'
  * ldap:1.12 'LDAP Plugin'
  * mailer:1.17 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.3.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * maven-plugin:2.13 'Maven Integration plugin'
  * metrics:3.1.2.7 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * pipeline-build-step:2.0 'Pipeline: Build Step'
  * pipeline-input-step:2.0 'Pipeline: Input Step'
  * pipeline-rest-api:1.4 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.0 *(update available)* 'Pipeline: Stage Step'
  * pipeline-stage-view:1.4 'Pipeline: Stage View Plugin'
  * plain-credentials:1.2 'Plain Credentials Plugin'
  * publish-over-ssh:1.14 'Publish Over SSH'
  * rebuild:1.25 'Rebuilder'
  * scm-api:1.2 'SCM API Plugin'
  * script-security:1.19 'Script Security Plugin'
  * ssh-agent:1.10 'SSH Agent Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.11 'Jenkins SSH Slaves plugin'
  * structs:1.1 'Structs Plugin'
  * subversion:2.5.7 'Jenkins Subversion Plug-in'
  * support-core:2.32 'Support Core Plugin'
  * timestamper:1.8.2 'Timestamper'
  * token-macro:1.12.1 'Token Macro Plugin'
  * warnings:4.53 'Warnings Plug-in'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.1 'Pipeline'
  * workflow-api:2.0 'Pipeline: API'
  * workflow-basic-steps:2.0 'Pipeline: Basic Steps'
  * workflow-cps:2.2 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.0 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.0 'Pipeline: Nodes and Processes'
  * workflow-job:2.2 'Pipeline: Job'
  * workflow-multibranch:2.3 'Pipeline: Multibranch'
  * workflow-scm-step:2.0 'Pipeline: SCM Step'
  * workflow-step-api:2.0 'Pipeline: Step API'
  * workflow-support:2.0 'Pipeline: Supporting APIs'
  * ws-cleanup:0.29 'Jenkins Workspace Cleanup Plugin'
