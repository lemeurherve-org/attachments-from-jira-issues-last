Item statistics
===============

  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 12
    - Number of builds per job: 15.333333333333334 [n=12, s=30.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 5
    - Number of items per container: 2.2 [n=5, s=1.0]

Total job statistics
======================

  * Number of jobs: 12
  * Number of builds per job: 15.333333333333334 [n=12, s=30.0]
