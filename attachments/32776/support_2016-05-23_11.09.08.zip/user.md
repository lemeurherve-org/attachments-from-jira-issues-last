User
====

Authentication
--------------

  * Authenticated: true
  * Name: bozaro
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@483d8f0f: Username: hudson.security.HudsonPrivateSecurityRealm$Details@2987c92; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@21a2c: RemoteIpAddress: 185.6.245.138; SessionId: 7d8a8rbdcmsry79eat00khyl; Granted Authorities: authenticated`

