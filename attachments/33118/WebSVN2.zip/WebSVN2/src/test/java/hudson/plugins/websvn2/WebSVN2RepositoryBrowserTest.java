package hudson.plugins.websvn2;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import org.junit.Test;

import hudson.scm.SubversionChangeLogSet.LogEntry;
import hudson.scm.SubversionChangeLogSet.Path;
import hudson.util.FormValidation;
import hudson.util.FormValidation.Kind;

/**
 * @version $Revision: 83023 $ ($Date: 2016-06-16 15:48:53 +0200 (Do, 16 Jun 2016) $) by $Author: christian $
 */
public class WebSVN2RepositoryBrowserTest {

  private static final Kind KIND_OF_VALIDATION_OK = FormValidation.ok().kind;
  private static final Kind KIND_OF_VALIDATION_ERROR = FormValidation.error("Foo").kind;
  private static final String NAME_OF_FILE_UNDER_VERSION_CONTROL = "/foo/bar/baz.txt";
  private static final String NAME_OF_FILE_URL_ENCODED;
  private static final String REPOSITORY_NAME = "foo-repo";
  private static final Path SOME_SVN_CHANGE_LOG_SET_PATH = new Path();
  private static final int SOME_REVISION = 4711;
  private static final LogEntry SOME_SVN_LOG_ENTRY = new LogEntry();
  static {
    SOME_SVN_LOG_ENTRY.setRevision(SOME_REVISION);
    SOME_SVN_CHANGE_LOG_SET_PATH.setValue(NAME_OF_FILE_UNDER_VERSION_CONTROL);
    SOME_SVN_CHANGE_LOG_SET_PATH.setLogEntry(SOME_SVN_LOG_ENTRY);
    try {
      NAME_OF_FILE_URL_ENCODED = URLEncoder.encode(NAME_OF_FILE_UNDER_VERSION_CONTROL, "ASCII");
    } catch (final UnsupportedEncodingException e) {
      throw new ExceptionInInitializerError(e);
    }
  }

  @Test
  public void pluginDescriptorChecksEmptyRepoURL() {
    final FormValidation formValidation = pluginDecriptorChecksRepoUrlAsERROR("");
    assertEquals(
        "Please set a WebSVN2 url in the form http://<i>server</i>/<i>optional-path</i>/wsvn/<i>Name-of-SVN-repo</i>.",
        formValidation.renderHtml());
  }

  @Test
  public void pluginDescriptorChecksRepoUrlMissingWsvnPath() {
    final FormValidation formValidation = pluginDecriptorChecksRepoUrlAsERROR("http://foo.bar/baz");
    assertEquals(
        "Please set a WebSVN2 url containing wsvn path as well as SVN repository in the form http://<i>server</i>/<i>optional-path</i>/wsvn/<i>Name-of-SVN-repo</i>.",
        formValidation.renderHtml());
  }

  @Test
  public void pluginDescriptorChecksRepoUrlMissingSvnRepository() {
    {
      final FormValidation formValidation = pluginDecriptorChecksRepoUrlAsERROR("http://foo.bar/wsvn/");
      assertEquals(
          "Please set a WebSVN2 url containing SVN repository in the form http://<i>server</i>/<i>optional-path</i>/wsvn/<i>Name-of-SVN-repo</i>.",
          formValidation.renderHtml());
    }
    {
      final FormValidation formValidation = pluginDecriptorChecksRepoUrlAsERROR("http://foo.bar/wsvn");
      assertEquals(
          "Please set a WebSVN2 url containing SVN repository in the form http://<i>server</i>/<i>optional-path</i>/wsvn/<i>Name-of-SVN-repo</i>.",
          formValidation.renderHtml());
    }
  }

  @Test
  public void pluginDescriptorChecksRepoUrlSuccessfully() {
    {
      final FormValidation formValidation = pluginDecriptorChecksRepoUrlAsOK("http://foo.bar/wsvn/" + REPOSITORY_NAME);
      assertEquals("<div/>", formValidation.renderHtml());
    }
    {
      final FormValidation formValidation = pluginDecriptorChecksRepoUrlAsOK(
          "http://foo.bar/wsvn/" + REPOSITORY_NAME + "/");
      assertEquals("<div/>", formValidation.renderHtml());
    }
  }

  @Test
  public void pluginDescriptorChecksRepoUrlAsMalformed() {
    final FormValidation formValidation = pluginDecriptorChecksRepoUrlAsERROR("foo/wsvn/repo");
    assertTrue(formValidation.renderHtml().startsWith("The entered url is not accepted: "));
  }

  @Test(expected = MalformedURLException.class)
  public void getRepnameIfNoRepoIsSpecified() throws MalformedURLException {
    createCutUsingUrl("http://foo.bar");
  }

  @Test
  public void getRepnameIfRepoIsSpecifiedViaQueryParameter() throws MalformedURLException {
    {
      final WebSVN2RepositoryBrowser CUT = createCutUsingUrl("http://foo.bar/baz/wsvn/" + REPOSITORY_NAME);
      assertEquals(REPOSITORY_NAME, CUT.getRepname());
    }
    {
      final WebSVN2RepositoryBrowser CUT = createCutUsingUrl("http://foo.bar/baz/wsvn/" + REPOSITORY_NAME + "/");
      assertEquals(REPOSITORY_NAME, CUT.getRepname());
    }
  }

  @Test
  public void getFileLinkOfArbitraryFilePath() throws IOException {
    final WebSVN2RepositoryBrowser CUT = createCutUsingUrl("http://foo.bar/baz/wsvn/" + REPOSITORY_NAME + "/");
    assertEquals(
        "http://foo.bar/baz/wsvn/" + REPOSITORY_NAME + "/" + NAME_OF_FILE_URL_ENCODED + "?rev=" + SOME_REVISION,
        CUT.getFileLink(SOME_SVN_CHANGE_LOG_SET_PATH).toString());
  }

  @Test
  public void getDiffLinkOfArbitraryFilePath() throws IOException {
    final WebSVN2RepositoryBrowser CUT = createCutUsingUrl("http://foo.bar/baz/wsvn/" + REPOSITORY_NAME + "/");
    assertEquals(
        "http://foo.bar/baz/wsvn/" + REPOSITORY_NAME + "/" + NAME_OF_FILE_URL_ENCODED + "?op=diff&rev=" + SOME_REVISION,
        CUT.getDiffLink(SOME_SVN_CHANGE_LOG_SET_PATH).toString());
  }

  @Test
  public void getChangeSetLinkOfArbitraryFilePath() throws IOException {
    final WebSVN2RepositoryBrowser CUT = createCutUsingUrl("http://foo.bar/baz/wsvn/" + REPOSITORY_NAME);
    assertEquals("http://foo.bar/baz/wsvn/" + REPOSITORY_NAME + "?op=revision&rev=" + SOME_REVISION,
        CUT.getChangeSetLink(SOME_SVN_LOG_ENTRY).toString());
  }

  private WebSVN2RepositoryBrowser createCutUsingUrl(final String urlValue) throws MalformedURLException {
    return new WebSVN2RepositoryBrowser(new URL(urlValue));
  }

  private FormValidation pluginDecriptorChecksRepoUrlAsOK(final String repoUrl) {
    final WebSVN2RepositoryBrowser.DescriptorImpl CUT = new WebSVN2RepositoryBrowser.DescriptorImpl();
    final FormValidation formValidation = CUT.doCheckReposUrl(repoUrl);
    assertEquals(KIND_OF_VALIDATION_OK, formValidation.kind);
    return formValidation;
  }

  private FormValidation pluginDecriptorChecksRepoUrlAsERROR(final String repoUrl) {
    final WebSVN2RepositoryBrowser.DescriptorImpl CUT = new WebSVN2RepositoryBrowser.DescriptorImpl();
    final FormValidation formValidation = CUT.doCheckReposUrl(repoUrl);
    assertEquals(KIND_OF_VALIDATION_ERROR, formValidation.kind);
    return formValidation;
  }

}
