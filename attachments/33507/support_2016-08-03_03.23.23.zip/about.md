Jenkins
=======

Version details
---------------

  * Version: `2.7.1`
  * Mode:    WAR
  * Url:     https://build.example.com:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/java/jdk1.7.0_60/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_60
      - Maximum memory:   3.42 GB (3674210304)
      - Allocated memory: 274.50 MB (287834112)
      - Free memory:      74.89 MB (78523512)
      - In-use memory:    199.61 MB (209310600)
      - PermGen used:     116.80 MB (122471264)
      - PermGen max:      1.00 GB (1073741824)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.60-b09
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-327.13.1.el7.x86_64
  * Process ID: 979 (0x3d3)
  * Process started: 2016-08-03 09:39:21.375+1000
  * Process uptime: 3 hr 44 min
  * JVM startup parameters:
      - Boot classpath: `/usr/java/jdk1.7.0_60/jre/lib/resources.jar:/usr/java/jdk1.7.0_60/jre/lib/rt.jar:/usr/java/jdk1.7.0_60/jre/lib/sunrsasign.jar:/usr/java/jdk1.7.0_60/jre/lib/jsse.jar:/usr/java/jdk1.7.0_60/jre/lib/jce.jar:/usr/java/jdk1.7.0_60/jre/lib/charsets.jar:/usr/java/jdk1.7.0_60/jre/lib/jfr.jar:/usr/java/jdk1.7.0_60/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-XX:MaxPermSize=1024m`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-Duser.timezone=Australia/Canberra`
      - arg[3]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.79 'Static Analysis Utilities'
  * ant:1.3 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * bouncycastle-api:1.648.3 'bouncycastle API Plugin'
  * branch-api:1.10 'Branch API Plugin'
  * build-user-vars-plugin:1.5 'Jenkins user build vars plugin'
  * clone-workspace-scm:0.6 'Jenkins Clone Workspace SCM Plug-in'
  * cloudbees-folder:5.12 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * credentials:2.1.4 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * durable-task:1.12 'Durable Task Plugin'
  * email-ext:2.45 'Email Extension Plugin'
  * envinject:1.92.1 'Environment Injector Plugin'
  * external-monitor-job:1.6 'External Monitor Job Type Plugin'
  * findbugs:4.65 'FindBugs Plug-in'
  * git:2.5.3 'Jenkins Git plugin'
  * git-client:1.19.7 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * gitlab-hook:1.4.2 'Gitlab Hook Plugin'
  * gitlab-merge-request-jenkins:2.0.0 'Gitlab Merge Request Builder'
  * gitlab-plugin:1.3.0 'GitLab Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * hudson-wsclean-plugin:1.0.5 'Distributed Workspace Clean plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * instant-messaging:1.35 'Jenkins instant-messaging plugin'
  * ircbot:2.27 'Jenkins IRC Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jacoco:2.0.1 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jenkins-multijob-plugin:1.21 'Jenkins Multijob plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.15 'JUnit Plugin'
  * kerberos-sso:1.0.2 'Kerberos SSO plugin'
  * ldap:1.12 'LDAP Plugin'
  * mailer:1.17 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 'Matrix Project Plugin'
  * maven-plugin:2.13 'Maven Integration plugin'
  * mercurial:1.56 'Jenkins Mercurial plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * multi-slave-config-plugin:1.2.0 'Multi slave config plugin'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * naginator:1.17.1 'Naginator'
  * next-build-number:1.4 'Next Build Number Plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.32 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.2 'Pipeline: Build Step'
  * pipeline-input-step:2.0 'Pipeline: Input Step'
  * pipeline-rest-api:1.6 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.1 'Pipeline: Stage Step'
  * pipeline-stage-view:1.6 'Pipeline: Stage View Plugin'
  * ruby-runtime:0.12 'ruby-runtime'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:1.2 'SCM API Plugin'
  * script-security:1.21 'Script Security Plugin'
  * slave-setup:1.10 'Jenkins Slave SetupPlugin'
  * slave-status:1.6 'slave-status'
  * ssh-agent:1.13 'SSH Agent Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.11 'Jenkins SSH Slaves plugin'
  * structs:1.3 'Structs Plugin'
  * subversion:2.6 'Jenkins Subversion Plug-in'
  * support-core:2.32 'Support Core Plugin'
  * svnmerge:2.6 'Jenkins svnmerge plugin'
  * tap:1.25 'Jenkins TAP Plugin'
  * throttle-concurrents:1.9.0 'Jenkins Throttle Concurrent Builds Plug-in'
  * token-macro:1.12.1 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.2 'Pipeline'
  * workflow-api:2.1 'Pipeline: API'
  * workflow-basic-steps:2.1 'Pipeline: Basic Steps'
  * workflow-cps:2.10 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.1 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.4 'Pipeline: Nodes and Processes'
  * workflow-job:2.4 'Pipeline: Job'
  * workflow-multibranch:2.8 'Pipeline: Multibranch'
  * workflow-scm-step:2.2 'Pipeline: SCM Step'
  * workflow-step-api:2.3 'Pipeline: Step API'
  * workflow-support:2.2 'Pipeline: Supporting APIs'
  * ws-cleanup:0.30 'Jenkins Workspace Cleanup Plugin'
