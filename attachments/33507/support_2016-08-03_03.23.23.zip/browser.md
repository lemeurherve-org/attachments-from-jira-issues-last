Browser
=======

  * Screen size: 1920x1200
  * User Agent
      - Type:     Browser
      - Name:     Chrome
      - Family:   CHROME
      - Producer: Google Inc.
      - Version:  52.0.2743.82
      - Raw:      `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.82 Safari/537.36`
  * Operating System
      - Name:     Linux
      - Family:   LINUX
      - Producer: 
      - Version:  

