Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 25
    - Number of builds per job: 36.32 [n=25, s=100.0]

Total job statistics
======================

  * Number of jobs: 25
  * Number of builds per job: 36.32 [n=25, s=100.0]
