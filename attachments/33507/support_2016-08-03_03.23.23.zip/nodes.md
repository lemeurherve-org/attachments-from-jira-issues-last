Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      20
      - FS root:        `/var/lib/jenkins`
      - Labels:         master
      - Usage:          `NORMAL`
      - Slave Version:  2.59
      - Java
          + Home:           `/usr/java/jdk1.7.0_60/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_60
          + Maximum memory:   3.42 GB (3674210304)
          + Allocated memory: 274.50 MB (287834112)
          + Free memory:      73.48 MB (77048608)
          + In-use memory:    201.02 MB (210785504)
          + PermGen used:     116.80 MB (122471864)
          + PermGen max:      1.00 GB (1073741824)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.60-b09
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-327.13.1.el7.x86_64
      - Process ID: 979 (0x3d3)
      - Process started: 2016-08-03 09:39:21.375+1000
      - Process uptime: 3 hr 44 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.7.0_60/jre/lib/resources.jar:/usr/java/jdk1.7.0_60/jre/lib/rt.jar:/usr/java/jdk1.7.0_60/jre/lib/sunrsasign.jar:/usr/java/jdk1.7.0_60/jre/lib/jsse.jar:/usr/java/jdk1.7.0_60/jre/lib/jce.jar:/usr/java/jdk1.7.0_60/jre/lib/charsets.jar:/usr/java/jdk1.7.0_60/jre/lib/jfr.jar:/usr/java/jdk1.7.0_60/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=1024m`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-Duser.timezone=Australia/Canberra`
          + arg[3]: `-DJENKINS_HOME=/var/lib/jenkins`

  * build-slave (`hudson.slaves.DumbSlave`)
      - Description:    _Clean build environment for building only. Tests, doc etc use test-slave_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         builder
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * test-slave (`hudson.slaves.DumbSlave`)
      - Description:    _build environment for load sharing, testing and analysis. This slave produces java doc and runs unit tests. Use only 1 executor to ensure unit tests are not run asynchronously._
      - Executors:      4
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         tester
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

