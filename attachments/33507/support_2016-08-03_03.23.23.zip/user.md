User
====

Authentication
--------------

  * Authenticated: true
  * Name: alex.chapman
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@b11f8f73: Username: org.acegisecurity.userdetails.ldap.LdapUserDetailsImpl@22cec498; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@0: RemoteIpAddress: 192.168.0.232; SessionId: null; Granted Authorities: authenticated`

