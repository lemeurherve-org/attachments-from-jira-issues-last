Current build queue has 8 item(s).
---------------
 * Name of item: part of onprem-upgrade-with-cluster-pipeline #61
    - In queue for: 16 hr
    - Is blocked: false
    - Why in queue: Jenkins is about to shut down
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@7303209
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@2f2b7c91
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@388a88c9
    - Can run: null
----

 * Name of item: part of onprem-upgrade-with-cluster-pipeline #61
    - In queue for: 16 hr
    - Is blocked: false
    - Why in queue: Jenkins is about to shut down
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@7303209
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@2f2b7c91
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@388a88c9
    - Can run: null
----

 * Name of item: part of onprem-upgrade-with-cluster-pipeline #61
    - In queue for: 16 hr
    - Is blocked: false
    - Why in queue: Jenkins is about to shut down
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@7303209
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@2f2b7c91
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@388a88c9
    - Can run: null
----

 * Name of item: part of onprem-upgrade-with-cluster-pipeline #61
    - In queue for: 16 hr
    - Is blocked: false
    - Why in queue: Jenkins is about to shut down
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@7303209
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@2f2b7c91
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@388a88c9
    - Can run: null
----

 * Name of item: part of onprem-upgrade-with-cluster-pipeline #61
    - In queue for: 16 hr
    - Is blocked: false
    - Why in queue: Jenkins is about to shut down
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@7303209
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@2f2b7c91
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@388a88c9
    - Can run: null
----

 * Name of item: part of onprem-upgrade-with-cluster-pipeline #61
    - In queue for: 16 hr
    - Is blocked: false
    - Why in queue: Jenkins is about to shut down
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@7303209
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@2f2b7c91
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@388a88c9
    - Can run: null
----

 * Name of item: part of onprem-upgrade-with-cluster-pipeline #61
    - In queue for: 16 hr
    - Is blocked: false
    - Why in queue: Jenkins is about to shut down
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@7303209
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@2f2b7c91
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@388a88c9
    - Can run: null
----

 * Name of item: part of onprem-upgrade-with-cluster-pipeline #61
    - In queue for: 16 hr
    - Is blocked: false
    - Why in queue: Jenkins is about to shut down
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@7303209
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@2f2b7c91
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@388a88c9
    - Can run: null
----

