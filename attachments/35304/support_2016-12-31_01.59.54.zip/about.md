Jenkins
=======

Version details
---------------

  * Version: `2.32.1`
  * Mode:    WAR
  * Url:     http://webqa-ci-staging1.qa.scl3.mozilla.com:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_111
      - Maximum memory:   3.46 GB (3717201920)
      - Allocated memory: 1.56 GB (1675624448)
      - Free memory:      370.86 MB (388877160)
      - In-use memory:    1.20 GB (1286747288)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.111-b15
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-642.1.1.el6.x86_64
  * Process ID: 32723 (0x7fd3)
  * Process started: 2016-12-31 01:55:50.831+0000
  * Process uptime: 4 min 3 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/Los_Angeles`
      - arg[2]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ansicolor:0.4.3 'AnsiColor'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.0.0-b14 'Blue Ocean beta'
  * blueocean-autofavorite:0.5 'blueocean-autofavorite'
  * blueocean-commons:1.0.0-b14 'Common API for Blue Ocean'
  * blueocean-config:1.0.0-b14 'Config API for Blue Ocean'
  * blueocean-dashboard:1.0.0-b14 'Dashboard for Blue Ocean'
  * blueocean-display-url:1.3 'BlueOcean Display URL plugin'
  * blueocean-events:1.0.0-b14 'Events API for Blue Ocean'
  * blueocean-i18n:1.0.0-b14 'i18n for Blue Ocean'
  * blueocean-jwt:1.0.0-b14 'JWT for Blue Ocean'
  * blueocean-personalization:1.0.0-b14 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.0.0-b14 'Pipeline REST API for Blue Ocean'
  * blueocean-rest:1.0.0-b14 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.0.0-b14 'REST Implementation for Blue Ocean'
  * blueocean-web:1.0.0-b14 'Web for Blue Ocean'
  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * branch-api:1.11.1 'Branch API Plugin'
  * build-failure-analyzer:1.17.2 'Build Failure Analyzer'
  * build-monitor-plugin:1.10+build.201611041949 'Build Monitor View'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * claim:2.9 'Jenkins Claim Plugin'
  * cloudbees-folder:5.15 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * config-file-provider:2.15.1 'Config File Provider Plugin'
  * credentials:2.1.10 'Credentials Plugin'
  * credentials-binding:1.10 'Credentials Binding Plugin'
  * custom-tools-plugin:0.4.4 'Jenkins Custom Tools Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.10 'Dashboard View'
  * display-url-api:0.5 'Display URL API'
  * docker-commons:1.5 'Docker Commons Plugin'
  * docker-workflow:1.9.1 'Docker Pipeline'
  * durable-task:1.12 'Durable Task Plugin'
  * envinject:1.93.1 'Environment Injector Plugin'
  * extended-choice-parameter:0.75 'Extended Choice Parameter Plug-In'
  * external-monitor-job:1.6 'External Monitor Job Type Plugin'
  * favorite:2.0.4 'Favorite'
  * git:3.0.1 'Jenkins Git plugin'
  * git-client:2.1.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.25.0 'GitHub plugin'
  * github-api:1.82 'GitHub API Plugin'
  * github-branch-source:1.10.1 'GitHub Branch Source Plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.11 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * instant-messaging:1.35 'Jenkins instant-messaging plugin'
  * ircbot:2.27 'Jenkins IRC Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jobConfigHistory:2.15 'Jenkins Job Configuration History Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.19 'JUnit Plugin'
  * ldap:1.13 'LDAP Plugin'
  * mailer:1.18 'Jenkins Mailer Plugin'
  * managed-scripts:1.3 'Managed Scripts'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 'Matrix Project Plugin'
  * maven-plugin:2.14 'Maven Integration plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * monitoring:1.62.0 'Monitoring'
  * ownership:0.9.0 'Job and Node ownership plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.32 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.4 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.5 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3 'Pipeline: Milestone Step'
  * pipeline-model-api:0.7.1 'Pipeline: Model API'
  * pipeline-model-declarative-agent:0.7.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:0.7.1 'Pipeline: Model Definition'
  * pipeline-rest-api:2.4 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:0.7.1 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.4 'Pipeline: Stage View Plugin'
  * plain-credentials:1.3 'Plain Credentials Plugin'
  * project-build-times:1.2.1 'Project Build Times'
  * rebuild:1.25 'Rebuilder'
  * resource-disposer:0.3 'Resource Disposer Plugin'
  * role-strategy:2.3.2 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:1.3 'SCM API Plugin'
  * script-security:1.24 'Script Security Plugin'
  * sse-gateway:1.10 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.12 'Jenkins SSH Slaves plugin'
  * structs:1.5 'Structs Plugin'
  * subversion:2.7.1 'Jenkins Subversion Plug-in'
  * support-core:2.38 'Support Core Plugin'
  * test-stability:1.0 'Test stability history'
  * testdroid-marionette:0.0.1 'Testdroid Marionette Plugin'
  * timestamper:1.8.7 'Timestamper'
  * token-macro:2.0 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * urltrigger:0.41 'Jenkins URLTrigger Plug-in'
  * variant:1.1 'Variant Plugin'
  * view-job-filters:1.27 'View Job Filters'
  * windows-slaves:1.2 'Windows Slaves Plugin'
  * workflow-aggregator:2.4 'Pipeline'
  * workflow-api:2.8 'Pipeline: API'
  * workflow-basic-steps:2.3 'Pipeline: Basic Steps'
  * workflow-cps:2.23 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.5 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.5 'Pipeline: Nodes and Processes'
  * workflow-job:2.9 'Pipeline: Job'
  * workflow-multibranch:2.9.2 'Pipeline: Multibranch'
  * workflow-scm-step:2.3 'Pipeline: SCM Step'
  * workflow-step-api:2.6 'Pipeline: Step API'
  * workflow-support:2.11 'Pipeline: Supporting APIs'
  * ws-cleanup:0.32 'Jenkins Workspace Cleanup Plugin'
  * xvfb:1.1.3 'Jenkins Xvfb plugin'
  * zaproxy:1.2.1 'ZAProxy Plugin'
