Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 6
    - Number of builds per job: 46.666666666666664 [n=6, s=50.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 4
    - Number of builds per job: 28.5 [n=4, s=10.0]

Total job statistics
======================

  * Number of jobs: 10
  * Number of builds per job: 39.4 [n=10, s=40.0]
