Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 26.842GB left on /var/lib/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:3162/15951MB  Swap:2039/2047MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 26.842GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
Ownership
----
 - Is Ignored: false
 - Computers:
   * master: unknown
