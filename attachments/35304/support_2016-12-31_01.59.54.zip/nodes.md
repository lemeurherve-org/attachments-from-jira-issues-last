Node statistics
===============

  * Total number of nodes
      - Sample size:        15
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        15
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        15
      - Average (mean):     14.999999999999998
      - Average (median):   15.0
      - Standard deviation: 1.7763568394002505E-15
      - Minimum:            15
      - Maximum:            15
      - 95th percentile:    15.0
      - 99th percentile:    15.0
  * Total number of executors in use
      - Sample size:        15
      - Average (mean):     0.02198864433802568
      - Average (median):   0.0
      - Standard deviation: 0.14664632234802716
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    0.0
      - 99th percentile:    1.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      15
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   3.46 GB (3717201920)
          + Allocated memory: 1.56 GB (1675624448)
          + Free memory:      369.50 MB (387453752)
          + In-use memory:    1.20 GB (1288170696)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-642.1.1.el6.x86_64
      - Process ID: 32723 (0x7fd3)
      - Process started: 2016-12-31 01:55:50.831+0000
      - Process uptime: 4 min 3 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-0.b15.el6_8.x86_64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/Los_Angeles`
          + arg[2]: `-DJENKINS_HOME=/var/lib/jenkins`

