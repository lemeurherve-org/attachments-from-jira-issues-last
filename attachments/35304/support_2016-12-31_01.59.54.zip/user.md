User
====

Authentication
--------------

  * Authenticated: true
  * Name: stephend
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@5a5ea1a1: Username: hudson.security.HudsonPrivateSecurityRealm$Details@36739546; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@fffc7f0c: RemoteIpAddress: 10.22.248.30; SessionId: 178spn02fhnc8iyzb9m9boiav; Granted Authorities: authenticated`

