Jenkins
=======

Version details
---------------

  * Version: `2.32.1`
  * Mode:    WAR
  * Url:     null
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_111
      - Maximum memory:   3.56 GB (3817865216)
      - Allocated memory: 1.45 GB (1553989632)
      - Free memory:      628.89 MB (659441376)
      - In-use memory:    853.11 MB (894548256)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.111-b14
  * Operating system
      - Name:         Mac OS X
      - Architecture: x86_64
      - Version:      10.11.6
  * Process ID: 26597 (0x67e5)
  * Process started: 2017-01-11 09:22:35.263+0100
  * Process uptime: 2 min 2 sec
  * JVM startup parameters:
      - Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/classes`
      - Classpath: `jenkins.war`
      - Library path: `/Users/egutierrez/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * config-file-provider:2.15.3 'Config File Provider Plugin'
  * credentials:2.1.10 'Credentials Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * structs:1.5 'Structs Plugin'
  * support-core:2.38 'Support Core Plugin'
  * token-macro:2.0 'Token Macro Plugin'
