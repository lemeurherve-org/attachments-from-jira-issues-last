-----------
 * Name awdl0
 ** Hardware Address - 963473c5d95a
 ** Index - 8
 ** InetAddress - /fe80:0:0:0:9434:73ff:fec5:d95a%awdl0
 ** MTU - 1484
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name en0
 ** Hardware Address - c4b301d5e1f7
 ** Index - 4
 ** InetAddress - /fe80:0:0:0:c6b3:1ff:fed5:e1f7%en0
 ** InetAddress - /192.168.1.113
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo0
 ** Index - 1
 ** InetAddress - /fe80:0:0:0:0:0:0:1%lo0
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** InetAddress - /127.0.0.1
 ** MTU - 16384
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
