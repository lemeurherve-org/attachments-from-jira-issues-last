Jenkins
=======

Version details
---------------

  * Version: `2.32.1`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_111
      - Maximum memory:   2.61 GB (2798125056)
      - Allocated memory: 1.25 GB (1343750144)
      - Free memory:      530.26 MB (556014328)
      - In-use memory:    751.24 MB (787735816)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.111-b14
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.2.0-42-generic
  * Process ID: 7 (0x7)
  * Process started: 2017-01-17 22:22:31.601+0100
  * Process uptime: 22 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.0 'Jenkins Active Directory plugin'
  * analysis-collector:1.50 'Static Analysis Collector Plug-in'
  * analysis-core:1.81 *(update available)* 'Static Analysis Utilities'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bitbucket:1.1.5 'Jenkins Bitbucket Plugin'
  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * branch-api:1.11.1 *(update available)* 'Branch API Plugin'
  * build-environment:1.6 'Build Environment Plugin'
  * build-failure-analyzer:1.17.2 'Build Failure Analyzer'
  * build-name-setter:1.6.5 'build-name-setter'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * cloudbees-folder:5.15 *(update available)* 'Folders Plugin'
  * cobertura:1.9.8 'Jenkins Cobertura Plugin'
  * compact-columns:1.10 'Compact Columns'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.10 'Credentials Plugin'
  * credentials-binding:1.10 'Credentials Binding Plugin'
  * custom-tools-plugin:0.4.4 'Jenkins Custom Tools Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.10 'Dashboard View'
  * display-url-api:0.5 'Display URL API'
  * docker-commons:1.5 *(update available)* 'Docker Commons Plugin'
  * docker-workflow:1.9.1 'Docker Pipeline'
  * durable-task:1.12 'Durable Task Plugin'
  * email-ext:2.53 'Email Extension Plugin'
  * embeddable-build-status:1.9 'embeddable-build-status'
  * emotional-jenkins-plugin:1.2 'emotional-jenkins-plugin'
  * envinject:1.93.1 'Environment Injector Plugin'
  * extended-choice-parameter:0.75 'Extended Choice Parameter Plug-In'
  * external-monitor-job:1.6 *(update available)* 'External Monitor Job Type Plugin'
  * git:3.0.1 *(update available)* 'Jenkins Git plugin'
  * git-client:2.2.0 *(update available)* 'Jenkins Git client plugin'
  * git-parameter:0.7.1 'Git Parameter Plug-In'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.25.0 *(update available)* 'GitHub plugin'
  * github-api:1.82 *(update available)* 'GitHub API Plugin'
  * github-branch-source:1.10.1 *(update available)* 'GitHub Branch Source Plugin'
  * github-organization-folder:1.5 *(update available)* 'GitHub Organization Folder Plugin'
  * gradle:1.25 'Gradle Plugin'
  * gravatar:2.1 'Jenkins Gravatar plugin'
  * greenballs:1.15 'Green Balls'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.11 *(update available)* 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * job-poll-action-plugin:1.0 'Job Poll Action Plugin'
  * jobConfigHistory:2.15 'Jenkins Job Configuration History Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.19 'JUnit Plugin'
  * ldap:1.13 'LDAP Plugin'
  * mailer:1.18 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:2.14 'Maven Integration plugin'
  * mercurial:1.57 *(update available)* 'Jenkins Mercurial plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * modernstatus:1.2 'Modern Status'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * monitoring:1.62.0 *(update available)* 'Monitoring'
  * msbuild:1.26 'Jenkins MSBuild Plugin'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * nunit:0.18 'Jenkins NUnit plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * pegdown-formatter:1.3 'PegDown Formatter Plugin'
  * pipeline-build-step:2.4 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.5 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3 'Pipeline: Milestone Step'
  * pipeline-rest-api:2.4 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-view:2.4 'Pipeline: Stage View Plugin'
  * plain-credentials:1.3 'Plain Credentials Plugin'
  * pollscm:1.3 'Jenkins Poll SCM plugin'
  * promoted-builds:2.28 'Jenkins promoted builds plugin'
  * resource-disposer:0.3 *(update available)* 'Resource Disposer Plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:1.3 *(update available)* 'SCM API Plugin'
  * script-security:1.24 *(update available)* 'Script Security Plugin'
  * shelve-project-plugin:1.5 'Shelve Project Plugin'
  * sidebar-link:1.7 'Sidebar Link'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.12 'Jenkins SSH Slaves plugin'
  * stashNotifier:1.11.4 'Stash Notifier'
  * structs:1.5 'Structs Plugin'
  * subversion:2.7.1 'Jenkins Subversion Plug-in'
  * support-core:2.38 'Support Core Plugin'
  * tasks:4.50 'Task Scanner Plug-in'
  * timestamper:1.8.7 'Timestamper'
  * token-macro:2.0 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * violation-comments-to-stash:1.42 'Jenkins Violation Comments to Bitbucket Server Plugin'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.58 *(update available)* 'Warnings Plug-in'
  * windows-slaves:1.2 'Windows Slaves Plugin'
  * workflow-aggregator:2.4 'Pipeline'
  * workflow-api:2.8 'Pipeline: API'
  * workflow-basic-steps:2.3 'Pipeline: Basic Steps'
  * workflow-cps:2.23 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.5 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.5 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.9 'Pipeline: Job'
  * workflow-multibranch:2.9.2 *(update available)* 'Pipeline: Multibranch'
  * workflow-remote-loader:1.3 'Jenkins Pipeline Remote Loader Plugin'
  * workflow-scm-step:2.3 'Pipeline: SCM Step'
  * workflow-step-api:2.6 *(update available)* 'Pipeline: Step API'
  * workflow-support:2.11 *(update available)* 'Pipeline: Supporting APIs'
  * ws-cleanup:0.32 'Jenkins Workspace Cleanup Plugin'
  * xunit:1.102 'xUnit plugin'
