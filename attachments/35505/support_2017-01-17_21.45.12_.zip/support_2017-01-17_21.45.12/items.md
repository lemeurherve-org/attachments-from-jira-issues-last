Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 39
    - Number of builds per job: 128.82051282051282 [n=39, s=200.0]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 1
    - Number of items per container: 0 [n=1]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 95
    - Number of builds per job: 25.357894736842105 [n=95, s=60.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 4
    - Number of items per container: 18.75 [n=4, s=20.0]

Total job statistics
======================

  * Number of jobs: 134
  * Number of builds per job: 55.47014925373134 [n=134, s=130.0]
