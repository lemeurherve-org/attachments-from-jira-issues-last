Loggers currently enabled
=========================
org.acegisecurity.providers.ldap - ALL
jenkins.security - ALL
org.acegisecurity.ldap - ALL
hudson.security - ALL
org.apache.sshd - WARNING
winstone - INFO
 - INFO
