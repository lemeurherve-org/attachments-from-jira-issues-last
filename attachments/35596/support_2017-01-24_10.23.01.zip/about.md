Jenkins
=======

Version details
---------------

  * Version: `2.32.1`
  * Mode:    WAR
  * Url:     https://jenkins.opendaylight.org/sandbox/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_121
      - Maximum memory:   1.70 GB (1823473664)
      - Allocated memory: 869.00 MB (911212544)
      - Free memory:      525.48 MB (551000520)
      - In-use memory:    343.52 MB (360212024)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.121-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-514.6.1.el7.x86_64
  * Process ID: 22783 (0x58ff)
  * Process started: 2017-01-24 02:04:50.248+0000
  * Process uptime: 8 hr 18 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-Djenkins.install.runSetupWizard=false`
      - arg[3]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.82 'Static Analysis Utilities'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * branch-api:1.11.1 'Branch API Plugin'
  * build-failure-analyzer:1.17.2 'Build Failure Analyzer'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * buildresult-trigger:0.17 'Jenkins BuildResultTrigger Plug-in'
  * clone-workspace-scm:0.6 'Jenkins Clone Workspace SCM Plug-in'
  * cloud-stats:0.6 'Cloud Statistics Plugin'
  * cloudbees-folder:5.16 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * config-file-provider:2.15.5 'Config File Provider Plugin'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.10 'Credentials Plugin'
  * credentials-binding:1.10 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.10 'Dashboard View'
  * depgraph-view:0.11 'Dependency Graph Viewer Plugin'
  * description-setter:1.10 'Jenkins description setter plugin'
  * display-url-api:0.5 'Display URL API'
  * durable-task:1.13 'Durable Task Plugin'
  * dynamic-axis:1.0.3 'Dynamic Axis'
  * email-ext:2.53 *(update available)* 'Email Extension Plugin'
  * envinject:1.93.1 'Environment Injector Plugin'
  * extended-read-permission:1.0 'Hudson Extended Read Permission Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * findbugs:4.69 'FindBugs Plug-in'
  * gearman-plugin:0.2.0 'Gearman Plugin'
  * gerrit-trigger:2.23.0 'Gerrit Trigger'
  * git:3.0.1 'Jenkins Git plugin'
  * git-client:2.2.1 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * gradle:1.25 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * http_request:1.8.13 'HTTP Request Plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * ivy:1.27.1 'Ivy Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jacoco:2.1.0 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jobConfigHistory:2.15 'Jenkins Job Configuration History Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.19 'JUnit Plugin'
  * ldap:1.13 *(update available)* 'LDAP Plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * m2-repo-reaper:1.0 'M2 Repository Cleanup Plugin'
  * mailer:1.18 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mask-passwords:2.9 'Mask Passwords Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.8 'Matrix Project Plugin'
  * maven-plugin:2.14 'Maven Integration plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * msginject:0.1.1 'Message Injector Plugin'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * naginator:1.17.2 'Naginator'
  * openstack-cloud:2.11 *(update available)* 'Openstack Cloud Plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.32 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.4 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.5 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3 'Pipeline: Milestone Step'
  * pipeline-rest-api:2.4 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-view:2.4 'Pipeline: Stage View Plugin'
  * plain-credentials:1.3 'Plain Credentials Plugin'
  * plot:1.9 'Plot plugin'
  * postbuildscript:0.17 'Jenkins Post-Build Script Plug-in'
  * PrioritySorter:3.5.0 'Jenkins Priority Sorter Plugin'
  * project-inheritance:1.5.3 'inheritance-plugin'
  * promoted-builds:2.28 'Jenkins promoted builds plugin'
  * rebuild:1.25 'Rebuilder'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * robot:1.6.4 'Robot Framework plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * schedule-build:0.3.4 'Schedule Build Plugin'
  * scm-api:1.3 'SCM API Plugin'
  * script-security:1.25 'Script Security Plugin'
  * scripttrigger:0.34 'scripttrigger'
  * shiningpanda:0.23 'ShiningPanda Plugin'
  * sonar:2.5 'Jenkins SonarQube Plugin'
  * ssh-agent:1.13 'SSH Agent Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.12 'Jenkins SSH Slaves plugin'
  * structs:1.5 'Structs Plugin'
  * subversion:2.7.1 'Jenkins Subversion Plug-in'
  * support-core:2.38 'Support Core Plugin'
  * swarm:2.2 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * timestamper:1.8.7 *(update available)* 'Timestamper'
  * token-macro:2.0 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * urltrigger:0.41 'Jenkins URLTrigger Plug-in'
  * windows-slaves:1.2 'Windows Slaves Plugin'
  * workflow-aggregator:2.4 'Pipeline'
  * workflow-api:2.8 'Pipeline: API'
  * workflow-basic-steps:2.3 'Pipeline: Basic Steps'
  * workflow-cps:2.24 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.5 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.8 'Pipeline: Nodes and Processes'
  * workflow-job:2.9 'Pipeline: Job'
  * workflow-multibranch:2.9.2 'Pipeline: Multibranch'
  * workflow-scm-step:2.3 'Pipeline: SCM Step'
  * workflow-step-api:2.7 'Pipeline: Step API'
  * workflow-support:2.12 'Pipeline: Supporting APIs'
  * ws-cleanup:0.32 'Jenkins Workspace Cleanup Plugin'
  * zmq-event-publisher:0.0.5 'Jenkins Event Publisher (via ZMQ PUB SUB)'
