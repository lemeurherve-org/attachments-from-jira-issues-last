Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 45
    - Number of builds per job: 4.733333333333333 [n=45, s=5.0]

Total job statistics
======================

  * Number of jobs: 45
  * Number of builds per job: 4.733333333333333 [n=45, s=5.0]
