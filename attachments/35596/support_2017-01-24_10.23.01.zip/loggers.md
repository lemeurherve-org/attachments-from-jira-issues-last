Loggers currently enabled
=========================
jenkins.plugins.openstack.compute - ALL
org.apache.sshd - WARNING
winstone - 5
 - INFO
