Support Bundle Manifest
=======================

Generated on 2017-01-24 10:23:01.060+0000

Requested components:

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/centos7-robot-2c-2g-1027/checksums.md5`

      - `nodes/slave/centos7-robot-2c-2g-2613/checksums.md5`

      - `nodes/slave/centos7-robot-2c-2g-2756/checksums.md5`

      - `nodes/slave/centos7-robot-2c-2g-5413/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/centos7-robot-2c-2g-1027/exportTable.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/exportTable.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/exportTable.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/environment.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/environment.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/environment.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/file-descriptors.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/file-descriptors.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/file-descriptors.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/proc/meminfo.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/proc/self/cmdline`

      - `nodes/slave/centos7-robot-2c-2g-1027/proc/self/environ`

      - `nodes/slave/centos7-robot-2c-2g-1027/proc/self/limits.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/proc/self/status.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/proc/meminfo.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/proc/self/cmdline`

      - `nodes/slave/centos7-robot-2c-2g-2613/proc/self/environ`

      - `nodes/slave/centos7-robot-2c-2g-2613/proc/self/limits.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/proc/self/status.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/proc/meminfo.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/proc/self/cmdline`

      - `nodes/slave/centos7-robot-2c-2g-2756/proc/self/environ`

      - `nodes/slave/centos7-robot-2c-2g-2756/proc/self/limits.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/proc/self/status.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/proc/meminfo.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/proc/self/cmdline`

      - `nodes/slave/centos7-robot-2c-2g-5413/proc/self/environ`

      - `nodes/slave/centos7-robot-2c-2g-5413/proc/self/limits.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/centos7-autorelease-4c-16g/gnuplot`

      - `load-stats/label/centos7-autorelease-4c-16g/hour.csv`

      - `load-stats/label/centos7-autorelease-4c-16g/min.csv`

      - `load-stats/label/centos7-autorelease-4c-16g/sec10.csv`

      - `load-stats/label/centos7-devstack-2c-4g/gnuplot`

      - `load-stats/label/centos7-devstack-2c-4g/hour.csv`

      - `load-stats/label/centos7-devstack-2c-4g/min.csv`

      - `load-stats/label/centos7-devstack-2c-4g/sec10.csv`

      - `load-stats/label/centos7-docker-2c-4g/gnuplot`

      - `load-stats/label/centos7-docker-2c-4g/hour.csv`

      - `load-stats/label/centos7-docker-2c-4g/min.csv`

      - `load-stats/label/centos7-docker-2c-4g/sec10.csv`

      - `load-stats/label/centos7-java-builder-2c-4g/gnuplot`

      - `load-stats/label/centos7-java-builder-2c-4g/hour.csv`

      - `load-stats/label/centos7-java-builder-2c-4g/min.csv`

      - `load-stats/label/centos7-java-builder-2c-4g/sec10.csv`

      - `load-stats/label/centos7-java-builder-2c-8g/gnuplot`

      - `load-stats/label/centos7-java-builder-2c-8g/hour.csv`

      - `load-stats/label/centos7-java-builder-2c-8g/min.csv`

      - `load-stats/label/centos7-java-builder-2c-8g/sec10.csv`

      - `load-stats/label/centos7-java-builder-4c-8g/gnuplot`

      - `load-stats/label/centos7-java-builder-4c-8g/hour.csv`

      - `load-stats/label/centos7-java-builder-4c-8g/min.csv`

      - `load-stats/label/centos7-java-builder-4c-8g/sec10.csv`

      - `load-stats/label/centos7-java-builder-8c-8g/gnuplot`

      - `load-stats/label/centos7-java-builder-8c-8g/hour.csv`

      - `load-stats/label/centos7-java-builder-8c-8g/min.csv`

      - `load-stats/label/centos7-java-builder-8c-8g/sec10.csv`

      - `load-stats/label/centos7-robot-2c-2g-1027/gnuplot`

      - `load-stats/label/centos7-robot-2c-2g-1027/hour.csv`

      - `load-stats/label/centos7-robot-2c-2g-1027/min.csv`

      - `load-stats/label/centos7-robot-2c-2g-1027/sec10.csv`

      - `load-stats/label/centos7-robot-2c-2g-2613/gnuplot`

      - `load-stats/label/centos7-robot-2c-2g-2613/hour.csv`

      - `load-stats/label/centos7-robot-2c-2g-2613/min.csv`

      - `load-stats/label/centos7-robot-2c-2g-2613/sec10.csv`

      - `load-stats/label/centos7-robot-2c-2g-2756/gnuplot`

      - `load-stats/label/centos7-robot-2c-2g-2756/hour.csv`

      - `load-stats/label/centos7-robot-2c-2g-2756/min.csv`

      - `load-stats/label/centos7-robot-2c-2g-2756/sec10.csv`

      - `load-stats/label/centos7-robot-2c-2g-5413/gnuplot`

      - `load-stats/label/centos7-robot-2c-2g-5413/hour.csv`

      - `load-stats/label/centos7-robot-2c-2g-5413/min.csv`

      - `load-stats/label/centos7-robot-2c-2g-5413/sec10.csv`

      - `load-stats/label/centos7-robot-2c-2g/gnuplot`

      - `load-stats/label/centos7-robot-2c-2g/hour.csv`

      - `load-stats/label/centos7-robot-2c-2g/min.csv`

      - `load-stats/label/centos7-robot-2c-2g/sec10.csv`

      - `load-stats/label/dynamic_autorelease/gnuplot`

      - `load-stats/label/dynamic_autorelease/hour.csv`

      - `load-stats/label/dynamic_autorelease/min.csv`

      - `load-stats/label/dynamic_autorelease/sec10.csv`

      - `load-stats/label/dynamic_controller/gnuplot`

      - `load-stats/label/dynamic_controller/hour.csv`

      - `load-stats/label/dynamic_controller/min.csv`

      - `load-stats/label/dynamic_controller/sec10.csv`

      - `load-stats/label/dynamic_devstack/gnuplot`

      - `load-stats/label/dynamic_devstack/hour.csv`

      - `load-stats/label/dynamic_devstack/min.csv`

      - `load-stats/label/dynamic_devstack/sec10.csv`

      - `load-stats/label/dynamic_docker/gnuplot`

      - `load-stats/label/dynamic_docker/hour.csv`

      - `load-stats/label/dynamic_docker/min.csv`

      - `load-stats/label/dynamic_docker/sec10.csv`

      - `load-stats/label/dynamic_java/gnuplot`

      - `load-stats/label/dynamic_java/hour.csv`

      - `load-stats/label/dynamic_java/min.csv`

      - `load-stats/label/dynamic_java/sec10.csv`

      - `load-stats/label/dynamic_java_8g/gnuplot`

      - `load-stats/label/dynamic_java_8g/hour.csv`

      - `load-stats/label/dynamic_java_8g/min.csv`

      - `load-stats/label/dynamic_java_8g/sec10.csv`

      - `load-stats/label/dynamic_merge/gnuplot`

      - `load-stats/label/dynamic_merge/hour.csv`

      - `load-stats/label/dynamic_merge/min.csv`

      - `load-stats/label/dynamic_merge/sec10.csv`

      - `load-stats/label/dynamic_merge_4c/gnuplot`

      - `load-stats/label/dynamic_merge_4c/hour.csv`

      - `load-stats/label/dynamic_merge_4c/min.csv`

      - `load-stats/label/dynamic_merge_4c/sec10.csv`

      - `load-stats/label/dynamic_merge_8c/gnuplot`

      - `load-stats/label/dynamic_merge_8c/hour.csv`

      - `load-stats/label/dynamic_merge_8c/min.csv`

      - `load-stats/label/dynamic_merge_8c/sec10.csv`

      - `load-stats/label/dynamic_robot/gnuplot`

      - `load-stats/label/dynamic_robot/hour.csv`

      - `load-stats/label/dynamic_robot/min.csv`

      - `load-stats/label/dynamic_robot/sec10.csv`

      - `load-stats/label/dynamic_verify/gnuplot`

      - `load-stats/label/dynamic_verify/hour.csv`

      - `load-stats/label/dynamic_verify/min.csv`

      - `load-stats/label/dynamic_verify/sec10.csv`

      - `load-stats/label/dynamic_verify_4c/gnuplot`

      - `load-stats/label/dynamic_verify_4c/hour.csv`

      - `load-stats/label/dynamic_verify_4c/min.csv`

      - `load-stats/label/dynamic_verify_4c/sec10.csv`

      - `load-stats/label/dynamic_verify_8c/gnuplot`

      - `load-stats/label/dynamic_verify_8c/hour.csv`

      - `load-stats/label/dynamic_verify_8c/min.csv`

      - `load-stats/label/dynamic_verify_8c/sec10.csv`

      - `load-stats/label/gbp_trusty/gnuplot`

      - `load-stats/label/gbp_trusty/hour.csv`

      - `load-stats/label/gbp_trusty/min.csv`

      - `load-stats/label/gbp_trusty/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/ubuntu-trusty-gbp-2c-2g/gnuplot`

      - `load-stats/label/ubuntu-trusty-gbp-2c-2g/hour.csv`

      - `load-stats/label/ubuntu-trusty-gbp-2c-2g/min.csv`

      - `load-stats/label/ubuntu-trusty-gbp-2c-2g/sec10.csv`

      - `load-stats/label/ubuntu-trusty-gbp-2c-4g/gnuplot`

      - `load-stats/label/ubuntu-trusty-gbp-2c-4g/hour.csv`

      - `load-stats/label/ubuntu-trusty-gbp-2c-4g/min.csv`

      - `load-stats/label/ubuntu-trusty-gbp-2c-4g/sec10.csv`

      - `load-stats/label/ubuntu-trusty-mininet-2c-2g/gnuplot`

      - `load-stats/label/ubuntu-trusty-mininet-2c-2g/hour.csv`

      - `load-stats/label/ubuntu-trusty-mininet-2c-2g/min.csv`

      - `load-stats/label/ubuntu-trusty-mininet-2c-2g/sec10.csv`

      - `load-stats/label/ubuntu-trusty-mininet-ovs-23-2c-2g/gnuplot`

      - `load-stats/label/ubuntu-trusty-mininet-ovs-23-2c-2g/hour.csv`

      - `load-stats/label/ubuntu-trusty-mininet-ovs-23-2c-2g/min.csv`

      - `load-stats/label/ubuntu-trusty-mininet-ovs-23-2c-2g/sec10.csv`

      - `load-stats/label/ubuntu-trusty-mininet-ovs-25-2c-2g/gnuplot`

      - `load-stats/label/ubuntu-trusty-mininet-ovs-25-2c-2g/hour.csv`

      - `load-stats/label/ubuntu-trusty-mininet-ovs-25-2c-2g/min.csv`

      - `load-stats/label/ubuntu-trusty-mininet-ovs-25-2c-2g/sec10.csv`

      - `load-stats/label/ubuntu_mininet/gnuplot`

      - `load-stats/label/ubuntu_mininet/hour.csv`

      - `load-stats/label/ubuntu_mininet/min.csv`

      - `load-stats/label/ubuntu_mininet/sec10.csv`

      - `load-stats/label/ubuntu_mininet_ovs_23/gnuplot`

      - `load-stats/label/ubuntu_mininet_ovs_23/hour.csv`

      - `load-stats/label/ubuntu_mininet_ovs_23/min.csv`

      - `load-stats/label/ubuntu_mininet_ovs_23/sec10.csv`

      - `load-stats/label/ubuntu_mininet_ovs_25/gnuplot`

      - `load-stats/label/ubuntu_mininet_ovs_25/hour.csv`

      - `load-stats/label/ubuntu_mininet_ovs_25/min.csv`

      - `load-stats/label/ubuntu_mininet_ovs_25/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/centos7-robot-2c-2g-1027/metrics.json`

      - `nodes/slave/centos7-robot-2c-2g-2613/metrics.json`

      - `nodes/slave/centos7-robot-2c-2g-2756/metrics.json`

      - `nodes/slave/centos7-robot-2c-2g-5413/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/centos7-robot-2c-2g-1027/networkInterface.md`

      - `nodes/slave/centos7-robot-2c-2g-2613/networkInterface.md`

      - `nodes/slave/centos7-robot-2c-2g-2756/networkInterface.md`

      - `nodes/slave/centos7-robot-2c-2g-5413/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/dmesg.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/dmi.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/proc/cpuinfo.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/proc/mounts.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/proc/swaps.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/proc/system-uptime.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/sysctl.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/userid.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/dmesg.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/dmi.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/proc/cpuinfo.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/proc/mounts.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/proc/swaps.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/proc/system-uptime.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/sysctl.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/userid.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/dmesg.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/dmi.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/proc/cpuinfo.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/proc/mounts.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/proc/swaps.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/proc/system-uptime.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/sysctl.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/userid.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/dmesg.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/dmi.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/proc/cpuinfo.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/proc/mounts.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/proc/swaps.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/proc/system-uptime.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/sysctl.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/centos7-robot-2c-2g-1027/system.properties`

      - `nodes/slave/centos7-robot-2c-2g-2613/system.properties`

      - `nodes/slave/centos7-robot-2c-2g-2756/system.properties`

      - `nodes/slave/centos7-robot-2c-2g-5413/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/centos7-robot-2c-2g-1027/thread-dump.txt`

      - `nodes/slave/centos7-robot-2c-2g-2613/thread-dump.txt`

      - `nodes/slave/centos7-robot-2c-2g-2756/thread-dump.txt`

      - `nodes/slave/centos7-robot-2c-2g-5413/thread-dump.txt`

