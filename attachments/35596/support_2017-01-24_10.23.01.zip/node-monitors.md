Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * centos7-robot-2c-2g-1027: Linux (amd64)
   * centos7-robot-2c-2g-2613: Linux (amd64)
   * centos7-robot-2c-2g-2756: Linux (amd64)
   * centos7-robot-2c-2g-5413: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * centos7-robot-2c-2g-1027: In sync
   * centos7-robot-2c-2g-2613: In sync
   * centos7-robot-2c-2g-2756: In sync
   * centos7-robot-2c-2g-5413: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 492.524GB left on /var/lib/jenkins.
   * centos7-robot-2c-2g-1027: Disk space is too low. Only 38.135GB left on /w.
   * centos7-robot-2c-2g-2613: Disk space is too low. Only 37.022GB left on /w.
   * centos7-robot-2c-2g-2756: Disk space is too low. Only 37.974GB left on /w.
   * centos7-robot-2c-2g-5413: Disk space is too low. Only 37.027GB left on /w.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:230/7822MB  Swap:494/499MB
   * centos7-robot-2c-2g-1027: Memory:927/1839MB  Swap:0/0MB
   * centos7-robot-2c-2g-2613: Memory:518/1839MB  Swap:0/0MB
   * centos7-robot-2c-2g-2756: Memory:410/1839MB  Swap:0/0MB
   * centos7-robot-2c-2g-5413: Memory:509/1839MB  Swap:0/0MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 77.613GB left on /tmp.
   * centos7-robot-2c-2g-1027: Disk space is too low. Only 38.135GB left on /tmp.
   * centos7-robot-2c-2g-2613: Disk space is too low. Only 37.022GB left on /tmp.
   * centos7-robot-2c-2g-2756: Disk space is too low. Only 37.974GB left on /tmp.
   * centos7-robot-2c-2g-5413: Disk space is too low. Only 37.027GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * centos7-robot-2c-2g-1027: 59ms
   * centos7-robot-2c-2g-2613: 65ms
   * centos7-robot-2c-2g-2756: 66ms
   * centos7-robot-2c-2g-5413: 78ms
