Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      3
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 869.00 MB (911212544)
          + Free memory:      514.87 MB (539883136)
          + In-use memory:    354.13 MB (371329408)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-514.6.1.el7.x86_64
      - Process ID: 22783 (0x58ff)
      - Process started: 2017-01-24 02:04:50.248+0000
      - Process uptime: 8 hr 18 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.121-0.b13.el7_3.x86_64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-Djenkins.install.runSetupWizard=false`
          + arg[3]: `-DJENKINS_HOME=/var/lib/jenkins`

  * centos7-robot-2c-2g-1027 (`jenkins.plugins.openstack.compute.JCloudsSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/w`
      - Labels:         dynamic_robot centos7-robot-2c-2g
      - Usage:          `NORMAL`
      - Launch method:  `jenkins.plugins.openstack.compute.JCloudsLauncher`
      - Availability:   `jenkins.plugins.openstack.compute.JCloudsRetentionStrategy`
      - Status:         on-line
      - Version:        3.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   409.00 MB (428867584)
          + Allocated memory: 175.50 MB (184025088)
          + Free memory:      62.07 MB (65083312)
          + In-use memory:    113.43 MB (118941776)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-514.2.2.el7.x86_64
      - Process ID: 9578 (0x256a)
      - Process started: 2017-01-24 10:13:58.143+0000
      - Process uptime: 9 min 3 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * centos7-robot-2c-2g-2613 (`jenkins.plugins.openstack.compute.JCloudsSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/w`
      - Labels:         dynamic_robot centos7-robot-2c-2g
      - Usage:          `NORMAL`
      - Launch method:  `jenkins.plugins.openstack.compute.JCloudsLauncher`
      - Availability:   `jenkins.plugins.openstack.compute.JCloudsRetentionStrategy`
      - Status:         on-line
      - Version:        3.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   409.00 MB (428867584)
          + Allocated memory: 172.50 MB (180879360)
          + Free memory:      127.02 MB (133186968)
          + In-use memory:    45.48 MB (47692392)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-514.2.2.el7.x86_64
      - Process ID: 9573 (0x2565)
      - Process started: 2017-01-24 09:59:15.849+0000
      - Process uptime: 23 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * centos7-robot-2c-2g-2756 (`jenkins.plugins.openstack.compute.JCloudsSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/w`
      - Labels:         dynamic_robot centos7-robot-2c-2g
      - Usage:          `NORMAL`
      - Launch method:  `jenkins.plugins.openstack.compute.JCloudsLauncher`
      - Availability:   `jenkins.plugins.openstack.compute.JCloudsRetentionStrategy`
      - Status:         on-line
      - Version:        3.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   409.00 MB (428867584)
          + Allocated memory: 154.50 MB (162004992)
          + Free memory:      89.98 MB (94346184)
          + In-use memory:    64.52 MB (67658808)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-514.2.2.el7.x86_64
      - Process ID: 9605 (0x2585)
      - Process started: 2017-01-24 09:29:07.634+0000
      - Process uptime: 53 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * centos7-robot-2c-2g-5413 (`jenkins.plugins.openstack.compute.JCloudsSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/w`
      - Labels:         dynamic_robot centos7-robot-2c-2g
      - Usage:          `NORMAL`
      - Launch method:  `jenkins.plugins.openstack.compute.JCloudsLauncher`
      - Availability:   `jenkins.plugins.openstack.compute.JCloudsRetentionStrategy`
      - Status:         on-line
      - Version:        3.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   409.00 MB (428867584)
          + Allocated memory: 174.50 MB (182976512)
          + Free memory:      28.31 MB (29683608)
          + In-use memory:    146.19 MB (153292904)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-514.2.2.el7.x86_64
      - Process ID: 9574 (0x2566)
      - Process started: 2017-01-24 09:59:15.566+0000
      - Process uptime: 23 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

