-----------
 * Name eth0
 ** Hardware Address - fa163ef2d789
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:f816:3eff:fef2:d789%eth0
 ** InetAddress - /10.29.11.70
 ** MTU - 1450
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
