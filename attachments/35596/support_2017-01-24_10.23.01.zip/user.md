User
====

Authentication
--------------

  * Authenticated: true
  * Name: abelur
  * Authorities 
      - `jenkins-administrators`
      - `authenticated`
      - `nexus-thirdparty-repo-admin`
      - `ROLE_JENKINS-ADMINISTRATORS`
      - `ROLE_GERRIT-RELENG-BUILDER-COMMITTERS`
      - `admin`
      - `ROLE_IDENTITY`
      - `jenkins-sandbox-access`
      - `ROLE_JENKINS-SANDBOX-ACCESS`
      - `identity`
      - `ROLE_NEXUS-THIRDPARTY-REPO-ADMIN`
      - `ROLE_ADMIN`
      - `gerrit-releng-builder-committers`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@3efecdae: Username: org.acegisecurity.userdetails.ldap.LdapUserDetailsImpl@78fe0381; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@3bcc: RemoteIpAddress: 172.24.96.142; SessionId: null; Granted Authorities: jenkins-administrators, authenticated, nexus-thirdparty-repo-admin, ROLE_JENKINS-ADMINISTRATORS, ROLE_GERRIT-RELENG-BUILDER-COMMITTERS, admin, ROLE_IDENTITY, jenkins-sandbox-access, ROLE_JENKINS-SANDBOX-ACCESS, identity, ROLE_NEXUS-THIRDPARTY-REPO-ADMIN, ROLE_ADMIN, gerrit-releng-builder-committers`

