Support Bundle Manifest
=======================

Generated on 2017-01-25 12:06:31.687+0000

Requested components:

  * Slave Log Recorders

      - `nodes/slave/centos7-robot-2c-2g-1470/jenkins.log`

      - `nodes/slave/centos7-robot-2c-2g-1470/logs/all_2017-01-25_11.00.24.log`

      - `nodes/slave/centos7-robot-2c-2g-1470/logs/all_memory_buffer.log`

      - `nodes/slave/centos7-robot-2c-2g-180/jenkins.log`

      - `nodes/slave/centos7-robot-2c-2g-180/logs/all_2017-01-25_09.44.02.log`

      - `nodes/slave/centos7-robot-2c-2g-180/logs/all_memory_buffer.log`

      - `nodes/slave/centos7-robot-2c-2g-7336/jenkins.log`

      - `nodes/slave/centos7-robot-2c-2g-7336/logs/all_2017-01-25_08.09.03.log`

      - `nodes/slave/centos7-robot-2c-2g-7336/logs/all_memory_buffer.log`

      - `nodes/slave/centos7-robot-2c-2g-8134/jenkins.log`

      - `nodes/slave/centos7-robot-2c-2g-8134/logs/all_2017-01-25_11.27.06.log`

      - `nodes/slave/centos7-robot-2c-2g-8134/logs/all_memory_buffer.log`

      - `nodes/slave/centos7-robot-2c-2g-8521/jenkins.log`

      - `nodes/slave/centos7-robot-2c-2g-8521/logs/all_2017-01-25_12.00.17.log`

      - `nodes/slave/centos7-robot-2c-2g-8521/logs/all_memory_buffer.log`

      - `nodes/slave/centos7-robot-2c-2g-9451/jenkins.log`

      - `nodes/slave/centos7-robot-2c-2g-9451/logs/all_2017-01-25_11.34.27.log`

      - `nodes/slave/centos7-robot-2c-2g-9451/logs/all_memory_buffer.log`

