Jenkins
=======

Version details
---------------

  * Version: `2.44`
  * Mode:    WAR
  * Url:     http://jenkins.asti.dost.gov.ph/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-oracle/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_101
      - Maximum memory:   1.73 GB (1860698112)
      - Allocated memory: 813.50 MB (853016576)
      - Free memory:      374.54 MB (392732296)
      - In-use memory:    438.96 MB (460284280)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.101-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.13.0-65-generic
      - Distribution: Ubuntu 14.04.5 LTS
  * Process ID: 10324 (0x2854)
  * Process started: 2017-02-13 15:53:51.829+0800
  * Process uptime: 12 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.0 'Jenkins Active Directory plugin'
  * allure-jenkins-plugin:2.10 *(update available)* 'Allure Jenkins Plugin'
  * analysis-collector:1.48 *(update available)* 'Static Analysis Collector Plug-in'
  * analysis-core:1.79 *(update available)* 'Static Analysis Utilities'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * artifactory:2.7.2 *(update available)* 'Jenkins Artifactory Plugin'
  * audit-trail:2.2 'Audit Trail'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * authorize-project:1.2.2 *(update available)* 'Authorize Project'
  * avatar:1.2 'Avatar Plugin'
  * backup:1.6.1 'Backup plugin'
  * bootstrap:1.3.2 'JavaScript GUI Lib: Twitter Bootstrap bundle plugin'
  * bootstraped-multi-test-results-report:1.4.22 *(update available)* 'bootstraped-multi-test-results-report'
  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * branch-api:1.11 *(update available)* 'Branch API Plugin'
  * build-failure-analyzer:1.17.1 *(update available)* 'Build Failure Analyzer'
  * build-flow-plugin:0.20 'Build Flow plugin'
  * build-monitor-plugin:1.10+build.201610041454 *(update available)* 'Build Monitor View'
  * build-pipeline-plugin:1.5.4 *(update available)* 'Build Pipeline Plugin'
  * buildgraph-view:1.3.2 *(update available)* 'buildgraph-view'
  * buildtriggerbadge:2.5 *(update available)* 'Build Trigger Badge Plugin'
  * checkstyle:3.46 *(update available)* 'Checkstyle Plug-in'
  * chromedriver:1.2 'chromedriver'
  * cloudbees-credentials:3.3 'CloudBees Credentials Plugin'
  * cloudbees-folder:5.13 *(update available)* 'Folders Plugin'
  * cobertura:1.9.8 'Jenkins Cobertura Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * config-file-provider:2.13 *(update available)* 'Config File Provider Plugin'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * credentials:2.1.10 *(update available)* 'Credentials Plugin'
  * credentials-binding:1.10 'Credentials Binding Plugin'
  * cucumber-perf:2.0.6 *(update available)* 'cucumber-perf'
  * cucumber-reports:3.1.0 *(update available)* 'Cucumber-JVM reports'
  * cucumber-testresult-plugin:0.9.7 'Cucumber json test reporting.'
  * custom-job-icon:0.2 'Custom Job Icon plugin'
  * cvs:2.12 *(update available)* 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.10 'Dashboard View'
  * delivery-pipeline-plugin:0.9.12 *(update available)* 'Delivery Pipeline Plugin'
  * depgraph-view:0.11 'Dependency Graph Viewer Plugin'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * display-url-api:0.5 *(update available)* 'Display URL API'
  * distfork:1.4.1 'Jenkins Distributed Fork plugin'
  * distTest:1.0 'Hudson Distributed Testing Plugin'
  * docker-commons:1.5 *(update available)* 'Docker Commons Plugin'
  * docker-workflow:1.9 *(update available)* 'CloudBees Docker Pipeline'
  * dry:2.45 *(update available)* 'DRY Plug-in'
  * durable-task:1.12 *(update available)* 'Durable Task Plugin'
  * dynatrace-dashboard:2.0.4 *(update available)* 'Dynatrace Application Monitoring Plugin'
  * ec2-deployment-dashboard:1.0.10 'Deployment Dashboard Plugin for Jenkins'
  * email-ext:2.51 *(update available)* 'Email Extension Plugin'
  * emailext-template:1.0 'Email Extension Template Plugin'
  * envinject:1.93.1 'Environment Injector Plugin'
  * environment-dashboard:1.1.4 'Environment Dashboard Plugin'
  * external-monitor-job:1.6 *(update available)* 'External Monitor Job Type Plugin'
  * ez-templates:1.2.3 *(update available)* 'EZ Templates'
  * ghprb:1.33.3 *(update available)* 'GitHub Pull Request Builder'
  * git:3.0.1 *(update available)* 'Jenkins Git plugin'
  * git-client:2.1.0 *(update available)* 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.24.0 *(update available)* 'GitHub plugin'
  * github-api:1.80 *(update available)* 'GitHub API Plugin'
  * github-pullrequest:0.1.0-rc16 *(update available)* 'GitHub Integration Plugin'
  * gitlab-hook:1.4.2 'Gitlab Hook Plugin'
  * gitlab-logo:1.0.1 *(update available)* 'GitLab Logo Plugin'
  * gitlab-merge-request-jenkins:2.0.0 'Gitlab Merge Request Builder'
  * gitlab-oauth:1.0.9 'Gitlab Authentication plugin'
  * gitlab-plugin:1.4.3 *(update available)* 'GitLab Plugin'
  * gradle:1.25 'Gradle Plugin'
  * gravatar:2.1 'Jenkins Gravatar plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.11 *(update available)* 'HTML Publisher plugin'
  * htmlresource:1.02 'HTMLResource'
  * http_request:1.8.12 *(update available)* 'HTTP Request Plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * ivy:1.26 *(update available)* 'Ivy Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jenkins-jira-issue-updater:1.18 'Jenkins Jira Issue Updater'
  * jenkins-multijob-plugin:1.22 *(update available)* 'Jenkins Multijob plugin'
  * jigomerge:0.9 'Jigomerge plugin'
  * jira:2.2.1 *(update available)* 'Jenkins JIRA plugin'
  * jira-ext:0.5 *(update available)* 'jira-ext Plugin'
  * JiraTestResultReporter:2.0.3 'Jenkins JiraTestResultReporter plugin'
  * jobConfigHistory:2.15 'Jenkins Job Configuration History Plugin'
  * jobgenerator:1.22 'Job Generator'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.18 *(update available)* 'JUnit Plugin'
  * ldap:1.13 *(update available)* 'LDAP Plugin'
  * m2-repo-reaper:1.0 'M2 Repository Cleanup Plugin'
  * m2release:0.14.0 'Jenkins Maven Release Plug-in Plug-in'
  * mailer:1.18 *(update available)* 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 *(update available)* 'Matrix Project Plugin'
  * maven-dependency-update-trigger:1.5 'Maven Dependency Update Trigger'
  * maven-info:0.2.0 'Jenkins Maven Info Plugin'
  * maven-invoker-plugin:1.2 'Jenkins Maven Invoker plugin'
  * maven-plugin:2.13 *(update available)* 'Maven Integration plugin'
  * maven-release-cascade:1.3.2 'Maven Cascade Release Plugin'
  * maven-repo-cleaner:1.2 'Maven Repository Scheduled Cleanup Plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * monitoring:1.61.0 *(update available)* 'Monitoring'
  * multi-slave-config-plugin:1.2.0 'Multi slave config plugin'
  * nant:1.4.3 'NAnt Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * nunit:0.18 'Jenkins NUnit plugin'
  * nvm-wrapper:0.1.1 'nvm wrapper'
  * ownership:0.9.0 *(update available)* 'Job and Node ownership plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.32 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.3 *(update available)* 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.2 *(update available)* 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.1 *(update available)* 'Pipeline: Input Step'
  * pipeline-milestone-step:1.1 *(update available)* 'Pipeline: Milestone Step'
  * pipeline-model-api:0.6 *(update available)* 'Pipeline: Model API'
  * pipeline-model-declarative-agent:0.6 *(update available)* 'Pipeline: Declarative Agent API'
  * pipeline-rest-api:2.1 *(update available)* 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-view:2.1 *(update available)* 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.1.6 *(update available)* 'Pipeline Utility Steps'
  * plain-credentials:1.3 'Plain Credentials Plugin'
  * plot:1.9 'Plot plugin'
  * pmd:3.45 *(update available)* 'PMD Plug-in'
  * project-build-times:1.2.1 'Project Build Times'
  * project-health-report:1.2 'Project Health Report'
  * project-stats-plugin:0.4 'Project statistics Plugin'
  * promoted-builds:2.27 *(update available)* 'Jenkins promoted builds plugin'
  * promoted-builds-simple:1.9 'Promoted Builds (Simple)'
  * publish-over-cifs:0.3 'Publish Over CIFS'
  * publish-over-ssh:1.14 *(update available)* 'Publish Over SSH'
  * python:1.3 'Python Plugin'
  * radiatorviewplugin:1.26 *(update available)* 'Radiator View Plugin'
  * repository:1.3 'Jenkins Maven Repository Server Plugin'
  * robot:1.6.4 'Robot Framework plugin'
  * ruby-runtime:0.12 'ruby-runtime'
  * run-condition:1.0 'Run Condition Plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:1.3 *(update available)* 'SCM API Plugin'
  * scp:1.8 'Hudson SCP publisher plugin'
  * script-security:1.24 *(update available)* 'Script Security Plugin'
  * selenium-aes:0.5 'Selenium Auto Exec Server(AES) plugin'
  * selenium-axis:0.0.6 'Selenium Capability Axis'
  * selenium-builder:1.14 'Jenkins Selenium Builder plugin'
  * seleniumhq:0.4 'Hudson Seleniumhq plugin'
  * seleniumhtmlreport:1.0 'Selenium HTML report'
  * seleniumrc-plugin:1.0 'SeleniumRC plugin'
  * shiningpanda:0.23 'ShiningPanda Plugin'
  * simple-theme-plugin:0.3 'Simple Theme Plugin'
  * slave-prerequisites:1.0 'Slave Prerequisites plugin'
  * slave-proxy:1.1 'slave-proxy'
  * slave-setup:1.10 'Jenkins Slave SetupPlugin'
  * slave-utilization-plugin:1.8 'Slave Utilization Plugin'
  * sloccount:1.21 'Jenkins SLOCCount Plug-in'
  * ssh:2.4 'Jenkins SSH plugin'
  * ssh-agent:1.13 *(update available)* 'SSH Agent Plugin'
  * ssh-credentials:1.12 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.11 *(update available)* 'Jenkins SSH Slaves plugin'
  * ssh2easy:1.4 'SSH2 Easy Plugin'
  * structs:1.5 'Structs Plugin'
  * subversion:2.6 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.38 'Support Core Plugin'
  * svn-revert-plugin:1.3 'Subversion Revert Plugin'
  * svn-tag:1.18 'Jenkins Subversion Tagging Plugin'
  * svn-workspace-cleaner:1.1 'Subversion Workspace Cleaner'
  * svnmerge:2.6 'Jenkins svnmerge plugin'
  * svnpublisher:0.1 'SVN Publisher plugin'
  * swarm:2.2 *(update available)* 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * systemloadaverage-monitor:1.2 'Slave Monitor for system load average'
  * tasks:4.49 *(update available)* 'Task Scanner Plug-in'
  * terminate-ssh-processes-plugin:1.0 'Terminate ssh processes'
  * test-results-analyzer:0.3.4 'Test Results Analyzer Plugin'
  * test-stability:1.0 'Test stability history'
  * testlink:3.12 'Jenkins TestLink Plugin'
  * thinBackup:1.7.4 *(update available)* 'ThinBackup'
  * token-macro:2.0 'Token Macro Plugin'
  * toolenv:1.1 'Tool Environment plugin'
  * tracking-svn:1.1 'Tracking SVN Plugin'
  * unreliable-slave-plugin:1.2 'unreliable-slave-plugin'
  * variant:1.1 'Variant Plugin'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.56 *(update available)* 'Warnings Plug-in'
  * windows-slaves:1.2 'Windows Slaves Plugin'
  * workflow-aggregator:2.4 *(update available)* 'Pipeline'
  * workflow-api:2.6 *(update available)* 'Pipeline: API'
  * workflow-basic-steps:2.2 *(update available)* 'Pipeline: Basic Steps'
  * workflow-cps:2.23 *(update available)* 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.4 *(update available)* 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.5 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.9 *(update available)* 'Pipeline: Job'
  * workflow-multibranch:2.9 *(update available)* 'Pipeline: Multibranch'
  * workflow-remote-loader:1.3 'Jenkins Pipeline Remote Loader Plugin'
  * workflow-scm-step:2.2 *(update available)* 'Pipeline: SCM Step'
  * workflow-step-api:2.5 *(update available)* 'Pipeline: Step API'
  * workflow-support:2.11 *(update available)* 'Pipeline: Supporting APIs'
  * xcode-plugin:1.4.11 'Xcode integration'
  * xshell:0.10 'Jenkins cross-platform shell plugin'
  * xunit:1.102 'xUnit plugin'
  * xvfb:1.1.3 'Jenkins Xvfb plugin'
  * xvnc:1.24 'Jenkins Xvnc plugin'
