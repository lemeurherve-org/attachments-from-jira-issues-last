Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 12
    - Number of items per container: 3.25 [n=12, s=2.0]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 14
    - Number of builds per job: 10.071428571428571 [n=14, s=20.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 12
    - Number of builds per job: 11.583333333333334 [n=12, s=20.0]
    - Number of items per container: 1.1666666666666667 [n=12, s=0.6]
  * `hudson.model.FreeStyleProject`
    - Number of items: 20
    - Number of builds per job: 20.75 [n=20, s=30.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 1
    - Number of builds per job: 1 [n=1]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 1
    - Number of items per container: 0 [n=1]

Total job statistics
======================

  * Number of jobs: 47
  * Number of builds per job: 14.808510638297872 [n=47, s=20.0]
