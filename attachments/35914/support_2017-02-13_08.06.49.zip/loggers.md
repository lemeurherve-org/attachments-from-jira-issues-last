Loggers currently enabled
=========================
org.littleshoot.proxy - WARNING
org.apache.sshd - WARNING
winstone - INFO
 - INFO
