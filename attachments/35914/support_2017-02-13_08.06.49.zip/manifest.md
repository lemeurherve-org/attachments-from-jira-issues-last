Support Bundle Manifest
=======================

Generated on 2017-02-13 16:06:49.961+0800

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-02-13_07.37.15.log`

      - `nodes/master/logs/all_2017-02-13_07.53.59.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/health-checker.log`

      - `other-logs/selenium.log`

  * Slave Log Recorders

      - `nodes/slave/ubuntu-node/jenkins.log`

      - `nodes/slave/ubuntu-node/logs/all_2017-02-13_07.54.21.log`

      - `nodes/slave/ubuntu-node/logs/all_memory_buffer.log`

      - `nodes/slave/windows-node-1/jenkins.log`

      - `nodes/slave/windows-node-1/logs/all_memory_buffer.log`

      - `nodes/slave/windows-node-2/jenkins.log`

      - `nodes/slave/windows-node-2/logs/all_memory_buffer.log`

      - `nodes/slave/windows-node-3/jenkins.log`

      - `nodes/slave/windows-node-3/logs/all_memory_buffer.log`

  * Garbage Collection Logs

  * Agents config files (Encrypted secrets are redacted)

      - `nodes/slave/ubuntu-node/config.xml`

      - `nodes/slave/windows-node-1/config.xml`

      - `nodes/slave/windows-node-2/config.xml`

      - `nodes/slave/windows-node-3/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/au.com.rayh.GlobalConfigurationImpl.xml`

      - `jenkins-root-configuration-files/audit-trail.xml`

      - `jenkins-root-configuration-files/be.certipost.hudson.plugin.SCPRepositoryPublisher.xml`

      - `jenkins-root-configuration-files/build-failure-analyzer.xml`

      - `jenkins-root-configuration-files/buildtriggerbadge.xml`

      - `jenkins-root-configuration-files/com.ceilfors.jenkins.plugins.jiratrigger.JiraTriggerGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/com.dabsquared.gitlabjenkins.GitLabPushTrigger.xml`

      - `jenkins-root-configuration-files/com.dabsquared.gitlabjenkins.connection.GitLabConnectionConfig.xml`

      - `jenkins-root-configuration-files/com.dynatrace.jenkins.dashboard.TAGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/com.hp.application.automation.tools.settings.AlmServerSettingsBuilder.xml`

      - `jenkins-root-configuration-files/com.hp.application.automation.tools.settings.MCServerSettingsBuilder.xml`

      - `jenkins-root-configuration-files/com.michelin.cio.hudson.plugins.copytoslave.CopyToSlaveBuildWrapper.xml`

      - `jenkins-root-configuration-files/com.mtvi.plateng.hudson.ldap.LdapMailAddressResolver.xml`

      - `jenkins-root-configuration-files/com.mtvi.plateng.subversion.SVNPublisher.xml`

      - `jenkins-root-configuration-files/com.smartcodeltd.jenkinsci.plugins.buildmonitor.BuildMonitorView.xml`

      - `jenkins-root-configuration-files/com.synopsys.arc.jenkins.plugins.ownership.nodes.OwnerNodeProperty.xml`

      - `jenkins-root-configuration-files/com.tikal.jenkins.plugins.multijob.PhaseJobsConfig.xml`

      - `jenkins-root-configuration-files/config1.xml`

      - `jenkins-root-configuration-files/config2016.xml`

      - `jenkins-root-configuration-files/credentials-configuration.xml`

      - `jenkins-root-configuration-files/de.codecentric.jenkins.dashboard.DashboardView.xml`

      - `jenkins-root-configuration-files/de.esailors.jenkins.teststability.StabilityTestDataPublisher.xml`

      - `jenkins-root-configuration-files/envInject.xml`

      - `jenkins-root-configuration-files/envinject-plugin-configuration.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/gitlab-hook-GitlabNotifier.xml`

      - `jenkins-root-configuration-files/gitlab-hook-GitlabWebHookRootAction.xml`

      - `jenkins-root-configuration-files/hudson.distTest.DistTestingBuilder.xml`

      - `jenkins-root-configuration-files/hudson.ivy.IvyBuildTrigger.xml`

      - `jenkins-root-configuration-files/hudson.ivy.IvyModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.analysis.core.GlobalSettings.xml`

      - `jenkins-root-configuration-files/hudson.plugins.clover.CloverBuildWrapper.xml`

      - `jenkins-root-configuration-files/hudson.plugins.clover.CloverInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.depgraph_view.DependencyGraphProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.disk_usage.DiskUsageProjectActionFactory.xml`

      - `jenkins-root-configuration-files/hudson.plugins.disk_usage.DiskUsageProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.emailext.ExtendedEmailPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.gradle.Gradle.xml`

      - `jenkins-root-configuration-files/hudson.plugins.jira.JiraProjectProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.nant.NantBuilder.xml`

      - `jenkins-root-configuration-files/hudson.plugins.promoted_builds.GlobalBuildPromotedBuilds.xml`

      - `jenkins-root-configuration-files/hudson.plugins.robot.RobotConfig.xml`

      - `jenkins-root-configuration-files/hudson.plugins.seleniumhq.SeleniumhqBuilder.xml`

      - `jenkins-root-configuration-files/hudson.plugins.svn_tag.SvnTagPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.testlink.TestLinkBuilder.xml`

      - `jenkins-root-configuration-files/hudson.plugins.throttleconcurrents.ThrottleJobProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.warnings.WarningsPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.xvnc.Xvnc.xml`

      - `jenkins-root-configuration-files/hudson.scm.CVSSCM.xml`

      - `jenkins-root-configuration-files/hudson.scm.SubversionSCM.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.tools.JDKInstaller.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/jenkins.metrics.api.MetricsAccessKey.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.hipchat.HipChatNotifier.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.http_request.HttpRequest.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.maveninfo.config.MavenInfoGlobalConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.publish_over_cifs.CifsPublisherPlugin.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.publish_over_ssh.BapSshPublisherPlugin.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.shiningpanda.tools.PythonInstallation.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.ssh2easy.gssh.GsshBuilderWrapper.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.svn_revert.JenkinsGlue.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.UpdateSiteWarningsConfiguration.xml`

      - `jenkins-root-configuration-files/jobConfigHistory.xml`

      - `jenkins-root-configuration-files/maven-release-cascade.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.codefirst.SimpleThemeDecorator.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.main.modules.sshd.SSHD.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.SeleniumAxis.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.checkssh.SshProcessManager.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.conditionalbuildstep.singlestep.SingleConditionalBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.detection.unreliable.slave.UnreliableSlaveDetection.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.commons.tools.DockerTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.environmentdashboard.DashboardBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.ghprb.GhprbTrigger.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.github.pullrequest.GitHubPRTrigger.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitlab.GitlabBuildTrigger.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitlablogo.GitlabLogoProperty.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.jiraext.Config.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.mavenrepocleaner.MavenRepoCleanerProperty.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.slave_proxy.MasterToSlaveProxy.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.slave_setup.SetupConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.testresultsanalyzer.TestResultsAnalyzerExtension.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.support.steps.StageStep.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.xvfb.Xvfb.xml`

      - `jenkins-root-configuration-files/org.jfrog.hudson.ArtifactoryBuilder.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.SSHBuildWrapper.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.m2release.M2ReleaseBuildWrapper.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.repositoryconnector.RepositoryConfiguration.xml`

      - `jenkins-root-configuration-files/ownership.xml`

      - `jenkins-root-configuration-files/promoted-builds-simple.xml`

      - `jenkins-root-configuration-files/proxy.xml`

      - `jenkins-root-configuration-files/ru.yandex.qatools.allure.jenkins.AllureReportPublisher.xml`

      - `jenkins-root-configuration-files/ru.yandex.qatools.allure.jenkins.tools.AllureCommandlineInstallation.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/selenium.xml`

      - `jenkins-root-configuration-files/singleuseslave-SUSGlobalConfig.xml`

      - `jenkins-root-configuration-files/slave-status.xml`

      - `jenkins-root-configuration-files/slavestaus.xml`

      - `jenkins-root-configuration-files/smart-jenkins.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/ubuntu-node/checksums.md5`

      - `nodes/slave/windows-node-1/checksums.md5`

      - `nodes/slave/windows-node-2/checksums.md5`

      - `nodes/slave/windows-node-3/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/ubuntu-node/exportTable.txt`

      - `nodes/slave/windows-node-1/exportTable.txt`

      - `nodes/slave/windows-node-2/exportTable.txt`

      - `nodes/slave/windows-node-3/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/ubuntu-node/environment.txt`

      - `nodes/slave/windows-node-1/environment.txt`

      - `nodes/slave/windows-node-2/environment.txt`

      - `nodes/slave/windows-node-3/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/ubuntu-node/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/ubuntu-node/proc/meminfo.txt`

      - `nodes/slave/ubuntu-node/proc/self/cmdline`

      - `nodes/slave/ubuntu-node/proc/self/environ`

      - `nodes/slave/ubuntu-node/proc/self/limits.txt`

      - `nodes/slave/ubuntu-node/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/ubuntu-node/gnuplot`

      - `load-stats/label/ubuntu-node/hour.csv`

      - `load-stats/label/ubuntu-node/min.csv`

      - `load-stats/label/ubuntu-node/sec10.csv`

      - `load-stats/label/ubuntu/gnuplot`

      - `load-stats/label/ubuntu/hour.csv`

      - `load-stats/label/ubuntu/min.csv`

      - `load-stats/label/ubuntu/sec10.csv`

      - `load-stats/label/windows-10/gnuplot`

      - `load-stats/label/windows-10/hour.csv`

      - `load-stats/label/windows-10/min.csv`

      - `load-stats/label/windows-10/sec10.csv`

      - `load-stats/label/windows-node-1/gnuplot`

      - `load-stats/label/windows-node-1/hour.csv`

      - `load-stats/label/windows-node-1/min.csv`

      - `load-stats/label/windows-node-1/sec10.csv`

      - `load-stats/label/windows-node-2/gnuplot`

      - `load-stats/label/windows-node-2/hour.csv`

      - `load-stats/label/windows-node-2/min.csv`

      - `load-stats/label/windows-node-2/sec10.csv`

      - `load-stats/label/windows-node-3/gnuplot`

      - `load-stats/label/windows-node-3/hour.csv`

      - `load-stats/label/windows-node-3/min.csv`

      - `load-stats/label/windows-node-3/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/ubuntu-node/metrics.json`

      - `nodes/slave/windows-node-1/metrics.json`

      - `nodes/slave/windows-node-2/metrics.json`

      - `nodes/slave/windows-node-3/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/ubuntu-node/networkInterface.md`

      - `nodes/slave/windows-node-1/networkInterface.md`

      - `nodes/slave/windows-node-2/networkInterface.md`

      - `nodes/slave/windows-node-3/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/ubuntu-node/dmesg.txt`

      - `nodes/slave/ubuntu-node/dmi.txt`

      - `nodes/slave/ubuntu-node/proc/cpuinfo.txt`

      - `nodes/slave/ubuntu-node/proc/mounts.txt`

      - `nodes/slave/ubuntu-node/proc/swaps.txt`

      - `nodes/slave/ubuntu-node/proc/system-uptime.txt`

      - `nodes/slave/ubuntu-node/sysctl.txt`

      - `nodes/slave/ubuntu-node/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/ubuntu-node/system.properties`

      - `nodes/slave/windows-node-1/system.properties`

      - `nodes/slave/windows-node-2/system.properties`

      - `nodes/slave/windows-node-3/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/ubuntu-node/thread-dump.txt`

      - `nodes/slave/windows-node-1/thread-dump.txt`

      - `nodes/slave/windows-node-2/thread-dump.txt`

      - `nodes/slave/windows-node-3/thread-dump.txt`

