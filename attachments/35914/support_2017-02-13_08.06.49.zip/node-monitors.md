Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * ubuntu-node: Linux (amd64)
   * windows-node-1: null
   * windows-node-2: null
   * windows-node-3: null
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * ubuntu-node: In sync
   * windows-node-1: null
   * windows-node-2: null
   * windows-node-3: null
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 18.195GB left on /var/lib/jenkins.
   * ubuntu-node: Disk space is too low. Only 91.484GB left on /home/qa/jenkins.
   * windows-node-1: null
   * windows-node-2: null
   * windows-node-3: null
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:4440/7983MB  Swap:4093/4093MB
   * ubuntu-node: Memory:117/1927MB  Swap:3525/3905MB
   * windows-node-1: null
   * windows-node-2: null
   * windows-node-3: null
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 18.195GB left on /tmp.
   * ubuntu-node: Disk space is too low. Only 13.332GB left on /tmp.
   * windows-node-1: null
   * windows-node-2: null
   * windows-node-3: null
Ownership
----
 - Is Ignored: false
 - Computers:
   * master: unknown
   * ubuntu-node: unknown
   * windows-node-1: null
   * windows-node-2: null
   * windows-node-3: null
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * ubuntu-node: 69ms
   * windows-node-1: Time out for last 1 try
   * windows-node-2: Time out for last 1 try
   * windows-node-3: Time out for last 1 try
System Load Average
----
 - Is Ignored: false
 - Computers:
   * master: 01.1
   * ubuntu-node: 00.1
   * windows-node-1: null
   * windows-node-2: null
   * windows-node-3: null
