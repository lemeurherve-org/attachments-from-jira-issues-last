Node statistics
===============

  * Total number of nodes
      - Sample size:        50
      - Average (mean):     5.0
      - Average (median):   5.0
      - Standard deviation: 0.0
      - Minimum:            5
      - Maximum:            5
      - 95th percentile:    5.0
      - 99th percentile:    5.0
  * Total number of nodes online
      - Sample size:        50
      - Average (mean):     1.9999999999999998
      - Average (median):   2.0
      - Standard deviation: 2.2204460492503128E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors
      - Sample size:        50
      - Average (mean):     20.0
      - Average (median):   20.0
      - Standard deviation: 0.0
      - Minimum:            20
      - Maximum:            20
      - 95th percentile:    20.0
      - 99th percentile:    20.0
  * Total number of executors in use
      - Sample size:        50
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      5
      - FS root:        `/var/lib/jenkins`
      - Labels:         master
      - Usage:          `NORMAL`
      - Slave Version:  3.4.1
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_101
          + Maximum memory:   1.73 GB (1860698112)
          + Allocated memory: 813.50 MB (853016576)
          + Free memory:      371.34 MB (389375600)
          + In-use memory:    442.16 MB (463640976)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.101-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-65-generic
          + Distribution: Ubuntu 14.04.5 LTS
      - Process ID: 10324 (0x2854)
      - Process started: 2017-02-13 15:53:51.829+0800
      - Process uptime: 12 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`

  * ubuntu-node (`hudson.slaves.DumbSlave`)
      - Description:    _202.90.157.28-ubuntu-node-kvm port 14_
      - Executors:      15
      - Remote FS root: `/home/qa/jenkins`
      - Labels:         ubuntu
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.4.1
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_101
          + Maximum memory:   592.00 MB (620756992)
          + Allocated memory: 36.50 MB (38273024)
          + Free memory:      12.60 MB (13207216)
          + In-use memory:    23.90 MB (25065808)
          + PermGen used:     18.00 MB (18870432)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.95-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.2.0-42-generic
          + Distribution: Ubuntu 15.10
      - Process ID: 15944 (0x3e48)
      - Process started: 2017-02-13 15:54:19.317+0800
      - Process uptime: 12 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

  * windows-node-1 (`hudson.slaves.DumbSlave`)
      - Description:    _202.90.157.93-windows-node-1-kvm port 11 202.90.157.93_
      - Executors:      10
      - Remote FS root: `C:\Jenkins-Node`
      - Labels:         windows-node-1
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * windows-node-2 (`hudson.slaves.DumbSlave`)
      - Description:    _202.90.157.6-windows-node-2-kvm port 12_
      - Executors:      10
      - Remote FS root: `C:\Jenkins-Node`
      - Labels:         windows-node-2
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * windows-node-3 (`hudson.slaves.DumbSlave`)
      - Description:    _202.90.157.67-windows-node3-kvm port 13_
      - Executors:      10
      - Remote FS root: `C:\Jenkins-Node`
      - Labels:         windows-10
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

