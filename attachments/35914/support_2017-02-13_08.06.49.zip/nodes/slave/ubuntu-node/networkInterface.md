-----------
 * Name ppp0
 ** Index - 39
 ** InetAddress - /10.212.134.2
 ** MTU - 1024
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name enp0s25
 ** Hardware Address - 1078d2e8227a
 ** Index - 2
 ** InetAddress - /2001:d18:0:a:1278:d2ff:fee8:227a%2
 ** InetAddress - /fe80:0:0:0:1278:d2ff:fee8:227a%2
 ** InetAddress - /202.90.157.28
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%1
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
