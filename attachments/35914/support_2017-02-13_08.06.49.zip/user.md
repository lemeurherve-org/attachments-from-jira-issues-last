User
====

Authentication
--------------

  * Authenticated: true
  * Name: ed
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@2e948493: Username: hudson.security.HudsonPrivateSecurityRealm$Details@6b48a486; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@b364: RemoteIpAddress: 172.16.1.73; SessionId: 177kvaf3n1kcmm7kwvjqqjye1; Granted Authorities: authenticated`

