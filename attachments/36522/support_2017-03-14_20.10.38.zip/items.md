Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 2
    - Number of builds per job: 28.5 [n=2, s=10.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 9
    - Number of builds per job: 77.88888888888889 [n=9, s=50.0]

Total job statistics
======================

  * Number of jobs: 11
  * Number of builds per job: 68.9090909090909 [n=11, s=50.0]
