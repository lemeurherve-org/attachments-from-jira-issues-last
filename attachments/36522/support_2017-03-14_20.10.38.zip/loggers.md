Loggers currently enabled
=========================
com.mongodb - WARNING
org.apache.sshd - WARNING
winstone - 5
 - INFO
