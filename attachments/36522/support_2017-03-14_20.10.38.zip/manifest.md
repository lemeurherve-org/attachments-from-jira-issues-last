Support Bundle Manifest
=======================

Generated on 2017-03-14 20:10:38.586+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-03-01_21.09.51.log`

      - `nodes/master/logs/all_2017-03-02_17.04.45.log`

      - `nodes/master/logs/all_2017-03-06_16.45.51.log`

      - `nodes/master/logs/all_2017-03-07_18.32.30.log`

      - `nodes/master/logs/all_2017-03-07_23.10.39.log`

      - `nodes/master/logs/all_2017-03-08_15.39.48.log`

      - `nodes/master/logs/all_2017-03-08_21.25.52.log`

      - `nodes/master/logs/all_2017-03-14_17.09.24.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Out of order build detection.log`

      - `other-logs/health-checker.log`

  * Garbage Collection Logs

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/build-failure-analyzer.xml`

      - `jenkins-root-configuration-files/buildstep-config-files.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.GitHubPushTrigger.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.customtools.CustomTool.xml`

      - `jenkins-root-configuration-files/com.smartcodeltd.jenkinsci.plugins.buildmonitor.BuildMonitorView.xml`

      - `jenkins-root-configuration-files/com.sonyericsson.rebuild.RebuildDescriptor.xml`

      - `jenkins-root-configuration-files/custom-config-files.xml`

      - `jenkins-root-configuration-files/de.esailors.jenkins.teststability.StabilityTestDataPublisher.xml`

      - `jenkins-root-configuration-files/envInject.xml`

      - `jenkins-root-configuration-files/envinject-plugin-configuration.xml`

      - `jenkins-root-configuration-files/fr.novia.zaproxyplugin.ZAProxyBuilder.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.ansicolor.AnsiColorBuildWrapper.xml`

      - `jenkins-root-configuration-files/hudson.plugins.build_timeout.operations.BuildStepOperation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.claim.ClaimConfig.xml`

      - `jenkins-root-configuration-files/hudson.plugins.copyartifact.TriggeredBuildSelector.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.ircbot.IrcPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.s3.S3BucketPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.timestamper.TimestamperConfig.xml`

      - `jenkins-root-configuration-files/hudson.scm.CVSSCM.xml`

      - `jenkins-root-configuration-files/hudson.scm.SubversionSCM.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/jenkins.metrics.api.MetricsAccessKey.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.testdroid.DeviceSessionWrapper.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.UpdateSiteWarningsConfiguration.xml`

      - `jenkins-root-configuration-files/jobConfigHistory.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.conditionalbuildstep.singlestep.SingleConditionalBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.configfiles.GlobalConfigFiles.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.configfiles.json.JsonConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.pipeline.modeldefinition.config.GlobalConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.xvfb.Xvfb.xml`

      - `jenkins-root-configuration-files/ownership.xml`

      - `jenkins-root-configuration-files/proxy.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

  * Environment variables

      - `nodes/master/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20170106-111137.700.txt`

      - `slow-requests/20170106-214241.406.txt`

      - `slow-requests/20170106-235423.406.txt`

      - `slow-requests/20170107-000917.406.txt`

      - `slow-requests/20170108-005550.406.txt`

      - `slow-requests/20170110-191119.511.txt`

      - `slow-requests/20170119-012036.659.txt`

      - `slow-requests/20170119-121828.754.txt`

      - `slow-requests/20170119-163206.540.txt`

      - `slow-requests/20170123-172648.682.txt`

      - `slow-requests/20170124-010934.909.txt`

      - `slow-requests/20170124-051437.909.txt`

      - `slow-requests/20170126-073229.273.txt`

      - `slow-requests/20170126-172520.273.txt`

      - `slow-requests/20170126-230727.977.txt`

      - `slow-requests/20170127-133117.466.txt`

      - `slow-requests/20170127-232527.182.txt`

      - `slow-requests/20170129-070533.410.txt`

      - `slow-requests/20170131-050304.877.txt`

      - `slow-requests/20170203-053709.868.txt`

      - `slow-requests/20170207-145324.769.txt`

      - `slow-requests/20170213-122701.893.txt`

      - `slow-requests/20170213-143720.962.txt`

      - `slow-requests/20170213-173211.232.txt`

      - `slow-requests/20170217-180328.311.txt`

      - `slow-requests/20170220-102025.311.txt`

      - `slow-requests/20170221-210801.877.txt`

      - `slow-requests/20170222-185439.181.txt`

      - `slow-requests/20170222-210854.061.txt`

      - `slow-requests/20170222-211457.061.txt`

      - `slow-requests/20170222-230641.521.txt`

      - `slow-requests/20170224-011035.521.txt`

      - `slow-requests/20170228-185255.802.txt`

      - `slow-requests/20170301-225006.026.txt`

      - `slow-requests/20170307-182533.643.txt`

      - `slow-requests/20170307-230630.297.txt`

      - `slow-requests/20170308-131319.306.txt`

      - `slow-requests/20170308-153907.765.txt`

  * Deadlock Records

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

