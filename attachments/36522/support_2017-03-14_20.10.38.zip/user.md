User
====

Authentication
--------------

  * Authenticated: true
  * Name: stephend
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@dfb4cb83: Username: hudson.security.HudsonPrivateSecurityRealm$Details@4c65d9da; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@59b2: RemoteIpAddress: 10.22.248.62; SessionId: null; Granted Authorities: authenticated`

