Jenkins
=======

Version details
---------------

  * Version: `2.46.2`
  * Mode:    WAR
  * Url:     http://gpuwa-mq4.nvidia.com:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_131
      - Maximum memory:   3.45 GB (3702521856)
      - Allocated memory: 1.49 GB (1596981248)
      - Free memory:      1.27 GB (1366411032)
      - In-use memory:    219.89 MB (230570216)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.131-b11
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-327.3.1.el7.x86_64
  * Process ID: 7 (0x7)
  * Process started: 2017-05-19 17:12:00.060+0000
  * Process uptime: 18 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.AuthorizationStrategy$Unsecured`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.4 'Jenkins Active Directory plugin'
  * ant:1.4 *(update available)* 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * artifactory:2.9.2 *(update available)* 'Jenkins Artifactory Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.0.0-b25 *(update available)* 'Blue Ocean beta'
  * blueocean-autofavorite:0.6 *(update available)* 'blueocean-autofavorite'
  * blueocean-commons:1.0.0-b25 *(update available)* 'Common API for Blue Ocean'
  * blueocean-config:1.0.0-b25 *(update available)* 'Config API for Blue Ocean'
  * blueocean-dashboard:1.0.0-b25 *(update available)* 'Dashboard for Blue Ocean'
  * blueocean-display-url:1.5.1 *(update available)* 'BlueOcean Display URL plugin'
  * blueocean-events:1.0.0-b25 *(update available)* 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.0.0-b25 *(update available)* 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.0.0-b25 *(update available)* 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.0.0-b25 *(update available)* 'i18n for Blue Ocean'
  * blueocean-jwt:1.0.0-b25 *(update available)* 'JWT for Blue Ocean'
  * blueocean-personalization:1.0.0-b25 *(update available)* 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.0.0-b25 *(update available)* 'Pipeline REST API for Blue Ocean'
  * blueocean-pipeline-editor:0.1-preview-4 *(update available)* 'Blue Ocean Pipeline Editor'
  * blueocean-rest:1.0.0-b25 *(update available)* 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.0.0-b25 *(update available)* 'REST Implementation for Blue Ocean'
  * blueocean-web:1.0.0-b25 *(update available)* 'Web for Blue Ocean'
  * bouncycastle-api:2.16.0 *(update available)* 'bouncycastle API Plugin'
  * branch-api:2.0.8 *(update available)* 'Branch API Plugin'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * cloudbees-folder:6.0.2 *(update available)* 'Folders Plugin'
  * config-file-provider:2.15.6 *(update available)* 'Config File Provider Plugin'
  * credentials:2.1.13 'Credentials Plugin'
  * credentials-binding:1.10 *(update available)* 'Credentials Binding Plugin'
  * discard-old-build:1.05 'Discard Old Build plugin'
  * display-url-api:1.1.1 *(update available)* 'Display URL API'
  * docker-build-publish:1.3.2 'CloudBees Docker Build and Publish plugin'
  * docker-build-step:1.40 *(update available)* 'docker-build-step'
  * docker-commons:1.6 'Docker Commons Plugin'
  * docker-plugin:0.16.2 'Docker plugin'
  * docker-workflow:1.10 *(update available)* 'Docker Pipeline'
  * durable-task:1.13 'Durable Task Plugin'
  * email-ext:2.57 *(update available)* 'Email Extension Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.0.4 'Favorite'
  * git:3.1.0 *(update available)* 'Jenkins Git plugin'
  * git-client:2.3.0 *(update available)* 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.26.1 *(update available)* 'GitHub plugin'
  * github-api:1.85 'GitHub API Plugin'
  * github-branch-source:2.0.4 *(update available)* 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * gradle:1.26 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * ivy:1.27.1 'Ivy Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jacoco:2.1.0 *(update available)* 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.14 *(update available)* 'LDAP Plugin'
  * mailer:1.19 *(update available)* 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.8 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:2.15.1 'Maven Integration plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nexus-artifact-uploader:2.9 'Nexus Artifact Uploader'
  * Office-365-Connector:2.4.2 'Office 365 Connector'
  * ownership:0.9.1 *(update available)* 'Job and Node ownership plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * pegdown-formatter:1.3 'PegDown Formatter Plugin'
  * pipeline-build-step:2.4 *(update available)* 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.5 *(update available)* 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3 *(update available)* 'Pipeline: Milestone Step'
  * pipeline-model-api:1.0.2 *(update available)* 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.0.2 *(update available)* 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.0.2 *(update available)* 'Pipeline: Model Definition'
  * pipeline-rest-api:2.6 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.0.2 *(update available)* 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.6 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * pubsub-light:1.7 *(update available)* 'Jenkins Pub-Sub "light" Bus'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * scm-api:2.1.0 *(update available)* 'SCM API Plugin'
  * script-security:1.27 'Script Security Plugin'
  * slack:2.1 *(update available)* 'Slack Notification Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.13 *(update available)* 'Jenkins SSH Slaves plugin'
  * structs:1.6 'Structs Plugin'
  * subversion:2.7.2 'Jenkins Subversion Plug-in'
  * support-core:2.41 'Support Core Plugin'
  * template-project:1.5.2 'Template Project plugin'
  * thinBackup:1.9 'ThinBackup'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.0 *(update available)* 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.2 *(update available)* 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.12 *(update available)* 'Pipeline: API'
  * workflow-basic-steps:2.4 'Pipeline: Basic Steps'
  * workflow-cps:2.29 *(update available)* 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.7 *(update available)* 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.10 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.10 *(update available)* 'Pipeline: Job'
  * workflow-multibranch:2.14 'Pipeline: Multibranch'
  * workflow-scm-step:2.4 'Pipeline: SCM Step'
  * workflow-step-api:2.9 'Pipeline: Step API'
  * workflow-support:2.13 *(update available)* 'Pipeline: Supporting APIs'
  * ws-cleanup:0.32 *(update available)* 'Jenkins Workspace Cleanup Plugin'
