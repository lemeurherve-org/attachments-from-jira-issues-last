Browser
=======

  * Screen size: 2560x1440
  * User Agent
      - Type:     Browser
      - Name:     Safari
      - Family:   SAFARI
      - Producer: Apple Inc.
      - Version:  10.1
      - Raw:      `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.1 Safari/603.1.30`
  * Operating System
      - Name:     OS X
      - Family:   OS_X
      - Producer: Apple Computer, Inc.
      - Version:  10.12.4

