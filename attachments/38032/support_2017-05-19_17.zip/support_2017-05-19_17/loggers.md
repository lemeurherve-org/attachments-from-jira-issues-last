Loggers currently enabled
=========================
winstone - INFO
hudson.plugins.active_directory - ALL
org.apache.sshd - WARNING
 - INFO
