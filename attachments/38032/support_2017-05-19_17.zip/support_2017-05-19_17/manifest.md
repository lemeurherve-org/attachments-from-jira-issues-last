Support Bundle Manifest
=======================

Generated on 2017-05-19 17:30:20.301+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-05-19_17.27.59.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/custom/Broken AD.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/copy_reference_file.log`

      - `other-logs/health-checker.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * All loggers currently enabled.

      - `loggers.md`

