package io.oscript

import groovy.transform.Field

@Field String batEncoding = '65001'

@Field String storageDir
@Field String v8version
@Field String projectName
@Field String gitURL

///// shell script helper ////////////////
void cmd(def command){
    
    def prefix = """
@echo off
chcp $batEncoding > nul

"""
    echo prefix + command
    bat prefix + command
}

//////////////////////////////////////////////////
void buildWithStandardSteps() {
    clean()
    getSources()
    checkSyntax('')
    makeVendorCF()
    makeDistribution()
}

//////////////////////////////////////////////////
void clean(){
    echo 'Cleaning'
    cmd("call packman clear")
}

/////////////////////////////////////////////////
void getSources(){
    echo 'Loading sources from storage'
    cmd("call packman load-storage \"$storageDir\" -use-tool1cd -details storage.info")
}

/////////////////////////////////////////////////
void checkSyntax(def arguments) {
    if(arguments == ''){
        arguments = '-ThinClient -Server -ExternalConnection'
    }

    echo "Checking syntax with $arguments"
    cmd('call packman check ' + arguments)
}

/////////////////////////////////////////////////
void migrate() {
    echo 'Running Migration Task'
    cmd("call deployka run /F\"${env.WORKSPACE}/.packman/v8r_TempDB\" -v8version $v8version -command \"MIGRATE\"")
}

/////////////////////////////////////////////////
void makeVendorCF() {
    echo 'Making vendor CF'
    cmd('call packman make-cf')
}

/////////////////////////////////////////////////
void makeDistribution() {
    echo('Making files')

    cmd("""
set VPACKMAN_BUILDVARS=НомерСборкиСервера=%BUILD_NUMBER%

call packman make-dist build/package.edf -files storage.info
if errorlevel=1 exit 1

echo making zip
call packman zip-dist -name-prefix $projectName -out .
""")
}

/////////////////////////////////////////////////
return this