
import io.oscript.buildSteps

def call(body){

    def steps = new buildSteps()

    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = steps
    body()
}