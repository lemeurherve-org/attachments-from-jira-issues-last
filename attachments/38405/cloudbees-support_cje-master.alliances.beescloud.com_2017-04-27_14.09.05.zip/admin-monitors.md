Monitors
========

`jenkins.CLI`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)
