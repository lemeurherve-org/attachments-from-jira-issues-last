Browser
=======

  * Screen size: 1920x1080
  * User Agent
      - Type:     Browser
      - Name:     Chrome
      - Family:   CHROME
      - Producer: Google Inc.
      - Version:  58.0.3029.81
      - Raw:      `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36`
  * Operating System
      - Name:     OS X
      - Family:   OS_X
      - Producer: Apple Computer, Inc.
      - Version:  10.12.4

