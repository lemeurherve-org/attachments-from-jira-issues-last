# Configuration

WAR Envelope detected [cje-2.46.2.1]
Installed Envelope detected [cje-2.46.2.1]
CloudBees Assurance Program enabled: true
Allow automatic upgrades of individual plugins on startup: false
Allow automatic downgrades of individual plugins on startup: false

# Report

SUCCESS - Beekeeper Upgrade Assistant enabled on version 2.46.2.1.

## Items Requiring Attention

## Valid Items

* UPDATE_SITE CAP Update Center Configuration.
** Description: CAP Update Centers correctly configured.
** Action: No action needed.

* PLUGIN Async Http Client (async-http-client)
** Description: Correctly installed at version 1.7.24.1
** Action: No action needed.

* PLUGIN bouncycastle API Plugin (bouncycastle-api)
** Description: Correctly installed at version 2.16.1
** Action: No action needed.

* PLUGIN CloudBees License Manager (cloudbees-license)
** Description: Correctly installed at version 9.9
** Action: No action needed.

* PLUGIN CloudBees Jenkins Enterprise License Entitlement Check (nectar-license)
** Description: Correctly installed at version 8.6
** Action: No action needed.

* PLUGIN Credentials Plugin (credentials)
** Description: Correctly installed at version 2.1.13
** Action: No action needed.

* PLUGIN Jackson 2 API Plugin (jackson2-api)
** Description: Correctly installed at version 2.7.3
** Action: No action needed.

* PLUGIN Metrics Plugin (metrics)
** Description: Correctly installed at version 3.1.2.9
** Action: No action needed.

* PLUGIN Support Core Plugin (support-core)
** Description: Correctly installed at version 2.39
** Action: No action needed.

* PLUGIN Beekeeper Upgrade Assistant Plugin (cloudbees-assurance)
** Description: Correctly installed at version 2.46.0.1
** Action: No action needed.

* PLUGIN Folders Plugin (cloudbees-folder)
** Description: Correctly installed at version 6.0.3
** Action: No action needed.

* PLUGIN CloudBees Folders Plus Plugin (cloudbees-folders-plus)
** Description: Correctly installed at version 3.1
** Action: No action needed.

* PLUGIN Structs Plugin (structs)
** Description: Correctly installed at version 1.6
** Action: No action needed.

* PLUGIN JUnit Plugin (junit)
** Description: Correctly installed at version 1.20
** Action: No action needed.

* PLUGIN Display URL API (display-url-api)
** Description: Correctly installed at version 1.1.1
** Action: No action needed.

* PLUGIN Icon Shim Plugin (icon-shim)
** Description: Correctly installed at version 2.0.3
** Action: No action needed.

* PLUGIN Jenkins Mailer Plugin (mailer)
** Description: Correctly installed at version 1.20
** Action: No action needed.

* PLUGIN MapDB API Plugin (mapdb-api)
** Description: Correctly installed at version 1.0.9.0
** Action: No action needed.

* PLUGIN Matrix Authorization Strategy Plugin (matrix-auth)
** Description: Correctly installed at version 1.5
** Action: No action needed.

* PLUGIN Variant Plugin (variant)
** Description: Correctly installed at version 1.1
** Action: No action needed.

* PLUGIN CloudBees Role-Based Access Control Plugin (nectar-rbac)
** Description: Correctly installed at version 5.15
** Action: No action needed.

* PLUGIN Javadoc Plugin (javadoc)
** Description: Correctly installed at version 1.4
** Action: No action needed.

* PLUGIN Token Macro Plugin (token-macro)
** Description: Correctly installed at version 2.1
** Action: No action needed.

* PLUGIN Maven Integration plugin (maven-plugin)
** Description: Correctly installed at version 2.14
** Action: No action needed.

* PLUGIN Pipeline: Step API (workflow-step-api)
** Description: Correctly installed at version 2.9
** Action: No action needed.

* PLUGIN SCM API Plugin (scm-api)
** Description: Correctly installed at version 2.1.1
** Action: No action needed.

* PLUGIN Pipeline: API (workflow-api)
** Description: Correctly installed at version 2.12
** Action: No action needed.

* PLUGIN Script Security Plugin (script-security)
** Description: Correctly installed at version 1.27
** Action: No action needed.

* PLUGIN Pipeline: Supporting APIs (workflow-support)
** Description: Correctly installed at version 2.14
** Action: No action needed.

* PLUGIN Pipeline: Job (workflow-job)
** Description: Correctly installed at version 2.10
** Action: No action needed.

* PLUGIN Matrix Project Plugin (matrix-project)
** Description: Correctly installed at version 1.8
** Action: No action needed.

* PLUGIN Operations Center Agent (operations-center-agent)
** Description: Correctly installed at version 2.46.0.2
** Action: No action needed.

* PLUGIN SSH Credentials Plugin (ssh-credentials)
** Description: Correctly installed at version 1.13
** Action: No action needed.

* PLUGIN CloudBees SSH Build Agents Plugin (cloudbees-ssh-slaves)
** Description: Correctly installed at version 1.7
** Action: No action needed.

* PLUGIN CloudBees Monitoring Plugin (cloudbees-monitoring)
** Description: Correctly installed at version 2.5
** Action: No action needed.

* PLUGIN Jenkins promoted builds plugin (promoted-builds)
** Description: Correctly installed at version 2.28.1
** Action: No action needed.

* PLUGIN CloudBees Template Plugin (cloudbees-template)
** Description: Correctly installed at version 4.28
** Action: No action needed.

* PLUGIN Unique ID Library Plugin (unique-id)
** Description: Correctly installed at version 2.1.3
** Action: No action needed.

* PLUGIN Operations Center Context (operations-center-context)
** Description: Correctly installed at version 2.46.0.3
** Action: No action needed.

* PLUGIN Operations Center Client Plugin (operations-center-client)
** Description: Correctly installed at version 2.46.0.2
** Action: No action needed.

* PLUGIN JavaScript GUI Lib: ACE Editor bundle plugin (ace-editor)
** Description: Correctly installed at version 1.1
** Action: No action needed.

* PLUGIN Jenkins Active Directory plugin (active-directory)
** Description: Correctly installed at version 2.4
** Action: No action needed.

* PLUGIN Ant Plugin (ant)
** Description: Correctly installed at version 1.4
** Action: No action needed.

* PLUGIN OWASP Markup Formatter Plugin (antisamy-markup-formatter)
** Description: Correctly installed at version 1.5
** Action: No action needed.

* PLUGIN Authentication Tokens API Plugin (authentication-tokens)
** Description: Correctly installed at version 1.3
** Action: No action needed.

* PLUGIN Plain Credentials Plugin (plain-credentials)
** Description: Correctly installed at version 1.4
** Action: No action needed.

* PLUGIN Credentials Binding Plugin (credentials-binding)
** Description: Correctly installed at version 1.11
** Action: No action needed.

* PLUGIN Amazon Web Services SDK (aws-java-sdk)
** Description: Correctly installed at version 1.11.68
** Action: No action needed.

* PLUGIN CloudBees Amazon Web Services Credentials Plugin (aws-credentials)
** Description: Correctly installed at version 1.16
** Action: No action needed.

* PLUGIN NodeJS Plugin (nodejs)
** Description: Correctly installed at version 0.2.2
** Action: No action needed.

* PLUGIN Jenkins jQuery plugin (jquery)
** Description: Correctly installed at version 1.11.2-0
** Action: No action needed.

* PLUGIN Azure PublisherSettings Credentials Plugin (azure-publishersettings-credentials)
** Description: Correctly installed at version 1.2
** Action: No action needed.

* PLUGIN CloudBees Azure CLI Plugin (azure-cli)
** Description: Correctly installed at version 1.1
** Action: No action needed.

* PLUGIN Common API for Blue Ocean (blueocean-commons)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN Web for Blue Ocean (blueocean-web)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN Branch API Plugin (branch-api)
** Description: Correctly installed at version 2.0.8
** Action: No action needed.

* PLUGIN Pipeline: SCM Step (workflow-scm-step)
** Description: Correctly installed at version 2.4
** Action: No action needed.

* PLUGIN Jenkins Git client plugin (git-client)
** Description: Correctly installed at version 2.3.0
** Action: No action needed.

* PLUGIN Run Condition Plugin (run-condition)
** Description: Correctly installed at version 1.0
** Action: No action needed.

* PLUGIN Conditional BuildStep (conditional-buildstep)
** Description: Correctly installed at version 1.3.5
** Action: No action needed.

* PLUGIN Jenkins Parameterized Trigger plugin (parameterized-trigger)
** Description: Correctly installed at version 2.32
** Action: No action needed.

* PLUGIN Jenkins Git plugin (git)
** Description: Correctly installed at version 3.1.0
** Action: No action needed.

* PLUGIN Favorite (favorite)
** Description: Correctly installed at version 2.0.4
** Action: No action needed.

* PLUGIN blueocean-autofavorite (blueocean-autofavorite)
** Description: Correctly installed at version 0.6
** Action: No action needed.

* PLUGIN JWT for Blue Ocean (blueocean-jwt)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN REST API for Blue Ocean (blueocean-rest)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN REST Implementation for Blue Ocean (blueocean-rest-impl)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin (jquery-detached)
** Description: Correctly installed at version 1.2.1
** Action: No action needed.

* PLUGIN Pipeline: Groovy (workflow-cps)
** Description: Correctly installed at version 2.29
** Action: No action needed.

* PLUGIN Durable Task Plugin (durable-task)
** Description: Correctly installed at version 1.13
** Action: No action needed.

* PLUGIN Pipeline: Nodes and Processes (workflow-durable-task-step)
** Description: Correctly installed at version 2.10
** Action: No action needed.

* PLUGIN Pipeline: Multibranch (workflow-multibranch)
** Description: Correctly installed at version 2.14
** Action: No action needed.

* PLUGIN GitHub API Plugin (github-api)
** Description: Correctly installed at version 1.85
** Action: No action needed.

* PLUGIN GitHub plugin (github)
** Description: Correctly installed at version 1.26.2
** Action: No action needed.

* PLUGIN GitHub Branch Source Plugin (github-branch-source)
** Description: Correctly installed at version 2.0.4
** Action: No action needed.

* PLUGIN Pipeline: Input Step (pipeline-input-step)
** Description: Correctly installed at version 2.5
** Action: No action needed.

* PLUGIN Pipeline: Stage Step (pipeline-stage-step)
** Description: Correctly installed at version 2.2
** Action: No action needed.

* PLUGIN Pipeline Graph Analysis Plugin (pipeline-graph-analysis)
** Description: Correctly installed at version 1.3
** Action: No action needed.

* PLUGIN Pipeline: Basic Steps (workflow-basic-steps)
** Description: Correctly installed at version 2.4
** Action: No action needed.

* PLUGIN Jenkins GIT server Plugin (git-server)
** Description: Correctly installed at version 1.7
** Action: No action needed.

* PLUGIN Pipeline: Shared Groovy Libraries (workflow-cps-global-lib)
** Description: Correctly installed at version 2.7
** Action: No action needed.

* PLUGIN Docker Commons Plugin (docker-commons)
** Description: Correctly installed at version 1.6
** Action: No action needed.

* PLUGIN Docker Pipeline (docker-workflow)
** Description: Correctly installed at version 1.10
** Action: No action needed.

* PLUGIN Pipeline: Model API (pipeline-model-api)
** Description: Correctly installed at version 1.1.2
** Action: No action needed.

* PLUGIN Pipeline: Declarative Extension Points API (pipeline-model-extensions)
** Description: Correctly installed at version 1.1.2
** Action: No action needed.

* PLUGIN Pipeline: Declarative Agent API (pipeline-model-declarative-agent)
** Description: Correctly installed at version 1.1.1
** Action: No action needed.

* PLUGIN Pipeline: Stage Tags Metadata (pipeline-stage-tags-metadata)
** Description: Correctly installed at version 1.1.2
** Action: No action needed.

* PLUGIN Pipeline: Model Definition (pipeline-model-definition)
** Description: Correctly installed at version 1.1.2
** Action: No action needed.

* PLUGIN Pipeline REST API for Blue Ocean (blueocean-pipeline-api-impl)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN Jenkins Pub-Sub "light" Bus (pubsub-light)
** Description: Correctly installed at version 1.7
** Action: No action needed.

* PLUGIN Server Sent Events (SSE) Gateway Plugin (sse-gateway)
** Description: Correctly installed at version 1.15
** Action: No action needed.

* PLUGIN Events API for Blue Ocean (blueocean-events)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN Personalization for Blue Ocean (blueocean-personalization)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN BlueOcean Display URL plugin (blueocean-display-url)
** Description: Correctly installed at version 1.5.1
** Action: No action needed.

* PLUGIN Blue Ocean Pipeline Editor (blueocean-pipeline-editor)
** Description: Correctly installed at version 0.2.0
** Action: No action needed.

* PLUGIN Pipeline: GitHub Groovy Libraries (pipeline-github-lib)
** Description: Correctly installed at version 1.0
** Action: No action needed.

* PLUGIN GitHub Organization Folder Plugin (github-organization-folder)
** Description: Correctly installed at version 1.6
** Action: No action needed.

* PLUGIN GitHub Pipeline for Blue Ocean (blueocean-github-pipeline)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN i18n for Blue Ocean (blueocean-i18n)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN Dashboard for Blue Ocean (blueocean-dashboard)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN Git Pipeline for Blue Ocean (blueocean-git-pipeline)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN Config API for Blue Ocean (blueocean-config)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN Blue Ocean (blueocean)
** Description: Correctly installed at version 1.0.1
** Action: No action needed.

* PLUGIN Jenkins build timeout plugin (build-timeout)
** Description: Correctly installed at version 1.18
** Action: No action needed.

* PLUGIN CloudBees Restart Aborted Builds Plugin (cloudbees-aborted-builds)
** Description: Correctly installed at version 1.9
** Action: No action needed.

* PLUGIN CloudBees Amazon AWS CLI Plugin (cloudbees-aws-cli)
** Description: Correctly installed at version 1.5.6
** Action: No action needed.

* PLUGIN Deployed On Column Plugin (deployed-on-column)
** Description: Correctly installed at version 1.7
** Action: No action needed.

* PLUGIN Deployer Framework Plugin (deployer-framework)
** Description: Correctly installed at version 1.1
** Action: No action needed.

* PLUGIN CloudBees Amazon Web Services Deploy Engine Plugin (cloudbees-aws-deployer)
** Description: Correctly installed at version 1.17
** Action: No action needed.

* PLUGIN Jenkins Mercurial plugin (mercurial)
** Description: Correctly installed at version 1.59
** Action: No action needed.

* PLUGIN Bitbucket Branch Source Plugin (cloudbees-bitbucket-branch-source)
** Description: Correctly installed at version 2.1.1
** Action: No action needed.

* PLUGIN CloudBees Even Scheduler Plugin (cloudbees-even-scheduler)
** Description: Correctly installed at version 3.7
** Action: No action needed.

* PLUGIN CloudBees GitHub Pull Requests Plugin (cloudbees-github-pull-requests)
** Description: Correctly installed at version 1.1
** Action: No action needed.

* PLUGIN CloudBees Groovy View Plugin (cloudbees-groovy-view)
** Description: Correctly installed at version 1.5
** Action: No action needed.

* PLUGIN CloudBees High Availability Management plugin (cloudbees-ha)
** Description: Correctly installed at version 4.7
** Action: No action needed.

* PLUGIN CloudBees Fast Archiving Plugin (cloudbees-jsync-archiver)
** Description: Correctly installed at version 5.5
** Action: No action needed.

* PLUGIN CloudBees Label Throttling Plugin (cloudbees-label-throttling-plugin)
** Description: Correctly installed at version 3.4
** Action: No action needed.

* PLUGIN CloudBees Long-Running Build Plugin (cloudbees-long-running-build)
** Description: Correctly installed at version 1.9
** Action: No action needed.

* PLUGIN CloudBees Nodes Plus Plugin (cloudbees-nodes-plus)
** Description: Correctly installed at version 1.14
** Action: No action needed.

* PLUGIN CloudBees Plugin Usage Plugin (cloudbees-plugin-usage)
** Description: Correctly installed at version 1.6
** Action: No action needed.

* PLUGIN CloudBees Quiet Start Plugin (cloudbees-quiet-start)
** Description: Correctly installed at version 1.2
** Action: No action needed.

* PLUGIN CloudBees Secure Copy Plugin (cloudbees-secure-copy)
** Description: Correctly installed at version 3.9
** Action: No action needed.

* PLUGIN CloudBees Support Plugin (cloudbees-support)
** Description: Correctly installed at version 3.9
** Action: No action needed.

* PLUGIN CloudBees View Creation Filter Plugin (cloudbees-view-creation-filter)
** Description: Correctly installed at version 1.3
** Action: No action needed.

* PLUGIN CloudBees Wasted Minutes Tracker Plugin (cloudbees-wasted-minutes-tracker)
** Description: Correctly installed at version 3.8
** Action: No action needed.

* PLUGIN CloudBees Pipeline (Deprecated) (cloudbees-workflow-aggregator)
** Description: Correctly installed at version 1.9.1
** Action: No action needed.

* PLUGIN CloudBees Pipeline: Templates Plugin (cloudbees-workflow-template)
** Description: Correctly installed at version 2.6
** Action: No action needed.

* PLUGIN CloudBees Pipeline: Groovy Checkpoint Plugin (workflow-cps-checkpoint)
** Description: Correctly installed at version 2.4
** Action: No action needed.

* PLUGIN JavaScript GUI Lib: Handlebars bundle plugin (handlebars)
** Description: Correctly installed at version 1.1.1
** Action: No action needed.

* PLUGIN Pipeline: REST API Plugin (pipeline-rest-api)
** Description: Correctly installed at version 2.6
** Action: No action needed.

* PLUGIN JavaScript GUI Lib: Moment.js bundle plugin (momentjs)
** Description: Correctly installed at version 1.1.1
** Action: No action needed.

* PLUGIN Pipeline: Stage View Plugin (pipeline-stage-view)
** Description: Correctly installed at version 2.6
** Action: No action needed.

* PLUGIN CloudBees Pipeline Stage View Extensions (cloudbees-workflow-ui)
** Description: Correctly installed at version 2.1
** Action: No action needed.

* PLUGIN Copy Artifact Plugin (copyartifact)
** Description: Correctly installed at version 1.38.1
** Action: No action needed.

* PLUGIN Dashboard View (dashboard-view)
** Description: Correctly installed at version 2.9.10
** Action: No action needed.

* PLUGIN CloudBees Docker Build and Publish plugin (docker-build-publish)
** Description: Correctly installed at version 1.3.2
** Action: No action needed.

* PLUGIN CloudBees Docker Traceability (docker-traceability)
** Description: Correctly installed at version 1.2
** Action: No action needed.

* PLUGIN CloudBees Docker Hub/Registry Notification (dockerhub-notification)
** Description: Correctly installed at version 2.2.0
** Action: No action needed.

* PLUGIN External Monitor Job Type Plugin (external-monitor-job)
** Description: Correctly installed at version 1.7
** Action: No action needed.

* PLUGIN CloudBees Git Validated Merge Plugin (git-validated-merge)
** Description: Correctly installed at version 3.20
** Action: No action needed.

* PLUGIN CloudBees Pull Request Builder for GitHub (github-pull-request-build)
** Description: Correctly installed at version 1.10
** Action: No action needed.

* PLUGIN CloudBees Back-up Plugin (infradna-backup)
** Description: Correctly installed at version 3.34
** Action: No action needed.

* PLUGIN LDAP Plugin (ldap)
** Description: Correctly installed at version 1.14
** Action: No action needed.

* PLUGIN Jenkins SSH Slaves plugin (ssh-slaves)
** Description: Correctly installed at version 1.16
** Action: No action needed.

* PLUGIN Node Iterator API Plugin (node-iterator-api)
** Description: Correctly installed at version 1.5.0
** Action: No action needed.

* PLUGIN CloudBees VMWare Autoscaling Plugin (nectar-vmware)
** Description: Correctly installed at version 4.3.5
** Action: No action needed.

* PLUGIN CloudBees OpenShift CLI Plugin (openshift-cli)
** Description: Correctly installed at version 1.3
** Action: No action needed.

* PLUGIN Operations Center Analytics Configuration (operations-center-analytics-config)
** Description: Correctly installed at version 2.46.0.2
** Action: No action needed.

* PLUGIN Operations Center Analytics Reporter (operations-center-analytics-reporter)
** Description: Correctly installed at version 2.46.0.2
** Action: No action needed.

* PLUGIN Operations Center Cloud (operations-center-cloud)
** Description: Correctly installed at version 2.46.0.2
** Action: No action needed.

* PLUGIN Operations Center OpenID Cluster Session Extension (operations-center-openid-cse)
** Description: Correctly installed at version 1.8.110
** Action: No action needed.

* PLUGIN PAM Authentication plugin (pam-auth)
** Description: Correctly installed at version 1.3
** Action: No action needed.

* PLUGIN Pipeline: Build Step (pipeline-build-step)
** Description: Correctly installed at version 2.4
** Action: No action needed.

* PLUGIN Pipeline: Milestone Step (pipeline-milestone-step)
** Description: Correctly installed at version 1.3.1
** Action: No action needed.

* PLUGIN CloudBees Skip Next Build Plugin (skip-plugin)
** Description: Correctly installed at version 4.0
** Action: No action needed.

* PLUGIN SSH Agent Plugin (ssh-agent)
** Description: Correctly installed at version 1.14
** Action: No action needed.

* PLUGIN Stack Trace Suppression Plugin (suppress-stack-trace)
** Description: Correctly installed at version 1.5
** Action: No action needed.

* PLUGIN Jenkins Translation Assistance plugin (translation)
** Description: Correctly installed at version 1.15
** Action: No action needed.

* PLUGIN CloudBees WikiText Security Plugin (wikitext)
** Description: Correctly installed at version 3.7
** Action: No action needed.

* PLUGIN Windows Slaves Plugin (windows-slaves)
** Description: Correctly installed at version 1.2
** Action: No action needed.

* PLUGIN Pipeline (workflow-aggregator)
** Description: Correctly installed at version 2.5
** Action: No action needed.
