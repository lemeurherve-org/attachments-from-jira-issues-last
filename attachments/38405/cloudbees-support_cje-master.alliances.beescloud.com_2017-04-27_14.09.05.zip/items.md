Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 49
    - Number of items per container: 3.816326530612245 [n=49, s=7.0]
  * `com.cloudbees.hudson.plugins.modeling.impl.auxiliary.AuxModel`
    - Number of items: 1
  * `com.cloudbees.hudson.plugins.modeling.impl.builder.BuilderTemplate`
    - Number of items: 1
  * `com.cloudbees.hudson.plugins.modeling.impl.jobTemplate.JobTemplate`
    - Number of items: 3
  * `com.infradna.hudson.plugins.backup.BackupProject`
    - Number of items: 7
    - Number of builds per job: 10.142857142857142 [n=7, s=7.0]
  * `hudson.maven.MavenModule`
    - Number of items: 11
    - Number of builds per job: 1.9090909090909092 [n=11, s=1.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 9
    - Number of builds per job: 1.8888888888888888 [n=9, s=4.0]
    - Number of items per container: 1.2222222222222223 [n=9, s=2.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 43
    - Number of builds per job: 2.883720930232558 [n=43, s=7.0]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 7
    - Number of items per container: 1.1428571428571428 [n=7, s=1.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 138
    - Number of builds per job: 3.927536231884058 [n=138, s=6.9]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 18
    - Number of items per container: 3.3333333333333335 [n=18, s=3.0]

Total job statistics
======================

  * Number of jobs: 208
  * Number of builds per job: 3.7259615384615383 [n=208, s=6.7]
