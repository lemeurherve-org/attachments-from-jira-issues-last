Loggers currently enabled
=========================
org.jenkinsci.plugins.pipeline.maven - ALL
hudson.remoting.PingThread - ALL
com.cloudbees.jenkins.plugins.cyberark - ALL
jenkins.mvn.WithMavenStepExecution.class - ALL
com.cloudbees.opscenter.server.model.PingThread - ALL
jenkins.mvn.WithMavenStepExecution - FINEST
hudson.slaves.ChannelPinger - ALL
org.apache.sshd - WARNING
hudson.plugins.jira - ALL
com.infradna.hudson.plugins.backup - ALL
com.cloudbees.opscenter.server.model.ChannelPinger - ALL
winstone - INFO
 - INFO
