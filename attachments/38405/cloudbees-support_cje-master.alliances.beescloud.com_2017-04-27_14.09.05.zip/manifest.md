CloudBees Support Bundle Manifest
=================================

Generated on 2017-04-27 14:09:05.026+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-04-21_07.57.38.log`

      - `nodes/master/logs/all_2017-04-21_08.23.37.log`

      - `nodes/master/logs/all_2017-04-23_01.47.36.log`

      - `nodes/master/logs/all_2017-04-23_13.00.06.log`

      - `nodes/master/logs/all_2017-04-23_19.08.06.log`

      - `nodes/master/logs/all_2017-04-26_21.27.13.log`

      - `nodes/master/logs/all_2017-04-26_21.45.13.log`

      - `nodes/master/logs/all_2017-04-27_08.13.51.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/custom/Backup Plugin.log`

      - `nodes/master/logs/custom/cyberark.log`

      - `nodes/master/logs/custom/hudson.plugins.jira.log`

      - `nodes/master/logs/custom/ping.log`

      - `nodes/master/logs/custom/withMaven.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/SharedConfigurationSynchronizer.log`

      - `other-logs/SharedConfigurationSynchronizer.log.1`

      - `other-logs/SharedConfigurationSynchronizer.log.2`

      - `other-logs/SharedConfigurationSynchronizer.log.3`

      - `other-logs/SharedConfigurationSynchronizer.log.4`

      - `other-logs/SharedConfigurationSynchronizer.log.5`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log.1`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log.2`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log.3`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log.4`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log.5`

      - `other-logs/health-checker.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

  * Slave Log Recorders

      - `nodes/slave/agent-1/jenkins.log`

      - `nodes/slave/agent-1/logs/all_2017-04-18_13.06.38.log`

      - `nodes/slave/agent-1/logs/all_2017-04-21_08.01.11.log`

      - `nodes/slave/agent-1/logs/all_2017-04-21_08.26.24.log`

      - `nodes/slave/agent-1/logs/all_2017-04-23_19.08.37.log`

      - `nodes/slave/agent-1/logs/all_2017-04-25_21.12.34.log`

      - `nodes/slave/agent-1/logs/all_2017-04-26_21.27.42.log`

      - `nodes/slave/agent-1/logs/all_2017-04-26_21.48.06.log`

      - `nodes/slave/agent-1/logs/all_2017-04-27_08.16.41.log`

      - `nodes/slave/agent-1/logs/all_memory_buffer.log`

  * Garbage Collection Logs

  * CloudBees Assurance Program

      - `cap/beekeeper.md`

  * Agents config files (Encrypted secrets are redacted)

      - `nodes/slave/agent-1/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/abortedBuilds.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugin.metrics.views.Alerter.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.TrackerConfig.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.amazonecs.ECSTaskTemplate.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.cyberark.credentials.CyberArkGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.evenscheduler.SchedulerPreference.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.git.vmerge.ValidatedMergeGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.jsync.archiver.JSyncArtifactManagerFactory.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.license.nectar.ExperimentalPlugins.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.requestfilter.Rules.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.ssl.SslSettings.xml`

      - `jenkins-root-configuration-files/com.cloudbees.opscenter.client.plugin.OperationsCenterRootAction.xml`

      - `jenkins-root-configuration-files/com.cloudbees.plugins.azure.AzureCliInstallation.xml`

      - `jenkins-root-configuration-files/com.cloudbees.plugins.cloudfoundry.cli.CloudFoundryCliInstallation.xml`

      - `jenkins-root-configuration-files/com.cloudbees.plugins.openshift.OpenShiftClient.xml`

      - `jenkins-root-configuration-files/com.infradna.hudson.plugins.backup.BackupBuilder.xml`

      - `jenkins-root-configuration-files/com.infradna.hudson.plugins.backup.store.DAVStore.xml`

      - `jenkins-root-configuration-files/com.infradna.hudson.plugins.backup.store.SftpStore.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftBuildCanceller.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftBuildVerifier.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftBuilder.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftCreator.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftDeployCanceller.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftDeployer.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftDeploymentVerifier.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftImageStreams.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftImageTagger.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftScaler.xml`

      - `jenkins-root-configuration-files/com.openshift.jenkins.plugins.pipeline.OpenShiftServiceVerifier.xml`

      - `jenkins-root-configuration-files/config_20160823.xml`

      - `jenkins-root-configuration-files/credentials-configuration.xml`

      - `jenkins-root-configuration-files/custom-config-files.xml`

      - `jenkins-root-configuration-files/cyberark-index.xml`

      - `jenkins-root-configuration-files/docker-traceability.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.analysis.core.GlobalSettings.xml`

      - `jenkins-root-configuration-files/hudson.plugins.ansicolor.AnsiColorBuildWrapper.xml`

      - `jenkins-root-configuration-files/hudson.plugins.build_timeout.operations.BuildStepOperation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.copyartifact.TriggeredBuildSelector.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.jira.JiraProjectProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.mercurial.MercurialInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.openid.OpenIdLoginService$GlobalConfigurationImpl.xml`

      - `jenkins-root-configuration-files/hudson.plugins.promoted_builds.GlobalBuildPromotedBuilds.xml`

      - `jenkins-root-configuration-files/hudson.plugins.warnings.WarningsPublisher.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.tools.JDKInstaller.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/javaposse.jobdsl.plugin.ExecuteDslScripts.xml`

      - `jenkins-root-configuration-files/javaposse.jobdsl.plugin.GlobalJobDslSecurityConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.metrics.api.MetricsAccessKey.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.http_request.HttpRequest.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.nodejs.tools.NodeJSInstallation.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.UpdateSiteWarningsConfiguration.xml`

      - `jenkins-root-configuration-files/license.xml`

      - `jenkins-root-configuration-files/maven-global-settings-files.xml`

      - `jenkins-root-configuration-files/maven-settings-files.xml`

      - `jenkins-root-configuration-files/nectar-rbac.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/nodejs.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.conditionalbuildstep.singlestep.SingleConditionalBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.configfiles.GlobalConfigFiles.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.commons.tools.DockerTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitApacheTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.github_branch_source.GitHubConfiguration.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.pipeline.modeldefinition.config.GlobalConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.support.steps.StageStep.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.m2release.M2ReleaseBuildWrapper.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/agent-1/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/agent-1/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/agent-1/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/agent-1/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/agent-1/proc/meminfo.txt`

      - `nodes/slave/agent-1/proc/self/cmdline`

      - `nodes/slave/agent-1/proc/self/environ`

      - `nodes/slave/agent-1/proc/self/limits.txt`

      - `nodes/slave/agent-1/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/agent-1/gnuplot`

      - `load-stats/label/agent-1/hour.csv`

      - `load-stats/label/agent-1/min.csv`

      - `load-stats/label/agent-1/sec10.csv`

      - `load-stats/label/docker/gnuplot`

      - `load-stats/label/docker/hour.csv`

      - `load-stats/label/docker/min.csv`

      - `load-stats/label/docker/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/agent-1/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/agent-1/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/agent-1/dmesg.txt`

      - `nodes/slave/agent-1/dmi.txt`

      - `nodes/slave/agent-1/proc/cpuinfo.txt`

      - `nodes/slave/agent-1/proc/mounts.txt`

      - `nodes/slave/agent-1/proc/swaps.txt`

      - `nodes/slave/agent-1/proc/system-uptime.txt`

      - `nodes/slave/agent-1/sysctl.txt`

      - `nodes/slave/agent-1/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/agent-1/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20170404-075533.052.txt`

      - `slow-requests/20170404-075533.053.txt`

      - `slow-requests/20170404-090248.052.txt`

      - `slow-requests/20170404-090248.053.txt`

      - `slow-requests/20170407-202239.052.txt`

      - `slow-requests/20170407-202239.053.txt`

      - `slow-requests/20170407-202239.054.txt`

      - `slow-requests/20170407-202239.055.txt`

      - `slow-requests/20170407-202239.056.txt`

      - `slow-requests/20170407-202239.057.txt`

      - `slow-requests/20170407-202254.052.txt`

      - `slow-requests/20170407-202254.053.txt`

      - `slow-requests/20170407-202254.054.txt`

      - `slow-requests/20170407-202254.055.txt`

      - `slow-requests/20170407-202309.052.txt`

      - `slow-requests/20170407-202309.053.txt`

      - `slow-requests/20170407-214645.269.txt`

      - `slow-requests/20170407-215307.578.txt`

      - `slow-requests/20170410-130343.891.txt`

      - `slow-requests/20170411-152150.604.txt`

      - `slow-requests/20170411-152150.605.txt`

      - `slow-requests/20170411-164344.190.txt`

      - `slow-requests/20170412-064535.203.txt`

      - `slow-requests/20170412-141127.842.txt`

      - `slow-requests/20170412-204007.563.txt`

      - `slow-requests/20170412-204243.563.txt`

      - `slow-requests/20170412-204243.564.txt`

      - `slow-requests/20170412-204243.565.txt`

      - `slow-requests/20170412-204243.566.txt`

      - `slow-requests/20170412-204243.567.txt`

      - `slow-requests/20170412-204246.563.txt`

      - `slow-requests/20170418-100801.858.txt`

      - `slow-requests/20170418-100801.859.txt`

      - `slow-requests/20170418-152614.601.txt`

      - `slow-requests/20170421-075656.601.txt`

      - `slow-requests/20170421-075815.057.txt`

      - `slow-requests/20170421-082446.436.txt`

      - `slow-requests/20170423-190728.436.txt`

      - `slow-requests/20170425-212325.879.txt`

      - `slow-requests/20170425-213428.879.txt`

      - `slow-requests/20170425-213631.879.txt`

      - `slow-requests/20170425-213631.880.txt`

      - `slow-requests/20170425-213631.881.txt`

      - `slow-requests/20170425-213631.882.txt`

      - `slow-requests/20170425-213631.883.txt`

      - `slow-requests/20170425-213634.879.txt`

      - `slow-requests/20170426-212756.284.txt`

      - `slow-requests/20170426-213650.284.txt`

      - `slow-requests/20170427-081037.044.txt`

      - `slow-requests/20170427-081544.881.txt`

  * Deadlock Records

  * Operations Center Connector Logs

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/agent-1/thread-dump.txt`

