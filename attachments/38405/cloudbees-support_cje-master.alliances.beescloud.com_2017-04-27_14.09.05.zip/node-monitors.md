Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * agent-1: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * agent-1: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 46.717GB left on /var/lib/jenkins.
   * agent-1: Disk space is too low. Only 22.170GB left on /home/ubuntu/jenkins-aws-home.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:1617/3951MB  Swap:0/0MB
   * agent-1: Memory:1332/2000MB  Swap:0/0MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 46.717GB left on /tmp.
   * agent-1: Disk space is too low. Only 22.170GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * agent-1: 2ms
Approved Folders
----
 - Is Ignored: false
 - Computers:
   * master: null
   * agent-1: null
Node owners
----
 - Is Ignored: false
 - Computers:
   * master: null
   * agent-1: null
