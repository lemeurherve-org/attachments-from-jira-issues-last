Node statistics
===============

  * Total number of nodes
      - Sample size:        1420
      - Average (mean):     0.9999999999999998
      - Average (median):   1.0
      - Standard deviation: 2.2204460492503128E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        1420
      - Average (mean):     0.9999999999999998
      - Average (median):   1.0
      - Standard deviation: 2.2204460492503128E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        1420
      - Average (mean):     1.9999999999999996
      - Average (median):   2.0
      - Standard deviation: 4.4408920985006257E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        1420
      - Average (mean):     2.2638714244036907E-80
      - Average (median):   0.0
      - Standard deviation: 2.0161449364851E-40
      - Minimum:            0
      - Maximum:            2
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.7
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   878.50 MB (921174016)
          + Allocated memory: 599.50 MB (628621312)
          + Free memory:      225.48 MB (236428784)
          + In-use memory:    374.02 MB (392192528)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-117-generic
          + Distribution: Ubuntu 14.04.5 LTS
      - Process ID: 1128 (0x468)
      - Process started: 2017-04-27 08:13:40.648+0000
      - Process uptime: 5 hr 55 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`

  * agent-1 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/home/ubuntu/jenkins-aws-home`
      - Labels:         docker
      - Usage:          `NORMAL`
      - Launch method:  `com.cloudbees.jenkins.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   485.31 MB (508887040)
          + Allocated memory: 31.06 MB (32571392)
          + Free memory:      8.68 MB (9103176)
          + In-use memory:    22.38 MB (23468216)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-117-generic
          + Distribution: Ubuntu 14.04.5 LTS
      - Process ID: 1463 (0x5b7)
      - Process started: 2017-04-27 08:16:37.868+0000
      - Process uptime: 5 hr 52 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

