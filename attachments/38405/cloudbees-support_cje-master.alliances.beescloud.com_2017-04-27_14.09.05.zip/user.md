User
====

Authentication
--------------

  * Authenticated: true
  * Name: admin
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@c4a26c59: Username: hudson.security.HudsonPrivateSecurityRealm$Details@5771ccc4; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@2eb76: RemoteIpAddress: 127.0.0.1; SessionId: 1nkyl3w7s71oj1c4bh8yfm0c69; Granted Authorities: authenticated`

