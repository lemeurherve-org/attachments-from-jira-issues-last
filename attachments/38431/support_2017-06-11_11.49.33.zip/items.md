Item statistics
===============

  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 15
    - Number of builds per job: 8.866666666666667 [n=15, s=10.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 12
    - Number of items per container: 1.25 [n=12, s=0.6]

Total job statistics
======================

  * Number of jobs: 15
  * Number of builds per job: 8.866666666666667 [n=15, s=10.0]
