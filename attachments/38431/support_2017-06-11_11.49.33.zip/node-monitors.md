Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * scaleone: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * scaleone: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 178.835GB left on /var/jenkins_home.
   * scaleone: Disk space is too low. Only 10.889GB left on /home/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:4639/16010MB  Swap:547/975MB
   * scaleone: Memory:902/2001MB  Swap:0/0MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 178.835GB left on /tmp.
   * scaleone: Disk space is too low. Only 10.889GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * scaleone: 174ms
