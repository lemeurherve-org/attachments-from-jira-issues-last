-----------
 * Name docker0
 ** Hardware Address - 024257e287a6
 ** Index - 6
 ** InetAddress - /fe80:0:0:0:42:57ff:fee2:87a6%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - de1950264002
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:dc19:50ff:fe26:4002%eth0
 ** InetAddress - /10.2.214.69
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
