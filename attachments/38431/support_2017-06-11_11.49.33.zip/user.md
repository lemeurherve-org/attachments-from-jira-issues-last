User
====

Authentication
--------------

  * Authenticated: true
  * Name: root
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@9db7c0a6: Username: hudson.security.HudsonPrivateSecurityRealm$Details@e6446dd; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@2cd90: RemoteIpAddress: 92.170.236.129; SessionId: 8ud2qzixw7l6hzzslpnf5fnx; Granted Authorities: authenticated`

