Jenkins
=======

Version details
---------------

  * Version: `2.60.1`
  * Mode:    WAR
  * Url:     http://jenkins.nmc.mk/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_131
      - Maximum memory:   957.00 MB (1003487232)
      - Allocated memory: 142.87 MB (149807104)
      - Free memory:      38.39 MB (40259896)
      - In-use memory:    104.47 MB (109547208)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.131-b11
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.16.0-73-generic
  * Process ID: 5 (0x5)
  * Process started: 2017-06-30 14:03:07.747+0000
  * Process uptime: 57 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.5 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bitbucket:1.1.5 'Jenkins Bitbucket Plugin'
  * blueocean:1.1.2 'Blue Ocean'
  * blueocean-autofavorite:1.0.0 'Autofavorite for Blue Ocean'
  * blueocean-commons:1.1.2 'Common API for Blue Ocean'
  * blueocean-config:1.1.2 'Config API for Blue Ocean'
  * blueocean-dashboard:1.1.2 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.0 'BlueOcean Display URL plugin'
  * blueocean-events:1.1.2 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.1.2 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.1.2 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.1.2 'i18n for Blue Ocean'
  * blueocean-jwt:1.1.2 'JWT for Blue Ocean'
  * blueocean-personalization:1.1.2 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.1.2 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:0.2.0 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.1.2 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.1.2 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.1.2 'REST Implementation for Blue Ocean'
  * blueocean-web:1.1.2 'Web for Blue Ocean'
  * bouncycastle-api:2.16.1 'bouncycastle API Plugin'
  * branch-api:2.0.10 'Branch API Plugin'
  * build-pipeline-plugin:1.5.7.1 'Build Pipeline Plugin'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * cloudbees-folder:6.0.4 'Folders Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * credentials:2.1.14 'Credentials Plugin'
  * credentials-binding:1.12 'Credentials Binding Plugin'
  * dashboard-view:2.9.11 'Dashboard View'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.7 'Docker Commons Plugin'
  * docker-workflow:1.12 'Docker Pipeline'
  * durable-task:1.14 'Durable Task Plugin'
  * email-ext:2.58 'Email Extension Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.0 'Favorite'
  * git:3.3.1 'Jenkins Git plugin'
  * git-client:2.4.6 'Jenkins Git client plugin'
  * git-parameter:0.8.0 'Git Parameter Plug-In'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.27.0 'GitHub plugin'
  * github-api:1.85.1 'GitHub API Plugin'
  * github-branch-source:2.0.6 'GitHub Branch Source Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.15 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.7 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.11 'Matrix Project Plugin'
  * maven-plugin:2.16 'Maven Integration plugin'
  * mercurial:1.61 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.34 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.5 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.4 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.7 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.7 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.7 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.7 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.8 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.7 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.8 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * publish-over-ssh:1.17 'Publish Over SSH'
  * pubsub-light:1.8 'Jenkins Pub-Sub "light" Bus'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * role-strategy:2.5.0 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.1.1 'SCM API Plugin'
  * script-security:1.29 'Script Security Plugin'
  * simple-theme-plugin:0.3 'Simple Theme Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.4 'Jenkins SSH plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.20 'Jenkins SSH Slaves plugin'
  * structs:1.9 'Structs Plugin'
  * subversion:2.8 'Jenkins Subversion Plug-in'
  * support-core:2.41 'Support Core Plugin'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.1 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.18 'Pipeline: API'
  * workflow-basic-steps:2.5 'Pipeline: Basic Steps'
  * workflow-cps:2.36 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.8 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.12 'Pipeline: Nodes and Processes'
  * workflow-job:2.12.1 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.11 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
  * ws-cleanup:0.33 'Jenkins Workspace Cleanup Plugin'
