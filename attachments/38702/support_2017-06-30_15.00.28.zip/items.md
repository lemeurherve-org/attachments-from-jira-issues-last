Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 2
    - Number of builds per job: 4.0 [n=2, s=6.0]

Total job statistics
======================

  * Number of jobs: 2
  * Number of builds per job: 4.0 [n=2, s=6.0]
