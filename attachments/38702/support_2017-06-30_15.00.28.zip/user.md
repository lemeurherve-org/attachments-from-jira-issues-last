User
====

Authentication
--------------

  * Authenticated: true
  * Name: rubin
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@6eff3b4: Username: hudson.security.HudsonPrivateSecurityRealm$Details@646e965e; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@7798: RemoteIpAddress: 192.168.1.2; SessionId: vp2k1xd33bch1e6rawnz4aagx; Granted Authorities: authenticated`

