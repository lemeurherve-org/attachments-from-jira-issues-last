Jenkins
=======

Version details
---------------

  * Version: `2.60.1`
  * Mode:    WAR
  * Url:     https://ci.jenkins.io/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8-openjdk/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_121
      - Maximum memory:   3.26 GB (3504865280)
      - Allocated memory: 1.49 GB (1604321280)
      - Free memory:      940.68 MB (986373000)
      - In-use memory:    589.32 MB (617948280)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.121-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.13.0-100-generic
  * Process ID: 7 (0x7)
  * Process started: 2017-07-11 20:48:59.618+0000
  * Process uptime: 5 min 48 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/resources.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/rt.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jce.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8-openjdk/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64/server:/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64:/usr/lib/jvm/java-1.8-openjdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Duser.home=/var/jenkins_home`
      - arg[1]: `-Djenkins.install.runSetupWizard=false`
      - arg[2]: `-Djenkins.model.Jenkins.slaveAgentPort=50000`
      - arg[3]: `-Dhudson.model.WorkspaceCleanupThread.retainForDays=2`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.87 'Static Analysis Utilities'
  * ansicolor:0.5.0 'AnsiColor'
  * ant:1.5 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * azure-credentials:1.2 'Azure Credentials'
  * azure-slave-plugin:0.3.3 *(update available)* 'Azure Slave Plugin'
  * azure-vm-agents:0.4.6 'Azure VM Agents'
  * beer:1.2 'beer'
  * blueocean:1.1.4 'Blue Ocean'
  * blueocean-autofavorite:1.0.0 'Autofavorite for Blue Ocean'
  * blueocean-commons:1.1.4 'Common API for Blue Ocean'
  * blueocean-config:1.1.4 'Config API for Blue Ocean'
  * blueocean-dashboard:1.1.4 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.0 'BlueOcean Display URL plugin'
  * blueocean-events:1.1.4 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.1.4 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.1.4 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.1.4 'i18n for Blue Ocean'
  * blueocean-jwt:1.1.4 'JWT for Blue Ocean'
  * blueocean-personalization:1.1.4 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.1.4 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:0.2.0 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.1.4 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.1.4 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.1.4 'REST Implementation for Blue Ocean'
  * blueocean-web:1.1.4 'Web for Blue Ocean'
  * bouncycastle-api:2.16.1 'bouncycastle API Plugin'
  * branch-api:2.0.10 'Branch API Plugin'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * buildtriggerbadge:2.8.1 'Build Trigger Badge Plugin'
  * checkstyle:3.48 'Checkstyle Plug-in'
  * cloud-stats:0.13 'Cloud Statistics Plugin'
  * cloudbees-folder:6.0.4 'Folders Plugin'
  * conditional-buildstep:1.3.5 *(update available)* 'Conditional BuildStep'
  * credentials:2.1.14 'Credentials Plugin'
  * credentials-binding:1.12 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.8 'Docker Commons Plugin'
  * docker-workflow:1.12 'Docker Pipeline'
  * durable-task:1.14 'Durable Task Plugin'
  * embeddable-build-status:1.9 'embeddable-build-status'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.0 'Favorite'
  * findbugs:4.70 'FindBugs Plug-in'
  * git:3.3.2 'Jenkins Git plugin'
  * git-client:2.4.6 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.27.0 'GitHub plugin'
  * github-api:1.86 'GitHub API Plugin'
  * github-branch-source:2.0.8 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * groovy:2.0 'Groovy'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jobConfigHistory:2.16 'Jenkins Job Configuration History Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * keyboard-shortcuts-plugin:1.2 'Keyboard Shortcuts Plugin'
  * ldap:1.16 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.7 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.11 'Matrix Project Plugin'
  * maven-plugin:2.16 *(update available)* 'Maven Integration plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parallel-test-executor:1.9 'Parallel Test Executor Plugin'
  * parameterized-trigger:2.35 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.4 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.7 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.8 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.8 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.8 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.8 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.8 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.8 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.3.0 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * pubsub-light:1.8 *(update available)* 'Jenkins Pub-Sub "light" Bus'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.1.1 'SCM API Plugin'
  * script-security:1.29.1 'Script Security Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.20 'Jenkins SSH Slaves plugin'
  * structs:1.9 'Structs Plugin'
  * subversion:2.9 'Jenkins Subversion Plug-in'
  * support-core:2.41 'Support Core Plugin'
  * throttle-concurrents:2.0.1 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.1 'Token Macro Plugin'
  * toolenv:1.1 'Tool Environment plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * variant:1.1 'Variant Plugin'
  * warnings:4.62 'Warnings Plug-in'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.18 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.36.1 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.8 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.12 'Pipeline: Nodes and Processes'
  * workflow-job:2.12.1 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.12 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
