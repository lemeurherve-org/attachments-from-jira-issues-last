Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 2
    - Number of items per container: 5.5 [n=2, s=4.0]
  * `hudson.maven.MavenModule`
    - Number of items: 19
    - Number of builds per job: 7.684210526315789 [n=19, s=4.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 7
    - Number of builds per job: 4.428571428571429 [n=7, s=5.0]
    - Number of items per container: 2.7142857142857144 [n=7, s=5.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 1
    - Number of builds per job: 129 [n=1]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 6
    - Number of items per container: 29.333333333333332 [n=6, s=50.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 1002
    - Number of builds per job: 5.983033932135728 [n=1002, s=17.68038787644052]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 177
    - Number of items per container: 5.649717514124294 [n=177, s=20.0]

Total job statistics
======================

  * Number of jobs: 1029
  * Number of builds per job: 6.123420796890184 [n=1029, s=17.876231571917934]
