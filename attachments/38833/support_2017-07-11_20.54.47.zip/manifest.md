Support Bundle Manifest
=======================

Generated on 2017-07-11 20:54:47.829+0000

Requested components:

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/celery/checksums.md5`

      - `nodes/slave/kelp/checksums.md5`

      - `nodes/slave/ubuntu-jenkinsinfra63f4f0/checksums.md5`

      - `nodes/slave/ubuntu-jenkinsinfra65a9d0/checksums.md5`

      - `nodes/slave/win2012-16b8a0/checksums.md5`

      - `nodes/slave/win2012-3d1060/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/celery/metrics.json`

      - `nodes/slave/kelp/metrics.json`

      - `nodes/slave/ubuntu-jenkinsinfra63f4f0/metrics.json`

      - `nodes/slave/ubuntu-jenkinsinfra65a9d0/metrics.json`

      - `nodes/slave/win2012-16b8a0/metrics.json`

      - `nodes/slave/win2012-3d1060/metrics.json`

  * Update Center

      - `update-center.md`

