Node statistics
===============

  * Total number of nodes
      - Sample size:        22
      - Average (mean):     6.0
      - Average (median):   6.0
      - Standard deviation: 0.0
      - Minimum:            6
      - Maximum:            6
      - 95th percentile:    6.0
      - 99th percentile:    6.0
  * Total number of nodes online
      - Sample size:        22
      - Average (mean):     2.9945998334695516
      - Average (median):   3.0
      - Standard deviation: 0.12716657498253653
      - Minimum:            0
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors
      - Sample size:        22
      - Average (mean):     2.9945998334695516
      - Average (median):   3.0
      - Standard deviation: 0.12716657498253653
      - Minimum:            0
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors in use
      - Sample size:        22
      - Average (mean):     0.026916854123225965
      - Average (median):   0.0
      - Standard deviation: 0.17521654573375225
      - Minimum:            0
      - Maximum:            2
      - 95th percentile:    0.0
      - 99th percentile:    1.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/var/jenkins_home`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.7
      - Java
          + Home:           `/usr/lib/jvm/java-1.8-openjdk/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   3.26 GB (3504865280)
          + Allocated memory: 1.49 GB (1604321280)
          + Free memory:      919.37 MB (964030368)
          + In-use memory:    610.63 MB (640290912)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-100-generic
      - Process ID: 7 (0x7)
      - Process started: 2017-07-11 20:48:59.618+0000
      - Process uptime: 5 min 48 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/resources.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/rt.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jce.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8-openjdk/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64/server:/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64:/usr/lib/jvm/java-1.8-openjdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Duser.home=/var/jenkins_home`
          + arg[1]: `-Djenkins.install.runSetupWizard=false`
          + arg[2]: `-Djenkins.model.Jenkins.slaveAgentPort=50000`
          + arg[3]: `-Dhudson.model.WorkspaceCleanupThread.retainForDays=2`

  * celery (`hudson.slaves.DumbSlave`)
      - Description:    _celery: Machine contributed from Rackspace_
      - Executors:      4
      - Remote FS root: `/home/jenkins/agent-workspace`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * kelp (`hudson.slaves.DumbSlave`)
      - Description:    _Kelp: a machine hosted in Rackspace Cloud_
      - Executors:      1
      - Remote FS root: `/home/jenkins/agent-workspace`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ubuntu-jenkinsinfra63f4f0 (`com.microsoft.azure.vmagent.AzureVMAgent`)
      - Description:    _Dynamically provisioned Ubuntu 16.04 LTS machine_
      - Executors:      1
      - Remote FS root: `/home/jenkins`
      - Labels:         linux java docker
      - Usage:          `NORMAL`
      - Launch method:  `com.microsoft.azure.vmagent.remote.AzureVMAgentSSHLauncher`
      - Availability:   `com.microsoft.azure.vmagent.AzureVMCloudRetensionStrategy`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_131
          + Maximum memory:   1.51 GB (1623719936)
          + Allocated memory: 106.50 MB (111673344)
          + Free memory:      70.86 MB (74304104)
          + In-use memory:    35.64 MB (37369240)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.131-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.0-81-generic
          + Distribution: Ubuntu 16.04.2 LTS
      - Process ID: 23678 (0x5c7e)
      - Process started: 2017-07-11 20:49:35.723+0000
      - Process uptime: 5 min 9 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

  * ubuntu-jenkinsinfra65a9d0 (`com.microsoft.azure.vmagent.AzureVMAgent`)
      - Description:    _Dynamically provisioned Ubuntu 16.04 LTS machine_
      - Executors:      1
      - Remote FS root: `/home/jenkins`
      - Labels:         linux java docker
      - Usage:          `NORMAL`
      - Launch method:  `com.microsoft.azure.vmagent.remote.AzureVMAgentSSHLauncher`
      - Availability:   `com.microsoft.azure.vmagent.AzureVMCloudRetensionStrategy`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_131
          + Maximum memory:   1.51 GB (1623719936)
          + Allocated memory: 78.50 MB (82313216)
          + Free memory:      48.20 MB (50537880)
          + In-use memory:    30.30 MB (31775336)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.131-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.0-81-generic
          + Distribution: Ubuntu 16.04.2 LTS
      - Process ID: 15251 (0x3b93)
      - Process started: 2017-07-11 20:49:35.729+0000
      - Process uptime: 5 min 10 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

  * win2012-16b8a0 (`com.microsoft.azure.vmagent.AzureVMAgent`)
      - Description:    _Dynamically provisioned Windows 2012 R2 agent_
      - Executors:      1
      - Remote FS root: `C:\Jenkins`
      - Labels:         windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `com.microsoft.azure.vmagent.AzureVMCloudRetensionStrategy`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\jre`
          + Vendor:           Azul Systems, Inc.
          + Version:          1.8.0_102
          + Maximum memory:   1.56 GB (1670381568)
          + Allocated memory: 261.00 MB (273678336)
          + Free memory:      113.98 MB (119515152)
          + In-use memory:    147.02 MB (154163184)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Azul Systems, Inc.
          + Version: 25.102-b14
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 1720 (0x6b8)
      - Process started: 2017-07-11 20:46:21.196+0000
      - Process uptime: 3 min 17 sec
      - JVM startup parameters:
          + Boot classpath: `c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\jre\lib\resources.jar;c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\jre\lib\rt.jar;c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\jre\lib\sunrsasign.jar;c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\jre\lib\jsse.jar;c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\jre\lib\jce.jar;c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\jre\lib\charsets.jar;c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\jre\lib\jfr.jar;c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\jre\classes`
          + Classpath: `c:\azurecsdir\slave.jar`
          + Library path: `c:\azurecsdir\zulu8.17.0.3-jdk8.0.102-win_x64\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;;c:\azurecsdir\git\cmd\;.`

  * win2012-3d1060 (`com.microsoft.azure.vmagent.AzureVMAgent`)
      - Description:    _Dynamically provisioned Windows 2012 R2 agent_
      - Executors:      1
      - Remote FS root: `C:\Jenkins`
      - Labels:         windows
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `com.microsoft.azure.vmagent.AzureVMCloudRetensionStrategy`
      - Status:         off-line

