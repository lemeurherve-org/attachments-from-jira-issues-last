Jenkins
=======

Version details
---------------

  * Version: `2.69`
  * Mode:    WAR
  * Url:     http://bcadlx03/Jenkins/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_111
      - Maximum memory:   423.44 MB (444006400)
      - Allocated memory: 173.76 MB (182202368)
      - Free memory:      53.51 MB (56108144)
      - In-use memory:    120.25 MB (126094224)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.111-b15
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-514.2.2.el7.x86_64
  * Process ID: 5730 (0x1662)
  * Process started: 2017-07-12 14:49:40.878+0000
  * Process uptime: 5 hr 7 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`
      - arg[3]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.SecurityRealm$None`
  * Authorization strategy: `hudson.security.AuthorizationStrategy$Unsecured`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.87 'Static Analysis Utilities'
  * ant:1.5 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.16.1 'bouncycastle API Plugin'
  * branch-api:2.0.10 'Branch API Plugin'
  * build-environment:1.6 'Build Environment Plugin'
  * build-pipeline-plugin:1.5.7.1 'Build Pipeline Plugin'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * build-timestamp:1.0.1 'Build Timestamp Plugin'
  * changelog-history:1.6 'Change Log History'
  * cloudbees-folder:6.0.4 'Folders Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * credentials:2.1.14 'Credentials Plugin'
  * credentials-binding:1.12 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * discard-old-build:1.05 'Discard Old Build plugin'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.8 'Docker Commons Plugin'
  * docker-workflow:1.12 'Docker Pipeline'
  * durable-task:1.14 'Durable Task Plugin'
  * email-ext:2.58 'Email Extension Plugin'
  * emma:1.29 'Jenkins Emma plugin'
  * enhanced-old-build-discarder:1.0 'enhanced-old-build-discarder'
  * envinject:2.1.3 'Environment Injector Plugin'
  * envinject-api:1.2 'EnvInject API Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * external-workspace-manager:1.1.1 'External Workspace Manager Plugin'
  * git:3.3.2 'Jenkins Git plugin'
  * git-client:2.4.6 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.27.0 'GitHub plugin'
  * github-api:1.86 'GitHub API Plugin'
  * github-branch-source:2.0.8 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * greenballs:1.15 'Green Balls'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * job-restrictions:0.6 'Jenkins Job Restrictions Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.16 'LDAP Plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.7 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.11 'Matrix Project Plugin'
  * maven-plugin:2.16 *(update available)* 'Maven Integration plugin'
  * mercurial:1.61 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * msbuild:1.27 'Jenkins MSBuild Plugin'
  * mstest:0.19 'MSTest plugin'
  * mstestrunner:1.3.0 'Jenkins MSTestRunner plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.4 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.7 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.8 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.8 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.8 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.8 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.8 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.8 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.3.0 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * powershell:1.3 'Jenkins PowerShell plugin'
  * regexemail:0.3 'Regex Email Plugin'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:2.1.1 'SCM API Plugin'
  * script-security:1.29.1 'Script Security Plugin'
  * search-all-results-plugin:1.0 'Search all results'
  * show-build-parameters:1.0 'Show Build Parameters plugin'
  * ssh:2.5 'Jenkins SSH plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.20 'Jenkins SSH Slaves plugin'
  * structs:1.9 'Structs Plugin'
  * subversion:2.9 'Jenkins Subversion Plug-in'
  * support-core:2.41 'Support Core Plugin'
  * thinBackup:1.9 'ThinBackup'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.1 'Token Macro Plugin'
  * validating-string-parameter:2.3 'Validating String Parameter Plugin'
  * warnings:4.62 'Warnings Plug-in'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.18 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.36.1 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.8 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.12 'Pipeline: Nodes and Processes'
  * workflow-job:2.13 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.12 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
  * ws-cleanup:0.33 'Jenkins Workspace Cleanup Plugin'
  * xunit:1.102 'xUnit plugin'
