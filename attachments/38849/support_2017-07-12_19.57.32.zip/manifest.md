Support Bundle Manifest
=======================

Generated on 2017-07-12 19:57:32.456+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-07-11_18.49.01.log`

      - `nodes/master/logs/all_2017-07-11_18.50.23.log`

      - `nodes/master/logs/all_2017-07-12_07.12.27.log`

      - `nodes/master/logs/all_2017-07-12_14.49.46.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/health-checker.log`

  * Slave Log Recorders

      - `nodes/slave/JGMachine/jenkins.log`

      - `nodes/slave/JGMachine/logs/all_2017-07-11_18.49.36.log`

      - `nodes/slave/JGMachine/logs/all_2017-07-11_18.50.54.log`

      - `nodes/slave/JGMachine/logs/all_2017-07-12_07.13.11.log`

      - `nodes/slave/JGMachine/logs/all_2017-07-12_14.50.33.log`

      - `nodes/slave/JGMachine/logs/all_memory_buffer.log`

      - `nodes/slave/LDMachine/jenkins.log`

      - `nodes/slave/LDMachine/logs/all_2017-07-12_10.24.48.log`

      - `nodes/slave/LDMachine/logs/all_2017-07-12_14.50.33.log`

      - `nodes/slave/LDMachine/logs/all_memory_buffer.log`

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/JGMachine/checksums.md5`

      - `nodes/slave/LDMachine/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/JGMachine/exportTable.txt`

      - `nodes/slave/LDMachine/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/JGMachine/environment.txt`

      - `nodes/slave/LDMachine/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/JGMachine/gnuplot`

      - `load-stats/label/JGMachine/hour.csv`

      - `load-stats/label/JGMachine/min.csv`

      - `load-stats/label/JGMachine/sec10.csv`

      - `load-stats/label/LDMachine/gnuplot`

      - `load-stats/label/LDMachine/hour.csv`

      - `load-stats/label/LDMachine/min.csv`

      - `load-stats/label/LDMachine/sec10.csv`

      - `load-stats/label/centos/gnuplot`

      - `load-stats/label/centos/hour.csv`

      - `load-stats/label/centos/min.csv`

      - `load-stats/label/centos/sec10.csv`

      - `load-stats/label/centos7/gnuplot`

      - `load-stats/label/centos7/hour.csv`

      - `load-stats/label/centos7/min.csv`

      - `load-stats/label/centos7/sec10.csv`

      - `load-stats/label/jerome/gnuplot`

      - `load-stats/label/jerome/hour.csv`

      - `load-stats/label/jerome/min.csv`

      - `load-stats/label/jerome/sec10.csv`

      - `load-stats/label/linux/gnuplot`

      - `load-stats/label/linux/hour.csv`

      - `load-stats/label/linux/min.csv`

      - `load-stats/label/linux/sec10.csv`

      - `load-stats/label/louisdavid/gnuplot`

      - `load-stats/label/louisdavid/hour.csv`

      - `load-stats/label/louisdavid/min.csv`

      - `load-stats/label/louisdavid/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/msbuild2013/gnuplot`

      - `load-stats/label/msbuild2013/hour.csv`

      - `load-stats/label/msbuild2013/min.csv`

      - `load-stats/label/msbuild2013/sec10.csv`

      - `load-stats/label/msbuild2015/gnuplot`

      - `load-stats/label/msbuild2015/hour.csv`

      - `load-stats/label/msbuild2015/min.csv`

      - `load-stats/label/msbuild2015/sec10.csv`

      - `load-stats/label/packaging/gnuplot`

      - `load-stats/label/packaging/hour.csv`

      - `load-stats/label/packaging/min.csv`

      - `load-stats/label/packaging/sec10.csv`

      - `load-stats/label/windows%26%26x64/gnuplot`

      - `load-stats/label/windows%26%26x64/hour.csv`

      - `load-stats/label/windows%26%26x64/min.csv`

      - `load-stats/label/windows%26%26x64/sec10.csv`

      - `load-stats/label/windows/gnuplot`

      - `load-stats/label/windows/hour.csv`

      - `load-stats/label/windows/min.csv`

      - `load-stats/label/windows/sec10.csv`

      - `load-stats/label/windows10/gnuplot`

      - `load-stats/label/windows10/hour.csv`

      - `load-stats/label/windows10/min.csv`

      - `load-stats/label/windows10/sec10.csv`

      - `load-stats/label/x64/gnuplot`

      - `load-stats/label/x64/hour.csv`

      - `load-stats/label/x64/min.csv`

      - `load-stats/label/x64/sec10.csv`

      - `load-stats/label/x86/gnuplot`

      - `load-stats/label/x86/hour.csv`

      - `load-stats/label/x86/min.csv`

      - `load-stats/label/x86/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/JGMachine/metrics.json`

      - `nodes/slave/LDMachine/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/JGMachine/networkInterface.md`

      - `nodes/slave/LDMachine/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/JGMachine/system.properties`

      - `nodes/slave/LDMachine/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20170711-201050.230.txt`

      - `slow-requests/20170712-145043.753.txt`

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/JGMachine/thread-dump.txt`

      - `nodes/slave/LDMachine/thread-dump.txt`

