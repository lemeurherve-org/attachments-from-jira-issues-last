Node statistics
===============

  * Total number of nodes
      - Sample size:        1230
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 0.0
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of nodes online
      - Sample size:        1230
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 0.0
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors
      - Sample size:        1230
      - Average (mean):     3.0000000000000004
      - Average (median):   3.0
      - Standard deviation: 4.440892098500626E-16
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors in use
      - Sample size:        1230
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 3.6111691472400816E-18
      - Minimum:            0
      - Maximum:            2
      - 95th percentile:    1.0
      - 99th percentile:    1.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      1
      - FS root:        `/var/lib/jenkins`
      - Labels:         linux centos centos7
      - Usage:          `NORMAL`
      - Slave Version:  3.10
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   423.44 MB (444006400)
          + Allocated memory: 173.76 MB (182202368)
          + Free memory:      52.18 MB (54715704)
          + In-use memory:    121.58 MB (127486664)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-514.2.2.el7.x86_64
      - Process ID: 5730 (0x1662)
      - Process started: 2017-07-12 14:49:40.878+0000
      - Process uptime: 5 hr 7 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-2.b15.el7_3.x86_64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`
          + arg[3]: `-DJENKINS_HOME=/var/lib/jenkins`

  * JGMachine (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 10 nodes - Jerome machine_
      - Executors:      1
      - Remote FS root: `c:\Jenkins`
      - Labels:         windows windows10 x86 x64 msbuild2015 packaging jerome
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_121`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   1.33 GB (1431830528)
          + Allocated memory: 674.00 MB (706740224)
          + Free memory:      297.56 MB (312017376)
          + In-use memory:    376.44 MB (394722848)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Windows 10
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 7644 (0x1ddc)
      - Process started: 2017-07-04 14:41:02.946+0000
      - Process uptime: 8 days 5 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_121\lib\resources.jar;C:\Program Files\Java\jre1.8.0_121\lib\rt.jar;C:\Program Files\Java\jre1.8.0_121\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_121\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_121\lib\jce.jar;C:\Program Files\Java\jre1.8.0_121\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_121\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_121\classes;C:\Program Files\Java\jre1.8.0_121\lib\deploy.jar;C:\Program Files\Java\jre1.8.0_121\lib\javaws.jar;C:\Program Files\Java\jre1.8.0_121\lib\plugin.jar`
          + Classpath: `C:\Program Files\Java\jre1.8.0_121\lib\deploy.jar`
          + Library path: `C:\Program Files\Java\jre1.8.0_121\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\ProgramData\Oracle\Java\javapath;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files\doxygen\bin;C:\Program Files\Git\cmd;C:\Program Files\TortoiseGit\bin;C:\Program Files\TortoiseHg\;C:\Program Files\Perforce;C:\Program Files (x86)\CMake\bin;C:\Program Files\gevorkyan.org\MicroProfiler\;C:\Program Files\gevorkyan.org\MicroProfiler\x86\;C:\Program Files\TortoiseSVN\bin;C:\Program Files\MiKTeX 2.9\miktex\bin\x64\;%USERPROFILE%\.dnx\bin;C:\Program Files\Microsoft DNX\Dnvm\;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit\;C:\Program Files (x86)\PuTTY\;C:\Users\jgodbout\AppData\Local\Microsoft\WindowsApps;"C:\Program Files\Java\jre1.8.0_121\bin";.`
          + arg[0]: `-Xbootclasspath/a:C:\Program Files\Java\jre1.8.0_121\lib\deploy.jar;C:\Program Files\Java\jre1.8.0_121\lib\javaws.jar;C:\Program Files\Java\jre1.8.0_121\lib\plugin.jar`
          + arg[1]: `-Xverify:remote`
          + arg[2]: `-Djava.security.manager`
          + arg[3]: `-Xmx1536m`
          + arg[4]: `-Djnlp.tk=awt`
          + arg[5]: `-Djnlpx.vmargs=LVhteDE1MzZtAA==`
          + arg[6]: `-Djnlpx.jvm=C:\Program Files\Java\jre1.8.0_121\bin\javaw.exe`
          + arg[7]: `-Djnlpx.splashport=60352`
          + arg[8]: `-Djnlpx.home=C:\Program Files\Java\jre1.8.0_121\bin`
          + arg[9]: `-Djnlpx.remove=false`
          + arg[10]: `-Djnlpx.offline=false`
          + arg[11]: `-Djnlpx.relaunch=true`
          + arg[12]: `-Djnlpx.session.data=C:\Users\jgodbout\AppData\Local\Temp\session1813708394438688250`
          + arg[13]: `-Djnlpx.heapsize=NULL,NULL`
          + arg[14]: `-Djava.security.policy=file:C:\Program Files\Java\jre1.8.0_121\lib\security\javaws.policy`
          + arg[15]: `-DtrustProxy=true`
          + arg[16]: `-Djnlpx.origFilenameArg=http://bcadlx03/Jenkins/computer/JGMachine/slave-agent.jnlp`

  * LDMachine (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 10 nodes_
      - Executors:      1
      - Remote FS root: `c:\Jenkins`
      - Labels:         windows windows10 x86 x64 msbuild2015 msbuild2013 packaging louisdavid
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.10
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_121`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   1.33 GB (1431830528)
          + Allocated memory: 486.00 MB (509607936)
          + Free memory:      195.30 MB (204784200)
          + In-use memory:    290.70 MB (304823736)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Windows 10
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 6884 (0x1ae4)
      - Process started: 2017-07-12 10:24:42.589+0000
      - Process uptime: 9 hr 32 min
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_121\lib\resources.jar;C:\Program Files\Java\jre1.8.0_121\lib\rt.jar;C:\Program Files\Java\jre1.8.0_121\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_121\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_121\lib\jce.jar;C:\Program Files\Java\jre1.8.0_121\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_121\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_121\classes;C:\Program Files\Java\jre1.8.0_121\lib\deploy.jar;C:\Program Files\Java\jre1.8.0_121\lib\javaws.jar;C:\Program Files\Java\jre1.8.0_121\lib\plugin.jar`
          + Classpath: `C:\Program Files\Java\jre1.8.0_121\lib\deploy.jar`
          + Library path: `C:\Program Files\Java\jre1.8.0_121\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\doxygen\bin;C:\Program Files\Git\cmd;C:\Program Files\TortoiseGit\bin;C:\Program Files\TortoiseHg\;C:\Program Files\Perforce;C:\Program Files (x86)\CMake\bin;C:\Program Files\gevorkyan.org\MicroProfiler\;C:\Program Files\gevorkyan.org\MicroProfiler\x86\;C:\Program Files\TortoiseSVN\bin;C:\Program Files\MiKTeX 2.9\miktex\bin\x64\;C:\Windows\system32\config\systemprofile\.dnx\bin;C:\Program Files\Microsoft DNX\Dnvm\;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Program Files (x86)\Windows Kits\8.1\Windows Performance Toolkit\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Microsoft SDKs\TypeScript\1.0\;C:\Users\ldgrondin\AppData\Local\Microsoft\WindowsApps;C:\Users\ldgrondin\AppData\Local\atom\bin;"C:\Program Files\Java\jre1.8.0_121\bin";.`
          + arg[0]: `-Xbootclasspath/a:C:\Program Files\Java\jre1.8.0_121\lib\deploy.jar;C:\Program Files\Java\jre1.8.0_121\lib\javaws.jar;C:\Program Files\Java\jre1.8.0_121\lib\plugin.jar`
          + arg[1]: `-Xverify:remote`
          + arg[2]: `-Djava.security.manager`
          + arg[3]: `-Xmx1536m`
          + arg[4]: `-Djnlp.tk=awt`
          + arg[5]: `-Djnlpx.vmargs=LVhteDE1MzZtAA==`
          + arg[6]: `-Djnlpx.jvm=C:\Program Files\Java\jre1.8.0_121\bin\javaw.exe`
          + arg[7]: `-Djnlpx.splashport=57833`
          + arg[8]: `-Djnlpx.home=C:\Program Files\Java\jre1.8.0_121\bin`
          + arg[9]: `-Djnlpx.remove=false`
          + arg[10]: `-Djnlpx.offline=false`
          + arg[11]: `-Djnlpx.relaunch=true`
          + arg[12]: `-Djnlpx.session.data=C:\Users\LDGRON~1\AppData\Local\Temp\session9052752725617490129`
          + arg[13]: `-Djnlpx.heapsize=NULL,NULL`
          + arg[14]: `-Djava.security.policy=file:C:\Program Files\Java\jre1.8.0_121\lib\security\javaws.policy`
          + arg[15]: `-DtrustProxy=true`
          + arg[16]: `-Djnlpx.origFilenameArg=http://bcadlx03/Jenkins/computer/LDMachine/slave-agent.jnlp`

