-----------
 * Name eth0
 ** Hardware Address - 00155d1eaf07
 ** Index - 2
 ** InetAddress - /fd09:a873:a6eb:130:3122:1250:2:66%eth0
 ** InetAddress - /fe80:0:0:0:8f24:d910:851f:416f%eth0
 ** InetAddress - /fe80:0:0:0:f642:73a6:2106:3aa2%eth0
 ** InetAddress - /10.1.30.66
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
