-----------
 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) Ethernet Connection I217-V
 ** Hardware Address - ac220bbf9535
 ** Index - 2
 ** InetAddress - /10.1.30.176
 ** InetAddress - /fd09:a873:a6eb:130:3211:1210:2:176
 ** InetAddress - /fe80:0:0:0:ae22:bff:febf:9535%eth0
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Kernel Debug Network Adapter
 ** Index - 3
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) Ethernet Connection I217-V-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 4
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) Ethernet Connection I217-V-QoS Packet Scheduler-0000
 ** Index - 5
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) Ethernet Connection I217-V-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 6
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
