Current build queue has 1 item(s).
---------------
 * Name of item: part of Bodycad cpp projects » CAD_CPP_ContinuousBuild #173
    - In queue for: 4 hr 35 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on windows&&x64
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@38d6362f
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@4974afe9
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@6f30799e
    - Can run: null
----

Is quieting down: false
