User
====

Authentication
--------------

  * Authenticated: true
  * Name: anonymous
  * Authorities 
      - `anonymous`
  * Raw: `org.acegisecurity.providers.anonymous.AnonymousAuthenticationToken@ffffffc4: Username: anonymous; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: anonymous`

