Jenkins
=======

Version details
---------------

  * Version: `2.60.2`
  * Mode:    WAR
  * Url:     http://jenkins.dev.aws.chotel.com:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/java/jdk1.8.0_102/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_102
      - Maximum memory:   2.95 GB (3172466688)
      - Allocated memory: 2.95 GB (3172466688)
      - Free memory:      2.55 GB (2737234872)
      - In-use memory:    415.07 MB (435231816)
      - GC strategy:      ConcMarkSweepGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.102-b14
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.9.38-16.33.amzn1.x86_64
  * Process ID: 2882 (0xb42)
  * Process started: 2017-09-14 00:20:51.529+0000
  * Process uptime: 2 min 37 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/java/jdk1.8.0_102/jre/lib/resources.jar:/usr/java/jdk1.8.0_102/jre/lib/rt.jar:/usr/java/jdk1.8.0_102/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_102/jre/lib/jsse.jar:/usr/java/jdk1.8.0_102/jre/lib/jce.jar:/usr/java/jdk1.8.0_102/jre/lib/charsets.jar:/usr/java/jdk1.8.0_102/jre/lib/jfr.jar:/usr/java/jdk1.8.0_102/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-XX:+HeapDumpOnOutOfMemoryError`
      - arg[1]: `-XX:HeapDumpPath=/var/lib/jenkins`
      - arg[2]: `-verbose:gc`
      - arg[3]: `-Xloggc:/var/log/jenkins/jenkins-gc-%t.log`
      - arg[4]: `-XX:NumberOfGCLogFiles=2`
      - arg[5]: `-XX:+UseGCLogFileRotation`
      - arg[6]: `-XX:GCLogFileSize=100m`
      - arg[7]: `-XX:+PrintGC`
      - arg[8]: `-XX:+PrintGCDateStamps`
      - arg[9]: `-XX:+PrintGCDetails`
      - arg[10]: `-XX:+PrintHeapAtGC`
      - arg[11]: `-XX:+PrintGCCause`
      - arg[12]: `-XX:+PrintTenuringDistribution`
      - arg[13]: `-XX:+PrintReferenceGC`
      - arg[14]: `-XX:+PrintAdaptiveSizePolicy`
      - arg[15]: `-XX:+UseConcMarkSweepGC`
      - arg[16]: `-XX:+ExplicitGCInvokesConcurrentAndUnloadsClasses`
      - arg[17]: `-XX:+CMSParallelRemarkEnabled`
      - arg[18]: `-XX:+ParallelRefProcEnabled`
      - arg[19]: `-XX:+CMSClassUnloadingEnabled`
      - arg[20]: `-XX:+ScavengeBeforeFullGC`
      - arg[21]: `-XX:+CMSScavengeBeforeRemark`
      - arg[22]: `-XX:NewSize=1365m`
      - arg[23]: `-XX:MaxNewSize=1365m`
      - arg[24]: `-XX:NewRatio=2`
      - arg[25]: `-Djenkins.model.Jenkins.logStartupPerformance=true`
      - arg[26]: `-Djava.awt.headless=true`
      - arg[27]: `-Djava.net.preferIPv4Stack=true`
      - arg[28]: `-DHA_JGROUPS_DIR=/tmp/jgroups/`
      - arg[29]: `-Dhudson.slaves.WorkspaceList=__`
      - arg[30]: `-Xmx3162m`
      - arg[31]: `-Xms3162m`
      - arg[32]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.92 'Static Analysis Utilities'
  * ansicolor:0.5.2 'AnsiColor'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * aws-credentials:1.22 'CloudBees Amazon Web Services Credentials Plugin'
  * aws-java-sdk:1.11.119 'Amazon Web Services SDK'
  * bitbucket:1.1.5 'Jenkins Bitbucket Plugin'
  * blueocean:1.2.1 'Blue Ocean'
  * blueocean-autofavorite:1.0.0 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.2.1 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.2.1 'Common API for Blue Ocean'
  * blueocean-config:1.2.1 'Config API for Blue Ocean'
  * blueocean-dashboard:1.2.1 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.1.0 'Display URL for Blue Ocean'
  * blueocean-events:1.2.1 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.2.1 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.2.1 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.2.1 'i18n for Blue Ocean'
  * blueocean-jwt:1.2.1 'JWT for Blue Ocean'
  * blueocean-personalization:1.2.1 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.2.1 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.2.1 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.2.1 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.2.1 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.2.1 'REST Implementation for Blue Ocean'
  * blueocean-web:1.2.1 'Web for Blue Ocean'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.11 'Branch API Plugin'
  * build-name-setter:1.6.7 'build-name-setter'
  * build-pipeline-plugin:1.5.7.1 'Build Pipeline Plugin'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * build-timestamp:1.0.1 'Build Timestamp Plugin'
  * build-user-vars-plugin:1.5 'Jenkins user build vars plugin'
  * build-with-parameters:1.4 'Build With Parameters'
  * built-on-column:1.1 'built-on-column'
  * cloudbees-bitbucket-branch-source:2.2.3 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.1.2 'Folders Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:2.16.3 'Config File Provider Plugin'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.15 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * dashboard-view:2.9.11 'Dashboard View'
  * description-setter:1.10 'Jenkins description setter plugin'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.8 'Docker Commons Plugin'
  * docker-workflow:1.13 'Docker Pipeline'
  * durable-task:1.14 'Durable Task Plugin'
  * ec2-fleet:1.1.4 'EC2 Fleet Jenkins Plugin'
  * email-ext:2.59 'Email Extension Plugin'
  * emailext-template:1.0 'Email Extension Template Plugin'
  * embeddable-build-status:1.9 'embeddable-build-status'
  * envinject:2.1.3 'Environment Injector Plugin'
  * envinject-api:1.2 'EnvInject API Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * ez-templates:1.3.0 'EZ Templates'
  * favorite:2.3.0 'Favorite'
  * git:3.5.1 'Jenkins Git plugin'
  * git-client:2.5.0 'Jenkins Git client plugin'
  * git-parameter:0.8.1 'Git Parameter Plug-In'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.28.0 'GitHub plugin'
  * github-api:1.86 'GitHub API Plugin'
  * github-branch-source:2.2.3 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * gradle:1.27.1 'Gradle Plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jenkins-multijob-plugin:1.28 'Jenkins Multijob plugin'
  * jira:2.4.2 'Jenkins JIRA plugin'
  * job-dsl:1.65 'Job DSL'
  * jobConfigHistory:2.17 'Jenkins Job Configuration History Plugin'
  * jquery:1.11.2-1 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.21 'JUnit Plugin'
  * ldap:1.17 'LDAP Plugin'
  * lockable-resources:2.0 'Lockable Resources plugin'
  * m2release:0.14.0 'Jenkins Maven Release Plug-in Plug-in'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mask-passwords:2.10.1 'Mask Passwords Plugin'
  * matrix-auth:1.7 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.11 'Matrix Project Plugin'
  * maven-plugin:2.17 'Maven Integration plugin'
  * mercurial:2.1 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nodejs:1.2.4 'NodeJS Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * Office-365-Connector:3.0 'Office 365 Connector'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35.1 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.9 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.9 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.9 'Pipeline: Declarative Extension Points API'
  * pipeline-multibranch-defaults:1.1 'Pipeline: Multibranch with defaults'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.9 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.4.1 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * publish-over-ssh:1.17 'Publish Over SSH'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * rebuild:1.25 'Rebuilder'
  * resource-disposer:0.7 'Resource Disposer Plugin'
  * role-strategy:2.6.0 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * s3:0.10.12 'Jenkins S3 publisher plugin'
  * scm-api:2.2.1 'SCM API Plugin'
  * script-security:1.34 'Script Security Plugin'
  * seed:2.1.4 'Seed Jenkins plug-in'
  * slack:2.3 'Slack Notification Plugin'
  * slave-setup:1.10 'Jenkins Slave SetupPlugin'
  * sonar:2.6.1 'SonarQube Scanner for Jenkins'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.5 'Jenkins SSH plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.21 'Jenkins SSH Slaves plugin'
  * stashNotifier:1.11.6 'Stash Notifier'
  * structs:1.10 'Structs Plugin'
  * support-core:2.41 'Support Core Plugin'
  * template-project:1.5.2 'Template Project plugin'
  * throttle-concurrents:2.0.1 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.3 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * warnings:4.63 'Warnings Plug-in'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.20 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.40 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.15 'Pipeline: Nodes and Processes'
  * workflow-job:2.12.2 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.12 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
  * ws-cleanup:0.34 'Jenkins Workspace Cleanup Plugin'
