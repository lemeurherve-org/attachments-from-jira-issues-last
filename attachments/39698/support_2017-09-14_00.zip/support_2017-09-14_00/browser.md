Browser
=======

  * Screen size: 3440x1440
  * User Agent
      - Type:     Browser
      - Name:     Safari
      - Family:   SAFARI
      - Producer: Apple Inc.
      - Version:  10.1.2
      - Raw:      `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8`
  * Operating System
      - Name:     OS X
      - Family:   OS_X
      - Producer: Apple Computer, Inc.
      - Version:  10.12.6

