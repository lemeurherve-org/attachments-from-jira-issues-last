Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 15
    - Number of items per container: 1.4 [n=15, s=2.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 3
    - Number of builds per job: 43.0 [n=3, s=60.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 6
    - Number of builds per job: 8.666666666666666 [n=6, s=6.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 1
    - Number of items per container: 0 [n=1]

Total job statistics
======================

  * Number of jobs: 9
  * Number of builds per job: 20.11111111111111 [n=9, s=40.0]
