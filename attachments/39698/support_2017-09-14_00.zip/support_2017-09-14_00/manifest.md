Support Bundle Manifest
=======================

Generated on 2017-09-14 00:23:28.470+0000

Requested components:

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.bitbucket.endpoints.BitbucketEndpointConfiguration.xml`

      - `jenkins-root-configuration-files/com.michelin.cio.hudson.plugins.maskpasswords.MaskPasswordsConfig.xml`

      - `jenkins-root-configuration-files/com.orctom.jenkins.plugin.buildtimestamp.BuildTimestampWrapper.xml`

      - `jenkins-root-configuration-files/com.sonyericsson.rebuild.RebuildDescriptor.xml`

      - `jenkins-root-configuration-files/com.tikal.jenkins.plugins.multijob.PhaseJobsConfig.xml`

      - `jenkins-root-configuration-files/envInject.xml`

      - `jenkins-root-configuration-files/envinject-plugin-configuration.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.analysis.core.GlobalSettings.xml`

      - `jenkins-root-configuration-files/hudson.plugins.ansicolor.AnsiColorBuildWrapper.xml`

      - `jenkins-root-configuration-files/hudson.plugins.build_timeout.operations.BuildStepOperation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.copyartifact.TriggeredBuildSelector.xml`

      - `jenkins-root-configuration-files/hudson.plugins.emailext.ExtendedEmailPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.gradle.Gradle.xml`

      - `jenkins-root-configuration-files/hudson.plugins.jira.JiraProjectProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.mercurial.MercurialInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.s3.S3BucketPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.MsBuildSQRunnerInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarRunnerInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.throttleconcurrents.ThrottleJobProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.timestamper.TimestamperConfig.xml`

      - `jenkins-root-configuration-files/hudson.plugins.warnings.WarningsPublisher.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/javaposse.jobdsl.plugin.ExecuteDslScripts.xml`

      - `jenkins-root-configuration-files/javaposse.jobdsl.plugin.GlobalJobDslSecurityConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.CLI.xml`

      - `jenkins-root-configuration-files/jenkins.metrics.api.MetricsAccessKey.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.nodejs.tools.NodeJSInstallation.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.publish_over_ssh.BapSshPublisherPlugin.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.SlackNotifier.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.webhook.GlobalConfig.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.UpdateSiteWarningsConfiguration.xml`

      - `jenkins-root-configuration-files/jobConfigHistory.xml`

      - `jenkins-root-configuration-files/net.nemerosa.jenkins.seed.SeedPlugin.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkins.plugins.lockableresources.LockableResourcesManager.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.conditionalbuildstep.singlestep.SingleConditionalBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.commons.tools.DockerTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitApacheTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.pipeline.milestone.MilestoneStep.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.pipeline.modeldefinition.config.GlobalConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.resourcedisposer.AsyncResourceDisposer.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.slave_setup.SetupConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.stashNotifier.StashNotifier.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.SSHBuildWrapper.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.m2release.M2ReleaseBuildWrapper.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/CFRG-Slave-us-east-1c-linux-standard/checksums.md5`

      - `nodes/slave/CFRG-Slave-us-east-1d-linux-standard/checksums.md5`

      - `nodes/slave/CFRG-Slave-us-east-1e-linux-standard/checksums.md5`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/checksums.md5`

      - `nodes/slave/CFRG-Slave-us-west-2b-linux-standard/checksums.md5`

      - `nodes/slave/CFRG-Slave-us-west-2c-linux-standard/checksums.md5`

      - `nodes/slave/INFR-Slave-us-east-1c-linux-standard/checksums.md5`

      - `nodes/slave/INFR-Slave-us-east-1d-linux-standard/checksums.md5`

      - `nodes/slave/INFR-Slave-us-east-1e-linux-standard/checksums.md5`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/checksums.md5`

      - `nodes/slave/INFR-Slave-us-west-2b-linux-standard/checksums.md5`

      - `nodes/slave/INFR-Slave-us-west-2c-linux-standard/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/CFRG-Slave-us-east-1c-linux-standard/environment.txt`

      - `nodes/slave/CFRG-Slave-us-east-1d-linux-standard/environment.txt`

      - `nodes/slave/CFRG-Slave-us-east-1e-linux-standard/environment.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/environment.txt`

      - `nodes/slave/CFRG-Slave-us-west-2b-linux-standard/environment.txt`

      - `nodes/slave/CFRG-Slave-us-west-2c-linux-standard/environment.txt`

      - `nodes/slave/INFR-Slave-us-east-1c-linux-standard/environment.txt`

      - `nodes/slave/INFR-Slave-us-east-1d-linux-standard/environment.txt`

      - `nodes/slave/INFR-Slave-us-east-1e-linux-standard/environment.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/environment.txt`

      - `nodes/slave/INFR-Slave-us-west-2b-linux-standard/environment.txt`

      - `nodes/slave/INFR-Slave-us-west-2c-linux-standard/environment.txt`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/dmesg.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/dmi.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/proc/cpuinfo.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/proc/mounts.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/proc/net/rpc/nfs.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/proc/net/rpc/nfsd.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/proc/swaps.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/proc/system-uptime.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/sysctl.txt`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/userid.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/dmesg.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/dmi.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/proc/cpuinfo.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/proc/mounts.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/proc/net/rpc/nfs.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/proc/net/rpc/nfsd.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/proc/swaps.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/proc/system-uptime.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/sysctl.txt`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/CFRG-Slave-us-east-1c-linux-standard/system.properties`

      - `nodes/slave/CFRG-Slave-us-east-1d-linux-standard/system.properties`

      - `nodes/slave/CFRG-Slave-us-east-1e-linux-standard/system.properties`

      - `nodes/slave/CFRG-Slave-us-west-2a-linux-standard/system.properties`

      - `nodes/slave/CFRG-Slave-us-west-2b-linux-standard/system.properties`

      - `nodes/slave/CFRG-Slave-us-west-2c-linux-standard/system.properties`

      - `nodes/slave/INFR-Slave-us-east-1c-linux-standard/system.properties`

      - `nodes/slave/INFR-Slave-us-east-1d-linux-standard/system.properties`

      - `nodes/slave/INFR-Slave-us-east-1e-linux-standard/system.properties`

      - `nodes/slave/INFR-Slave-us-west-2a-linux-standard/system.properties`

      - `nodes/slave/INFR-Slave-us-west-2b-linux-standard/system.properties`

      - `nodes/slave/INFR-Slave-us-west-2c-linux-standard/system.properties`

