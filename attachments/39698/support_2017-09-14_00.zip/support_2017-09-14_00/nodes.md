Node statistics
===============

  * Total number of nodes
      - Sample size:        10
      - Average (mean):     13.0
      - Average (median):   13.0
      - Standard deviation: 0.0
      - Minimum:            13
      - Maximum:            13
      - 95th percentile:    13.0
      - 99th percentile:    13.0
  * Total number of nodes online
      - Sample size:        10
      - Average (mean):     2.940544163707122
      - Average (median):   3.0
      - Standard deviation: 0.3396714237560631
      - Minimum:            1
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors
      - Sample size:        10
      - Average (mean):     10.762176654828487
      - Average (median):   11.0
      - Standard deviation: 1.3586856950242525
      - Minimum:            3
      - Maximum:            11
      - 95th percentile:    11.0
      - 99th percentile:    11.0
  * Total number of executors in use
      - Sample size:        10
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      3
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Slave Version:  3.7
      - Java
          + Home:           `/usr/java/jdk1.8.0_102/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_102
          + Maximum memory:   2.95 GB (3172466688)
          + Allocated memory: 2.95 GB (3172466688)
          + Free memory:      2.55 GB (2735325760)
          + In-use memory:    416.89 MB (437140928)
          + GC strategy:      ConcMarkSweepGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.102-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.9.38-16.33.amzn1.x86_64
      - Process ID: 2882 (0xb42)
      - Process started: 2017-09-14 00:20:51.529+0000
      - Process uptime: 2 min 37 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_102/jre/lib/resources.jar:/usr/java/jdk1.8.0_102/jre/lib/rt.jar:/usr/java/jdk1.8.0_102/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_102/jre/lib/jsse.jar:/usr/java/jdk1.8.0_102/jre/lib/jce.jar:/usr/java/jdk1.8.0_102/jre/lib/charsets.jar:/usr/java/jdk1.8.0_102/jre/lib/jfr.jar:/usr/java/jdk1.8.0_102/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[1]: `-XX:HeapDumpPath=/var/lib/jenkins`
          + arg[2]: `-verbose:gc`
          + arg[3]: `-Xloggc:/var/log/jenkins/jenkins-gc-%t.log`
          + arg[4]: `-XX:NumberOfGCLogFiles=2`
          + arg[5]: `-XX:+UseGCLogFileRotation`
          + arg[6]: `-XX:GCLogFileSize=100m`
          + arg[7]: `-XX:+PrintGC`
          + arg[8]: `-XX:+PrintGCDateStamps`
          + arg[9]: `-XX:+PrintGCDetails`
          + arg[10]: `-XX:+PrintHeapAtGC`
          + arg[11]: `-XX:+PrintGCCause`
          + arg[12]: `-XX:+PrintTenuringDistribution`
          + arg[13]: `-XX:+PrintReferenceGC`
          + arg[14]: `-XX:+PrintAdaptiveSizePolicy`
          + arg[15]: `-XX:+UseConcMarkSweepGC`
          + arg[16]: `-XX:+ExplicitGCInvokesConcurrentAndUnloadsClasses`
          + arg[17]: `-XX:+CMSParallelRemarkEnabled`
          + arg[18]: `-XX:+ParallelRefProcEnabled`
          + arg[19]: `-XX:+CMSClassUnloadingEnabled`
          + arg[20]: `-XX:+ScavengeBeforeFullGC`
          + arg[21]: `-XX:+CMSScavengeBeforeRemark`
          + arg[22]: `-XX:NewSize=1365m`
          + arg[23]: `-XX:MaxNewSize=1365m`
          + arg[24]: `-XX:NewRatio=2`
          + arg[25]: `-Djenkins.model.Jenkins.logStartupPerformance=true`
          + arg[26]: `-Djava.awt.headless=true`
          + arg[27]: `-Djava.net.preferIPv4Stack=true`
          + arg[28]: `-DHA_JGROUPS_DIR=/tmp/jgroups/`
          + arg[29]: `-Dhudson.slaves.WorkspaceList=__`
          + arg[30]: `-Xmx3162m`
          + arg[31]: `-Xms3162m`
          + arg[32]: `-DJENKINS_HOME=/var/lib/jenkins`

  * CFRG-Slave-us-east-1c-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux CFRG Slaves in us-east-1c_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         cfrg cfrg-us-east-1
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * CFRG-Slave-us-east-1d-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux CFRG Slaves in us-east-1d_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         cfrg cfrg-us-east-1
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * CFRG-Slave-us-east-1e-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux CFRG Slaves in us-east-1e_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         cfrg cfrg-us-east-1
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * CFRG-Slave-us-west-2a-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux CFRG Slaves in us-west-2a_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         cfrg cfrg-us-west-2
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `/usr/java/jdk1.8.0_102/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_102
          + Maximum memory:   880.00 MB (922746880)
          + Allocated memory: 73.50 MB (77070336)
          + Free memory:      48.84 MB (51217472)
          + In-use memory:    24.66 MB (25852864)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.102-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.9.38-16.33.amzn1.x86_64
      - Process ID: 2832 (0xb10)
      - Process started: 2017-09-14 00:21:13.072+0000
      - Process uptime: 2 min 15 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_102/jre/lib/resources.jar:/usr/java/jdk1.8.0_102/jre/lib/rt.jar:/usr/java/jdk1.8.0_102/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_102/jre/lib/jsse.jar:/usr/java/jdk1.8.0_102/jre/lib/jce.jar:/usr/java/jdk1.8.0_102/jre/lib/charsets.jar:/usr/java/jdk1.8.0_102/jre/lib/jfr.jar:/usr/java/jdk1.8.0_102/jre/classes`
          + Classpath: `/opt/jenkins-slave/slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * CFRG-Slave-us-west-2b-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux CFRG Slaves in us-west-2b_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         cfrg cfrg-us-west-2
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * CFRG-Slave-us-west-2c-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux CFRG Slaves in us-west-2c_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         cfrg cfrg-us-west-2
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * INFR-Slave-us-east-1c-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux INFR Slaves in us-east-1c_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         infr infr-us-east-1
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * INFR-Slave-us-east-1d-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux INFR Slaves in us-east-1d_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         infr infr-us-east-1
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * INFR-Slave-us-east-1e-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux INFR Slaves in us-east-1e_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         infr infr-us-east-1
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * INFR-Slave-us-west-2a-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux INFR Slaves in us-west-2a_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         infr infr-us-west-2
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `/usr/java/jdk1.8.0_102/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_102
          + Maximum memory:   910.62 MB (954859520)
          + Allocated memory: 58.00 MB (60817408)
          + Free memory:      47.18 MB (49474448)
          + In-use memory:    10.82 MB (11342960)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.102-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.9.38-16.33.amzn1.x86_64
      - Process ID: 2799 (0xaef)
      - Process started: 2017-09-14 00:21:13.181+0000
      - Process uptime: 2 min 15 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_102/jre/lib/resources.jar:/usr/java/jdk1.8.0_102/jre/lib/rt.jar:/usr/java/jdk1.8.0_102/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_102/jre/lib/jsse.jar:/usr/java/jdk1.8.0_102/jre/lib/jce.jar:/usr/java/jdk1.8.0_102/jre/lib/charsets.jar:/usr/java/jdk1.8.0_102/jre/lib/jfr.jar:/usr/java/jdk1.8.0_102/jre/classes`
          + Classpath: `/opt/jenkins-slave/slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * INFR-Slave-us-west-2b-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux INFR Slaves in us-west-2b_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         infr infr-us-west-2
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * INFR-Slave-us-west-2c-linux-standard (`hudson.slaves.DumbSlave`)
      - Description:    _Standard Linux INFR Slaves in us-west-2c_
      - Executors:      4
      - Remote FS root: `/opt/jenkins-slave`
      - Labels:         infr infr-us-west-2
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

