package issue

import org.jenkinsci.plugins.workflow.cps.DSL

class BaseClass implements Serializable {
    DSL steps

    BaseClass(DSL steps) {
        this.steps = steps
    }
}
