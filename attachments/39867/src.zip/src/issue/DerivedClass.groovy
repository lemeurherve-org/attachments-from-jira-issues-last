package issue

import org.jenkinsci.plugins.workflow.cps.DSL

class DerivedClass extends BaseClass implements Serializable {

    DerivedClass(DSL steps) {
        super(steps)
    }

    def doSomething() {
        steps.echo "Won't work"
    }
}
