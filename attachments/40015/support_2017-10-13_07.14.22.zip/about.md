Jenkins
=======

Version details
---------------

  * Version: `2.73.2`
  * Mode:    WAR
  * Url:     https://ci.bodidata.com/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_131
      - Maximum memory:   878.50 MB (921174016)
      - Allocated memory: 439.00 MB (460324864)
      - Free memory:      214.43 MB (224845608)
      - In-use memory:    224.57 MB (235479256)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.131-b11
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.4.0-87-generic
      - Distribution: Ubuntu 16.04.3 LTS
  * Process ID: 23878 (0x5d46)
  * Process started: 2017-10-13 07:08:33.204+0000
  * Process uptime: 5 min 49 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Dcom.cloudbees.hudson.plugins.folder.computed.FolderComputation.BACKUP_LOG_COUNT=10`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.3-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.3.0 'Blue Ocean'
  * blueocean-autofavorite:1.0.0 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.3.0 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.3.0 'Common API for Blue Ocean'
  * blueocean-config:1.3.0 'Config API for Blue Ocean'
  * blueocean-dashboard:1.3.0 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.1.0 'Display URL for Blue Ocean'
  * blueocean-events:1.3.0 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.3.0 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.3.0 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.3.0 'i18n for Blue Ocean'
  * blueocean-jira:1.3.0 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.3.0 'JWT for Blue Ocean'
  * blueocean-personalization:1.3.0 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.3.0 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.3.0 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.3.0 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.3.0 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.3.0 'REST Implementation for Blue Ocean'
  * blueocean-web:1.3.0 'Web for Blue Ocean'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.14 'Branch API Plugin'
  * build-timeout:1.19 'Build Timeout'
  * cloudbees-bitbucket-branch-source:2.2.3 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.2.0 'Folders Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * display-url-api:2.1.0 'Display URL API'
  * docker-commons:1.9 'Docker Commons Plugin'
  * docker-workflow:1.13 'Docker Pipeline'
  * durable-task:1.14 'Durable Task Plugin'
  * email-ext:2.60 'Email Extension Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.0 'Favorite'
  * git:3.6.0 'Jenkins Git plugin'
  * git-client:2.5.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.28.0 'GitHub plugin'
  * github-api:1.89 'GitHub API Plugin'
  * github-branch-source:2.2.3 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * gradle:1.28 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.8.7.0 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jira:2.4.2 'Jenkins JIRA plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.21 'JUnit Plugin'
  * ldap:1.17 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.1 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.12 'Matrix Project Plugin'
  * maven-plugin:3.0 'Maven Integration plugin'
  * mercurial:2.2 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.2 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.2 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.2 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.2 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * resource-disposer:0.8 'Resource Disposer Plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.2.3 'SCM API Plugin'
  * script-security:1.34 'Script Security Plugin'
  * slack:2.3 'Slack Notification Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.5 'Jenkins SSH plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.21 'Jenkins SSH Slaves plugin'
  * structs:1.10 'Structs Plugin'
  * subversion:2.9 'Jenkins Subversion Plug-in'
  * support-core:2.41 'Support Core Plugin'
  * testng-plugin:1.14 'TestNG Results Plugin'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.3 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.22 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.41 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.15 'Pipeline: Nodes and Processes'
  * workflow-job:2.14.1 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.13 'Pipeline: Step API'
  * workflow-support:2.15 'Pipeline: Supporting APIs'
  * ws-cleanup:0.34 'Jenkins Workspace Cleanup Plugin'
