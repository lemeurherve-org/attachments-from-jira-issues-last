Item statistics
===============

  * `jenkins.branch.OrganizationFolder`
    - Number of items: 1
    - Number of items per container: 5 [n=1]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 15
    - Number of builds per job: 20.733333333333334 [n=15, s=30.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 5
    - Number of items per container: 3.0 [n=5, s=2.0]

Total job statistics
======================

  * Number of jobs: 15
  * Number of builds per job: 20.733333333333334 [n=15, s=30.0]
