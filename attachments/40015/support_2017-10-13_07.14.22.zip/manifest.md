Support Bundle Manifest
=======================

Generated on 2017-10-13 07:14:22.385+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-10-13_04.47.56.log`

      - `nodes/master/logs/all_2017-10-13_04.49.10.log`

      - `nodes/master/logs/all_2017-10-13_05.18.00.log`

      - `nodes/master/logs/all_2017-10-13_06.56.27.log`

      - `nodes/master/logs/all_2017-10-13_07.01.09.log`

      - `nodes/master/logs/all_2017-10-13_07.03.31.log`

      - `nodes/master/logs/all_2017-10-13_07.05.08.log`

      - `nodes/master/logs/all_2017-10-13_07.08.35.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/health-checker.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log.1`

      - `other-logs/jenkins.branch.MultiBranchProject.log.2`

      - `other-logs/jenkins.branch.MultiBranchProject.log.3`

      - `other-logs/jenkins.branch.MultiBranchProject.log.4`

      - `other-logs/jenkins.branch.MultiBranchProject.log.5`

      - `other-logs/jenkins.branch.OrganizationFolder.log`

      - `other-logs/jenkins.branch.OrganizationFolder.log.1`

      - `other-logs/jenkins.branch.OrganizationFolder.log.2`

      - `other-logs/jenkins.branch.OrganizationFolder.log.3`

      - `other-logs/jenkins.branch.OrganizationFolder.log.4`

      - `other-logs/jenkins.branch.OrganizationFolder.log.5`

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/windows-slave-1/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/windows-slave-1/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/windows-slave-1/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/linux/gnuplot`

      - `load-stats/label/linux/hour.csv`

      - `load-stats/label/linux/min.csv`

      - `load-stats/label/linux/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/qt/gnuplot`

      - `load-stats/label/qt/hour.csv`

      - `load-stats/label/qt/min.csv`

      - `load-stats/label/qt/sec10.csv`

      - `load-stats/label/ubuntu/gnuplot`

      - `load-stats/label/ubuntu/hour.csv`

      - `load-stats/label/ubuntu/min.csv`

      - `load-stats/label/ubuntu/sec10.csv`

      - `load-stats/label/windows-slave-1/gnuplot`

      - `load-stats/label/windows-slave-1/hour.csv`

      - `load-stats/label/windows-slave-1/min.csv`

      - `load-stats/label/windows-slave-1/sec10.csv`

      - `load-stats/label/windows/gnuplot`

      - `load-stats/label/windows/hour.csv`

      - `load-stats/label/windows/min.csv`

      - `load-stats/label/windows/sec10.csv`

      - `load-stats/label/windows10/gnuplot`

      - `load-stats/label/windows10/hour.csv`

      - `load-stats/label/windows10/min.csv`

      - `load-stats/label/windows10/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/windows-slave-1/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/windows-slave-1/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/windows-slave-1/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20170913-102154.861.txt`

      - `slow-requests/20170913-102300.861.txt`

      - `slow-requests/20170913-102609.861.txt`

      - `slow-requests/20170913-102742.861.txt`

      - `slow-requests/20170917-101606.861.txt`

      - `slow-requests/20170917-101748.861.txt`

      - `slow-requests/20170917-101942.861.txt`

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/windows-slave-1/thread-dump.txt`

