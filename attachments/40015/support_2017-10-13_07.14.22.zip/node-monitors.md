Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * windows-slave-1: Windows 10 (x86)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * windows-slave-1: 12 sec behind
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 5.019GB left on /data/common/jenkins/home.
   * windows-slave-1: Disk space is too low. Only 86.483GB left on C:\Jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:179/3950MB  Swap:0/0MB
   * windows-slave-1: Memory:5939/8094MB  Swap:7134/9374MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 5.019GB left on /tmp.
   * windows-slave-1: Disk space is too low. Only 86.482GB left on C:\Windows\Temp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * windows-slave-1: 3999ms
