Node statistics
===============

  * Total number of nodes
      - Sample size:        23
      - Average (mean):     2.0000000000000004
      - Average (median):   2.0
      - Standard deviation: 4.440892098500626E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        23
      - Average (mean):     1.9967672176860212
      - Average (median):   2.0
      - Standard deviation: 0.05676558316875667
      - Minimum:            1
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors
      - Sample size:        23
      - Average (mean):     7.987068870744086
      - Average (median):   8.0
      - Standard deviation: 0.22706233267502668
      - Minimum:            4
      - Maximum:            8
      - 95th percentile:    8.0
      - 99th percentile:    8.0
  * Total number of executors in use
      - Sample size:        23
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      4
      - FS root:        `/data/common/jenkins/home`
      - Labels:         ubuntu linux
      - Usage:          `NORMAL`
      - Slave Version:  3.10.2
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_131
          + Maximum memory:   878.50 MB (921174016)
          + Allocated memory: 439.00 MB (460324864)
          + Free memory:      213.62 MB (223995744)
          + In-use memory:    225.38 MB (236329120)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.131-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.0-87-generic
          + Distribution: Ubuntu 16.04.3 LTS
      - Process ID: 23878 (0x5d46)
      - Process started: 2017-10-13 07:08:33.204+0000
      - Process uptime: 5 min 49 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Dcom.cloudbees.hudson.plugins.folder.computed.FolderComputation.BACKUP_LOG_COUNT=10`

  * windows-slave-1 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 10 with Qt_
      - Executors:      4
      - Remote FS root: `C:\Jenkins`
      - Labels:         windows windows10 qt
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        (timeout with no cache available)

