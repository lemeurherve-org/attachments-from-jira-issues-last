User
====

Authentication
--------------

  * Authenticated: true
  * Name: hai
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@83247167: Username: hudson.security.HudsonPrivateSecurityRealm$Details@10f720a0; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@21a2c: RemoteIpAddress: 115.78.233.251; SessionId: node0167trcbij4kxfdi447cc78mnd1; Granted Authorities: authenticated`

