#!groovy
/**
FIXME: JLP.- En pruebas. No funcionan los condicionales. NO USAR AÚN. La versión que falla es la 1.2.4 · Core 2.73

 * Pipeline común a todos los proyectos de tipo parent.pom en Eprinsa
 */
def call(String rutaPomXml) {
	echo "Construyendo pipeline de proyecto de tipo paren.pom. Ruta pom xml: ${rutaPomXml}"
	env.RUTA_POM_XML = rutaPomXml
	 
	pipeline { 
		agent none	//Agente principal
		options { buildDiscarder(logRotator(numToKeepStr: '10')) }
		tools { 
	        maven 'maven 3.3.9' //Usamos maven 3.3.9
	        jdk 'java1.8' //Compilamos con Java 1.8
	    }
		// triggers { /*pollSCM('H/60 * * * *') JLP.- Desactivado provisional*/ }
		stages {
			stage('Preparación') {
				//agent none JLP.- Parece que no hace bien el checkout
				agent { label 'linux' }
				steps {
					parallel('Comprobando si existen nuevas versiones a título informativo': {
								muestraNuevasVersiones rutaPomXml: env.RUTA_POM_XML
							 })
				}
			}
			stage('Configurar parámetros adicionales') {
				agent none
				steps {
					ofreceConfigurarParametrosAdicionales()
				}
			}
			stage('Generación') 
			{
				agent { label 'linux' }
				steps {
					genera esLibreria: false, rutaPomXml: env.RUTA_POM_XML
				}
			}
			stage('Subida a Nexus') 
			{
				agent { label 'linux' }
				steps {
					subeANexus rutaPomXml: env.RUTA_POM_XML
				}
			}
			stage('Aprobar liberación') {
				agent none
				when {
					expression {				
						env.BRANCH_NAME == 'develop' || env.BRANCH_NAME.contains('release/') || env.BRANCH_NAME.contains('hotfix/')
					}
				}
				steps {
					apruebaLiberarVersion esLibreria: false
				}
			}
			stage('Liberación') {
				when {
					environment name: 'LIBERACION', value: 'Sí'
				}
				agent { label 'linux' }
				steps {
					liberaVersion	esLibreria: false, rutaPomXml: env.RUTA_POM_XML
				}
				
				post {
					success {
						enviaMailVersionLiberada quien: QUIEN_LIBERA, para: 'desarrollo.eadmon@eprinsa.es'
					}
				}
			}
		}
		post {
			always {
				node('linux') {
					finalizaPipeline()
				}
			}
			changed {
				node('linux') {
					notificaCambioEstadoPipeline()
				}
	        }
	    }
	}
}
