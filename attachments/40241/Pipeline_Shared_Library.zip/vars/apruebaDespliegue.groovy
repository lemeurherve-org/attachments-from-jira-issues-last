#!/usr/bin/env groovy
/**
 * Pregunta al usuario si aprueba el despliegue en los casos de que se está generando una nueva compilación en develop o feature.
 * Si el cambio es es release se desplegará siempre
 */
def call(args) {
	def entorno = args.entorno
	def libreriasComunes = args.libreriasComunes?:false
	def esAPIRestful=args?.esAPIRestful?:false
	def esAplicacionADF=args?.esAPIRestful?:false
	def esAplicacionJSF=args?.esAPIRestful?:false
	def fuerzaElegirOpcionesDespliegue = args.fuerzaElegirOpcionesDespliegue?:env.FUERZA_ELEGIR_OPCIONES_DESPLIEGUE
	def esAccionDesatendida = (env.ACCION_DESATENDIDA=='Desplegar y lanzar tests')
	def fuerzaAprobarDespliegue = args.fuerzaAprobarDespliegue ?:esAccionDesatendida

	milestone label: 'Versión lista para desplegar', ordinal: 20

	try { 
		timeout(time:1, unit:'HOURS') {
			if(!libreriasComunes) { 
				/*
					Si estamos en las rama de develop o release, cualquier cambio despliega automáticamente pues se supone estable. 
					De este modo implantamos correctamente la integración continua: cada cambio es testeado automáticamente sin interacción de usuario.
					
					En las aplicaciones ADF (que no se generan con maven) siempre se pregunta
				*/
				
				def esRamaEstable = (env.BRANCH_NAME.equals('develop') || env.BRANCH_NAME.contains('release/'))
				
				if((!esAplicacionADF && !fuerzaElegirOpcionesDespliegue && esRamaEstable)
					|| fuerzaAprobarDespliegue) {
					if(esRamaEstable) { 
						echo """Aprobando automáticamente cambio en la rama ${env.BRANCH_NAME} 					
						Si estamos en las rama de develop o release, cualquier cambio despliega automáticamente pues se supone estable. 
						De este modo implantamos correctamente la integración continua: cada cambio es testeado automáticamente sin interacción de usuario
							"""
					}
					
					if(fuerzaAprobarDespliegue) { 
						if(esAccionDesatendida) { 
							echo "Se fuerza aprobación de despliegue automática por tratarse de una ejecución desatendida"
						} else { 
							echo "Recibido forzar aprobación de despliegue automática por parámetro"
						}  					
					}
					
					env.DESPLIEGUE_Y_TESTS = "Sí"
				} else {
					env.DESPLIEGUE_Y_TESTS = input message: 'Requerida acción de usuario', ok: 'Continuar',
					  parameters: [
						  choice(
								name: "¿Desplegar y lanzar tests en ${entorno}?", 
								choices: 'Sí\nNo', 
								description: "Elige Sí para desplegar y lanzar los tests en el Weblogic de ${entorno}", 
								defaultValue: "No", 
								ok: "Continuar"
						  )
					  ]
				}
			} else {
				/*
					Si estamos en las ramas de release, cualquier cambio despliega automáticamente pues se supone estable. 
					De este modo implantamos correctamente la integración continua: cada cambio es testeado automáticamente sin interacción de usuario
				*/
				if((env.BRANCH_NAME.contains('release/') && !fuerzaElegirOpcionesDespliegue)/*env.BRANCH_NAME.equals('develop') || //JLP.- Regresión: es muy lento tener que parar todo y redesplegar todo. En develop vamos a dejar al usuario elegir. */
						|| fuerzaAprobarDespliegue 
					) {
					echo """Aprobando automáticamente cambio en la rama ${env.BRANCH_NAME} 					
					Si estamos en las rama de develop o release, cualquier cambio despliega automáticamente pues se supone estable. 
					De este modo implantamos correctamente la integración continua: cada cambio es testeado automáticamente sin interacción de usuario
						"""
					env.DESPLIEGUE = "Sí"
					env.PARAR_APLICACIONES = "Sí"
					env.ELIGE_APLICACIONES = "No"
					env.ELEGIR_LIBRERIAS = "No"
				} else { 
				/*
				Si estamos en las ramas features o develop (en proceso de desarrollo de una nueva característica o corrección) le preguntamos al usuario si quiere desplegar (quizás no).
				*/
					echo """Preguntando al usuario si aprueba el despliegue del cambio realizado en la rama ${env.BRANCH_NAME} 					
							Si estamos en las ramas features (en proceso de desarrollo de una nueva característica o corrección) le preguntamos al usuario si quiere desplegar (quizás no).
						"""
					def respuesta = input message: 'Requerida acción de usuario', ok: 'Continuar',
					  parameters: [
						choice(
									name: "¿Desplegar en ${entorno}?", 
									choices: 'Sí\nNo', 
									defaultValue: 'No',
									description: "Elige Sí para desplegar en el Weblogic de ${entorno}"
						),
						choice(
									name: '¿Parar algunas aplicaciones antes de desplegar?',
									choices: 'No\nSí, permiteme elegir cuales\nSí, todas', 
									defaultValue: 'No',
									description: """Elige Sí para parar/arrancar las aplicaciones corriendo actualmente en Weblogic antes/después del despliegue de las librerías comunes.  
													Util si la librería común que se quiere redesplegar ya está siendo usada por alguna aplicación, en cuyo caso, de no ser parada, el despliegue fallará."""
						),
						choice(
									name: '¿Seleccionar qué librerías comunes desplegar?',
									choices: 'No\nSí', 
									defaultValue: 'No',
									description: 'Elige Sí para seleccionar qué librerías comunes desplegar. Elige No para desplegar todas.'
						)					
					]
					env.DESPLIEGUE = respuesta["¿Desplegar en ${entorno}?"]
					def parar = respuesta["¿Parar algunas aplicaciones antes de desplegar?"]
					switch(parar) {
						case 'No':
							env.PARAR_APLICACIONES = 'No' 
							break;
						case 'Sí, permiteme elegir cuales':
							env.PARAR_APLICACIONES = 'Sí' 
							env.ELIGE_APLICACIONES = 'Sí'
							break;
						case 'Sí, todas':
							env.PARAR_APLICACIONES = 'Sí' 
							env.ELIGE_APLICACIONES = 'No'
							break;
					}
					
					env.ELEGIR_LIBRERIAS = respuesta["¿Seleccionar qué librerías comunes desplegar?"]
					echo """
						¿Se desplegará?: ${DESPLIEGUE}
						¿Parar/Arrancar aplicaciones? ${PARAR_APLICACIONES}?
						¿Seleccionar qué librerías comunes desplegar? ${ELEGIR_LIBRERIAS}?
						"""
				}
			}
		}
	} catch(err) { // timeout reached or input false
		wasTimeoutOrCancelledByUser error: err
	}

}