#!/usr/bin/env groovy
/**
 * Pregunta al usaurio si quiere liberar esta versión. 
 */
def call(args) {
	def esLibreria = args?.esLibreria?:false
	def libreriasComunes = args?.libreriasComunes?:false
	def diasTimeoutLiberacion = args?.diasTimeoutLiberacion?:21
	
		echo """Aprobando liberación de versión. 
		Argumentos: ${args}
		"""
	
	milestone label: 'Versión lista para liberar', ordinal: 50
	
	/*
	 No se permite liberar una versión que no esté en develop o release (tipicamente una feature)
	*/
	if(esLibreria && !libreriasComunes && (env.BRANCH_NAME!='develop' && !env.BRANCH_NAME.startsWith('release/') && !env.BRANCH_NAME.startsWith('hotfix/'))) {
		error "No se permite liberar una versión si no se está en la rama develop, release candidate o hotfix"
		return 
	} 
	
	try { 
		timeout(time: diasTimeoutLiberacion, unit:'DAYS') {
			def descripcion
			
			if(libreriasComunes) { 
				descripcion= "Elige Sí para crear tag de esta versión, subirla a Nexus y posteriormente pasarla a producción"
			} else if(esLibreria) {
				descripcion= "Elige Sí para crear tag de esta versión y subirla a Nexus"
			} else {
				descripcion= "Elige Sí para crear tag de esta versión para posteriormente pasarla a producción"
			}
			/*Preguntamos al usuario si quiere pasar esta versión a Producción*/
			def respuesta = input message: 'Requerida acción de usuario', submitterParameter: 'quien_libera', ok: "Continuar", id: "liberacion",
					  parameters: [
					  	choice(name: "¿Liberar esta versión?", choices: 'No\nSí', description: descripcion, defaultValue: "No"),
					  	string(name: "Comentarios de la versión", description: "En caso de liberar, este comentario será incluido en el email enviado al equipo")
					  ]
	
			env.LIBERACION = respuesta['¿Liberar esta versión?']
			env.QUIEN_LIBERA = respuesta['quien_libera']
			env.COMENTARIO_VERSION = respuesta['Comentarios de la versión']
					
			echo "¿Liberar? ${LIBERACION} ¿Quién libera? ${QUIEN_LIBERA} Comentario de la versión: ${COMENTARIO_VERSION}"		
		}
	} catch(err) { // timeout reached or input false
		def didTimeout = wasTimeoutReached error: err
		def userCancelled = wasCancelledByUser error: err

		if (didTimeout) {
			//JLP.- Si llegó hasta aquí, que se considere como marcar NO en lugar de abortar la ejecución
			/*		
	        currentBuild.result = 'NOT_BUILT'
	        error "Cancelado por timeout"
	        */
	        env.LIBERACION = 'No'
	    } else if (userCancelled) {
	        // do something else
	        currentBuild.result = 'FAILURE'
	        error "Cancelado por el usuario"
	    } 
	}
}