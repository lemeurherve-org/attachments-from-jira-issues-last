#!groovy
//!!!!!!! JLP.- Obsoleto. Usar ofreceConfigurarParametrosAdicionales
def call(args) {
	try { 
		timeout(time:15, unit:'SECONDS') {
			env.AÑADIR_PARAMETROS_MAVEN_ADICIONALES = input message: 'Requerida acción de usuario', ok: 'Continuar',
			  parameters: [
				  choice(
					name: "Añadir parámetros maven adicionales",
					choices: 'No\nSí', 
					description: 'Elige Sí para añadir parámetros adicionales al comando maven de generación, como por ejemplo para poder especificar el - U que equivale al Force Update of Snapshots/Releases de Eclipse',
					defaultValue: 'No'
					)						  
			  ]
		}
	} catch(err) { 
		def userCancelled2 = wasCancelledByUser error: err
		if (userCancelled2) {
	        // do something else
	        currentBuild.result = 'FAILURE'
	        error "Cancelado por el usuario"
	    } else {
	    	//Timeout. Seguimos 
	    	echo """Se alcanzó timeout sin especificar parámetros maven extra. Seguimos.
	    	Error lanzado por el timeout: ${err}
	    	"""
	    }
	}
	
	return env.AÑADIR_PARAMETROS_MAVEN_ADICIONALES
}