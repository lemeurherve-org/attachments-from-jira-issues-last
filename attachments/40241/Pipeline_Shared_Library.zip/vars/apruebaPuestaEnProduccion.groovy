#!/usr/bin/env groovy
/**
 * Pregunta al usuario si quiere colocar una versión previamente liberada en producción.
 */
def call(args) {
	def ultimoTag = args?.ultimoTag ?:''
	def version = args?.version?:null
	def rutaPomXml = args?.rutaPomXml?:null
	
	if(version==null) {
		if(env.NODE_NAME=='linux' && rutaPomXml!=null) { 
			def pom = readMavenPom file: rutaPomXml
			
			version = pom.getVersion()
			
		} else {
			version = 'liberada' 
		} 
	}
		
	def userCancelled = false
	def didTimeout = false
	
	/*
	Le pide al usuario que elija el tag para regenerar la versión que se va a copiar
	*/
	try { 
		timeout(time:1, unit:'HOURS') {
				def respuesta = input message: "¿Quieres colocar la versión ${version} en la carpeta de Producción?", ok: "Continuar",
				parameters: [
				  	choice(name: "¿Copiar en la carpeta de Producción?", choices: 'No\nSí', description: "Elige Sí para copiar el EAR/WAR generado en la carpeta de producción para su despliegue automático el día de liberación.", defaultValue: "No")
				  	/* JLP.- Parece que no funciona bien
				  	, [
						$class: 'GitParameterDefinition', 
						name: "versión",
						description: "Tag de la versión que quieres liberar",
						type: "Tag",
						defaultValue: "${ultimoTag}"
					]*/
				]
				
				/*env.TAG_RELEASE = respuesta['versión']
				env.PASAR_A_PRODUCCION = respuesta['¿Copiar en la carpeta de Producción?']*/
				env.PASAR_A_PRODUCCION = respuesta
		}
	} catch(err) { // timeout reached or input false
		didTimeout = wasTimeoutReached error: err
		userCancelled = wasCancelledByUser error: err
	}

	if (didTimeout) {
		//JLP.- Si llegó hasta aquí, que se considere como marcar NO en lugar de abortar la ejecución
		/*
        currentBuild.result = 'NOT_BUILT'
        error "Cancelado por timeout"
        */
        env.PASAR_A_PRODUCCION = 'No'
     } else if (userCancelled) {
       // do something else
        currentBuild.result = 'FAILURE'
        error "Cancelado por el usuario"
    } 
}