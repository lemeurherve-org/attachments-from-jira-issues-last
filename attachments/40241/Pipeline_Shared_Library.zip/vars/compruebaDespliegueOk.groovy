#!/usr/bin/env groovy
/**
 * Comprueba si el despliegue de una aplicación web/api rest se llevó a cabo correctamente haciendo una petición HTTP a la misma
 */
def call(args) {
	def contextoUrl=args.contextoUrl
	def esAPIRestful=args.esAPIRestful?:false
	def entorno = args.entorno ?:'indefinido'
		
	def sufijo = esAPIRestful ? '/info/version' : ''

	echo "Comprobando que se ha desplegado correctamente en ${entorno}"
			
	if(entorno == 'desarrollo') {
		httpRequest ignoreSslErrors: true, responseHandle: 'NONE', url: "http://eprinsa-des-ofvirtual.e-admin.es/${contextoUrl}${sufijo}"
	} else if(entorno == 'preproduccion') {
		httpRequest ignoreSslErrors: true, responseHandle: 'NONE', url: "http://eprinsa-test-ofvirtual.e-admin.es/${contextoUrl}${sufijo}"
	} else if(entorno == 'formacion') {
		httpRequest ignoreSslErrors: true, responseHandle: 'NONE', url: "http://formacion-ofvirtual.e-admin.es/${contextoUrl}${sufijo}"
	} else {
		error "No se especificó el entorno donde está la aplicación/api que se quiere comprobar" 
	}
}
