#!/usr/bin/env groovy
/**
* Cuenta cuántos commits se realizaron manualmente (esto es, commits que no han sido realizados automáticamente por Jenkins) desde una versión liberada hasta ahora. 
*/
def call(args) {
	echo "Contando commits manuales... ${args}"
	
	def desdeVersion=args.desdeVersion
	
	def salida = sh(returnStdout: true, script: "git log ${desdeVersion}..")
	
	echo "Cambios detectados:\n${salida}"
	
	def lineas = salida.split('\n')
	
	def cuenta = 0
	
	for (i = 0; i < lineas.size(); i++) {
		def linea = lineas[i]
		
		if(linea.startsWith('Author:')) {
			if(!linea.contains('Jenkins')) { 
				cuenta++
			} 
		}
	}
	
	echo "Encontrados ${cuenta} cambios manuales"
	
	return cuenta
}