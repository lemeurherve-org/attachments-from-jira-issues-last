#!/usr/bin/env groovy
/**
 * Despliega una serie de aplicaciones/librerías comunes en Weblogic
 */
def call(args) {
	//def esLibreria=args.esLibreria?:false
	def libreriasComunes = args.libreriasComunes?:false
	def rutasPomXml=args.rutaPomXml?.split(',')
	def entorno = args.entorno ?:env.ENTORNO?:'indefinido'
	def parametrosMaven = args.parametrosMaven?:env.PARAMETROS_MAVEN_ADICIONALES?:''
	
	if(!rutasPomXml) { 
		error "ERROR EN EL SCRIPT: No se recibió el parámetro 'rutasPomXml' en el script 'despliega.groovy'"
		return 
	}

	milestone label: 'Versión desplegándose', ordinal: 30

	echo "Despliegue en Weblogic ${entorno} de ${rutasPomXml}"

	if(libreriasComunes) { 
		echo "Desplegando "+rutasPomXml.size() + " librerías comunes..."
	/*} else if(esLibreria) {
		echo "Desplegando "+rutasPomXml.size() + " librerías..."*/
	} else { 
		echo "Desplegando "+rutasPomXml.size() + " aplicaciones..."
	}
	
	def errorProducido

	def descargaTodoDeNuevo = parametrosMaven?.contains('-U')
	def tiempo = !descargaTodoDeNuevo? 20 /*20 minutos si es sólo desplegar*/ : 1440 /* 1 día si tiene que volverse a traer todos los jar de nuevo*/
	
	waitUntil {
		try { 
			errorProducido = null
			echo "Reservando el uso de Weblogic ${entorno} para despliegue. Todos los accesos a Weblogic ${entorno} del resto de tareas quedarán a la espera."
			lock(resource: null, label: "weblogic_${entorno}") {
			
				timeout(time: tiempo, unit:'MINUTES') {
					for(i = 0; i < rutasPomXml.size(); i++) { 
						def rutaPomXml = rutasPomXml[i]
						if(libreriasComunes) { 
							echo "Desplegando librería común ${rutaPomXml}"
							sh "mvn com.oracle.weblogic:weblogic-maven-plugin:deploy -f '${rutaPomXml}' -P${entorno} ${parametrosMaven}"
						} else {
							echo "Desplegando aplicación ${rutaPomXml}"
							sh "mvn com.oracle.weblogic:weblogic-maven-plugin:deploy -f '${rutaPomXml}' -P${entorno} ${parametrosMaven}"
						}
					}
				}
			}
			echo "Liberado el uso de Weblogic ${entorno} para despliegue. Listo para ser accedido por el resto de tareas."
			return true
		} catch(err) {
			errorProducido = err
			def fueTimeout = wasTimeoutReached error: err
			def log
			def titulo
			
			def timeoutReintentar = 15
			
			if(!fueTimeout) {
				log = """Se produjo un error al desplegar. Pedimos al usuario si quiere reintentar (esperamos por ${timeoutReintentar} minutos). 
					Error producido: ${err}
					"""  
				titulo = "Fallo al desplegar"
			} else {
				log = """Se produjo un timeout tras tratar de desplegar por más de ${tiempo} minutos. Pedimos al usuario si quiere reintentar (esperamos por ${timeoutReintentar} minutos). 
					Error producido: ${err}
				""" 
				titulo = "Timeout tratando de desplegar"
			}
			
			echo log
			
			timeout(time: timeoutReintentar, unit:'MINUTES') {
				def respuesta = input message: titulo, ok: 'Continuar',
						  parameters: [
							choice(
										name: "¿Reintentar despliegue en ${entorno}?", 
										choices: 'No\nSí', 
										defaultValue: 'No',
										description: "Elige Sí para reintentar el despliegue en el Weblogic de ${entorno}"
							),
							string(
								name: "Parámetros maven adicionales", 
								description: 'Parámetros que se añadirán a la llamada maven util por ejemplo para especificar el - U que equivale al Force Update of Snapshots/Releases de Eclipse',
								defaultValue: parametrosMaven
							)						  
							
						]

				echo "Respuesta del usuario: ${respuesta}"
				def reintentar = respuesta["¿Reintentar despliegue en ${entorno}?"]
				parametrosMaven = respuesta["Parámetros maven adicionales"]
	        	return reintentar != 'Sí'
        	}
		}
	}
	
	if(errorProducido) {
		throw errorProducido 
	}
}
