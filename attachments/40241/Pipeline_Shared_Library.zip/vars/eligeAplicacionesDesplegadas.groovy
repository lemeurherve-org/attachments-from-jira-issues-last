#!/usr/bin/env groovy
/**
 * Pide al usuario que elija de entre las aplicaciones desplegadas cual se pararán/arrancarán 
 */
def call(args) {
	echo """Eligiendo aplicaciones desplegadas...
			Argumentos: ${args}
		"""
	def cadenaAplicacionesDesplegadas=args.cadenaAplicacionesDesplegadas
	def fuerzaTodasSeleccionadas = args?.fuerzaTodasSeleccionadas?:(env.ELIGE_APLICACIONES=='No')
	def rama = args?.rama?:env.BRANCH_NAME
	
	def seleccionadas
	
	/*
	* Si estamos en entorno de preproducción paramos/arrancamos todas. En cualquier otro caso (desarrollo, feature, o hotfix) elegimos cuales
	*/
	if(fuerzaTodasSeleccionadas || rama.contains('release/')) { 

		seleccionadas = cadenaAplicacionesDesplegadas.split(',')
		echo "En la rama ${rama} se paran/arrancan todas las aplicaciones: ${seleccionadas}"
	} else { 
		echo "Preguntando al usuario qué aplicaciones quiere parar/arrancar..."
		
		seleccionadas = eligeAplicaciones motivo: 'Parar/Arrancar', cadenaAplicaciones: cadenaAplicacionesDesplegadas
	}
		
	env.APLICACIONES_SELECCIONADAS = seleccionadas.join(',')
}