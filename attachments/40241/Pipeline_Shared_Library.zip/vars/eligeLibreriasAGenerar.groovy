#!/usr/bin/env groovy
/**
 * Pregunta al usuario qué librerías comunes quiere desplegar
 */
def call(args) {
	def entorno=args?.entorno?:'indefinido'
	def cadenaLibrerias=args?.cadenaLibrerias?:''
	def fuerzaTodasSeleccionadas=args?.fuerzaTodasSeleccionadas?:false
	def motivo = args?.motivo?:'Selecciona'

	def listaLibrerias = cadenaLibrerias.split(',') 
		
	def seleccionadas
	def ruta_seleccionadas
	
	try { 
		timeout(time:1, unit:'HOURS') {
			/*
			* Si estamos en entorno de preproducción desplegamos todas. En cualquier otro caso (desarrollo, feature, o hotfix) elegimos cuales.
			*/
			if(fuerzaTodasSeleccionadas || env.BRANCH_NAME?.contains('release/')) {
				if(fuerzaTodasSeleccionadas) {
					 echo "Se fuerza la generación/despliegue de todas las liberías comunes" + (env.BRANCH_NAME ? " de la rama ${env.BRANCH_NAME}" : '')
				} else if(env.BRANCH_NAME?.contains('release/')) {  
					echo "En la rama ${env.BRANCH_NAME} se generan/despliegan todas las librerías comunes:"
				} 
				
				seleccionadas = cadenaLibrerias.split(',')
				ruta_seleccionadas = seleccionadas.collect { 'src/' + it }
			} else { 
				echo "Preguntando al usuario qué librerías quiere generar..."

				def parametrosLibrerias = []
				
				listaLibrerias.each {
					def nombreLib = it
	
					parametrosLibrerias << booleanParam(name: nombreLib, defaultValue: false, description: "${motivo} ${nombreLib}")				 
				}
		
				def respuesta =  input message: 'Requerida acción de usuario', ok: 'Continuar', parameters: parametrosLibrerias
					  
				echo "Respuesta del usuario: ${respuesta}"
				seleccionadas = respuesta.findAll { it.value == true }.collect { it.key }
				ruta_seleccionadas = respuesta.findAll { it.value == true }.collect { 'src/' + it.key }
				echo """Seleccionadas: ${seleccionadas}
						Ruta: ${ruta_seleccionadas}
					"""
			}
		}
	} catch(err) { // timeout reached or input false
		wasTimeoutOrCancelledByUser error: err		
	}


	env.LIBRERIAS_SELECCIONADAS = seleccionadas.join(',')
	env.RUTA_POM_XML_LIBRERIAS_SELECCIONADAS = ruta_seleccionadas.join(',')

	echo """Librerías elegidas para generar/desplegar ${env.LIBRERIAS_SELECCIONADAS}
			Ruta: ${env.RUTA_POM_XML_LIBRERIAS_SELECCIONADAS}
		"""
			
}