#!/usr/bin/env groovy
/**
 * Compila el código y genera el artefacto correspondiente (EAR, JAR o WAR en función del caso)
 */
def call(args) {
	def esLibreria=args.esLibreria?:false
	def libreriasComunes=args.libreriasComunes?:false
	def rutaPomXml=args.rutaPomXml
	def rutaDiccionarioError = args.rutaDiccionarioError ?: ''
	def entorno = args.entorno ?:'indefinido'
	def parametrosMaven = args.parametrosMaven?:env.PARAMETROS_MAVEN_ADICIONALES?:''
	
	echo env.BRANCH_NAME ? "Generación desde la rama ${env.BRANCH_NAME}. Argumentos: ${args}" : "Generando... Argumentos: ${args}"
	
	if(esLibreria && !libreriasComunes) {
		try {
			sh "mvn clean -f '${rutaPomXml}'"
		} catch (err) {
			echo "Se produjo un error tratando de limpiar el build anterior: ${err}"
			//JLP.-No influye en el resultado. No considero finalmente que haya que marcarlo como inestable
			//currentBuild.result = 'UNSTABLE'
	    }
		echo "Generando librería. Utilizando la ruta '${rutaDiccionarioError}' para localizar los diccionarios de error"
		sh "mvn install -f '${rutaPomXml}' -DrutaDictError.tests=${rutaDiccionarioError} -DoracleHome=/usr/lib/oracle/12.1/client64 -Dmaven.javadoc.skip=true ${parametrosMaven}"
	} else {
		try {
			sh "mvn clean -f '${rutaPomXml}'"
		} catch (err) {
			echo "Se produjo un error tratando de limpiar el build anterior: ${err}"
			//JLP.-No influye en el resultado. No considero finalmente que haya que marcarlo como inestable
			//currentBuild.result = 'UNSTABLE'
	    }
		if(entorno!='indefinido') {
			echo "Generando aplicación para entorno ${entorno}" 
			sh "mvn install -f '${rutaPomXml}' -P${entorno} ${parametrosMaven}"
		} else {
			echo "Generando" 
			sh "mvn clean install -f '${rutaPomXml}' ${parametrosMaven}"
		}
	}
}