#!groovy
/**
 * Crea documentación Javadoc de una librería JAR
 */
def call(args) {
	def rutaPomXml = args.rutaPomXml

	echo "Creación documentación javadoc"
	sh "mvn javadoc:javadoc -f '${rutaPomXml}'"
}