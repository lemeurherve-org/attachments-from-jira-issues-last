#!/usr/bin/env groovy
/**
 * Lanza los test JMeter de una aplicación
 */
def call(args) {
     wrap([$class: 'MaskPasswordsBuildWrapper',varPasswordPairs: [[password: "${args.contraseña}", var: 'args.contraseña']]]) {
		echo """Lanzando test jmeters...
				Args: ${args}
			"""
	}
	def rutaPomXml=args.rutaPomXml
	def entorno = args.entorno ?:'indefinido'
	//def jmeterServidor = args.jmeterServidor //Deprecated, no usar
	//def cliente = args.cliente ?:'eprinsa' //Deprecated, no usar
	def usuario = args.usuario?:env.JMETER_USER
	def contraseña = args.contraseña?:env.JMETER_PASSWORD
	
	/*if(!jmeterServidor) {
		def partes = cliente.split('-')
		cliente = partes[0]
		def clon = (partes.length>1 && partes[1]=='clon')
	
		if(entorno == 'preproduccion') { 
			jmeterServidor = "${cliente}-test-ofvirtual2.e-admin.es"; //JLP.- Provisional el servidor con ofvirtual
		} else { 
			if(clon) {
				jmeterServidor = "${cliente}-clon-ofvirtual2.e-admin.es"; //JLP.- Provisional el servidor con ofvirtual
			} else { 
				jmeterServidor = "${cliente}-des-ofvirtual2.e-admin.es"; //JLP.- Provisional el servidor con ofvirtual
			}
		} 
	}*/

	milestone label: 'Testeando la aplicación', ordinal: 40

	if(usuario!=null && !usuario.trim().isEmpty() && contraseña!=null && !contraseña.trim().isEmpty()) { 
        /* Enmascara la password para que no salga en la consola */
         wrap([$class: 'MaskPasswordsBuildWrapper',varPasswordPairs: [[password: "${contraseña}", var: 'contraseña']]]) {
			echo """Lanzar tests JMeter en ${entorno} utilizando credenciales
					usuario: ${usuario}
					contraseña: ${contraseña}  
					"""
			echo "Lanzar tests funcionales JMeter en ${entorno}"
            sh "mvn com.lazerycode.jmeter:jmeter-maven-plugin:jmeter -f '${rutaPomXml}' -P${entorno} -Djmeter.user=${usuario} -Djmeter.password=${contraseña} -Djmeter.ficheros_tests='funcional/*.jmx' -Djmeter.resultados_tests='${env.WORKSPACE}/resultados_tests/funcionales'"

			echo "Lanzar tests de rendimiento JMeter en ${entorno}"
            sh "mvn com.lazerycode.jmeter:jmeter-maven-plugin:jmeter -f '${rutaPomXml}' -P${entorno} -Djmeter.user=${usuario} -Djmeter.password=${contraseña} -Djmeter.ficheros_tests='rendimiento/*.jmx' -Djmeter.resultados_tests='${env.WORKSPACE}/resultados_tests/rendimiento'"
         }
	} else { 
		echo "Lanzar tests funcionales JMeter en ${entorno}"
		sh "mvn com.lazerycode.jmeter:jmeter-maven-plugin:jmeter -f '${rutaPomXml}' -P${entorno} -Djmeter.ficheros_tests='funcional/*.jmx' -Djmeter.resultados_tests='${env.WORKSPACE}/resultados_tests/funcionales'"

		echo "Lanzar tests de rendimiento JMeter en ${entorno}"
		sh "mvn com.lazerycode.jmeter:jmeter-maven-plugin:jmeter -f '${rutaPomXml}' -P${entorno} -Djmeter.ficheros_tests='rendimiento/*.jmx' -Djmeter.resultados_tests='${env.WORKSPACE}/resultados_tests/rendimiento'"
	}
}