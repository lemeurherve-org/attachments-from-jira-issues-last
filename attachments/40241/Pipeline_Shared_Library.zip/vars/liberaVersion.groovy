#!/usr/bin/env groovy
/**
 * Libera una nueva versión realizando un tag y subiendo a Nexus dicha versión liberada. Además elimina la rama release candidate
 */
def call(args) {
	def esLibreria=args.esLibreria?:false
	def libreriasComunes = args.libreriasComunes?:false
	def rutaPomXml=args.rutaPomXml
	def entorno = 'produccion' //JLP.- Cuando se libera el entorno debería de ser siempre 'produccion' args.entorno ?:'indefinido'
	def rutaDiccionarioError = args.rutaDiccionarioError ?: ''
	def scmUrl = args.scmUrl?:scm.getUserRemoteConfigs()[0].getUrl()
	def quien = args.quien?:env.QUIEN_LIBERA
	def subeANexus = args.subeANexus?:false 
	def parametrosMaven = args.parametrosMaven?:env.PARAMETROS_MAVEN_ADICIONALES?:''

		echo """Liberando versión. 
		Argumentos: ${args}
		"""
			
	milestone label: 'Versión liberándose', ordinal: 60

	if(esLibreria&&!libreriasComunes) {
			/*
			 Si no se han hecho commits manuales por parte de algún desarrollador desde el último tag, no se permite liberar.
			 */
		def	ultimaVersionLiberada = args.version?:obtenUltimaVersionLiberada()
			
		/* Si es un proyecto nuevo y aun no hay tags, dejamos liberar*/
		if(ultimaVersionLiberada) {  
			def commitsManuales = cuentaCommitsManuales desdeVersion: ultimaVersionLiberada
			
			if(commitsManuales==0) {
				error "No se ha subido ningún cambio desde la última liberación. No se permite liberar si no hay al menos algún commit realizado por un desarrollador desde la última versión." 
			}
		} else { 
			echo "No se pudo determinar si hubo cambios desde la última liberación. Al no poder determinarse, seguimos liberando."
		}

		//Si hay nuevas versiones de librerías Eprinsa o parent.pom, no permitimos liberar
		def nuevasVersiones = usaUltimasVersionesLibreriasEprinsa rutaPomXml: rutaPomXml, snapshots: false

		try {
			//Preparamos la versión exacta a liberar (sin SNAPSHOT)
			echo "Preparando la versión exacta a liberar (sin SNAPSHOT)"
			sh "mvn release:clean release:prepare -f '${rutaPomXml}' -DrutaDictError.tests=${rutaDiccionarioError} -DoracleHome=/usr/lib/oracle/12.1/client64  ${parametrosMaven} -Darguments='-DrutaDictError.tests=${rutaDiccionarioError} -DoracleHome=/usr/lib/oracle/12.1/client64 ${parametrosMaven}' --batch-mode"
		} catch(err) { 
			echo "Se produjo el siguiente error tratando de liberar: ${err}"
			error "${nuevasVersiones} \nNo se puede liberar debido a que existen nuevas versiones. Actualiza la versión correspondiente, comprueba que todo sigue funcionando correctamente, sube los cambios y vuelve a liberar."
		}
		
		//Liberamos
		echo "Liberando..."
		sh "mvn release:perform -f ${env.RUTA_POM_XML} -DrutaDictError.tests=${rutaDiccionarioError} -DoracleHome=/usr/lib/oracle/12.1/client64  ${parametrosMaven} -Darguments='-DrutaDictError.tests=${rutaDiccionarioError} -DoracleHome=/usr/lib/oracle/12.1/client64 ${parametrosMaven}' --batch-mode"				
	} else {
	
		def esAplicacion = !libreriasComunes
	
		if(env.BRANCH_NAME.contains('release/')) {
			echo "Comprobamos si hay nuevas versiones de dependencias en Eprinsa, en cuya caso, fallará la liberación"
			def nuevasVersiones = usaUltimasVersionesLibreriasEprinsa rutaPomXml: rutaPomXml, snapshots: false
			try {
				//Preparamos la versión exacta a liberar (sin SNAPSHOT)
				echo "Preparamos la versión exacta a liberar (sin SNAPSHOT)"
				sh "mvn release:clean release:prepare -f '${rutaPomXml}' -P${entorno} ${parametrosMaven} --batch-mode -Darguments='${parametrosMaven}" + ((esAplicacion && !subeANexus) ? " -Dmaven.deploy.skip=true":"") + "'"/*JLP.- Los jar/war de las aplicaciones no se suben a nexus*/
			} catch(err) { 
				echo "Se produjo el siguiente error tratando de liberar: ${err}"
				error """No se puede liberar por los siguientes posibles motivos:
						\n1) Existen nuevas versiones. ¿Nuevas versiones detectadas?: ${nuevasVersiones}.
						\n2) Existen dependencias -SNAPSHOT. Consulte el log más arriba para determinar qué dependencias son.
						\n   Solución: Actualice la versión correspondiente, compruebe que todo sigue funcionando correctamente, suba los cambios y vuelva a liberar."""
			}
			
			//sh "mvn jgitflow:release-finish -f '${rutaPomXml}' -DpushReleases=true"

			/*Pasa a la siguiente versión en la rama actual*/
			echo "Pasamos a la siguiente versión en la rama ${env.BRANCH_NAME}"
			sh "mvn release:perform -f '${rutaPomXml}' -P${entorno} ${parametrosMaven} --batch-mode -Darguments='${parametrosMaven}" + ((esAplicacion && !subeANexus) ? " -Dmaven.deploy.skip=true":"") + "'" /*JLP.- Los jar/war de las aplicaciones no se suben a nexus*/
			
			echo "Hacemos merge en develop con lo liberado."
			echo "Cambiamos a la rama develop"
			def credenciales = '77d170ae-31ff-4961-9ec4-ff370a075ee3' //JLP.- Corresponde a las identificador de las credenciales 'jenkins (usuario para git)'. Si cambiase este usuario est id dejará de ser válido 
			git url: scmUrl, credentialsId: credenciales, branch: 'develop'
			
			try { 
				echo "Hacemos merge con '${env.BRANCH_NAME}'..."
				sh "git merge ${env.BRANCH_NAME}"
	
				/* JLP.- No hace falta el commit. El merge ya lo hace implícitamente						
				echo "Hacemos commit..."
				sh "git commit -a -m 'Actualizando develop con los cambios de la release candidate ${env.BRANCH_NAME}' --author='${quien}'"
				*/
	
				echo "Hacemos push..."
				sh "git push origin 'develop'"
			} catch(err) { 
				echo "Se produjo el siguiente error tratando de realizar el merge: ${err}"
				echo "No se pudo realizar el merge de manera automática. Solución: Realice el merge de manera manual utilizando SourceTree o Tortoise."
				currentBuild.result = 'UNSTABLE'
			}
			
			echo "Liberado ok"			
			
		} else {
			//Liberamos
			sh "mvn release:clean release:prepare release:perform -f '${rutaPomXml}' -P${entorno} ${parametrosMaven} --batch-mode"
		}
	}
}