#!/usr/bin/env groovy
/**
* Limpia el EAR generado por JDeveloper de configuración basura que este mete
*/
def call(args) {
	def rutaPomXml=args.rutaPomXml
	def entorno = args.entorno ?:'indefinido'

	milestone label: "Limpiando EAR generado por JDeveloper", ordinal: 25

	sh "mvn es.eprinsa.maven:eprinsa-maven-plugin:limpia-ficheros-configuracion -f '${rutaPomXml}' -P${entorno}"	
}
