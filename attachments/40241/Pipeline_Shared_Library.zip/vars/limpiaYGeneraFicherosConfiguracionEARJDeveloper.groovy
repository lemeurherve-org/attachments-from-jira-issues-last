#!/usr/bin/env groovy
/**
 Limpia el EAR generado por JDeveloper de configuración basura que este mete y genera los ficheros de configuración en función del entorno y los almacena dentro de un EAR previamente generado con JDeveloper
*/
def call(args) {
	def rutaPomXml=args.rutaPomXml
	def entorno = args.entorno ?:'indefinido'

	milestone label: "Limpiando y generando ficheros de configuración dentro del EAR generado por JDeveloper", ordinal: 25

	sh "mvn es.eprinsa.maven:eprinsa-maven-plugin:limpia-ficheros-configuracion es.eprinsa.maven:eprinsa-maven-plugin:genera-ficheros-configuracion -f '${rutaPomXml}' -P${entorno}"	
}
