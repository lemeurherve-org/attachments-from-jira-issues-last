#!/usr/bin/env groovy
/**
 Obtiene un array con la lista de aplicaciones desplegables actualmente en weblogic
 
 Esta lista se obtiene un fichero con el nombre de todas ellas. 
 */
def call(args) {
	def cadenaAplicacionesDesplegables
	
	echo """Obteniendo lista de aplicaciones desplegables...
			Argumentos: ${args}"""
	
	def fichero=args.fichero

	if(fichero == null) {
		def porDefecto = '/epr/java/jenkins/Lista desplegables Weblogic.txt'
		echo "No se pasó como argumento el fichero. Usando fichero por defecto '${porDefecto}'"
		fichero = porDefecto
	} 

	echo "Obteniendo lista de aplicaciones desde el fichero ${fichero}"

	cadenaAplicacionesDesplegables = readFile fichero

	echo """Salida obtenida desde fichero:
	${cadenaAplicacionesDesplegables}
	 """		

	def listaAplicacionesDesplegables = cadenaAplicacionesDesplegables.split("\n")
	
	def listaAplicacionesDesplegablesEprinsa = listaAplicacionesDesplegables.findAll { !it.trim().startsWith('#') }.collect { it.trim() }

	echo """Filtrando de la lista de aplicaciones encontradas en fichero...
		Lista original (${listaAplicacionesDesplegables.size()}): ${listaAplicacionesDesplegables}
		Lista filtrada (${listaAplicacionesDesplegablesEprinsa.size()}): ${listaAplicacionesDesplegablesEprinsa}
		"""
		
	env.LISTA_APLICACIONES_DESPLEGABLES = listaAplicacionesDesplegablesEprinsa.join(',').replaceAll('\n','').replaceAll('\r','')	
	
	echo "Cadena de aplicaciones desplegables: ${env.LISTA_APLICACIONES_DESPLEGABLES}"	
	
	return listaAplicacionesDesplegablesEprinsa.join('\n')
}