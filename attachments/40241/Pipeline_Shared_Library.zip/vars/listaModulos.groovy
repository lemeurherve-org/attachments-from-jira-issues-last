#!/usr/bin/env groovy
/**
 * Obtiene un array con los módulos de un pom.xml
 */
def call(args) {
	def rutaPomXml=args.rutaPomXml
	echo "Eligiendo librerías comunes a generar en el entorno ${entorno} con la ruta del pom.xml ${rutaPomXml}"
	
	def pom = readMavenPom file: rutaPomXml
	
	def modulos = pom.getModules()
	def cadenaModulos = modulos.join(',')
	
	env.LISTA_MODULOS = cadenaModulos
	
	return modulos
}