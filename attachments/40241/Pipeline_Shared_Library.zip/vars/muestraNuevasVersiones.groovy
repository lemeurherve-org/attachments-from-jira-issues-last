#!groovy

/**
 * Muestra en pantalla si hay nuevas veriones de dependencias (librerías)
 */
def call(args) {
	def rutaPomXml = args.rutaPomXml
	def parametrosMaven = args.parametrosMaven?:env.PARAMETROS_MAVEN_ADICIONALES?:''
			
	echo "Comprobando si hay nuevas versiones de dependencias (librerías):"		
	
	try { 
		sh "mvn versions:display-plugin-updates versions:display-dependency-updates -f '${rutaPomXml}' ${parametrosMaven}"
	} catch(err) {
		echo 	"""Error tratando de mostrar en pantalla si hay nuevas versiones de dependencias (librerías). Ignoramos error y seguimos.
					Error: ${err}
				""" 
	}
}