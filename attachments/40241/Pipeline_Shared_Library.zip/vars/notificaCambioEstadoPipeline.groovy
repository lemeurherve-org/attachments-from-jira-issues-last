def call(args) {
	echo """Notificando cambio de estado...\n
			Argumentos: ${args}
		"""
	def para = args?.para?:'jlp01@eprinsa.es'
 
 	if(currentBuild.result!='ABORTED' && currentBuild.result!='NOT_BUILT') {
 		echo "Enviando email a ${para} con el estado ${currentBuild.result} del job ${env.JOB_NAME}"   
		timeout(time:1, unit:'MINUTES') {
			step([$class: 'Mailer',
				notifyEveryUnstableBuild: true,
				recipients: para,
				sendToIndividuals: true])
		}
	} else {
		echo "Ignoramos el estado ${currentBuild.result} que no se notifica por email." 
	}
}