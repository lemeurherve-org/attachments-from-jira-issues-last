#!/usr/bin/env groovy
def call() {
	try { 
	echo """Obteniendo último tag versión liberada...\n
		"""
//			Argumentos: ${args}

		/*Obtiene el último tag generado*/
		def estado = sh( returnStatus : true, script:"git describe --abbrev=0")
		
		def existeTag = (estado==0)
		echo """Estado del comando git:
				$estado
				
				¿Existe tag?
				${existeTag}
			 """
	
		if(existeTag) {
			 
			def ultimoTag = sh(
				script: "git describe --abbrev=0",
				returnStdout: true
			)
		
			env.ULTIMA_VERSION_LIBERADA = ultimoTag.replace('\n','').replace('\r','') 
		
			return env.ULTIMA_VERSION_LIBERADA
		}
	} catch(err) { 
		echo "Se produjo un error tratando de determinar la versión de la última liberación. Puede que no haya ninguna. Continuamos. Error: ${err}"		
	}
}