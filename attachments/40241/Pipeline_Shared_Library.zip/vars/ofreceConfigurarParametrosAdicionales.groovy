#!groovy

/**
 * Pregunta al usuario si quiere configurar algunas parámetros adicionales antes de generar, y si es así se los presenta
 */
def call(args) {
	echo "Preguntando al usuario si quiere configurar algunos parámetros adicionales antes de generar. Argumentos recibidos: ${args}"
	def esLibreria=args?.esLibreria?:false
	def libreriasComunes=args?.libreriasComunes?:false
	def esAPIRestful=args?.esAPIRestful?:false
	def esAplicacionADF=args?.esAplicacionADF?:false
	def esAplicacionJSF=args?.esAplicacionJSF?:false
	def esDesplegable = args?.esDesplegable?:(esAPIRestful||esAplicacionADF||esAplicacionJSF)
	
	def aprobado
	try { 
		timeout(time:10, unit:'SECONDS') {
			aprobado = input message: 'Requerida acción de usuario', ok: 'Continuar',
			  parameters: [
				  choice(
					name: "Configurar parámetros adicionales",
					choices: 'No\nSí', 
					description: 'Elige Sí para configurar parámetros adicionales, como por ejemplo parámetros adicionales a la generación de maven como -U (equivalente al Force Update of Snapshots/Releases de Eclipse)',
					defaultValue: 'No'
					)						  
			  ]
		}
	} catch(err) { 
		def userCancelled2 = wasCancelledByUser error: err
		if (userCancelled2) {
	        // do something else
	        currentBuild.result = 'FAILURE'
	        error "Cancelado por el usuario"
	    } else {
	    	//Timeout. Seguimos 
	    	echo """Se alcanzó timeout sin especificar parámetros maven extra. Seguimos.
	    	Error lanzado por el timeout: ${err}
	    	"""
	    }
	}
	
	if(aprobado == 'Sí') {
		def userCancelled = false
		def didTimeout = false
	
		try { 
			timeout(time:1, unit:'HOURS') {
				def parametros = []
				
				if(libreriasComunes) {
					parametros.add(choice(
							name: "Configuración adicional en el despliegue", 
							choices: 'No\nSí', 
							description: "Elige Sí para mostrar opciones sobre qué librerías desplegar o qué aplicaciones parar/arrancar", 
							defaultValue: "No", 
							ok: "Continuar"
						)) 
					parametros.add(choice(
								name: "Información sobre nuevas versiones", 
								choices: 'No\nSí', 
								description: "Elige Sí para mostrar que maven compruebe si hay nuevas versiones de librerías de terceros y plugins liberadas con el fin de ser actualizadas", 
								defaultValue: "No", 
								ok: "Continuar"
							))
						
				} else if(esDesplegable && !esAplicacionADF /*JLP.- En las aplicaciones ADF siempre se va a preguntar */) { 
					parametros.add(choice(
							name: "Configuración adicional en el despliegue", 
							choices: 'No\nSí', 
							description: "Elige Sí para poder elegir configuraciones adicionales en el despliegue como por ejemplo si saltar el despliegue y los tests", 
							defaultValue: "No", 
							ok: "Continuar"
						)) 
				}
				
				parametros.add( string(
						name: "Parámetros maven adicionales", 
						description: 'Parámetros que se añadirán a la llamada maven util por ejemplo para especificar el - U que equivale al Force Update of Snapshots/Releases de Eclipse',
						defaultValue: ''
						))
						
				def respuesta = input message: 'Requerida acción de usuario', ok: 'Continuar', parameters: parametros					  				  
				 
				if(parametros.size() > 1) { 
					env.PARAMETROS_MAVEN_ADICIONALES = respuesta['Parámetros maven adicionales']
					env.MOSTRAR_INFO_SOBRE_NUEVAS_VERSIONES = respuesta['Información sobre nuevas versiones']
					env.FUERZA_ELEGIR_OPCIONES_DESPLIEGUE = respuesta['Configuración adicional en el despliegue']
				} else { 
					env.PARAMETROS_MAVEN_ADICIONALES = respuesta
				}
			}
		} catch(err) { // timeout reached or input false
			didTimeout = wasTimeoutReached error: err
			userCancelled = wasCancelledByUser error: err
		}
	
		if (didTimeout) {
	        // do something on timeout
	        currentBuild.result = 'NOT_BUILT'
	        error "Cancelado por timeout"
	    } else if (userCancelled) {
	        // do something else
	        currentBuild.result = 'FAILURE'
	        error "Cancelado por el usuario"
	    } 
	}
}
