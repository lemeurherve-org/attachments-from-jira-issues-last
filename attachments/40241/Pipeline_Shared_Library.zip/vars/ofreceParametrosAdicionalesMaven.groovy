#!groovy
//!!!!!!! JLP.- Obsoleto. Usar ofreceConfigurarParametrosAdicionales
/**
 * Preguna al usuario qué parámetros adicionales quiere añadir en la generación maven y le deja introducirlos
 */
def call(args) {
	def aprobado = apruebaParametrosAdicionalesMaven()
	
	if(aprobado == 'Sí') {
		parametrosAdicionalesMaven() 
	}
}
