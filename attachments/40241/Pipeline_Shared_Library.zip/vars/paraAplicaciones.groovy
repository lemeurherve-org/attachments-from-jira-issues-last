#!/usr/bin/env groovy
/**
 * Obtiene un array con la lista de aplicaciones desplegadas actualmente en weblogic
 */
def call(args) {
	echo "Parando aplicaciones... ${args}"
	
	def rutaPomXml=args.rutaPomXml
	def cadenaAplicacionesSeleccionadas=args.cadenaAplicacionesSeleccionadas
	def entorno = args.entorno ?:env.ENTORNO?:'indefinido'
	
	if(!cadenaAplicacionesSeleccionadas) {
		error "ERROR EN EL SCRIPT: No se recibió el parámetro 'cadenaAplicacionesSeleccionadas' en el script 'paraAplicaciones.groovy'"
		return 
	}
	
	def listaAplicacionesSeleccionadas = cadenaAplicacionesSeleccionadas.split(',')
	
	echo "Parando " + listaAplicacionesSeleccionadas.size() + " aplicaciones en ${entorno}..."
	
	def target
	switch(entorno) {
		case "desarrollo":
			target = 'infra_cluster_des_1'
			break;
		case "formacion":
			target = 'formacion'
			break;
		case "preproduccion":
			target = 'preproduccion' 
			break; 
		default:
			error "ERROR EN EL SCRIPT: El entorno de ejecución no puede ser '${entorno}' en el script 'paraAplicaciones.groovy'"
			return
	} 
	
	echo "Reservando el uso de Weblogic ${entorno} para parar aplicaciones. Todos los accesos a Weblogic ${entorno} del resto de tareas quedarán a la espera."
	lock(resource: null, label: "weblogic_${entorno}") {
		for (i = 0; i < listaAplicacionesSeleccionadas.size(); i++) { 
			def nombreFicheroApp = listaAplicacionesSeleccionadas[i]
			def nombreApp = nombreFicheroApp.replace('.ear','').replace('.war','')
			
			echo "Parando ${nombreApp} en ${entorno}"
						
			sh "mvn com.oracle.weblogic:weblogic-maven-plugin:stop-app -f '${rutaPomXml}' -P${entorno} -Ddespliegue.nombre=${nombreApp} -Ddespliegue.cluster=${target} -DfailOnError=false"
		}
	}
	echo "Liberado el uso de Weblogic ${entorno} para parar aplicaciones. Listo para ser accedido por el resto de tareas."
}