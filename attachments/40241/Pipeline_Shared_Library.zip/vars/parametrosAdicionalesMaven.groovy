#!groovy
//!!!!!!! JLP.- Obsoleto. Usar ofreceConfigurarParametrosAdicionales
/**
 * Preguna al usuario qué parámetros adicionales quiere añadir en la generación maven
 */
def call(args) {
	def userCancelled = false
	def didTimeout = false

	try { 
		timeout(time:1, unit:'HOURS') {
			env.PARAMETROS_MAVEN_ADICIONALES = input message: 'Requerida acción de usuario', ok: 'Continuar',
			  parameters: [
				  string(
					name: "Parámetros maven adicionales", 
					description: 'Parámetros que se añadirán a la llamada maven util por ejemplo para especificar el - U que equivale al Force Update of Snapshots/Releases de Eclipse',
					defaultValue: ''
					)						  
			  ]
		}
	} catch(err) { // timeout reached or input false
		didTimeout = wasTimeoutReached error: err
		userCancelled = wasCancelledByUser error: err
	}

	if (didTimeout) {
        // do something on timeout
        currentBuild.result = 'NOT_BUILT'
        error "Cancelado por timeout"
    } else if (userCancelled) {
        // do something else
        currentBuild.result = 'FAILURE'
        error "Cancelado por el usuario"
    } 
}