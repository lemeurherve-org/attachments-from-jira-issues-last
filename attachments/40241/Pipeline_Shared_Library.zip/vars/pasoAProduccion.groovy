#!/usr/bin/env groovy
/**
 * Copia el EAR generado en Producción
 */
def call(args) {
	def para = args?.para?:'desarrollo.eadmon@eprinsa.es'
	def libreriasComunes = args?.libreriasComunes?:false
	def fechaLiberacion = args?.fechaLiberacion?:env.FECHA_PROXIMA_LIBERACION
	def esWAR = args?.esWAR?:false
	def patronFicheros = args?.patronFicheros?:null
	def rutaPomXml = args?.rutaPomXml?:null

	def rutaFichero = args?.rutaFichero?:null
	def nombreAplicacion = args?.nombreAplicacion?:null
	def entorno = args?.entorno?:null
	def nombreFichero = args?.nombreFichero?:null
	
	if(!libreriasComunes) {
		/* PARA APLICACIONES*/
		 
		def ficheros
	
		if(rutaFichero) {
			
			ficheros = [ new File(rutaFichero) ]
			 
		} else { 		
			if(nombreAplicacion && entorno && nombreFichero) {
				def carpeta
				switch(entorno) {
					case "desarrollo":
						carpeta = 'desarrollo'
						break;
					case "formacion":
						carpeta = 'formacion'
						break;
					case "preproduccion":
						carpeta = 'pruebas' 
						break; 
					case "produccion":
						carpeta = 'produccion'
						break;
					default:
						error "ERROR EN EL SCRIPT: El entorno de ejecución no puede ser '${entorno}' en el script 'pasoAProduccion.groovy'"
						return
				} 		
			
				rutaFichero = "/otroslogs/aplicaciones/weblogic/${nombreAplicacion}/${carpeta}/app/${nombreFichero}"
				
				ficheros = [ new File(rutaFichero) ] 
			} else { 
				if(patronFicheros) { 
					echo "Copia de ${patronFicheros} en Producción"
				} else { 
					def extension
					if(!esWAR) { 
						/*Copia el/los EAR en Producción*/
						echo 'Copia del/los EAR en Producción'
					
						extension = '.ear'
					} else {
						/*Copia el WAR en Producción*/
						echo 'Copia del/los WAR en Producción'
				
						extension = '.war'
					}
					
					patronFicheros = "**/target/*${extension}"
				}
		
				ficheros = findFiles glob: patronFicheros
			}
		}
				
		ficheros.each { 
			def nombre = it.name.replace('.ear','').replace('.war','')
			def destino = "/otroslogs/aplicaciones/weblogic/${nombre}/produccion/app"
			
			echo "Copiando ${it.name} a ${destino} para su posterior paso a producción" + (fechaLiberacion? " el ${fechaLiberacion}":'')
			/*JLP.- Comprueba primero si existe el directorio y si no existe lo crea. Después, copia el fichero*/
			sh "test -d \"${destino}\" || mkdir -p \"${destino}\" && cp -f ${it} \"${destino}\""
			
		}
	} else {
		/* PARA LIBRERÍAS COMUNES */ 
		def modulos = listaModulos rutaPomXml: rutaPomXml
		
		// JLP.- Por cada librería vamos a leer la propiedad identificador.libreria para ver en qué carpeta se debe copiar
		modulos.each { modulo->
			def pom = readMavenPom file: "src/${modulo}/pom.xml"
			def properties = pom.getProperties()
			def identificadorLibreria = properties['identificador.libreria']
			//def version = pom.getVersion()

			def ficheros = findFiles glob: "src/${modulo}/target/*.war"
			ficheros.each { 
				def nombreCompleto = it.name.replace('.ear','').replace('.war','')
				int separador = nombreCompleto.lastIndexOf('-') 
				def nombre = nombreCompleto.substring(0, separador)
				def version = nombreCompleto.substring(separador+1,nombreCompleto.length())
				def destino = "/otroslogs/aplicaciones/weblogic/${identificadorLibreria}/produccion/lib/${version}"
				
				echo "Copiando ${it.name} a ${destino} para su posterior paso a producción" + (fechaLiberacion? " el ${fechaLiberacion}":'')
				sh "test -d \"${destino}\" || mkdir -p \"${destino}\" && cp -f ${it} \"${destino}/${nombre}.war\""
			}
		}
	}
	
	//TODO: Mandar email 	
}