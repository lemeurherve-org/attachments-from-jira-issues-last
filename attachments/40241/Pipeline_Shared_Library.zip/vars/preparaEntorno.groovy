#!groovy

/**
 * Elige el entorno en función de la rama y/o la elección de usuario
 */
def call(args) {
	echo """Preparando entorno...\n
			Argumentos: ${args}
	"""
	def esLibreria = args?.esLibreria?:false
	def libreriasComunes = args?.libreriasComunes?:false
	def paraVersionAnterior = args?.paraVersionAnterior?:false
	def rama = args?.rama?:env.BRANCH_NAME
	
	/*JLP.- No siempre es requerida la rama
	 if(rama==null) {
		error "Se necesita conocer la rama git de trabajo para poder preparar el entorno. Rama recibida por parámetro: ${args?.rama}. Variable de entorno env.BRANCH_NAME=${env.BRANCH_NAME}"  
	}*/
	
	echo "¿Es librería? ${esLibreria}"
	echo "¿Son liberíras comunes? ${libreriasComunes}"

	echo "Preparando entorno en función de los parámetros recibidos:" 			
	env.ACCION_DESATENDIDA = params?.accionDesatendida?:null
	env.JMETER_USER = params?.jmeterUser?:null
	env.JMETER_PASSWORD = params?.jmeterPassword?:null
	def entorno = params?.entorno?:null
	
	if(entorno) { 
		echo "Entorno ${entorno} asignado por parámetro"
		env.ENTORNO = entorno
	}
	
	def vienePasswordJMeter = (env.JMETER_PASSWORD!=null && !env.JMETER_PASSWORD.trim().isEmpty())
	
	echo """Parámetros recibidos:
			Entorno: ${entorno} 
			Acción desatendida: ${env.ACCION_DESATENDIDA}
			Usuario jmeter: ${env.JMETER_USER}
			¿Contraseña jmeter? ${vienePasswordJMeter}
			"""
	if(vienePasswordJMeter) { 
	    wrap([$class: 'MaskPasswordsBuildWrapper',varPasswordPairs: [[password: "${env.JMETER_PASSWORD}", var: 'env.JMETER_PASSWORD']]]) {
			echo """Parámetros enmascarados recibidos:
					Contraseña jmeter: ${env.JMETER_PASSWORD}
					"""
		}
	}
			
	if(esLibreria && !libreriasComunes) {
		echo "Preparando entorno para librería" 
		if((entorno!=null && entorno!='desarrollo') || rama.contains('release/') || rama.contains('hotfix/') ) {
			env.RUTA_DICCIONARIO_ERROR = '/otroslogs/confxml/produccion/12c/errmsg';
		} else {
			env.RUTA_DICCIONARIO_ERROR = '/otroslogs/confxml/desarrollo/12c/errmsg';
		}
		echo "Se asigna la ruta de los diccionarios de error '${env.RUTA_DICCIONARIO_ERROR}'" + ((rama && !entorno) ? " para el código fuente de la rama ${rama}":'') + (entorno ? " para el entorno ${entorno}":'')
	} else {
		if(libreriasComunes) { 
			echo "Preparando entorno para librerías comunes"
		} else { 
			echo "Preparando entorno para aplicación"
		} 
		
		try {
			echo "Determinando si preguntar o no a usuario..."
			if(paraVersionAnterior) {
				echo "Se está preperando el entorno para una versión anterior"
				timeout(time:1, unit:'HOURS') {
					if(!entorno) { 
						echo "Se le pregunta al usuario para qué entorno está generando la aplicación"
						env.ENTORNO = input message: 'Requerida acción de usuario', ok: 'Continuar',
						  parameters: [
							  choice(name: "¿Para qué entorno estas generando la aplicación?", choices: 'produccion\npreproduccion\nformacion\ndesarrollo', description: "Los ficheros de configuración de la aplicación se generarán con unos valores u otros dependiendo del entorno", defaultValue: "preproduccion")
						  ]
					} else { 
						echo "El entorno de despliegue ha sido impuesto por parámetro. Será ${entorno}"
					}
					echo "Se asigna el entorno '${env.ENTORNO}'" + (rama ? " para el código fuente de la rama ${rama}":'')
				}
			} else if(entorno=='preproduccion' || rama?.contains('release/') || rama?.contains('hotfix/')) {
				echo "Se está preperando el entorno para una versión en fase de pre-producción"
				timeout(time:1, unit:'HOURS') {
					if(!entorno) { 
						echo "Se le pregunta al usuario para qué entorno está generando la aplicación"
						env.ENTORNO = input message: 'Requerida acción de usuario', ok: 'Continuar',
						  parameters: [
							  choice(name: "¿Para qué entorno estas generando la aplicación?", choices: 'preproduccion\nformacion\ndesarrollo', description: "Los ficheros de configuración de la aplicación se generarán con unos valores u otros dependiendo del entorno", defaultValue: "preproduccion")
						  ]
					} else { 
						echo "El entorno de despliegue ha sido impuesto por parámetro. Será ${entorno}"
					}
					echo "Se asigna el entorno '${env.ENTORNO}'" + (rama ? " para el código fuente de la rama ${rama}":'')
					env.SIGUIENTE_FASE = 'Producción'
				}
			} else {
				echo "Se está preperando el entorno para una versión en fase de desarrollo"
				if(!entorno) {
					echo "El entorno de despliegue será desarrollo" 
					env.ENTORNO = 'desarrollo'
				} else { 
					echo "El entorno de despliegue ha sido impuesto por parámetro. Será ${entorno}"
				}
				env.SIGUIENTE_FASE = 'Pre-producción'
				echo "Se asigna automáticamente el entorno '${env.ENTORNO}'" + (rama ? " para el código fuente de la rama ${rama}. Las ramas en la carpeta release/ permitirán elegir el entorno.":'')
			}
		} catch(err) { // timeout reached or input false
			wasTimeoutOrCancelledByUser error: err
		}
	
	}
}