#!/usr/bin/env groovy
/**
 * Rearranca una lista de aplicaciones en Weblogic. Las aplicaciones deben estar desplegadas y paradas.
 */
def call(args) {
	echo "Redesplega aplicaciones... ${args}"

	def rutaPomXml=args.rutaPomXml
	def cadenaAplicacionesSeleccionadas=args.cadenaAplicacionesSeleccionadas
	def entorno = args.entorno ?:env.ENTORNO?:'indefinido'

	if(!cadenaAplicacionesSeleccionadas) {
		error "ERROR EN EL SCRIPT: No se recibió el parámetro 'cadenaAplicacionesSeleccionadas' en el script 'arrancaAplicaciones.groovy'"
		return 
	}
	
	def listaAplicacionesSeleccionadas = cadenaAplicacionesSeleccionadas.split(',')
	
	echo "Redesplegando " + listaAplicacionesSeleccionadas.size() + " aplicaciones en ${entorno}..." 
	
	def target
	def rutaDesplegableBase
	switch(entorno) {
		case "desarrollo":
			target = 'infra_cluster_des_1'		
			rutaDesplegableBase='/u01/app/oracle/config_des/domains/jweb_des/servers/AdminServer/upload'
			break;
		case "formacion":
			target = 'formacion'
			rutaDesplegableBase='/u01/app/oracle/config/domains/jweb_for/servers/AdminServer/upload'
			break;
		case "preproduccion":
			target = 'preproduccion' 
			rutaDesplegableBase='/u01/app/oracle/config/domains/jweb/servers/AdminServer/upload'
			break; 
		default:
			error "ERROR EN EL SCRIPT: El entorno de ejecución no puede ser '${entorno}' en el script 'arrancaAplicaciones.groovy'"
			return
	} 
	
	echo "Reservando el uso de Weblogic ${entorno} para rearrancar aplicaciones. Todos los accesos a Weblogic ${entorno} del resto de tareas quedarán a la espera."
	lock(resource: null, label: "weblogic_${entorno}") {
		for (i = 0; i < listaAplicacionesSeleccionadas.size(); i++) {
			def nombreFicheroApp = listaAplicacionesSeleccionadas[i]
			def nombreApp = nombreFicheroApp.replace('.ear','').replace('.war','')
			def rutaDesplegable= "${rutaDesplegableBase}/${nombreApp}/app/${nombreFicheroApp}"
			def rutaPlan =  "${rutaDesplegableBase}/${nombreApp}/plan/Plan1221.xml" //JLP: Si se normaliza a Plan.xml como antes hay que cambiar esto
			
			echo "Redesplegando ${nombreApp} en ${entorno}"
			echo """Datos del redespliegue:
				Nombre fichero app: ${nombreFicheroApp} 
				Ruta desplegable: ${rutaDesplegable} 
				"""
						
			sh "mvn com.oracle.weblogic:weblogic-maven-plugin:redeploy -f '${rutaPomXml}' -P${entorno} -Ddespliegue.nombre=${nombreApp} -Ddespliegue.cluster=${target} -Ddespliegue.upload=false -Ddespliegue.ruta.desplegable=${rutaDesplegable} -Ddespliegue.ruta.plan=${rutaPlan} -N -DfailOnError=false"
		}
	}
	echo "Liberado el uso de Weblogic ${entorno} para redesplegar aplicaciones. Listo para ser accedido por el resto de tareas."
}