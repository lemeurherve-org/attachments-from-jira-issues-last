#!groovy

/**
 * Sube a nexus un artefacto generado previamente. No vuelve a lanzar los tests que se lanzaron en el proceso genera.
 * Si la subida a Nexus falla pone el job en inestable pero continúa
 */
def call(args) {
	def rutaPomXml = args.rutaPomXml
	
	milestone label: "Subiendo a Nexus versión con nuevo cambio subido a ${env.BRANCH_NAME}", ordinal: 10
	
	try {
		//Tratamos de desplegar en Nexus y si falla permitimos seguir. Aquí no se vuelven a lanzar los tests que ya se lanzaron antes.
		sh "mvn deploy -f '${rutaPomXml}' -Dmaven.test.skip=true -DoracleHome=/usr/lib/oracle/12.1/client64"
	} catch(err) {
		echo "Se produjo un error tratando de subir a Nexus al JAR generado: ${err}"
		currentBuild.result = 'UNSTABLE'
	}
}