#!groovy
def call(args) {
	def err = args.error

	def didTimeout = wasTimeoutReached error: err
	def userCancelled = wasCancelledByUser error: err

	if (didTimeout) {
        // do something on timeout
        currentBuild.result = 'ABORTED'
        error "Cancelado por timeout"
    } else if (userCancelled) {
        // do something else
        currentBuild.result = 'FAILURE'
        error "Cancelado por el usuario"
    } else {
    	echo """Relanzando error original:
    		${err}
    	"""
    	throw err 
    } 
}