#!groovy
def call(args) {
	def err = args.error
	def causes
	def mainCause

	try { 
		causes = err.getCauses()
		mainCause = causes?.get(0)
		def user = mainCause?.getUser()
		    
	    if('SYSTEM' == user?.toString()) { // SYSTEM means timeout.
	        echo "Cancelado por timeout"
	        return true
	    }
    } catch(err2) {
    	echo """
    	Se produjo un error tratando de determinar si se produjo un timeout. Seguimos.	    	 
    	Error producido al determinar usuario: ${err2}
    	Causas del error de timeout: ${causes}
    	Causa principal: ${mainCause} 
    	""" 
    	//throw err
    }
    
    return false
}
