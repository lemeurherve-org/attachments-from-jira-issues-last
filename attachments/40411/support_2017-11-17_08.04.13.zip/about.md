Jenkins
=======

Version details
---------------

  * Version: `2.90`
  * Mode:    Webapp Directory
  * Url:     https://www5.in.tum.de/jenkins/mardyn/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.15.v20160210`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_111
      - Maximum memory:   1.48 GB (1594359808)
      - Allocated memory: 1.48 GB (1594359808)
      - Free memory:      667.15 MB (699553320)
      - In-use memory:    853.35 MB (894806488)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.111-b14
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.13.0-65-generic
      - Distribution: Ubuntu 14.04.3 LTS
  * Process ID: 10984 (0x2ae8)
  * Process started: 2017-11-14 14:55:34.177+0000
  * Process uptime: 2 days 17 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/opt/jetty/lib/apache-jsp/org.eclipse.jetty.apache-jsp-9.2.15.v20160210.jar:/opt/jetty/lib/apache-jsp/org.eclipse.jetty.orbit.org.eclipse.jdt.core-3.8.2.v20130121.jar:/opt/jetty/lib/apache-jsp/org.mortbay.jasper.apache-el-8.0.9.M3.jar:/opt/jetty/lib/apache-jsp/org.mortbay.jasper.apache-jsp-8.0.9.M3.jar:/opt/jetty/lib/apache-jstl/org.apache.taglibs.taglibs-standard-impl-1.2.1.jar:/opt/jetty/lib/apache-jstl/org.apache.taglibs.taglibs-standard-spec-1.2.1.jar:/opt/jetty/resources:/opt/jetty/lib/servlet-api-3.1.jar:/opt/jetty/lib/jetty-schemas-3.1.jar:/opt/jetty/lib/jetty-http-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-server-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-xml-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-util-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-io-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-jndi-9.2.15.v20160210.jar:/opt/jetty/lib/jndi/javax.mail.glassfish-1.4.1.v201005082020.jar:/opt/jetty/lib/jndi/javax.transaction-api-1.2.jar:/opt/jetty/lib/jetty-security-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-servlet-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-webapp-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-deploy-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-plus-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-annotations-9.2.15.v20160210.jar:/opt/jetty/lib/annotations/asm-5.0.1.jar:/opt/jetty/lib/annotations/asm-commons-5.0.1.jar:/opt/jetty/lib/annotations/javax.annotation-api-1.2.jar:/opt/jetty/lib/websocket/javax.websocket-api-1.0.jar:/opt/jetty/lib/websocket/javax-websocket-client-impl-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/javax-websocket-server-impl-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-api-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-client-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-common-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-server-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-servlet-9.2.15.v20160210.jar`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-XX:PermSize=512M`
      - arg[1]: `-XX:MaxPermSize=1024M`
      - arg[2]: `-Xms512M`
      - arg[3]: `-Xmx1536M`
      - arg[4]: `-Djetty.logs=/opt/jetty/logs`
      - arg[5]: `-Djetty.home=/opt/jetty`
      - arg[6]: `-Djetty.base=/opt/jetty`
      - arg[7]: `-Djava.io.tmpdir=/tmp`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.92 'Static Analysis Utilities'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.3-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * BlameSubversion:1.200 'Hudson Blame Subversion Plug-in'
  * blueocean:1.3.2 'Blue Ocean'
  * blueocean-autofavorite:1.1.0 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.3.2 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.3.2 'Common API for Blue Ocean'
  * blueocean-config:1.3.2 'Config API for Blue Ocean'
  * blueocean-dashboard:1.3.2 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.1.1 'Display URL for Blue Ocean'
  * blueocean-events:1.3.2 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.3.2 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.3.2 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.3.2 'i18n for Blue Ocean'
  * blueocean-jira:1.3.2 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.3.2 'JWT for Blue Ocean'
  * blueocean-personalization:1.3.2 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.3.2 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.3.2 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.3.2 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.3.2 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.3.2 'REST Implementation for Blue Ocean'
  * blueocean-web:1.3.2 'Web for Blue Ocean'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.15 'Branch API Plugin'
  * cccc:0.6 'Jenkins CCCC Plug-in'
  * chucknorris:1.0 'ChuckNorris Plugin'
  * cloudbees-bitbucket-branch-source:2.2.7 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.2.1 'Folders Plugin'
  * command-launcher:1.1 'Command Agent Launcher Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * copy-project-link:1.5 'Copy project link plugin'
  * copyartifact:1.39 'Copy Artifact Plugin'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * display-url-api:2.1.0 'Display URL API'
  * docker-commons:1.9 'Docker Commons Plugin'
  * docker-workflow:1.14 'Docker Pipeline'
  * durable-task:1.15 *(update available)* 'Durable Task Plugin'
  * email-ext:2.61 'Email Extension Plugin'
  * emailext-template:1.0 'Email Extension Template Plugin'
  * extended-read-permission:2.0 'Jenkins Extended Read Permission Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.1 'Favorite'
  * git:3.6.4 'Jenkins Git plugin'
  * git-client:2.6.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.28.1 'GitHub plugin'
  * github-api:1.90 'GitHub API Plugin'
  * github-branch-source:2.3.1 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * groovyaxis:0.3 'groovyaxis'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.8.7.0 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jira:2.5 'Jenkins JIRA plugin'
  * jquery:1.12.4-0 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.21 *(update available)* 'JUnit Plugin'
  * ldap:1.18 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.2 'Matrix Authorization Strategy Plugin'
  * matrix-groovy-execution-strategy:1.0.7 'Matrix Groovy Execution Strategy Plugin'
  * matrix-project:1.12 'Matrix Project Plugin'
  * maven-plugin:3.0 'Maven Integration plugin'
  * mercurial:2.2 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.4 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.4 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.4 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.4 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.5.1 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * PrioritySorter:3.5.1 'Jenkins Priority Sorter Plugin'
  * publish-over-ssh:1.17 'Publish Over SSH'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * role-strategy:2.6.1 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.2.5 'SCM API Plugin'
  * script-security:1.35 'Script Security Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.5 'Jenkins SSH plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.22 'Jenkins SSH Slaves plugin'
  * structs:1.10 'Structs Plugin'
  * subversion:2.9 'Jenkins Subversion Plug-in'
  * support-core:2.43 'Support Core Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * token-macro:2.3 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * variant:1.1 'Variant Plugin'
  * warnings:4.63 'Warnings Plug-in'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.23.1 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.41 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.17 'Pipeline: Nodes and Processes'
  * workflow-job:2.15 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.13 'Pipeline: Step API'
  * workflow-support:2.16 'Pipeline: Supporting APIs'
  * xunit:1.102 'xUnit plugin'
