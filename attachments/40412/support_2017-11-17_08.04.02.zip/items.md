Item statistics
===============

  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 1536
    - Number of builds per job: 7.09765625 [n=1536, s=4.1550841321146725]
  * `hudson.matrix.MatrixProject`
    - Number of items: 14
    - Number of builds per job: 9.357142857142858 [n=14, s=5.0]
    - Number of items per container: 109.71428571428571 [n=14, s=70.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 15
    - Number of builds per job: 162.13333333333333 [n=15, s=300.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 3
    - Number of builds per job: 14.666666666666666 [n=3, s=10.0]

Total job statistics
======================

  * Number of jobs: 1568
  * Number of builds per job: 8.615433673469388 [n=1568, s=35.108902564025335]
