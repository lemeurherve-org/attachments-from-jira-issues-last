Loggers currently enabled
=========================
com.cloudbees.jenkins.GitHubPushTrigger - ALL
org.jenkinsci.plugins.github - ALL
org.apache.sshd - WARNING
com.cloudbees.jenkins.GitHubWebHook - ALL
 - INFO
