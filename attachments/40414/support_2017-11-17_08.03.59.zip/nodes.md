Node statistics
===============

  * Total number of nodes
      - Sample size:        15628
      - Average (mean):     7.0
      - Average (median):   7.0
      - Standard deviation: 0.0
      - Minimum:            7
      - Maximum:            7
      - 95th percentile:    7.0
      - 99th percentile:    7.0
  * Total number of nodes online
      - Sample size:        15628
      - Average (mean):     3.000000000000001
      - Average (median):   3.0
      - Standard deviation: 8.881784197001254E-16
      - Minimum:            3
      - Maximum:            5
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors
      - Sample size:        15628
      - Average (mean):     14.0
      - Average (median):   14.0
      - Standard deviation: 1.281314845416133E-26
      - Minimum:            14
      - Maximum:            19
      - 95th percentile:    14.0
      - 99th percentile:    14.0
  * Total number of executors in use
      - Sample size:        15628
      - Average (mean):     3.744084995852324E-42
      - Average (median):   0.0
      - Standard deviation: 2.8405788001314087E-21
      - Minimum:            0
      - Maximum:            9
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      1
      - FS root:        `/srv/ls1`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.14
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   1.33 GB (1431830528)
          + Allocated memory: 1.28 GB (1377304576)
          + Free memory:      600.08 MB (629226896)
          + In-use memory:    713.42 MB (748077680)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-65-generic
          + Distribution: Ubuntu 14.04.3 LTS
      - Process ID: 10984 (0x2ae8)
      - Process started: 2017-11-14 14:55:34.177+0000
      - Process uptime: 2 days 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `/opt/jetty/lib/apache-jsp/org.eclipse.jetty.apache-jsp-9.2.15.v20160210.jar:/opt/jetty/lib/apache-jsp/org.eclipse.jetty.orbit.org.eclipse.jdt.core-3.8.2.v20130121.jar:/opt/jetty/lib/apache-jsp/org.mortbay.jasper.apache-el-8.0.9.M3.jar:/opt/jetty/lib/apache-jsp/org.mortbay.jasper.apache-jsp-8.0.9.M3.jar:/opt/jetty/lib/apache-jstl/org.apache.taglibs.taglibs-standard-impl-1.2.1.jar:/opt/jetty/lib/apache-jstl/org.apache.taglibs.taglibs-standard-spec-1.2.1.jar:/opt/jetty/resources:/opt/jetty/lib/servlet-api-3.1.jar:/opt/jetty/lib/jetty-schemas-3.1.jar:/opt/jetty/lib/jetty-http-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-server-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-xml-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-util-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-io-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-jndi-9.2.15.v20160210.jar:/opt/jetty/lib/jndi/javax.mail.glassfish-1.4.1.v201005082020.jar:/opt/jetty/lib/jndi/javax.transaction-api-1.2.jar:/opt/jetty/lib/jetty-security-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-servlet-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-webapp-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-deploy-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-plus-9.2.15.v20160210.jar:/opt/jetty/lib/jetty-annotations-9.2.15.v20160210.jar:/opt/jetty/lib/annotations/asm-5.0.1.jar:/opt/jetty/lib/annotations/asm-commons-5.0.1.jar:/opt/jetty/lib/annotations/javax.annotation-api-1.2.jar:/opt/jetty/lib/websocket/javax.websocket-api-1.0.jar:/opt/jetty/lib/websocket/javax-websocket-client-impl-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/javax-websocket-server-impl-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-api-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-client-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-common-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-server-9.2.15.v20160210.jar:/opt/jetty/lib/websocket/websocket-servlet-9.2.15.v20160210.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-XX:PermSize=512M`
          + arg[1]: `-XX:MaxPermSize=1024M`
          + arg[2]: `-Xms512M`
          + arg[3]: `-Xmx1536M`
          + arg[4]: `-Djetty.logs=/opt/jetty/logs`
          + arg[5]: `-Djetty.home=/opt/jetty`
          + arg[6]: `-Djetty.base=/opt/jetty`
          + arg[7]: `-Djava.io.tmpdir=/tmp`

  * KNL-Cluster-login (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      8
      - Remote FS root: `/naslx/projects/pr63so/ga38cor3`
      - Labels:         KNL
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.14
      - Java
          + Home:           `/lrz/mnt/sys.x86_sles12/compilers/java/jdk1.8.0_112/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_112
          + Maximum memory:   26.67 GB (28631367680)
          + Allocated memory: 595.00 MB (623902720)
          + Free memory:      210.60 MB (220829448)
          + In-use memory:    384.40 MB (403073272)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.112-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.74-92.35-default
      - Process ID: 331 (0x14b)
      - Process started: 2017-11-14 14:56:36.090+0000
      - Process uptime: 2 days 17 hr
      - JVM startup parameters:
          + Boot classpath: `/lrz/mnt/sys.x86_sles12/compilers/java/jdk1.8.0_112/jre/lib/resources.jar:/lrz/mnt/sys.x86_sles12/compilers/java/jdk1.8.0_112/jre/lib/rt.jar:/lrz/mnt/sys.x86_sles12/compilers/java/jdk1.8.0_112/jre/lib/sunrsasign.jar:/lrz/mnt/sys.x86_sles12/compilers/java/jdk1.8.0_112/jre/lib/jsse.jar:/lrz/mnt/sys.x86_sles12/compilers/java/jdk1.8.0_112/jre/lib/jce.jar:/lrz/mnt/sys.x86_sles12/compilers/java/jdk1.8.0_112/jre/lib/charsets.jar:/lrz/mnt/sys.x86_sles12/compilers/java/jdk1.8.0_112/jre/lib/jfr.jar:/lrz/mnt/sys.x86_sles12/compilers/java/jdk1.8.0_112/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `:/home/hpc/pr63so/ga38cor3/lib:/lrz/sys/intel/studio2017_u4/impi/2017.3.196/lib64:/lrz/sys/intel/studio2017_u4/compilers_and_libraries_2017.4.196/linux/mkl/lib/intel64:/lrz/sys/intel/studio2017_u4/debugger_2017/libipt/intel64/lib:/lrz/sys/intel/studio2017_u4/compilers_and_libraries_2017.4.196/linux/compiler/lib/intel64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * KNL-Cluster-prio (`hudson.slaves.DumbSlave`)
      - Description:    _KNL node for priority tasks (e.g. starting SLURM jobs)_
      - Executors:      1
      - Remote FS root: `/naslx/projects/pr63so/ga38cor3/jenkins-mardyn`
      - Labels:         KNL_PRIO
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * MAC Cluster Intel (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/tmp/jenkins-mardyn`
      - Labels:         SNB
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * SuperMIC (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/home/hpc/pr94ta/di25hup/jenkins-mardyn`
      - Labels:         KNC
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * SuperMIC-prio (`hudson.slaves.DumbSlave`)
      - Description:    _SuperMIC node for priority tasks (e.g. starting interactive jobs)_
      - Executors:      1
      - Remote FS root: `/home/hpc/pr94ta/di25hup/jenkins-mardyn`
      - Labels:         KNC_PRIO
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * atsccs11 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/work/jenkins/mardyn`
      - Labels:         HSW
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.14
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_151
          + Maximum memory:   6.97 GB (7484735488)
          + Allocated memory: 155.00 MB (162529280)
          + Free memory:      104.48 MB (109557504)
          + In-use memory:    50.52 MB (52971776)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.151-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.13.0-16-generic
          + Distribution: Ubuntu 17.10
      - Process ID: 19357 (0x4b9d)
      - Process started: 2017-11-14 14:56:23.724+0000
      - Process uptime: 2 days 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

