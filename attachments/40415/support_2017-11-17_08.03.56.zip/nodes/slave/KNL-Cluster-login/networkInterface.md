-----------
 * Name bond0
 ** Hardware Address - 6805ca54d329
 ** Index - 5
 ** InetAddress - /fe80:0:0:0:6a05:caff:fe54:d329%bond0
 ** InetAddress - /129.187.20.108
 ** InetAddress - /10.156.79.108
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - a4bf0114153a
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:a6bf:1ff:fe14:153a%eth0
 ** InetAddress - /10.0.0.8
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
