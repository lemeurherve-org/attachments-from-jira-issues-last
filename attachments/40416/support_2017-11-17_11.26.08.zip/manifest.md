Support Bundle Manifest
=======================

Generated on 2017-11-17 11:26:08.255+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-11-16_22.10.26.log`

      - `nodes/master/logs/all_2017-11-17_00.42.12.log`

      - `nodes/master/logs/all_2017-11-17_00.54.42.log`

      - `nodes/master/logs/all_2017-11-17_01.10.09.log`

      - `nodes/master/logs/all_2017-11-17_01.33.29.log`

      - `nodes/master/logs/all_2017-11-17_02.50.58.log`

      - `nodes/master/logs/all_2017-11-17_06.06.49.log`

      - `nodes/master/logs/all_2017-11-17_08.36.15.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Connection Activity monitoring to agents.log`

      - `other-logs/Connection Activity monitoring to agents.log.1`

      - `other-logs/Connection Activity monitoring to agents.log.2`

      - `other-logs/Connection Activity monitoring to agents.log.3`

      - `other-logs/Connection Activity monitoring to agents.log.4`

      - `other-logs/Connection Activity monitoring to agents.log.5`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Download metadata.log.2`

      - `other-logs/Download metadata.log.3`

      - `other-logs/Download metadata.log.4`

      - `other-logs/Download metadata.log.5`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Fingerprint cleanup.log.1`

      - `other-logs/Fingerprint cleanup.log.2`

      - `other-logs/Fingerprint cleanup.log.3`

      - `other-logs/Fingerprint cleanup.log.4`

      - `other-logs/Fingerprint cleanup.log.5`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/Workspace clean-up.log.1`

      - `other-logs/Workspace clean-up.log.2`

      - `other-logs/Workspace clean-up.log.3`

      - `other-logs/Workspace clean-up.log.4`

      - `other-logs/Workspace clean-up.log.5`

      - `other-logs/health-checker.log`

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/KNL-Cluster-login/checksums.md5`

      - `nodes/slave/KNL-Cluster-prio/checksums.md5`

      - `nodes/slave/MAC Cluster Intel/checksums.md5`

      - `nodes/slave/SuperMIC-prio/checksums.md5`

      - `nodes/slave/SuperMIC/checksums.md5`

      - `nodes/slave/atsccs11/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/KNL-Cluster-login/exportTable.txt`

      - `nodes/slave/KNL-Cluster-prio/exportTable.txt`

      - `nodes/slave/MAC Cluster Intel/exportTable.txt`

      - `nodes/slave/SuperMIC-prio/exportTable.txt`

      - `nodes/slave/SuperMIC/exportTable.txt`

      - `nodes/slave/atsccs11/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/KNL-Cluster-login/environment.txt`

      - `nodes/slave/KNL-Cluster-prio/environment.txt`

      - `nodes/slave/MAC Cluster Intel/environment.txt`

      - `nodes/slave/SuperMIC-prio/environment.txt`

      - `nodes/slave/SuperMIC/environment.txt`

      - `nodes/slave/atsccs11/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/atsccs11/file-descriptors.txt`

  * Master Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/atsccs11/proc/meminfo.txt`

      - `nodes/slave/atsccs11/proc/self/cmdline`

      - `nodes/slave/atsccs11/proc/self/environ`

      - `nodes/slave/atsccs11/proc/self/limits.txt`

      - `nodes/slave/atsccs11/proc/self/mountstats.txt`

      - `nodes/slave/atsccs11/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/HSW/gnuplot`

      - `load-stats/label/HSW/hour.csv`

      - `load-stats/label/HSW/min.csv`

      - `load-stats/label/HSW/sec10.csv`

      - `load-stats/label/KNC/gnuplot`

      - `load-stats/label/KNC/hour.csv`

      - `load-stats/label/KNC/min.csv`

      - `load-stats/label/KNC/sec10.csv`

      - `load-stats/label/KNC_PRIO/gnuplot`

      - `load-stats/label/KNC_PRIO/hour.csv`

      - `load-stats/label/KNC_PRIO/min.csv`

      - `load-stats/label/KNC_PRIO/sec10.csv`

      - `load-stats/label/KNL-Cluster-login/gnuplot`

      - `load-stats/label/KNL-Cluster-login/hour.csv`

      - `load-stats/label/KNL-Cluster-login/min.csv`

      - `load-stats/label/KNL-Cluster-login/sec10.csv`

      - `load-stats/label/KNL-Cluster-prio/gnuplot`

      - `load-stats/label/KNL-Cluster-prio/hour.csv`

      - `load-stats/label/KNL-Cluster-prio/min.csv`

      - `load-stats/label/KNL-Cluster-prio/sec10.csv`

      - `load-stats/label/KNL/gnuplot`

      - `load-stats/label/KNL/hour.csv`

      - `load-stats/label/KNL/min.csv`

      - `load-stats/label/KNL/sec10.csv`

      - `load-stats/label/KNL_PRIO/gnuplot`

      - `load-stats/label/KNL_PRIO/hour.csv`

      - `load-stats/label/KNL_PRIO/min.csv`

      - `load-stats/label/KNL_PRIO/sec10.csv`

      - `load-stats/label/MAC+Cluster+Intel/gnuplot`

      - `load-stats/label/MAC+Cluster+Intel/hour.csv`

      - `load-stats/label/MAC+Cluster+Intel/min.csv`

      - `load-stats/label/MAC+Cluster+Intel/sec10.csv`

      - `load-stats/label/SNB/gnuplot`

      - `load-stats/label/SNB/hour.csv`

      - `load-stats/label/SNB/min.csv`

      - `load-stats/label/SNB/sec10.csv`

      - `load-stats/label/SuperMIC-prio/gnuplot`

      - `load-stats/label/SuperMIC-prio/hour.csv`

      - `load-stats/label/SuperMIC-prio/min.csv`

      - `load-stats/label/SuperMIC-prio/sec10.csv`

      - `load-stats/label/SuperMIC/gnuplot`

      - `load-stats/label/SuperMIC/hour.csv`

      - `load-stats/label/SuperMIC/min.csv`

      - `load-stats/label/SuperMIC/sec10.csv`

      - `load-stats/label/atsccs11/gnuplot`

      - `load-stats/label/atsccs11/hour.csv`

      - `load-stats/label/atsccs11/min.csv`

      - `load-stats/label/atsccs11/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/KNL-Cluster-login/metrics.json`

      - `nodes/slave/KNL-Cluster-prio/metrics.json`

      - `nodes/slave/MAC Cluster Intel/metrics.json`

      - `nodes/slave/SuperMIC-prio/metrics.json`

      - `nodes/slave/SuperMIC/metrics.json`

      - `nodes/slave/atsccs11/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/KNL-Cluster-login/networkInterface.md`

      - `nodes/slave/KNL-Cluster-prio/networkInterface.md`

      - `nodes/slave/MAC Cluster Intel/networkInterface.md`

      - `nodes/slave/SuperMIC-prio/networkInterface.md`

      - `nodes/slave/SuperMIC/networkInterface.md`

      - `nodes/slave/atsccs11/networkInterface.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/atsccs11/dmesg.txt`

      - `nodes/slave/atsccs11/dmi.txt`

      - `nodes/slave/atsccs11/proc/cpuinfo.txt`

      - `nodes/slave/atsccs11/proc/mounts.txt`

      - `nodes/slave/atsccs11/proc/net/rpc/nfs.txt`

      - `nodes/slave/atsccs11/proc/net/rpc/nfsd.txt`

      - `nodes/slave/atsccs11/proc/swaps.txt`

      - `nodes/slave/atsccs11/proc/system-uptime.txt`

      - `nodes/slave/atsccs11/sysctl.txt`

      - `nodes/slave/atsccs11/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/KNL-Cluster-login/system.properties`

      - `nodes/slave/KNL-Cluster-prio/system.properties`

      - `nodes/slave/MAC Cluster Intel/system.properties`

      - `nodes/slave/SuperMIC-prio/system.properties`

      - `nodes/slave/SuperMIC/system.properties`

      - `nodes/slave/atsccs11/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20171117-112535.976.txt`

      - `slow-requests/20171117-112544.976.txt`

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/KNL-Cluster-login/thread-dump.txt`

      - `nodes/slave/KNL-Cluster-prio/thread-dump.txt`

      - `nodes/slave/MAC Cluster Intel/thread-dump.txt`

      - `nodes/slave/SuperMIC-prio/thread-dump.txt`

      - `nodes/slave/SuperMIC/thread-dump.txt`

      - `nodes/slave/atsccs11/thread-dump.txt`

