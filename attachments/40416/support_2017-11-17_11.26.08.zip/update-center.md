=== Sites ===
 - Url: http://updates.jenkins-ci.org/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 3 hr 6 min
Proxy: 'async-http-client' not installed, so no proxy info available.
