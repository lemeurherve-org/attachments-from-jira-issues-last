User
====

Authentication
--------------

  * Authenticated: true
  * Name: seckler
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@2db36ce9: Username: hudson.security.HudsonPrivateSecurityRealm$Details@6a26074a; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@380f4: RemoteIpAddress: 0:0:0:0:0:0:0:1; SessionId: hrgdu1fg78vl1ui27duwrepey; Granted Authorities: authenticated`

