#!groovy
/**
FIXME: JLP.- En pruebas. No funcionan los condicionales. NO USAR AÚN. La version que falla es la 1.2.4 · Core 2.73

 * Pipeline común a todos los proyectos de tipo APIRESTful en Eprinsa
 */
def call(String pomXmlPath, String rutaPomXmlEAR, String contextoUrl) {
	echo """Construyendo pipeline de proyecto de tipo API RESTful.
			Ruta pom xml: ${pomXmlPath} 
			Ruta pom xml del EAR: ${rutaPomXmlEAR}
			Contexto URL del APIREST: ${contextoUrl}
		"""
	
	env.POM_XML_PATH = pomXmlPath
	env.RUTA_POM_XML_EAR = rutaPomXmlEAR
	env.CONTEXTO_URL = contextoUrl	
	env.TAG_RELEASE = '' //Valor por defecto de este parámetro en caso de darse timeout por falta de interacción de usuario

	pipeline { 
		agent none	//Agente principal
		options { buildDiscarder(logRotator(numToKeepStr: '10')) }
		tools { 
	        maven 'maven 3.3.9' //Usamos maven 3.3.9
	        jdk 'java1.8' //Compilamos con Java 1.8
	    }
		// triggers { /*pollSCM('H/60 * * * *') JLP.- Desactivado provisional*/ }
		stages {
			stage('Preparación') {
				//agent none JLP.- Parece que no hace bien el checkout
				agent { label 'linux' }
				steps {
					parallel('Preparación en función del environment': {
								preparaEntorno isLibrary: false
							 },
							 'Obteniendo fecha próxima liberación': {
								obtenFechaProximaLiberacion()
							 }
							)
				}
			}
			stage('Configurar parámetros adicionales') {
				agent none
				steps {
					ofreceConfigurarParametrosAdicionales esAPIRestful: true
				}
			}
			stage('Generación') 
			{
				agent { label 'linux' }
				steps {
					usaUltimasVersionesLibreriasEprinsa pomXmlPath: env.POM_XML_PATH
					genera isLibrary: false, pomXmlPath: env.POM_XML_PATH, environment: env.ENTORNO
				}
			}
			stage('Aprobar despliegue') {
				agent none
				steps {
					apruebaDespliegue environment: env.ENTORNO
				}
			}
			stage('Despliegue') 
			{
				when {
					environment name: 'DESPLIEGUE_Y_TESTS', value: 'Sí'
				}
				agent { label 'linux' }
				steps {
					despliega isLibrary: false, pomXmlPath: env.RUTA_POM_XML_EAR, environment: env.ENTORNO
				}
			}
			stage('Comprobación servicio activo') {
				agent { label 'linux' }
				steps {				
					/*
					Comprobamos que se desplegó OK
					*/
					compruebaDespliegueOk	contextoUrl: CONTEXTO_URL,	esAPIRestful: true, environment : env.ENTORNO
				}
			}
			stage('Lanzar tests JMeter') {
				agent { label 'linux' }
				when {
					environment name: 'DESPLIEGUE_Y_TESTS', value: 'Sí'
				}
				steps {
					lanzaTestsJMeter pomXmlPath: env.POM_XML_PATH, environment: env.ENTORNO
				}
				post {
					always {
						recopilaResultadosJMeter environment: env.ENTORNO
					}
				}
			}
			stage('Pasar a la fase de Pre-producción') {
				when {
					branch 'develop'
				}
				agent none
				steps {
					apruebaPasoAFaseDePruebas()
				}
			}
			stage('Creación de Release Candidate') {
				when {
					branch 'develop'
					environment name: 'PASAR_A_PREPRODUCCION', value: 'Sí'
				}
				agent { label 'linux' }
				steps {
					creaReleaseCandidate pomXmlPath: env.POM_XML_PATH, 
					fechaLiberacion: env.FECHA_LIBERACION, 
					who: env.QUIEN_PASA_A_PREPRODUCCION
				}
			}
			stage('Pasar a la fase de Producción') {
				when {
					expression {
						env.BRANCH_NAME.contains('release/') || env.BRANCH_NAME.contains('hotfix/')
					}
				}
				agent none
				steps {
					apruebaLiberarVersion isLibrary: false
				}
			}
			stage('Liberación') {
				when {
					expression {
						env.RELEASE == 'Sí'
					}
				}
				agent { label 'linux' }
				steps {
					liberaVersion	isLibrary: false, pomXmlPath: env.POM_XML_PATH, environment: env.ENTORNO
				}
				post {
					/*JLP.- Cuando se liberó version and se hizo merge con develop correctamente */
					success {
						enviaMailVersionLiberada	who: "${WHO_IS_RELEASING}",
									to: 'desarrollo.eadmon@eprinsa.es',
									isLibrary: false,
									pomXmlPath: env.POM_XML_PATH
					}
					/*JLP.- Cuando se liberó version correctamente pero no se pudo hacer merge con develop */
					unstable {
						enviaMailVersionLiberada	who: "${WHO_IS_RELEASING}",
									to: 'desarrollo.eadmon@eprinsa.es',
									isLibrary: false,
									pomXmlPath: env.POM_XML_PATH
					}
				}
			}
			stage('Puesta en producción') {
				agent none
				when {
					expression { env.BRANCH_NAME.contains('release/') || env.BRANCH_NAME.contains('hotfix/') }
				}
				steps {
					node('linux') {
						obtenUltimaVersionLiberada()
					}
					apruebaPuestaEnProduccion()
				}
			}
			stage('Copia a la carpeta de paso a producción') {
				agent { label 'linux' }
				when {
					environment name: 'PASAR_A_PRODUCCION', value: "Sí"
				}
				steps {
					pasoAProduccion()	
				}
			}
		}
		post {
			always {
				node('linux') {
					finalizaPipeline guardaEAR: true
				}
			}
			changed {
				node('linux') {
					notificaCambioEstadoPipeline()
				}
	        }
	    }
	}
}