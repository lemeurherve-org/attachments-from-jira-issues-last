#!groovy

/**
FIXME: JLP.- En pruebas. No funcionan los condicionales. NO USAR AÚN. La version que falla es la 1.2.4 · Core 2.73

 * Pipeline común to la generacion de una version anterior de un proyecto/library/library común
 */
def call(String pomXmlPath, String rutaPomXmlEAR, String contextoUrl, Tipo tipo) {
	echo """Construyendo pipeline de generación de version anterior de proyecto/library/library común.
			Ruta pom xml: ${pomXmlPath} 
			Ruta pom xml del EAR: ${rutaPomXmlEAR}
			Contexto URL del APIREST: ${contextoUrl}
			Tipo: ${tipo}
		"""
	env.POM_XML_PATH = pomXmlPath
	env.RUTA_POM_XML_EAR = rutaPomXmlEAR
	env.CONTEXTO_URL = contextoUrl
	env.ES_LIBRERIA = (tipo == Tipo.LIBRERIA)
	env.ES_API_RESTFUL = (tipo == Tipo.APIRESTFUL)
	
	env.GUARDA_EAR = (tipo == Tipo.APIRESTFUL) || (tipo == Tipo.APLICACION_JSF)|| (tipo == Tipo.APLICACION_ADF)
	env.GUARDA_JAR = (tipo == Tipo.LIBRERIA)
	env.GUARDA_WAR = (tipo == Tipo.LIBRERIA_COMUN)
	
	env.TAG_RELEASE = '' //Valor por defecto de este parámetro en caso de darse timeout por falta de interacción de usuario

	/*JLP.- En los pipeline que no son multibranch este valor no viene relleno por defecto así que se lo damos nosotros*/
	env.BRANCH_NAME = params.rama_git
		
	pipeline { 
		agent none	//Agente principal
		options { 
			skipDefaultCheckout(true) //JLP.- Queremos hacer checkout del tag seleccionado
			buildDiscarder(logRotator(numToKeepStr: '10')) 
		}
		tools { 
	        maven 'maven 3.3.9' //Usamos maven 3.3.9
	        jdk 'java1.8' //Compilamos con Java 1.8
	    }
	/* JLP.- Esto lo configuramos en el job jenkins directamente (esto aún no funciona en las pipelines)
	parameters {
		gitParam('rama_git') {
			type('BRANCH_TAG')
			description('Tag de la version que quieres release')
			tagFilter('*')
			branchFilter('origin/master')
			defaultValue('origin/master')
		}
        [$class: 'GitParameterDefinition', branch: '', branchFilter: 'origin/master', defaultValue: 'origin/master', , name: 'rama_git', quickFilterEnabled: false, selectedValue: 'DEFAULT', sortMode: 'NONE', tagFilter: '*', type: 'PT_BRANCH_TAG']
    }*/
		stages {
			stage('Checkout version anterior') {
				agent { label 'linux' }
				steps {
		
					echo "Haciendo checkout de la rama git: ${params.rama_git}"
					//git branch: params.rama_git, credentialsId: '77d170ae-31ff-4961-9ec4-ff370a075ee3', url: scm.getUserRemoteConfigs()[0].getUrl()
					checkout scm: [$class: 'GitSCM', userRemoteConfigs: [[url: scm.getUserRemoteConfigs()[0].getUrl(), credentialsId: '77d170ae-31ff-4961-9ec4-ff370a075ee3']], branches: [[name: params.rama_git]]],poll: false
				}
			}
			stage('Preparación en función del environment') {
				agent { label 'linux' }
				steps {
					preparaEntorno isLibrary: env.ES_LIBRERIA, paraVersionAnterior: true
				}
			}
			stage('Configurar parámetros adicionales') {
				agent none
				steps {
					ofreceConfigurarParametrosAdicionales esAPIRestful: env.ES_API_RESTFUL
				}
			}
			stage('Generación') 
			{
				agent { label 'linux' }
				steps {
					genera isLibrary: env.ES_LIBRERIA, pomXmlPath: env.POM_XML_PATH, environment: env.ENTORNO
				}
			}
			stage('Aprobar despliegue') {
				agent none
				when {
					expression {
						env.ENTORNO != 'produccion'
					}
				}
				steps {
					apruebaDespliegue environment: env.ENTORNO, fuerzaElegirOpcionesDespliegue: true
				}
			}
			stage('Despliegue') 
			{
				when {
					environment name: 'DESPLIEGUE_Y_TESTS', value: 'Sí'
				}
				agent { label 'linux' }
				steps {
					despliega isLibrary: env.ES_LIBRERIA, pomXmlPath: env.RUTA_POM_XML_EAR, environment: env.ENTORNO
				}
			}
			stage('Comprobación servicio activo') {
				agent { label 'linux' }
				when {
					environment name: 'DESPLIEGUE_Y_TESTS', value: 'Sí'
				}
				steps {				
					/*
					Comprobamos que se desplegó OK
					*/
					compruebaDespliegueOk	contextoUrl: CONTEXTO_URL,	esAPIRestful: env.ES_API_RESTFUL, environment : env.ENTORNO
				}
			}
			stage('Lanzar tests JMeter') {
				agent { label 'linux' }
				when {
					environment name: 'DESPLIEGUE_Y_TESTS', value: 'Sí'
				}
				steps {
					lanzaTestsJMeter pomXmlPath: env.POM_XML_PATH, environment: env.ENTORNO, cliente: 'haciendalocal-clon'
				}
				post {
					always {
						recopilaResultadosJMeter environment: env.ENTORNO
					}
				}
			}
			stage('Puesta en producción') {
				agent none
				when {
					environment name: 'ENTORNO', value: 'produccion'
				}
				steps {
					apruebaPuestaEnProduccion version: params.rama_git //JLP.- El parámetro 'rama_git' viene configurado desde el job jenkins
				}
			}
			stage('Copia a la carpeta de paso a producción') {
				agent { label 'linux' }
				when {
					environment name: 'PASAR_A_PRODUCCION', value: "Sí"
				}
				steps {
					pasoAProduccion()	
				}
			}
		}
		post {
			always {
				node('linux') {
					finalizaPipeline guardaEAR: env.GUARDA_EAR, guardaJAR: env.GUARDA_JAR, guardaWAR: env.GUARDA_WAR
				}
			}
			changed {
				node('linux') {
					notificaCambioEstadoPipeline()
				}
	        }
	    }
	}
	
}