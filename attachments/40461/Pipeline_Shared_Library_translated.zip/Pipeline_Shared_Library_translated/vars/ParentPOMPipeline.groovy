#!groovy
/**
FIXME: JLP.- En pruebas. No funcionan los condicionales. NO USAR AÚN. La version que falla es la 1.2.4 · Core 2.73

 * Pipeline común a todos los proyectos de tipo parent.pom en Eprinsa
 */
def call(String pomXmlPath) {
	echo "Construyendo pipeline de proyecto de tipo paren.pom. Ruta pom xml: ${pomXmlPath}"
	env.POM_XML_PATH = pomXmlPath
	 
	pipeline { 
		agent none	//Agente principal
		options { buildDiscarder(logRotator(numToKeepStr: '10')) }
		tools { 
	        maven 'maven 3.3.9' //Usamos maven 3.3.9
	        jdk 'java1.8' //Compilamos con Java 1.8
	    }
		// triggers { /*pollSCM('H/60 * * * *') JLP.- Desactivado provisional*/ }
		stages {
			stage('Preparación') {
				//agent none JLP.- Parece que no hace bien el checkout
				agent { label 'linux' }
				steps {
					parallel('Comprobando si existen nuevas versiones a título informativo': {
								muestraNuevasVersiones pomXmlPath: env.POM_XML_PATH
							 })
				}
			}
			stage('Configurar parámetros adicionales') {
				agent none
				steps {
					ofreceConfigurarParametrosAdicionales()
				}
			}
			stage('Generación') 
			{
				agent { label 'linux' }
				steps {
					genera isLibrary: false, pomXmlPath: env.POM_XML_PATH
				}
			}
			stage('Subida a Nexus') 
			{
				agent { label 'linux' }
				steps {
					uploadToNexus pomXmlPath: env.POM_XML_PATH
				}
			}
			stage('Aprobar liberación') {
				agent none
				when {
					expression {				
						env.BRANCH_NAME == 'develop' || env.BRANCH_NAME.contains('release/') || env.BRANCH_NAME.contains('hotfix/')
					}
				}
				steps {
					apruebaLiberarVersion isLibrary: false
				}
			}
			stage('Liberación') {
				when {
					environment name: 'RELEASE', value: 'Sí'
				}
				agent { label 'linux' }
				steps {
					liberaVersion	isLibrary: false, pomXmlPath: env.POM_XML_PATH
				}
				
				post {
					success {
						enviaMailVersionLiberada who: WHO_IS_RELEASING, to: 'desarrollo.eadmon@eprinsa.es'
					}
				}
			}
		}
		post {
			always {
				node('linux') {
					finalizaPipeline()
				}
			}
			changed {
				node('linux') {
					notificaCambioEstadoPipeline()
				}
	        }
	    }
	}
}
