#!/usr/bin/env groovy
/**
 * Pregunta al usaurio si quiere release this version. 
 */
def call(args) {
	def isLibrary = args?.isLibrary?:false
	def commonLibraries = args?.commonLibraries?:false
	def releaseDaysTimeout = args?.releaseDaysTimeout?:21
	
		echo """Approving release de version. 
		Args: ${args}
		"""
	
	milestone label: 'Version ready for releasing', ordinal: 50
	
	/*
	 No se permite release una version que no esté en develop o release (tipicamente una feature)
	*/
	if(isLibrary && !commonLibraries && (env.BRANCH_NAME!='develop' && !env.BRANCH_NAME.startsWith('release/') && !env.BRANCH_NAME.startsWith('hotfix/'))) {
		error "No se permite release una version si no se está en la rama develop, release candidate o hotfix"
		return 
	} 
	
	try { 
		timeout(time: releaseDaysTimeout, unit:'DAYS') {
			def descripcion
			
			if(commonLibraries) { 
				descripcion= "Choose Yes to create a tag for this version, upload it to Nexus and then pass it to production stage"
			} else if(isLibrary) {
				descripcion= "Choose Yes to create a tag for this version and upload it to Nexus"
			} else {
				descripcion= "Choose Yes to create a tag for this version to then pass it to production stage"
			}
			/*Preguntamos al usuario si quiere pasar this version a Producción*/
			def respuesta = input message: 'User action requested', submitterParameter: 'who_is_releasing', ok: "Continue", id: "liberacion",
					  parameters: [
					  	choice(name: "Release this version?", choices: 'No\nYes', description: descripcion, defaultValue: "No"),
					  	string(name: "Version comments", description: "En caso de release, este comentario será incluido en el email enviado al equipo")
					  ]
	
			env.RELEASE = respuesta['Release this version?']
			env.WHO_IS_RELEASING = respuesta['who_is_releasing']
			env.VERSION_COMMENT = respuesta['Version comments']
					
			echo "Release? ${RELEASE} ¿Quién libera? ${WHO_IS_RELEASING} Comentario de la version: ${VERSION_COMMENT}"		
		}
	} catch(err) { // timeout reached or input false
		def didTimeout = wasTimeoutReached error: err
		def userCancelled = wasCancelledByUser error: err

		if (didTimeout) {
			//JLP.- Si llegó hasta aquí, que se considere como marcar NO en lugar de abortar la ejecución
			/*		
	        currentBuild.result = 'NOT_BUILT'
	        error "Cancelado por timeout"
	        */
	        env.RELEASE = 'No'
	    } else if (userCancelled) {
	        // do something else
	        currentBuild.result = 'FAILURE'
	        error "Cancelled by user"
	    } 
	}
}