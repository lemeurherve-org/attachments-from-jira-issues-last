#!groovy
//!!!!!!! JLP.- Obsoleto. Usar ofreceConfigurarParametrosAdicionales
def call(args) {
	try { 
		timeout(time:15, unit:'SECONDS') {
			env.AÑADIR_PARAMETROS_MAVEN_ADICIONALES = input message: 'User action requested', ok: 'Continue',
			  parameters: [
				  choice(
					name: "Añadir parámetros maven adicionales",
					choices: 'No\nYes', 
					description: 'Choose Yes to añadir parámetros adicionales al comando maven de generación, como por ejemplo to poder especificar el - U que equivale al Force Update of Snapshots/Releases de Eclipse',
					defaultValue: 'No'
					)						  
			  ]
		}
	} catch(err) { 
		def userCancelled2 = wasCancelledByUser error: err
		if (userCancelled2) {
	        // do something else
	        currentBuild.result = 'FAILURE'
	        error "Cancelled by user"
	    } else {
	    	//Timeout. Seguimos 
	    	echo """Se alcanzó timeout sin especificar parámetros maven extra. Seguimos.
	    	Error lanzado por el timeout: ${err}
	    	"""
	    }
	}
	
	return env.AÑADIR_PARAMETROS_MAVEN_ADICIONALES
}