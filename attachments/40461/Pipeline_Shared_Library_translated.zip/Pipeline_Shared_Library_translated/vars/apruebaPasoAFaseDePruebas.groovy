#!/usr/bin/env groovy
/**
 * Aprueba el paso a la fase de pre-producción. Para ello pregunta al usuario la fecha de liberación and que se utilizará más adelante to crear una rama release con la misma
 */
def call(args) {
	echo """Aprobando paso a la fase de preproducción.
		Args: ${args}
		"""
	 
	def fechaProximaLiberacion = args!=null && args.fechaProximaLiberacion ?:env.FECHA_PROXIMA_LIBERACION
	
	if(fechaProximaLiberacion?.trim()) { 
		echo "Fecha de la próxima liberación recibida: ${fechaProximaLiberacion}"
	} else { 
		echo "No se recibió fecha de próxima liberación"
	}
	
	def userCancelled = false
	def didTimeout = false
	
	try { 
		timeout(time:8, unit:'HOURS') {
			def respuesta = input message: "¿Pasar this version a la fase de Pre-Producción?", ok: "Continue", submitterParameter: 'quien_pasa_a_pre',
				parameters: [
				  	choice(name: "¿Pasar a rama release?", choices: 'No\nYes', description: "Choose Yes to crear o fusionar en caso de que exista, una rama release que te permitirá desplegar this version en el environment de pre-producción", defaultValue: "No"),
					string(
						name: "Fecha de liberación",
						description: "Especifica la fecha de liberación en formato AA.MM.DD (AA=Dos dígitos del año, MM=Dos dígitos del mes, DD=Dos dígitos del día). Se creará una rama release/AA.MM.DD to comenzar la fase de Tests sobre ella",
						defaultValue: fechaProximaLiberacion
					)
				]
	
			env.PASAR_A_PREPRODUCCION = respuesta['¿Pasar a rama release?']
			env.QUIEN_PASA_A_PREPRODUCCION = respuesta['quien_pasa_a_pre']
			env.FECHA_LIBERACION = respuesta['Fecha de liberación']
					
			echo """¿Pasar a rama release? ${env.PASAR_A_PREPRODUCCION}
					¿Quien pasa a preproducción? ${env.QUIEN_PASA_A_PREPRODUCCION}
					¿Fecha de liberación? ${env.FECHA_LIBERACION} 
				""" 
		}
	} catch(err) { // timeout reached or input false
		didTimeout = wasTimeoutReached error: err
		userCancelled = wasCancelledByUser error: err
	}

	if (didTimeout) {
        // do something on timeout
		//JLP.- Si llegó hasta aquí, que se considere como marcar NO en lugar de abortar la ejecución
        /*currentBuild.result = 'NOT_BUILT'
        error "Cancelado por timeout"*/
        env.PASAR_A_PREPRODUCCION = 'No'
    } else if (userCancelled) {
        // do something else
        currentBuild.result = 'FAILURE'
       error "Cancelled by user"
     } 
}