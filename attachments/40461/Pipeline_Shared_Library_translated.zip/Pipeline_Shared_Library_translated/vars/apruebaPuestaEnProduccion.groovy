#!/usr/bin/env groovy
/**
 * Pregunta al usuario si quiere colocar una version previamente liberada en producción.
 */
def call(args) {
	def ultimoTag = args?.ultimoTag ?:''
	def version = args?.version?:null
	def pomXmlPath = args?.pomXmlPath?:null
	
	if(version==null) {
		if(env.NODE_NAME=='linux' && pomXmlPath!=null) { 
			def pom = readMavenPom file: pomXmlPath
			
			version = pom.getVersion()
			
		} else {
			version = 'liberada' 
		} 
	}
		
	def userCancelled = false
	def didTimeout = false
	
	/*
	Le pide al usuario que elija el tag to regenerar la version que se va a copiar
	*/
	try { 
		timeout(time:1, unit:'HOURS') {
				def respuesta = input message: "¿Quieres colocar la version ${version} en la carpeta de Producción?", ok: "Continue",
				parameters: [
				  	choice(name: "¿Copiar en la carpeta de Producción?", choices: 'No\nYes', description: "Choose Yes to copiar el EAR/WAR generado en la carpeta de producción to su despliegue automático el día de liberación.", defaultValue: "No")
				  	/* JLP.- Parece que no funciona bien
				  	, [
						$class: 'GitParameterDefinition', 
						name: "version",
						description: "Tag de la version que quieres release",
						type: "Tag",
						defaultValue: "${ultimoTag}"
					]*/
				]
				
				/*env.TAG_RELEASE = respuesta['version']
				env.PASAR_A_PRODUCCION = respuesta['¿Copiar en la carpeta de Producción?']*/
				env.PASAR_A_PRODUCCION = respuesta
		}
	} catch(err) { // timeout reached or input false
		didTimeout = wasTimeoutReached error: err
		userCancelled = wasCancelledByUser error: err
	}

	if (didTimeout) {
		//JLP.- Si llegó hasta aquí, que se considere como marcar NO en lugar de abortar la ejecución
		/*
        currentBuild.result = 'NOT_BUILT'
        error "Cancelado por timeout"
        */
        env.PASAR_A_PRODUCCION = 'No'
     } else if (userCancelled) {
       // do something else
        currentBuild.result = 'FAILURE'
        error "Cancelled by user"
    } 
}