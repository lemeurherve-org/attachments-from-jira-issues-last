#!/usr/bin/env groovy
/**
 * Rearranca una lista de aplicaciones en Weblogic. Las aplicaciones deben estar desplegadas and paradas.
 */
def call(args) {
	echo "Rearrancando aplicaciones... ${args}"

	def pomXmlPath=args.pomXmlPath
	def cadenaAplicacionesSeleccionadas=args.cadenaAplicacionesSeleccionadas
	def environment = args.environment ?:env.ENTORNO?:'undefined'

	if(!cadenaAplicacionesSeleccionadas) {
		error "ERROR EN EL SCRIPT: No se recibió el parámetro 'cadenaAplicacionesSeleccionadas' en el script 'arrancaAplicaciones.groovy'"
		return 
	}
	
	def listaAplicacionesSeleccionadas = cadenaAplicacionesSeleccionadas.split(',')
	
	echo "Rearrancando " + listaAplicacionesSeleccionadas.size() + " aplicaciones en ${environment}..." 
	
	def target
	switch(environment) {
		case "desarrollo":
			target = 'infra_cluster_des_1'
			break;
		case "formacion":
			target = 'formacion'
			break;
		case "preproduccion":
			target = 'preproduccion' 
			break; 
		default:
			error "ERROR EN EL SCRIPT: El environment de ejecución no puede ser '${environment}' en el script 'arrancaAplicaciones.groovy'"
			return
	} 
	
	echo "Reservando el uso de Weblogic ${environment} to rearrancar aplicaciones. Todos los accesos a Weblogic ${environment} del resto de tareas quedarán a la espera."
	lock(resource: null, label: "weblogic_${environment}") {
		for (i = 0; i < listaAplicacionesSeleccionadas.size(); i++) { 
			def nombreFicheroApp = listaAplicacionesSeleccionadas[i]
			def nombreApp = nombreFicheroApp.replace('.ear','').replace('.war','')
			
			echo "Rearrancando ${nombreApp} en ${environment}"
						
			sh "mvn com.oracle.weblogic:weblogic-maven-plugin:start-app -f '${pomXmlPath}' -P${environment} -Ddespliegue.nombre=${nombreApp} -Ddespliegue.cluster=${target} -DfailOnError=false"
		}
	}
	echo "Released el uso de Weblogic ${environment} to rearrancar aplicaciones. Listo to ser accedido por el resto de tareas."
}