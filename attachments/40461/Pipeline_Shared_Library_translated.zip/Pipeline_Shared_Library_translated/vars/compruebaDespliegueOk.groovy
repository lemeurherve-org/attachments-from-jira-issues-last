#!/usr/bin/env groovy
/**
 * Comprueba si el despliegue de una application web/api rest se llevó a cabo correctamente haciendo una petición HTTP a la misma
 */
def call(args) {
	def contextoUrl=args.contextoUrl
	def esAPIRestful=args.esAPIRestful?:false
	def environment = args.environment ?:'undefined'
		
	def sufijo = esAPIRestful ? '/info/version' : ''

	echo "Comprobando que se ha desplegado correctamente en ${environment}"
			
	if(environment == 'desarrollo') {
		httpRequest ignoreSslErrors: true, responseHandle: 'NONE', url: "http://eprinsa-des-ofvirtual.e-admin.es/${contextoUrl}${sufijo}"
	} else if(environment == 'preproduccion') {
		httpRequest ignoreSslErrors: true, responseHandle: 'NONE', url: "http://eprinsa-test-ofvirtual.e-admin.es/${contextoUrl}${sufijo}"
	} else if(environment == 'formacion') {
		httpRequest ignoreSslErrors: true, responseHandle: 'NONE', url: "http://formacion-ofvirtual.e-admin.es/${contextoUrl}${sufijo}"
	} else {
		error "No se especificó el environment donde está la application/api que se quiere comprobar" 
	}
}
