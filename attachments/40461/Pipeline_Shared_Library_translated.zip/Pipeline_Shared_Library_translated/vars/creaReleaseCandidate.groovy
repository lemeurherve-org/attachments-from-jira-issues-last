#!/usr/bin/env groovy
/**
 * Crea una rama release con la fecha de liberación
 */
def call(args) {
	echo "Creando rama release candidate...\nArgumentos: ${args}"

	def fechaLiberacion = args.fechaLiberacion
	def pomXmlPath=args.pomXmlPath
	def scmUrl = args.scmUrl?:scm.getUserRemoteConfigs()[0].getUrl()
	def who = args.who?:env.QUIEN_PASA_A_PREPRODUCCION
	
	echo "Usando SCM URL: ${scmUrl}"

	if(!fechaLiberacion) {
		error "No se especificó una fecha de liberación" 
	}
	
	if(!pomXmlPath) {
		error "No se especificó path donde se localiza el fichero pom.xml" 
	}
	
	def credenciales = '77d170ae-31ff-4961-9ec4-ff370a075ee3' //JLP.- Corresponde a las identificador de las credenciales 'jenkins (usuario to git)'. Si cambiase este usuario est id dejará de ser válido 
	git url: scmUrl, credentialsId: credenciales, branch: env.BRANCH_NAME
	
	echo "Comprobando si la rama 'release/${fechaLiberacion}' ya existe..."
	def estado = sh( returnStatus : true, script: "git rev-parse --verify 'release/${fechaLiberacion}'")
	def existeRama = (estado==0)
	echo """Estado del comando git:
			$estado
			
			¿Existe rama?
			${existeRama}
		 """
	
	if(existeRama) {
		echo "La rama 'release/${fechaLiberacion}' ya existe."
		git url: scmUrl, credentialsId: credenciales, branch: "release/${fechaLiberacion}"
		echo "Performing merge con develop..."
		sh "git merge develop"
		echo "Detectamos si hay cambios que se deben subir..."
		def salida = sh (returnStdout: true, script: "git diff --numstat")
		def lineas = salida.split('\n')
		echo "Cambios pendientes de subir: " +lineas.size() + "\n${lineas}" 
		if(lineas.size()>0) { 
			echo "Listando ficheros..."
			def salidaLista = sh (returnStdout: true, script: "git diff --stat --cached")
			echo "Ficheros:\n${salidaLista}"
			echo "Hacemos commit..."
			sh "git commit -a -m 'Actualizando release candidate ${fechaLiberacion}' --author='${who}'"
			echo "Hacemos push..."
			sh "git push origin 'release/${fechaLiberacion}'"
		} else {
			echo "Nada que subir a la rama 'release/${fechaLiberacion}'"
		}
	} else {
		echo "Creando/actualizando rama 'release/${fechaLiberacion}'..."
		def tmpDir = pwd tmp: true 
		sh "mvn release:branch -f '${pomXmlPath}' -DbranchName='release/${fechaLiberacion}' -DlocalRepoDirectory='${tmpDir}' -DupdateBranchVersions=true -DupdateWorkingCopyVersions=false"
	}
	
	/*
	try { 
		sh "mvn jgitflow:release-start -f '${pomXmlPath}' -DpushReleases=true -DreleaseVersion='${fechaLiberacion}'"
	} catch(err) {
	 	echo """
	 			Error trying to de crear una rama release: ${err}
	 			Es posible que se deba a que existen despendencias -SNAPSHOT. 
	 			Reintentamos permitiendo estas dependencias pero no se permitirá release dicha rama hasta que no se sustituyan dichas depencendias por la version liberada
	 		""" 
		sh "mvn jgitflow:release-start -f '${pomXmlPath}' -DpushReleases=true -DreleaseVersion='${fechaLiberacion}' -DallowSnapshots=true"
	 	currentBuild.result = 'UNSTABLE'
	}
	*/
}