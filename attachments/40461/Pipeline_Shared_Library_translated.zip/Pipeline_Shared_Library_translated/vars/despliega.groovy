#!/usr/bin/env groovy
/**
 * Despliega una serie de aplicaciones/librerías comunes en Weblogic
 */
def call(args) {
	//def isLibrary=args.isLibrary?:false
	def commonLibraries = args.commonLibraries?:false
	def rutasPomXml=args.pomXmlPath?.split(',')
	def environment = args.environment ?:env.ENTORNO?:'undefined'
	def mavenParams = args.mavenParams?:env.MAVEN_EXTRA_PARAMS?:''
	
	if(!rutasPomXml) { 
		error "ERROR EN EL SCRIPT: No se recibió el parámetro 'rutasPomXml' en el script 'despliega.groovy'"
		return 
	}

	milestone label: 'Version desplegándose', ordinal: 30

	echo "Despliegue en Weblogic ${environment} de ${rutasPomXml}"

	if(commonLibraries) { 
		echo "Desplegando "+rutasPomXml.size() + " librerías comunes..."
	/*} else if(isLibrary) {
		echo "Desplegando "+rutasPomXml.size() + " librerías..."*/
	} else { 
		echo "Desplegando "+rutasPomXml.size() + " aplicaciones..."
	}
	
	def errorProducido

	def descargaTodoDeNuevo = mavenParams?.contains('-U')
	def tiempo = !descargaTodoDeNuevo? 20 /*20 minutos si es sólo desplegar*/ : 1440 /* 1 día si tiene que volverse a traer todos los jar de nuevo*/
	
	waitUntil {
		try { 
			errorProducido = null
			echo "Reservando el uso de Weblogic ${environment} to despliegue. Todos los accesos a Weblogic ${environment} del resto de tareas quedarán a la espera."
			lock(resource: null, label: "weblogic_${environment}") {
			
				timeout(time: tiempo, unit:'MINUTES') {
					for(i = 0; i < rutasPomXml.size(); i++) { 
						def pomXmlPath = rutasPomXml[i]
						if(commonLibraries) { 
							echo "Desplegando library común ${pomXmlPath}"
							sh "mvn com.oracle.weblogic:weblogic-maven-plugin:deploy -f '${pomXmlPath}' -P${environment} ${mavenParams}"
						} else {
							echo "Desplegando application ${pomXmlPath}"
							sh "mvn com.oracle.weblogic:weblogic-maven-plugin:deploy -f '${pomXmlPath}' -P${environment} ${mavenParams}"
						}
					}
				}
			}
			echo "Released el uso de Weblogic ${environment} to despliegue. Listo to ser accedido por el resto de tareas."
			return true
		} catch(err) {
			errorProducido = err
			def fueTimeout = wasTimeoutReached error: err
			def log
			def titulo
			
			def timeoutReintentar = 15
			
			if(!fueTimeout) {
				log = """Se produjo un error al desplegar. Pedimos al usuario si quiere reintentar (esperamos por ${timeoutReintentar} minutos). 
					Error producido: ${err}
					"""  
				titulo = "Fallo al desplegar"
			} else {
				log = """Se produjo un timeout tras tratar de desplegar por más de ${tiempo} minutos. Pedimos al usuario si quiere reintentar (esperamos por ${timeoutReintentar} minutos). 
					Error producido: ${err}
				""" 
				titulo = "Timeout tratando de desplegar"
			}
			
			echo log
			
			timeout(time: timeoutReintentar, unit:'MINUTES') {
				def respuesta = input message: titulo, ok: 'Continue',
						  parameters: [
							choice(
										name: "¿Reintentar despliegue en ${environment}?", 
										choices: 'No\nYes', 
										defaultValue: 'No',
										description: "Choose Yes to reintentar el despliegue en el Weblogic de ${environment}"
							),
							string(
								name: "Parámetros maven adicionales", 
								description: 'Parámetros que se añadirán a la llamada maven util por ejemplo to especificar el - U que equivale al Force Update of Snapshots/Releases de Eclipse',
								defaultValue: mavenParams
							)						  
							
						]

				echo "Respuesta del usuario: ${respuesta}"
				def reintentar = respuesta["¿Reintentar despliegue en ${environment}?"]
				mavenParams = respuesta["Parámetros maven adicionales"]
	        	return reintentar != 'Sí'
        	}
		}
	}
	
	if(errorProducido) {
		throw errorProducido 
	}
}
