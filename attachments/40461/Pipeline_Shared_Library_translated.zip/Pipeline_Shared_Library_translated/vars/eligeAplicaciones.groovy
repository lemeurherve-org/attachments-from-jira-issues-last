#!/usr/bin/env groovy
/**
 * Pide al usuario que elija de entre una lista de aplicaciones 
 */
def call(args) {
	def motivo = args?.motivo?:'Selecciona'
	def cadenaAplicaciones= args?.cadenaAplicaciones?:''

	def listaAplicaciones = cadenaAplicaciones.split(',') 
	
	def seleccionadas
	
	echo """Eligiendo aplicaciones...\n
			Args: ${args}
		"""

	try { 
		timeout(time:1, unit:'HOURS') {
			
			def parametrosAplicaciones = []
			
			listaAplicaciones.each {
				def nombreFicheroApp = it
				def nombreApp = nombreFicheroApp.replace('.ear','').replace('.war','')

				parametrosAplicaciones << booleanParam(name: nombreFicheroApp, defaultValue: false, description: "${motivo} ${nombreApp}")				 
			}
			
			def respuesta =  input message: 'User action requested', ok: 'Continue', parameters: parametrosAplicaciones

			seleccionadas = respuesta.findAll { it.value == true }.collect { it.key }
			echo "El usuario a elegido parar/arrancar ${seleccionadas}"
		}
	} catch(err) { // timeout reached or input false
		wasTimeoutOrCancelledByUser error: err
	}
		
	env.APLICACIONES_SELECCIONADAS = seleccionadas.join(',')
		
	return seleccionadas
}