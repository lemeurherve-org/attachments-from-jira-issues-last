#!/usr/bin/env groovy
/**
 * Ejecuta una serie de procesos que se deben ejectuar siempre tras la finalización de una pipeline.
 * Estos procesos son:
	- Borrado del directorio de trabajo 
	- Almacenamiento de los Javadocs producidos
	- Almacenamiento de los informes JUnit producidos 
	- Almacenamiento del EAR generado, en el caso de aplicaciones
	- Almacenamiento del JAR generado, en el caso de librerías
	- Almacenamiento del WAR generado, en el caso de librerías comunes	
 */
def call(args) {
	echo """Finalizando pipeline...
				Args: ${args}
		"""
	def guardaEAR = args?.guardaEAR?:false
	def guardaWAR = args?.guardaWAR?:false
	def guardaJAR = args?.guardaJAR?:false
	def recopilaJUnit = args?.recopilaResultadosJUnit?:false
	
	timeout(time:1, unit:'MINUTES') {
		if(guardaEAR) { 
			echo "Guardando EAR generado"
			archiveArtifacts artifacts: '**/target/*.ear', fingerprint: true, allowEmptyArchive: true 						
		}
		
		if(guardaWAR) { 
			echo "Guardando WARs generados"
			archiveArtifacts artifacts: '**/target/*.war', fingerprint: true, allowEmptyArchive: true
		}
		
		if(guardaJAR) { 
				echo "Guardando JAR generado"
				archiveArtifacts artifacts: '**/target/*.jar', fingerprint: true, allowEmptyArchive: true
					
                echo "Guardando Javadocs generados"
                archiveArtifacts artifacts: '**/target/site/apidocs/**/*.html', onlyIfSuccessful: true, allowEmptyArchive: true
		}
		
		if(guardaJAR || recopilaJUnit) {                                 
			recopilaResultadosJUnit()
		}

		//Limpia todo lo que no se haya archivado en el workspace
		echo "Limpiando workspace..."
		deleteDir()	
	} 
	
	echo "Pipeline finalizado"
}