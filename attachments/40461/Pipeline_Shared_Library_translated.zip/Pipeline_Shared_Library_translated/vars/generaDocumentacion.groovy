#!groovy
/**
 * Crea documentación Javadoc de una library JAR
 */
def call(args) {
	def pomXmlPath = args.pomXmlPath

	echo "Creación documentación javadoc"
	sh "mvn javadoc:javadoc -f '${pomXmlPath}'"
}