#!/usr/bin/env groovy
/**
* Genera los ficheros de configuración en función del environment and los almacena dentro de un EAR previamente generado con JDeveloper
*/
def call(args) {
	def pomXmlPath=args.pomXmlPath
	def environment = args.environment ?:'undefined'

	milestone label: "Generating ficheros de configuración dentro del EAR generado por JDeveloper", ordinal: 25

	sh "mvn es.eprinsa.maven:eprinsa-maven-plugin:genera-ficheros-configuracion -f '${pomXmlPath}' -P${environment}"	
}
