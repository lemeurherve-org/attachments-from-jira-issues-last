#!/usr/bin/env groovy
/**
 * Compila el código and genera el artefacto correspondiente (EAR, JAR o WAR en función del caso)
 */
def call(args) {
	def isLibrary=args.isLibrary?:false
	def commonLibraries=args.commonLibraries?:false
	def pomXmlPath=args.pomXmlPath
	def errorCodesDictionaryPath = args.errorCodesDictionaryPath ?: ''
	def environment = args.environment ?:'undefined'
	def mavenParams = args.mavenParams?:env.MAVEN_EXTRA_PARAMS?:''
	
	echo env.BRANCH_NAME ? "Genartion from branch ${env.BRANCH_NAME}. Args: ${args}" : "Generating... Args: ${args}"
	
	if(isLibrary && !commonLibraries) {
		try {
			sh "mvn clean -f '${pomXmlPath}'"
		} catch (err) {
			echo "Error trying to clean previous build: ${err}"
	    }
		echo "Generating library. Using path '${errorCodesDictionaryPath}' in order to locate error code dictionaries"
		sh "mvn install -f '${pomXmlPath}' -DrutaDictError.tests=${errorCodesDictionaryPath} -DoracleHome=/usr/lib/oracle/12.1/client64 -Dmaven.javadoc.skip=true ${mavenParams}"
	} else {
		try {
			sh "mvn clean -f '${pomXmlPath}'"
		} catch (err) {
			echo "Error trying to clean previous build: ${err}"
			//JLP.-No influye en el resultado. No considero finalmente que haya que marcarlo como inestable
			//currentBuild.result = 'UNSTABLE'
	    }
		if(environment!='undefined') {
			echo "Generating application for environment ${environment}" 
			sh "mvn install -f '${pomXmlPath}' -P${environment} ${mavenParams}"
		} else {
			echo "Generating" 
			sh "mvn clean install -f '${pomXmlPath}' ${mavenParams}"
		}
	}
}