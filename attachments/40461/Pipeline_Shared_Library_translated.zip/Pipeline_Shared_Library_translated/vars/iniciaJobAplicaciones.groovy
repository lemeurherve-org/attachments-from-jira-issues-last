#!/usr/bin/env groovy
def call(args) {

	def cadenaAplicaciones=args.cadenaAplicaciones?:env.APLICACIONES_SELECCIONADAS
	def rama=args.rama?:null
	def accionDesatendida=args.accionDesatendida?:env.ACCION
	def jmeterUser=args.jmeterUser?:env.JMETER_USER
	def jmeterPassword=args.jmeterPassword?:env.JMETER_PASSWORD
	
	def listaAplicacionesSeleccionadas = cadenaAplicaciones.split(',')
				 	
 	def parallelNodes = [:]

 	for (i = 0; i < listaAplicacionesSeleccionadas.size(); i++) {
		def nombreFicheroApp = listaAplicacionesSeleccionadas[i]
		def nombreJob = nombreFicheroApp.replace('.ear','').replace('.war','')
 		
 		def ramaEscapada = rama.replace('/','%2F').replace('#','%23')
 		
        parallelNodes[nombreJob] = {
	        // this node (one per instance) is later executed in parallel
	        node('master') { //JLP.- Aquí también debo usar nodo master
		         wrap([$class: 'MaskPasswordsBuildWrapper',varPasswordPairs: [[password: "${jmeterPassword}", var: 'jmeterPassword']]]) {
		        	echo """Iniciando job ${nombreJob} pipeline/${ramaEscapada} pasándole los parámetros:
		        	accionDesatendida=${accion}
		        	 jmeterUser=${jmeterUser}
		        	 jmeterPassword=${jmeterPassword}
		        	"""
		        }
		 		 def resultado = build job: "${nombreJob} pipeline/${ramaEscapada}", wait: true, 
		 		  parameters: [
			        string(name: 'accionDesatendida', value: accionDesatendida),
			        string(name: 'jmeterUser', value: jmeterUser),
			        string(name: 'jmeterPassword', value: jmeterPassword)
			    	]
			    	
			    echo "Resultado de la ejecución de ${nombreJob} con la acción '${accionDesatendida}': ${resultado}" 
	        }
	    }
    }

    parallel parallelNodes
}