#!/usr/bin/env groovy
def call(args) {
	timeout(time:1, unit:'DAYS') {    
				def jmeter_tests = input id: 'jmeter_tests', message: 'User action requested', ok: 'Continue',
				parameters: [
						string(
							name: 'login',
							description: 'Usuario to testear API Portal Empleado'
						),
						password(
							name: 'password',
							description: 'Contraseña del usuario to testear API Portal Empleado'
						)
					]
				//echo "Introducido por el usuario: ${jmeter_tests} Tipo: " + jmeter_tests.getClass()
				//echo "Login: " + jmeter_tests['login']
				env.JMETER_USER = jmeter_tests['login']
				env.JMETER_PASSWORD = jmeter_tests['password']
	}
}