#!/usr/bin/env groovy
/**
 * Lanza los test JMeter de una application
 */
def call(args) {
     wrap([$class: 'MaskPasswordsBuildWrapper',varPasswordPairs: [[password: "${args.contraseña}", var: 'args.contraseña']]]) {
		echo """Lanzando test jmeters...
				Args: ${args}
			"""
	}
	def pomXmlPath=args.pomXmlPath
	def environment = args.environment ?:'undefined'
	//def jmeterServidor = args.jmeterServidor //Deprecated, no usar
	//def cliente = args.cliente ?:'eprinsa' //Deprecated, no usar
	def usuario = args.usuario?:env.JMETER_USER
	def contraseña = args.contraseña?:env.JMETER_PASSWORD
	
	/*if(!jmeterServidor) {
		def partes = cliente.split('-')
		cliente = partes[0]
		def clon = (partes.length>1 && partes[1]=='clon')
	
		if(environment == 'preproduccion') { 
			jmeterServidor = "${cliente}-test-ofvirtual2.e-admin.es"; //JLP.- Provisional el servidor con ofvirtual
		} else { 
			if(clon) {
				jmeterServidor = "${cliente}-clon-ofvirtual2.e-admin.es"; //JLP.- Provisional el servidor con ofvirtual
			} else { 
				jmeterServidor = "${cliente}-des-ofvirtual2.e-admin.es"; //JLP.- Provisional el servidor con ofvirtual
			}
		} 
	}*/

	milestone label: 'Testeando la application', ordinal: 40

	if(usuario!=null && !usuario.trim().isEmpty() && contraseña!=null && !contraseña.trim().isEmpty()) { 
        /* Enmascara la password to que no salga en la consola */
         wrap([$class: 'MaskPasswordsBuildWrapper',varPasswordPairs: [[password: "${contraseña}", var: 'contraseña']]]) {
			echo """Lanzar tests JMeter en ${environment} utilizando credenciales
					usuario: ${usuario}
					contraseña: ${contraseña}  
					"""
			echo "Lanzar tests funcionales JMeter en ${environment}"
            sh "mvn com.lazerycode.jmeter:jmeter-maven-plugin:jmeter -f '${pomXmlPath}' -P${environment} -Djmeter.user=${usuario} -Djmeter.password=${contraseña} -Djmeter.ficheros_tests='funcional/*.jmx' -Djmeter.resultados_tests='${env.WORKSPACE}/resultados_tests/funcionales'"

			echo "Lanzar tests de rendimiento JMeter en ${environment}"
            sh "mvn com.lazerycode.jmeter:jmeter-maven-plugin:jmeter -f '${pomXmlPath}' -P${environment} -Djmeter.user=${usuario} -Djmeter.password=${contraseña} -Djmeter.ficheros_tests='rendimiento/*.jmx' -Djmeter.resultados_tests='${env.WORKSPACE}/resultados_tests/rendimiento'"
         }
	} else { 
		echo "Lanzar tests funcionales JMeter en ${environment}"
		sh "mvn com.lazerycode.jmeter:jmeter-maven-plugin:jmeter -f '${pomXmlPath}' -P${environment} -Djmeter.ficheros_tests='funcional/*.jmx' -Djmeter.resultados_tests='${env.WORKSPACE}/resultados_tests/funcionales'"

		echo "Lanzar tests de rendimiento JMeter en ${environment}"
		sh "mvn com.lazerycode.jmeter:jmeter-maven-plugin:jmeter -f '${pomXmlPath}' -P${environment} -Djmeter.ficheros_tests='rendimiento/*.jmx' -Djmeter.resultados_tests='${env.WORKSPACE}/resultados_tests/rendimiento'"
	}
}