#!/usr/bin/env groovy
/**
 * Obtiene un array con la lista de aplicaciones desplegadas actualmente en weblogic
 */
def call(args) {
	echo "Listando aplicaciones desplegadas... ${args}"
	
	def pomXmlPath=args.pomXmlPath
	def environment=args.environment?:'undefined'
	def fichero=args.fichero
	def mavenParams = args.mavenParams?:env.MAVEN_EXTRA_PARAMS?:''
	def permitirReintentar = args.permitirReintentar?:false

	def cadenaAplicacionesDesplegadas = ''

	def target
	switch(environment) {
		case "desarrollo":
			target = 'infra_cluster_des_1'
			break;
		case "formacion":
			target = 'formacion'
			break;
		case "preproduccion":
			target = 'preproduccion' 
			break; 
		/*default: //Aquí no queremos que falle
			error "ERROR EN EL SCRIPT: El environment de ejecución no puede ser '${environment}' en el script 'paraAplicaciones.groovy'"
			return*/
	} 

	waitUntil {
		try { 
			echo "Obteniendo lista de aplicaciones desplegadas actualmente en el Weblogic de ${environment}..."
			
			def scriptListaApps = "mvn com.oracle.weblogic:weblogic-maven-plugin:list-apps -f '${pomXmlPath}' -P${environment} ${mavenParams}"
			
			if(target) { 
				scriptListaApps += " -Ddespliegue.cluster=${target}"
			}
		
			cadenaAplicacionesDesplegadas = sh (
				script: scriptListaApps,
				returnStdout: true
			)
			
			echo """Salida obtenida desde Weblogic:
				${cadenaAplicacionesDesplegadas}
				 """
			return true
		} catch (err) { 
			if(!permitirReintentar) { 
				echo "Se produjo un error al tratar de obtener la lista de aplicaciones desplegadas: ${err}."
				if(fichero) { 
					echo "Intentamos traernos la lista de aplicaciones extraida desde el fichero '${fichero}'\nSalida:\n${cadenaAplicacionesDesplegadas}"
					cadenaAplicacionesDesplegadas = listaAplicacionesDesplegables fichero: fichero
				} else {
					echo "No se proporcionó el fichero con la lista de aplicaciones. No se puede sacar la lista de aplicaciones." 
					cadenaAplicacionesDesplegadas = ''			
				}
				
				return true
			} else { 
				timeout(time:1, unit:'MINUTES') {
					def respuesta = input message: 'Fallo al obtener la lista de aplicaciones desplegadas', ok: 'Continue',
							  parameters: [
								choice(
											name: "¿Reintentar obtener listado de aplicaciones desplegadas en ${environment}?", 
											choices: 'No\nYes', 
											defaultValue: 'No',
											description: "Choose Yes to reintentar obtener el listado de aplicaciones desplegadas en el Weblogic de ${environment}"
								),
								string(
									name: "Parámetros maven adicionales", 
									description: 'Parámetros que se añadirán a la llamada maven util por ejemplo to especificar el - U que equivale al Force Update of Snapshots/Releases de Eclipse',
									defaultValue: mavenParams
								)						  
								
							]
	
					def reintentar = respuesta["¿Reintentar obtener listado de aplicaciones desplegadas en ${environment}?"]
					mavenParams = respuesta["Parámetros maven adicionales"]
					echo """Respuesta del usuario: ${respuesta}.\n
							¿Reintentar? ${reintentar}
							Parámetros maven: ${mavenParams}
					"""
		        	return reintentar != 'Sí'
	        	}
			}
		}
	}
	
	def listaAplicacionesDesplegadas = cadenaAplicacionesDesplegadas.split("\n")
	
	def listaAplicacionesDesplegadasEprinsa = listaAplicacionesDesplegadas.findAll { it.trim().startsWith('API') || it.trim().startsWith('Web') || it.trim().startsWith('afirma')}.collect { it.trim() }

	echo """Filtrando de la lista de aplicaciones sólo las de Eprinsa...
		Lista original (${listaAplicacionesDesplegadas.size()}): ${listaAplicacionesDesplegadas}
		Lista filtrada (${listaAplicacionesDesplegadasEprinsa.size()}): ${listaAplicacionesDesplegadasEprinsa}
		"""
		
	if(listaAplicacionesDesplegadasEprinsa.empty && fichero) {
		echo "La lista de aplicaciones obtenidas está vacía. Cargamos la lista de aplicaciones desplegables desde fichero..." 
		cadenaAplicacionesDesplegadas = listaAplicacionesDesplegables fichero: fichero
		listaAplicacionesDesplegadasEprinsa = cadenaAplicacionesDesplegadas.split("\n")
		echo "Lista obtenida: ${listaAplicacionesDesplegadasEprinsa}"
	}
	
	env.LISTA_APLICACIONES_DESPLEGADAS = listaAplicacionesDesplegadasEprinsa.join(',').replaceAll('\n','').replaceAll('\r','')	
	
	echo "Cadena de aplicaciones desplegadas: ${env.LISTA_APLICACIONES_DESPLEGADAS}"
	return env.LISTA_APLICACIONES_DESPLEGADAS	
}