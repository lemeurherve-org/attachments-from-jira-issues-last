#!/usr/bin/env groovy
/**
 * Obtiene un array con los módulos de un pom.xml
 */
def call(args) {
	def pomXmlPath=args.pomXmlPath
	echo "Eligiendo librerías comunes a generar en el environment ${environment} con path del pom.xml ${pomXmlPath}"
	
	def pom = readMavenPom file: pomXmlPath
	
	def modulos = pom.getModules()
	def cadenaModulos = modulos.join(',')
	
	env.LISTA_MODULOS = cadenaModulos
	
	return modulos
}