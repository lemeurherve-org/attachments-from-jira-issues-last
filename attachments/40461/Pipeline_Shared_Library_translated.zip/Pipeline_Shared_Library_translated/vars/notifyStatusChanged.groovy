def call(args) {
	echo """Notificando cambio de estado...\n
			Args: ${args}
		"""
	def to = args?.to?:'jlp01@eprinsa.es'
 
 	if(currentBuild.result!='ABORTED' && currentBuild.result!='NOT_BUILT') {
 		echo "Enviando email a ${to} con el estado ${currentBuild.result} del job ${env.JOB_NAME}"   
		timeout(time:1, unit:'MINUTES') {
			step([$class: 'Mailer',
				notifyEveryUnstableBuild: true,
				recipients: to,
				sendToIndividuals: true])
		}
	} else {
		echo "Ignoramos el estado ${currentBuild.result} que no se notifica por email." 
	}
}