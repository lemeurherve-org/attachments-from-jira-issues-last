#!groovy

/**
 * Pregunta al usuario si quiere configurar algunas parámetros adicionales antes de generar, and si es aYes se los presenta
 */
def call(args) {
	echo "Asking user if he wants to setup some extra parameters. Passed args: ${args}"
	def isLibrary=args?.isLibrary?:false
	def commonLibraries=args?.commonLibraries?:false
	def esAPIRestful=args?.esAPIRestful?:false
	def esAplicacionADF=args?.esAplicacionADF?:false
	def esAplicacionJSF=args?.esAplicacionJSF?:false
	def esDesplegable = args?.esDesplegable?:(esAPIRestful||esAplicacionADF||esAplicacionJSF)
	
	def aprobado
	try { 
		timeout(time:10, unit:'SECONDS') {
			aprobado = input message: 'User action requested', ok: 'Continue',
			  parameters: [
				  choice(
					name: "Setup extra configuration",
					choices: 'No\nYes', 
					description: 'Choose Yes for setting up extra parameters, like -U maven parameters or some more',
					defaultValue: 'No'
					)						  
			  ]
		}
	} catch(err) { 
		def userCancelled2 = wasCancelledByUser error: err
		if (userCancelled2) {
	        // do something else
	        currentBuild.result = 'FAILURE'
	        error "Cancelled by user"
	    } else {
	    	//Timeout. Seguimos 
	    	echo """Timeout reached with no maven extra parameter specified.
	    	Timeout error: ${err}
	    	"""
	    }
	}
	
	if(aprobado == 'Yes') {
		def userCancelled = false
		def didTimeout = false
	
		try { 
			timeout(time:1, unit:'HOURS') {
				def parametros = []
				
				if(commonLibraries) {
					parametros.add(choice(
							name: "Deployment extra configuration", 
							choices: 'No\nYes', 
							description: "Choose Yes in order to show options about which libraries to depoloy or which applications to start/stop previously", 
							defaultValue: "No", 
							ok: "Continue"
						)) 
					parametros.add(choice(
								name: "New versions information", 
								choices: 'No\nYes', 
								description: "Choose Yes in order to show if there are new dependency versions available", 
								defaultValue: "No", 
								ok: "Continue"
							))
						
				} else if(esDesplegable && !esAplicacionADF /*JLP.- En las aplicaciones ADF siempre se va a preguntar */) { 
					parametros.add(choice(
							name: "Deployment extra configuration", 
							choices: 'No\nYes', 
							description: "Choose Yes in order to choose additional config in deployment like skip deployment and tests", 
							defaultValue: "No", 
							ok: "Continue"
						)) 
				}
				
				parametros.add( string(
						name: "Maven extra parameters", 
						description: 'Maven extra parameters added in command line',
						defaultValue: ''
						))
						
				def respuesta = input message: 'User action requested', ok: 'Continue', parameters: parametros					  				  
				 
				if(parametros.size() > 1) { 
					env.MAVEN_EXTRA_PARAMS = respuesta['Maven extra parameters']
					env.MOSTRAR_INFO_SOBRE_NUEVAS_VERSIONES = respuesta['New versions information']
					env.FUERZA_ELEGIR_OPCIONES_DESPLIEGUE = respuesta['Deployment extra configuration']
				} else { 
					env.MAVEN_EXTRA_PARAMS = respuesta
				}
			}
		} catch(err) { // timeout reached or input false
			didTimeout = wasTimeoutReached error: err
			userCancelled = wasCancelledByUser error: err
		}
	
		if (didTimeout) {
	        // do something on timeout
	        currentBuild.result = 'NOT_BUILT'
	        error "Cancelled by timeout"
	    } else if (userCancelled) {
	        // do something else
	        currentBuild.result = 'FAILURE'
	        error "Cancelled by user"
	    } 
	}
}
