#!groovy
//!!!!!!! JLP.- Obsoleto. Usar ofreceConfigurarParametrosAdicionales
/**
 * Preguna al usuario qué parámetros adicionales quiere añadir en la generación maven
 */
def call(args) {
	def userCancelled = false
	def didTimeout = false

	try { 
		timeout(time:1, unit:'HOURS') {
			env.MAVEN_EXTRA_PARAMS = input message: 'User action requested', ok: 'Continue',
			  parameters: [
				  string(
					name: "Parámetros maven adicionales", 
					description: 'Parámetros que se añadirán a la llamada maven util por ejemplo to especificar el - U que equivale al Force Update of Snapshots/Releases de Eclipse',
					defaultValue: ''
					)						  
			  ]
		}
	} catch(err) { // timeout reached or input false
		didTimeout = wasTimeoutReached error: err
		userCancelled = wasCancelledByUser error: err
	}

	if (didTimeout) {
        // do something on timeout
        currentBuild.result = 'NOT_BUILT'
        error "Cancelado por timeout"
    } else if (userCancelled) {
        // do something else
        currentBuild.result = 'FAILURE'
        error "Cancelled by user"
    } 
}