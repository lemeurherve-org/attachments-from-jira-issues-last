#!/usr/bin/env groovy
/**
 * Copia el EAR generado en Producción
 */
def call(args) {
	def to = args?.to?:'desarrollo.eadmon@eprinsa.es'
	def commonLibraries = args?.commonLibraries?:false
	def fechaLiberacion = args?.fechaLiberacion?:env.FECHA_PROXIMA_LIBERACION
	def esWAR = args?.esWAR?:false
	def patronFicheros = args?.patronFicheros?:null
	def pomXmlPath = args?.pomXmlPath?:null

	def rutaFichero = args?.rutaFichero?:null
	def nombreAplicacion = args?.nombreAplicacion?:null
	def environment = args?.environment?:null
	def nombreFichero = args?.nombreFichero?:null
	
	if(!commonLibraries) {
		/* PARA APLICACIONES*/
		 
		def ficheros
	
		if(rutaFichero) {
			
			ficheros = [ new File(rutaFichero) ]
			 
		} else { 		
			if(nombreAplicacion && environment && nombreFichero) {
				def carpeta
				switch(environment) {
					case "desarrollo":
						carpeta = 'desarrollo'
						break;
					case "formacion":
						carpeta = 'formacion'
						break;
					case "preproduccion":
						carpeta = 'pruebas' 
						break; 
					case "produccion":
						carpeta = 'produccion'
						break;
					default:
						error "ERROR EN EL SCRIPT: El environment de ejecución no puede ser '${environment}' en el script 'pasoAProduccion.groovy'"
						return
				} 		
			
				rutaFichero = "/otroslogs/aplicaciones/weblogic/${nombreAplicacion}/${carpeta}/app/${nombreFichero}"
				
				ficheros = [ new File(rutaFichero) ] 
			} else { 
				if(patronFicheros) { 
					echo "Copia de ${patronFicheros} en Producción"
				} else { 
					def extension
					if(!esWAR) { 
						/*Copia el/los EAR en Producción*/
						echo 'Copia del/los EAR en Producción'
					
						extension = '.ear'
					} else {
						/*Copia el WAR en Producción*/
						echo 'Copia del/los WAR en Producción'
				
						extension = '.war'
					}
					
					patronFicheros = "**/target/*${extension}"
				}
		
				ficheros = findFiles glob: patronFicheros
			}
		}
				
		ficheros.each { 
			def nombre = it.name.replace('.ear','').replace('.war','')
			def destino = "/otroslogs/aplicaciones/weblogic/${nombre}/produccion/app"
			
			echo "Copiando ${it.name} a ${destino} to su posterior paso a producción" + (fechaLiberacion? " el ${fechaLiberacion}":'')
			/*JLP.- Comprueba primero si existe el directorio and si no existe lo crea. Después, copia el fichero*/
			sh "test -d \"${destino}\" || mkdir -p \"${destino}\" && cp -f ${it} \"${destino}\""
			
		}
	} else {
		/* PARA LIBRERÍAS COMUNES */ 
		def modulos = listaModulos pomXmlPath: pomXmlPath
		
		// JLP.- Por cada library vamos a leer la propiedad identificador.libreria to ver en qué carpeta se debe copiar
		modulos.each { modulo->
			def pom = readMavenPom file: "src/${modulo}/pom.xml"
			def properties = pom.getProperties()
			def identificadorLibreria = properties['identificador.libreria']
			//def version = pom.getVersion()

			def ficheros = findFiles glob: "src/${modulo}/target/*.war"
			ficheros.each { 
				def nombreCompleto = it.name.replace('.ear','').replace('.war','')
				int separador = nombreCompleto.lastIndexOf('-') 
				def nombre = nombreCompleto.substring(0, separador)
				def version = nombreCompleto.substring(separador+1,nombreCompleto.length())
				def destino = "/otroslogs/aplicaciones/weblogic/${identificadorLibreria}/produccion/lib/${version}"
				
				echo "Copiando ${it.name} a ${destino} to su posterior paso a producción" + (fechaLiberacion? " el ${fechaLiberacion}":'')
				sh "test -d \"${destino}\" || mkdir -p \"${destino}\" && cp -f ${it} \"${destino}/${nombre}.war\""
			}
		}
	}
	
	//TODO: Mandar email 	
}