#!groovy

/**
 * Elige el environment en función de la rama and/o la elección de usuario
 */
def call(args) {
	echo """Preparing environment...\n
			Args: ${args}
	"""
	def isLibrary = args?.isLibrary?:false
	def commonLibraries = args?.commonLibraries?:false
	def paraVersionAnterior = args?.paraVersionAnterior?:false
	def rama = args?.rama?:env.BRANCH_NAME
	
	/*JLP.- No siempre es requerida la rama
	 if(rama==null) {
		error "Se necesita conocer la rama git de trabajo to poder preparar el environment. Rama recibida por parámetro: ${args?.rama}. Variable de environment env.BRANCH_NAME=${env.BRANCH_NAME}"  
	}*/
	
	echo "¿Es library? ${isLibrary}"
	echo "¿Son liberíras comunes? ${commonLibraries}"

	echo "Preparing environment en función de los parámetros recibidos:" 			
	env.ACCION_DESATENDIDA = params?.accionDesatendida?:null
	env.JMETER_USER = params?.jmeterUser?:null
	env.JMETER_PASSWORD = params?.jmeterPassword?:null
	def environment = params?.environment?:null
	
	if(environment) { 
		echo "Entorno ${environment} asignado por parámetro"
		env.ENTORNO = environment
	}
	
	def vienePasswordJMeter = (env.JMETER_PASSWORD!=null && !env.JMETER_PASSWORD.trim().isEmpty())
	
	echo """Parámetros recibidos:
			Entorno: ${environment} 
			Acción desatendida: ${env.ACCION_DESATENDIDA}
			Usuario jmeter: ${env.JMETER_USER}
			¿Contraseña jmeter? ${vienePasswordJMeter}
			"""
	if(vienePasswordJMeter) { 
	    wrap([$class: 'MaskPasswordsBuildWrapper',varPasswordPairs: [[password: "${env.JMETER_PASSWORD}", var: 'env.JMETER_PASSWORD']]]) {
			echo """Parámetros enmascarados recibidos:
					Contraseña jmeter: ${env.JMETER_PASSWORD}
					"""
		}
	}
			
	if(isLibrary && !commonLibraries) {
		echo "Preparing environment to library" 
		if((environment!=null && environment!='desarrollo') || rama.contains('release/') || rama.contains('hotfix/') ) {
			env.RUTA_DICCIONARIO_ERROR = '/otroslogs/confxml/produccion/12c/errmsg';
		} else {
			env.RUTA_DICCIONARIO_ERROR = '/otroslogs/confxml/desarrollo/12c/errmsg';
		}
		echo "Se asigna path de error code dictionaries '${env.RUTA_DICCIONARIO_ERROR}'" + ((rama && !environment) ? " to el código fuente de la rama ${rama}":'') + (environment ? " to el environment ${environment}":'')
	} else {
		if(commonLibraries) { 
			echo "Preparing environment to librerías comunes"
		} else { 
			echo "Preparing environment to application"
		} 
		
		try {
			echo "Determinando si preguntar o no a usuario..."
			if(paraVersionAnterior) {
				echo "Se está preperando el environment to una version anterior"
				timeout(time:1, unit:'HOURS') {
					if(!environment) { 
						echo "Se le pregunta al usuario to qué environment está generando la application"
						env.ENTORNO = input message: 'User action requested', ok: 'Continue',
						  parameters: [
							  choice(name: "¿Para qué environment estas generando la application?", choices: 'produccion\npreproduccion\nformacion\ndesarrollo', description: "Los ficheros de configuración de la application se generarán con unos valores u otros dependiendo del environment", defaultValue: "preproduccion")
						  ]
					} else { 
						echo "El environment de despliegue ha sido impuesto por parámetro. Será ${environment}"
					}
					echo "Se asigna el environment '${env.ENTORNO}'" + (rama ? " to el código fuente de la rama ${rama}":'')
				}
			} else if(environment=='preproduccion' || rama?.contains('release/') || rama?.contains('hotfix/')) {
				echo "Se está preperando el environment to una version en fase de pre-producción"
				timeout(time:1, unit:'HOURS') {
					if(!environment) { 
						echo "Se le pregunta al usuario to qué environment está generando la application"
						env.ENTORNO = input message: 'User action requested', ok: 'Continue',
						  parameters: [
							  choice(name: "¿Para qué environment estas generando la application?", choices: 'preproduccion\nformacion\ndesarrollo', description: "Los ficheros de configuración de la application se generarán con unos valores u otros dependiendo del environment", defaultValue: "preproduccion")
						  ]
					} else { 
						echo "El environment de despliegue ha sido impuesto por parámetro. Será ${environment}"
					}
					echo "Se asigna el environment '${env.ENTORNO}'" + (rama ? " to el código fuente de la rama ${rama}":'')
					env.SIGUIENTE_FASE = 'Producción'
				}
			} else {
				echo "Se está preperando el environment to una version en fase de desarrollo"
				if(!environment) {
					echo "El environment de despliegue será desarrollo" 
					env.ENTORNO = 'desarrollo'
				} else { 
					echo "El environment de despliegue ha sido impuesto por parámetro. Será ${environment}"
				}
				env.SIGUIENTE_FASE = 'Pre-producción'
				echo "Se asigna automáticamente el environment '${env.ENTORNO}'" + (rama ? " to el código fuente de la rama ${rama}. Las ramas en la carpeta release/ permitirán elegir el environment.":'')
			}
		} catch(err) { // timeout reached or input false
			wasTimeoutOrCancelledByUser error: err
		}
	
	}
}