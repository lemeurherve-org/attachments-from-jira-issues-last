#!/usr/bin/env groovy
def call(args) { 
	def environment = args?.environment ?:'undefined'
	def reintentar = args?.reintentar?:false
	def porcentajeUmbralErrorTestsRendimiento = args?.porcentajeUmbralErrorTestsRendimiento?:50 

	echo "Guardando logs JMeter..."
	archiveArtifacts artifacts: '**/target/jmeter/**/*.log', fingerprint: true, allowEmptyArchive: true

	echo "Guardando informes JMeter..."
	archiveArtifacts artifacts: '**/*.jtl', fingerprint: true, allowEmptyArchive: true
	
	echo "Generating informe con el resultado de los tests funcionales en ${environment}"
	/*performanceReport compareBuildPrevious: false, configType: 'ART', errorFailedThreshold: 0, errorUnstableResponseTimeThreshold: '', errorUnstableThreshold: 0, failBuildIfNoResultFile: false, modeOfThreshold: false, modePerformancePerTestCase: true, modeThroughput: true, nthBuildNumber: 0, relativeFailedThresholdNegative: 0.0, relativeFailedThresholdPositive: 0.0, relativeUnstableThresholdNegative: 0.0, relativeUnstableThresholdPositive: 0.0, sourceDataFiles: '** /*.jtl'*/
	perfReport errorFailedThreshold: 0, errorUnstableThreshold: 0, modeThroughput: true, sourceDataFiles: "${env.WORKSPACE}/resultados_tests/funcionales/*.jtl", failBuildIfNoResultFile: false

	def inestableAntes = (currentBuild.result == 'UNSTABLE')
	def falloAntes = (currentBuild.result == 'FAILURE') 

	echo "Generating informe con el resultado de los tests de rendimiento en ${environment}"
	perfReport errorFailedThreshold: porcentajeUmbralErrorTestsRendimiento, //JLP.- Porcentaje de errores que hace que se considere que los test de rendimiento fallan. En caso de no superar este umbral, sólo se considera inestable  
			errorUnstableThreshold: 0, modeThroughput: true, sourceDataFiles: "${env.WORKSPACE}/resultados_tests/rendimiento/*.jtl", failBuildIfNoResultFile: false

	def inestableDespues = (currentBuild.result == 'UNSTABLE')
	def falloDespues = (currentBuild.result == 'FAILURE') 
	
	if(!inestableAntes && inestableDespues) {
		echo "Un porcentaje menor del ${porcentajeUmbralErrorTestsRendimiento}% de los tests de rendimiento no se han superado."
		echo "Se pasan los tests de rendimiento pero se marca el proyecto como INESTABLE. Revise por qué se está produciendo this situación."
	}

	if(!falloAntes && falloDespues) {
		echo "Un porcentaje mayor del ${porcentajeUmbralErrorTestsRendimiento}% de los tests de rendimiento no se han superado."
		echo "Se considera que no se pasan los tests. Puede modificar este umbral como parámetro en la pipeline."
	}

	
	if(currentBuild.result == 'FAILURE' && reintentar) {
		timeout(time:5, unit:'MINUTES') {
			def respuesta = input message: "Fallo en los tests", ok: 'Continue', submitterParameter: 'who', 
					  parameters: [
						choice(
									name: "¿Continuar el proceso aunque los tests hayan fallado?", 
									choices: 'No\nYes', 
									defaultValue: 'No',
									description: "Choose Yes to continuar o No to terminar"
						),
						string(name: "Version comments", description: "En caso de release, este comentario será incluido en el email enviado al equipo")						
					]
			def continuar = respuesta['¿Continuar el proceso aunque los tests hayan fallado?']
			def who = respuesta['who']
			def motivo = respuesta['Version comments']		
					
        	if(continuar != 'Sí') { 
				error "Los test JMeter realizados en ${environment} han fallado. Compruebe el informe to conocer el detalle de los fallos." 
        	} else {
        		if(environment=='preproduccion') {
        			//Mandamos mail indicando que alguien aprobó continuar el proceso aunque fallasen los tests
        			env.AVISO_TESTS_FALLARON = "${who} ha decidido continuar el proceso de liberación aunque los test en preproducción fallaron."
        			
        			if(motivo?.trim()) {
        				env.AVISO_TESTS_FALLARON +="\n\nMotivo proporcionado por ${who}:\n\n<i>${motivo}</i>" 
        			}	
        		} 
        	}
    	}
	}			
}