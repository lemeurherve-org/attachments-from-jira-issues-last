#!/usr/bin/env groovy
def call(args) { 
	echo "Recopilando informe con el resultado de los tests JUNIT"
	junit allowEmptyResults: true, testResults: 'target/surefire-reports/*.xml'
}