#!/usr/bin/env groovy
/**
 * Rearranca una lista de aplicaciones en Weblogic. Las aplicaciones deben estar desplegadas and paradas.
 */
def call(args) {
	echo "Redesplega aplicaciones... ${args}"

	def pomXmlPath=args.pomXmlPath
	def cadenaAplicacionesSeleccionadas=args.cadenaAplicacionesSeleccionadas
	def environment = args.environment ?:env.ENTORNO?:'undefined'

	if(!cadenaAplicacionesSeleccionadas) {
		error "ERROR EN EL SCRIPT: No se recibió el parámetro 'cadenaAplicacionesSeleccionadas' en el script 'arrancaAplicaciones.groovy'"
		return 
	}
	
	def listaAplicacionesSeleccionadas = cadenaAplicacionesSeleccionadas.split(',')
	
	echo "Redesplegando " + listaAplicacionesSeleccionadas.size() + " aplicaciones en ${environment}..." 
	
	def target
	def rutaDesplegableBase
	switch(environment) {
		case "desarrollo":
			target = 'infra_cluster_des_1'		
			rutaDesplegableBase='/u01/app/oracle/config_des/domains/jweb_des/servers/AdminServer/upload'
			break;
		case "formacion":
			target = 'formacion'
			rutaDesplegableBase='/u01/app/oracle/config/domains/jweb_for/servers/AdminServer/upload'
			break;
		case "preproduccion":
			target = 'preproduccion' 
			rutaDesplegableBase='/u01/app/oracle/config/domains/jweb/servers/AdminServer/upload'
			break; 
		default:
			error "ERROR EN EL SCRIPT: El environment de ejecución no puede ser '${environment}' en el script 'arrancaAplicaciones.groovy'"
			return
	} 
	
	echo "Reservando el uso de Weblogic ${environment} to rearrancar aplicaciones. Todos los accesos a Weblogic ${environment} del resto de tareas quedarán a la espera."
	lock(resource: null, label: "weblogic_${environment}") {
		for (i = 0; i < listaAplicacionesSeleccionadas.size(); i++) {
			def nombreFicheroApp = listaAplicacionesSeleccionadas[i]
			def nombreApp = nombreFicheroApp.replace('.ear','').replace('.war','')
			def rutaDesplegable= "${rutaDesplegableBase}/${nombreApp}/app/${nombreFicheroApp}"
			def rutaPlan =  "${rutaDesplegableBase}/${nombreApp}/plan/Plan1221.xml" //JLP: Si se normaliza a Plan.xml como antes hay que cambiar esto
			
			echo "Redesplegando ${nombreApp} en ${environment}"
			echo """Datos del redespliegue:
				Nombre fichero app: ${nombreFicheroApp} 
				Ruta desplegable: ${rutaDesplegable} 
				"""
						
			sh "mvn com.oracle.weblogic:weblogic-maven-plugin:redeploy -f '${pomXmlPath}' -P${environment} -Ddespliegue.nombre=${nombreApp} -Ddespliegue.cluster=${target} -Ddespliegue.upload=false -Ddespliegue.ruta.desplegable=${rutaDesplegable} -Ddespliegue.ruta.plan=${rutaPlan} -N -DfailOnError=false"
		}
	}
	echo "Released el uso de Weblogic ${environment} to redesplegar aplicaciones. Listo to ser accedido por el resto de tareas."
}