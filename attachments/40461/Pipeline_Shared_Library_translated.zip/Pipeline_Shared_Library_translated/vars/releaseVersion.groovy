#!/usr/bin/env groovy
/**
 * Libera una nueva version realizando un tag and subiendo a Nexus dicha version liberada. Además elimina la rama release candidate
 */
def call(args) {
	def isLibrary=args.isLibrary?:false
	def commonLibraries = args.commonLibraries?:false
	def pomXmlPath=args.pomXmlPath
	def environment = 'produccion' //JLP.- Cuando se libera el environment debería de ser siempre 'produccion' args.environment ?:'undefined'
	def errorCodesDictionaryPath = args.errorCodesDictionaryPath ?: ''
	def scmUrl = args.scmUrl?:scm.getUserRemoteConfigs()[0].getUrl()
	def who = args.who?:env.WHO_IS_RELEASING
	def uploadToNexus = args.uploadToNexus?:false 
	def mavenParams = args.mavenParams?:env.MAVEN_EXTRA_PARAMS?:''

		echo """Releasing version. 
		Args: ${args}
		"""
			
	milestone label: 'Version liberándose', ordinal: 60

	if(isLibrary&&!commonLibraries) {
			/*
			 Si no se han hecho commits manuales por parte de algún desarrollador desde el último tag, no se permite release.
			 */
		def	lastReleasedVersion = args.version?:obtenUltimaVersionLiberada()
			
		/* Si es un proyecto nuevo and aun no hay tags, dejamos release*/
		if(lastReleasedVersion) {  
			def userCommitsCount = cuentaCommitsManuales desdeVersion: lastReleasedVersion
			
			if(userCommitsCount==0) {
				error "No se ha subido ningún cambio desde la última liberación. No se permite release si no hay al menos algún commit realizado por un desarrollador desde la última version." 
			}
		} else { 
			echo "No se pudo determinar si hubo cambios desde la última liberación. Al no poder determinarse, seguimos liberando."
		}

		//Si hay nuevas versiones de librerías Eprinsa o parent.pom, no permitimos release
		def newVersions = usaUltimasVersionesLibreriasEprinsa pomXmlPath: pomXmlPath, snapshots: false

		try {
			//Preparamos la version exacta a release (sin SNAPSHOT)
			echo "Preparing exact version to release (sin SNAPSHOT)"
			sh "mvn release:clean release:prepare -f '${pomXmlPath}' -DrutaDictError.tests=${errorCodesDictionaryPath} -DoracleHome=/usr/lib/oracle/12.1/client64  ${mavenParams} -Darguments='-DrutaDictError.tests=${errorCodesDictionaryPath} -DoracleHome=/usr/lib/oracle/12.1/client64 ${mavenParams}' --batch-mode"
		} catch(err) { 
			echo "Error occurred trying to release: ${err}"
			error "${newVersions} \nNo se puede release due to there are new versions. Actualiza la version correspondiente, comprueba que todo sigue funcionando correctamente, sube los cambios and vuelve a release."
		}
		
		//Liberamos
		echo "Releasing..."
		sh "mvn release:perform -f ${env.POM_XML_PATH} -DrutaDictError.tests=${errorCodesDictionaryPath} -DoracleHome=/usr/lib/oracle/12.1/client64  ${mavenParams} -Darguments='-DrutaDictError.tests=${errorCodesDictionaryPath} -DoracleHome=/usr/lib/oracle/12.1/client64 ${mavenParams}' --batch-mode"				
	} else {
	
		def isApplication = !commonLibraries
	
		if(env.BRANCH_NAME.contains('release/')) {
			echo "Checking if there are new versions de dependencias en Eprinsa, en cuya caso, fallará la liberación"
			def newVersions = usaUltimasVersionesLibreriasEprinsa pomXmlPath: pomXmlPath, snapshots: false
			try {
				//Preparamos la version exacta a release (sin SNAPSHOT)
				echo "Preparamos la version exacta a release (sin SNAPSHOT)"
				sh "mvn release:clean release:prepare -f '${pomXmlPath}' -P${environment} ${mavenParams} --batch-mode -Darguments='${mavenParams}" + ((isApplication && !uploadToNexus) ? " -Dmaven.deploy.skip=true":"") + "'"/*JLP.- Los jar/war de las aplicaciones no se suben a nexus*/
			} catch(err) { 
				echo "Error occurred trying to release: ${err}"
				error """No se puede release por los siguientes posibles motivos:
						\n1) Existen nuevas versiones. ¿Nuevas versiones detectadas?: ${newVersions}.
						\n2) Existen dependencias -SNAPSHOT. Consulte el log más arriba to determinar qué dependencias son.
						\n   Solución: Actualice la version correspondiente, compruebe que todo sigue funcionando correctamente, suba los cambios and vuelva a release."""
			}
			
			//sh "mvn jgitflow:release-finish -f '${pomXmlPath}' -DpushReleases=true"

			/*Pasa a la siguiente version en la rama actual*/
			echo "Pasamos a la siguiente version en la rama ${env.BRANCH_NAME}"
			sh "mvn release:perform -f '${pomXmlPath}' -P${environment} ${mavenParams} --batch-mode -Darguments='${mavenParams}" + ((isApplication && !uploadToNexus) ? " -Dmaven.deploy.skip=true":"") + "'" /*JLP.- Los jar/war de las aplicaciones no se suben a nexus*/
			
			echo "Performing merge en develop con lo released."
			echo "Checking out branch develop"
			def credenciales = '77d170ae-31ff-4961-9ec4-ff370a075ee3' //JLP.- Corresponde a las identificador de las credenciales 'jenkins (usuario to git)'. Si cambiase este usuario est id dejará de ser válido 
			git url: scmUrl, credentialsId: credenciales, branch: 'develop'
			
			try { 
				echo "Performing merge con '${env.BRANCH_NAME}'..."
				sh "git merge ${env.BRANCH_NAME}"
	
				/* JLP.- No hace falta el commit. El merge ya lo hace implícitamente						
				echo "Hacemos commit..."
				sh "git commit -a -m 'Actualizando develop con los cambios de la release candidate ${env.BRANCH_NAME}' --author='${who}'"
				*/
	
				echo "Hacemos push..."
				sh "git push origin 'develop'"
			} catch(err) { 
				echo "Error occurred trying to realizar el merge: ${err}"
				echo "No se pudo realizar el merge de manera automática. Solución: Realice el merge de manera manual utilizando SourceTree o Tortoise."
				currentBuild.result = 'UNSTABLE'
			}
			
			echo "Released ok"			
			
		} else {
			//Liberamos
			sh "mvn release:clean release:prepare release:perform -f '${pomXmlPath}' -P${environment} ${mavenParams} --batch-mode"
		}
	}
}