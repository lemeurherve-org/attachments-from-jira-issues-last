#!/usr/bin/env groovy
/**
 * Envía un email informando de la liberación más reciente (último tag creado)
 */
def call(args) {
	echo """Enviando un email informando de la liberación más reciente (último tag creado)...\n
			Args: ${args}
		"""
	
	def who = args?.who
	def to = args?.to
	def isLibrary=args?.isLibrary?:false
	def pomXmlPath=args?.pomXmlPath
	def comentario=args?.comentario?:env.VERSION_COMMENT
	def avisoTestFallaron=args?.avisoTestFallaron?:env.AVISO_TESTS_FALLARON

	//Obtenemos el último tag recien creado. Permito pasarlo por parámetro to pruebas
	def version = args?.version?:obtenUltimaVersionLiberada()

    def nombre = env.JOB_NAME.split('/')[0]
	//def nombre = env.JOB_BASE_NAME //JLP.- No funciona this línea, pone el nombre de la rama en lugar del nombre del proyecto
	
	def mensaje= "<b style='color: darkblue'>${who}</b> ha released la version <u>${version}</u> de <i>${nombre}</i>."
	
	if(comentario?.trim()) {
		mensaje += "<br/><table style='border:  1px solid gray; margin: 10px;'><thead style='background-color: bisque;'><tr><th style='text-align: left; border: 1px solid;'><u>Version comments</u>:</th></tr></thead><tbody><tr><td style=''>${comentario}</td></tr></table>"
	}
	
	if(avisoTestFallaron?.trim()) { 
		mensaje += "<br/><table><thead style='color: red'><tr><th><u>AVISO. LIBERADA VERSIÓN CON TESTS FALLIDOS</u>:</th></tr></thead><tbody><tr><td style=''>${avisoTestFallaron}</td></tr></table>"
	}
	
	if(isLibrary) {
		try { 
			/*
			 Cambiamos al tag de la version liberada
			*/
			def scmUrl = args.scmUrl?:scm.getUserRemoteConfigs()[0].getUrl()
			echo "Usando SCM URL: ${scmUrl}"
			checkout scm: [$class: 'GitSCM', userRemoteConfigs: [[url: scmUrl]], branches: [[name: "refs/tags/${version}"]]], poll: false
		} catch (err) {
			echo "Error trying to de hacer checkout del tag 'refs/tags/${version}'. Error: ${err}" 
		}		

		try { 					
			def curDir = pwd()
			def fichero = "${curDir}/dependencias.txt"
					
			sh "mvn dependency:tree -Dtokens=whitespace -f '${pomXmlPath}' -DoutputFile=${fichero}"
			
			def cadenaDependencias = readFile fichero
					
			def listaDependencias = cadenaDependencias.split("\n")
			
			def listaDependenciasScopeCompile = listaDependencias.findAll { it.contains ':compile' }
	
			mensaje += """
					<br/><br/>Considere actualizar las aplicaciones que utilicen una version anterior de dicha library. 
					<br/><br/><b style='color: red'>IMPORTANTE:</b>Asegúrese de actualizar también las dependencias de la misma con el fin de evitar comportamientos extraños.
					<br/><br/>
					<table style='border: 1px solid black;'>
					<thead style='background-color: cornflowerblue; color: white;'><tr><th style='border-bottom: 1px black solid; padding: 3px;'>Lista de dependencias de ${nombre} ${version}:</th></tr></thead>
					<tbody><tr><td style='border-bottom: 1px black solid; padding: 3px;'>
					""" + listaDependenciasScopeCompile.join("</td></tr><tr><td style='border-bottom: 1px black solid; padding: 3px;'>").replaceAll(":compile","") + 
					"</td></tr></tbody></table>"			
		} catch (err) {
			echo "Error trying to de obtener la lista de dependencias pero continuamos. Error: ${err}" 
		}		

		nombre = "la libreria ${nombre}"		
	}

	def asunto="Una nueva version de ${nombre} ha sido liberada"

	echo "Enviando mail informando de que la version ${version} de ${nombre} ha sido liberada"
	
	//Mandamos mail indicando que una nueva version ha sido liberada
	emailext body: mensaje, mimeType: 'text/html; charset=UTF-8', subject: asunto, to: to
}