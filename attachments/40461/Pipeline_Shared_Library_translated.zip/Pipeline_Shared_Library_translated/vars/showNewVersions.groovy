#!groovy

/**
 * Muestra en pantalla si hay nuevas veriones de dependencias (librerías)
 */
def call(args) {
	def pomXmlPath = args.pomXmlPath
	def mavenParams = args.mavenParams?:env.MAVEN_EXTRA_PARAMS?:''
			
	echo "Checking new dependency versions:"		
	
	try { 
		sh "mvn versions:display-plugin-updates versions:display-dependency-updates -f '${pomXmlPath}' ${mavenParams}"
	} catch(err) {
		echo 	"""Error trying to display new dependency versions. Ignoring error and continuing.
					Error: ${err}
				""" 
	}
}