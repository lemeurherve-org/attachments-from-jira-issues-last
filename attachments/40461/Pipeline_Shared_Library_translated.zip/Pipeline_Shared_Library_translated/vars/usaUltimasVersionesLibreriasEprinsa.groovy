#!groovy
def call(args) {
	def pomXmlPath=args.pomXmlPath
	def snapshots=args.snapshots//?:!env.BRANCH_NAME.contains('release/') <-- De este modo si pones false se lo salta
			
	echo "Comprobando si hay nuevas versiones de dependencias Eprinsa... ${args}"

	if(snapshots) {
		echo "Using últimas versiones SNAPSHOT disponibles de las librerías es.eprinsa.*:*"
	} else {
		echo "Using últimas versiones liberadas  de las librerías es.eprinsa.*:*"
	}

	try { 
		def salida = sh (
				script: "mvn versions:update-parent versions:use-releases versions:use-latest-versions versions:update-properties -f '${pomXmlPath}' -Dincludes=es.eprinsa.*:* -Dexcludes=com.oracle.adf.*:* -DallowSnapshots=${snapshots} -DallowMajorUpdates=false -DexcludeReactor=false",
				returnStdout: true
				)
	
		echo "Comprobación de versiones:\n\n${salida}"
		
		def lineas = salida.split('\n')			
				
		def actualizadas = lineas.findAll{ it.contains('Updating') || it.contains('Updated') }.collect { 
			it
				.replace('[INFO]','')
				.replace('Updating parent','Hay una nueva version del parent pom:')
				.replace('Updated','Hay una nueva version de la library')
				.trim()
		}
		
		if(actualizadas.size()>0) {
			def mensaje = "El pom.xml ha sido actualizado con las siguientes versiones:\n${actualizadas}"
			
			if(!snapshots) {
				mensaje += "\nDebe actualizar manualmente las dependencias en el fichero pom.xml o el proceso de liberación fallará." 
			}
			 
			echo mensaje
		} else {
			echo "No se encontraron nuevas versiones de librerías de Eprinsa. Permitimos continuar." 
		}
	
		return actualizadas.join('\n')
	} catch(err) {
		echo "Error trying to de usar las últimas versiones de librerías EPRINSA. Continuamos pero lo consideramos inestable.\nError: ${err}"
		currentBuild.result = 'UNSTABLE'  
	}
}