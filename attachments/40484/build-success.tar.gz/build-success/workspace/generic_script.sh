echo "generic script file $1 $2"
