println "groovy script file" + args[0] + " " + args[1]
