Jenkins
=======

Version details
---------------

  * Version: `2.89.2`
  * Mode:    WAR
  * Url:     null
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/java/jdk1.8.0_102/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_102
      - Maximum memory:   1.91 GB (2051014656)
      - Allocated memory: 1.91 GB (2051014656)
      - Free memory:      957.65 MB (1004164768)
      - In-use memory:    998.35 MB (1046849888)
      - GC strategy:      G1
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.102-b14
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-693.el7.x86_64
  * Process ID: 1371 (0x55b)
  * Process started: 2017-12-15 13:49:09.829+0000
  * Process uptime: 34 min
  * JVM startup parameters:
      - Boot classpath: `/usr/java/jdk1.8.0_102/jre/lib/resources.jar:/usr/java/jdk1.8.0_102/jre/lib/rt.jar:/usr/java/jdk1.8.0_102/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_102/jre/lib/jsse.jar:/usr/java/jdk1.8.0_102/jre/lib/jce.jar:/usr/java/jdk1.8.0_102/jre/lib/charsets.jar:/usr/java/jdk1.8.0_102/jre/lib/jfr.jar:/usr/java/jdk1.8.0_102/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Xmx1955m`
      - arg[2]: `-Xms1955m`
      - arg[3]: `-XX:+AlwaysPreTouch`
      - arg[4]: `-Xloggc:/home/jenkins/gc-%t.log`
      - arg[5]: `-XX:NumberOfGCLogFiles=5`
      - arg[6]: `-XX:+UseGCLogFileRotation`
      - arg[7]: `-XX:GCLogFileSize=20m`
      - arg[8]: `-XX:+PrintGC`
      - arg[9]: `-XX:+PrintGCDateStamps`
      - arg[10]: `-XX:+PrintGCDetails`
      - arg[11]: `-XX:+PrintHeapAtGC`
      - arg[12]: `-XX:+PrintGCCause`
      - arg[13]: `-XX:+PrintTenuringDistribution`
      - arg[14]: `-XX:+PrintReferenceGC`
      - arg[15]: `-XX:+PrintAdaptiveSizePolicy`
      - arg[16]: `-XX:+UseG1GC`
      - arg[17]: `-XX:+ExplicitGCInvokesConcurrent`
      - arg[18]: `-XX:+ParallelRefProcEnabled`
      - arg[19]: `-XX:+UseStringDeduplication`
      - arg[20]: `-XX:+UnlockDiagnosticVMOptions`
      - arg[21]: `-XX:G1SummarizeRSetStatsPeriod=1`
      - arg[22]: `-Djava.awt.headless=true`
      - arg[23]: `-Djavax.net.ssl.trustStore=/etc/pki/ca-trust/extracted/java/cacerts`
      - arg[24]: `-Dcom.cloudbees.workflow.rest.external.JobExt.maxRunsPerJob=50`
      - arg[25]: `-Dcom.cloudbees.workflow.rest.external.FlowNodeLogExt.maxReturnChars=10240000`
      - arg[26]: `-Dpermissive-script-security.enabled=true`
      - arg[27]: `-Dhudson.model.ParametersAction.keepUndefinedParameters=true`
      - arg[28]: `-Dcom.sun.management.jmxremote`
      - arg[29]: `-Dcom.sun.management.jmxremote.ssl=false`
      - arg[30]: `-Dcom.sun.management.jmxremote.authenticate=false`
      - arg[31]: `-Dcom.sun.management.jmxremote.port=1098`
      - arg[32]: `-Djenkins.install.runSetupWizard=false`
      - arg[33]: `-DJENKINS_HOME=/home/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.SecurityRealm$None`
  * Authorization strategy: `hudson.security.AuthorizationStrategy$Unsecured`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.3-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.16 'Branch API Plugin'
  * cloudbees-folder:6.2.1 'Folders Plugin'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * display-url-api:2.2.0 'Display URL API'
  * docker-commons:1.10 'Docker Commons Plugin'
  * docker-workflow:1.14 'Docker Pipeline'
  * durable-task:1.17 'Durable Task Plugin'
  * git:3.6.4 'Jenkins Git plugin'
  * git-client:2.6.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.8.10.1 'Jackson 2 API Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.23 'JUnit Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * matrix-auth:2.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.12 'Matrix Project Plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pipeline-build-step:2.6 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.5 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.5 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.5 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.5 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.5.1 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * scm-api:2.2.6 'SCM API Plugin'
  * script-security:1.39 'Script Security Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * structs:1.10 'Structs Plugin'
  * support-core:2.44 'Support Core Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-api:2.24 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.42 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.17 'Pipeline: Nodes and Processes'
  * workflow-job:2.12.2 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.14 'Pipeline: Step API'
  * workflow-support:2.16 'Pipeline: Supporting APIs'
