Monitors
========

`jenkins.CLI`
--------------
(active and enabled)

`jenkins.diagnostics.SecurityIsOffMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

`jenkins.security.csrf.CSRFAdministrativeMonitor`
--------------
(active and enabled)

`jenkins.slaves.DeprecatedAgentProtocolMonitor`
--------------
(active and enabled)
