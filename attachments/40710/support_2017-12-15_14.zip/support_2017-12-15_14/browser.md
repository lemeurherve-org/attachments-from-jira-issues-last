Browser
=======

  * Screen size: 1920x1080
  * User Agent
      - Type:     Browser
      - Name:     Safari
      - Family:   SAFARI
      - Producer: Apple Inc.
      - Version:  11.0.1
      - Raw:      `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/604.3.5 (KHTML, like Gecko) Version/11.0.1 Safari/604.3.5`
  * Operating System
      - Name:     OS X
      - Family:   OS_X
      - Producer: Apple Computer, Inc.
      - Version:  10.13.1

