Item statistics
===============

  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 2
    - Number of builds per job: 2.5 [n=2, s=2.0]

Total job statistics
======================

  * Number of jobs: 2
  * Number of builds per job: 2.5 [n=2, s=2.0]
