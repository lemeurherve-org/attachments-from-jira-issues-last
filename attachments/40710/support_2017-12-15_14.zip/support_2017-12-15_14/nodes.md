Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/home/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.14
      - Java
          + Home:           `/usr/java/jdk1.8.0_102/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_102
          + Maximum memory:   1.91 GB (2051014656)
          + Allocated memory: 1.91 GB (2051014656)
          + Free memory:      954.65 MB (1001019040)
          + In-use memory:    1001.35 MB (1049995616)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.102-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-693.el7.x86_64
      - Process ID: 1371 (0x55b)
      - Process started: 2017-12-15 13:49:09.829+0000
      - Process uptime: 34 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_102/jre/lib/resources.jar:/usr/java/jdk1.8.0_102/jre/lib/rt.jar:/usr/java/jdk1.8.0_102/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_102/jre/lib/jsse.jar:/usr/java/jdk1.8.0_102/jre/lib/jce.jar:/usr/java/jdk1.8.0_102/jre/lib/charsets.jar:/usr/java/jdk1.8.0_102/jre/lib/jfr.jar:/usr/java/jdk1.8.0_102/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Xmx1955m`
          + arg[2]: `-Xms1955m`
          + arg[3]: `-XX:+AlwaysPreTouch`
          + arg[4]: `-Xloggc:/home/jenkins/gc-%t.log`
          + arg[5]: `-XX:NumberOfGCLogFiles=5`
          + arg[6]: `-XX:+UseGCLogFileRotation`
          + arg[7]: `-XX:GCLogFileSize=20m`
          + arg[8]: `-XX:+PrintGC`
          + arg[9]: `-XX:+PrintGCDateStamps`
          + arg[10]: `-XX:+PrintGCDetails`
          + arg[11]: `-XX:+PrintHeapAtGC`
          + arg[12]: `-XX:+PrintGCCause`
          + arg[13]: `-XX:+PrintTenuringDistribution`
          + arg[14]: `-XX:+PrintReferenceGC`
          + arg[15]: `-XX:+PrintAdaptiveSizePolicy`
          + arg[16]: `-XX:+UseG1GC`
          + arg[17]: `-XX:+ExplicitGCInvokesConcurrent`
          + arg[18]: `-XX:+ParallelRefProcEnabled`
          + arg[19]: `-XX:+UseStringDeduplication`
          + arg[20]: `-XX:+UnlockDiagnosticVMOptions`
          + arg[21]: `-XX:G1SummarizeRSetStatsPeriod=1`
          + arg[22]: `-Djava.awt.headless=true`
          + arg[23]: `-Djavax.net.ssl.trustStore=/etc/pki/ca-trust/extracted/java/cacerts`
          + arg[24]: `-Dcom.cloudbees.workflow.rest.external.JobExt.maxRunsPerJob=50`
          + arg[25]: `-Dcom.cloudbees.workflow.rest.external.FlowNodeLogExt.maxReturnChars=10240000`
          + arg[26]: `-Dpermissive-script-security.enabled=true`
          + arg[27]: `-Dhudson.model.ParametersAction.keepUndefinedParameters=true`
          + arg[28]: `-Dcom.sun.management.jmxremote`
          + arg[29]: `-Dcom.sun.management.jmxremote.ssl=false`
          + arg[30]: `-Dcom.sun.management.jmxremote.authenticate=false`
          + arg[31]: `-Dcom.sun.management.jmxremote.port=1098`
          + arg[32]: `-Djenkins.install.runSetupWizard=false`
          + arg[33]: `-DJENKINS_HOME=/home/jenkins`

