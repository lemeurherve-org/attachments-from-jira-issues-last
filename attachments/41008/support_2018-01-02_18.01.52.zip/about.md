Jenkins
=======

Version details
---------------

  * Version: `2.99`
  * Mode:    WAR
  * Url:     http://lcolocdkairbus05.colo.fr.sopra:10004/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/opt/java/jdk1.8.0_121/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_121
      - Maximum memory:   948.50 MB (994574336)
      - Allocated memory: 948.50 MB (994574336)
      - Free memory:      850.84 MB (892174824)
      - In-use memory:    97.66 MB (102399512)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.121-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-514.26.2.el7.x86_64
  * Process ID: 98 (0x62)
  * Process started: 2018-01-02 17:32:29.206+0000
  * Process uptime: 29 mn
  * JVM startup parameters:
      - Boot classpath: `/opt/java/jdk1.8.0_121/jre/lib/resources.jar:/opt/java/jdk1.8.0_121/jre/lib/rt.jar:/opt/java/jdk1.8.0_121/jre/lib/sunrsasign.jar:/opt/java/jdk1.8.0_121/jre/lib/jsse.jar:/opt/java/jdk1.8.0_121/jre/lib/jce.jar:/opt/java/jdk1.8.0_121/jre/lib/charsets.jar:/opt/java/jdk1.8.0_121/jre/lib/jfr.jar:/opt/java/jdk1.8.0_121/jre/classes`
      - Classpath: `/home/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dhttp.proxyHost=colo.proxy.corp.sopra`
      - arg[1]: `-Dhttp.proxyPort=8080`
      - arg[2]: `-Dhttp.nonProxyHosts=localhost|127.0.0.1|.sopra|*.sopra`
      - arg[3]: `-Dhttps.proxyHost=colo.proxy.corp.sopra`
      - arg[4]: `-Dhttps.proxyPort=8080`
      - arg[5]: `-Dhttps.nonProxyHosts=localhost|127.0.0.1|.sopra|*.sopra`
      - arg[6]: `-Dcdk.project=PRE_CREWING-jenkins-lcolocdkairbus05`
      - arg[7]: `-Duser.timezone=Europe/Paris`
      - arg[8]: `-XX:MaxPermSize=128m`
      - arg[9]: `-Xmx1024m`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.93 'Static Analysis Utilities'
  * ansible:0.6.2 'Jenkins Ansible plugin'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.3-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.17 'Branch API Plugin'
  * build-name-setter:1.6.7 'build-name-setter'
  * checkstyle:3.49 'Checkstyle Plug-in'
  * cloudbees-folder:6.2.1 'Folders Plugin'
  * cobertura:1.12 'Jenkins Cobertura Plugin'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * compress-artifacts:1.10 'Compress Artifacts Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:2.16.4 'Config File Provider Plugin'
  * copyartifact:1.39 'Copy Artifact Plugin'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * delivery-pipeline-plugin:1.1.0 'Delivery Pipeline Plugin'
  * dependency-check-jenkins-plugin:3.0.2 'OWASP Dependency-Check Plugin'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * display-url-api:2.2.0 'Display URL API'
  * docker-commons:1.10 'Docker Commons Plugin'
  * docker-java-api:3.0.14 'Docker API Plugin'
  * docker-plugin:1.1.2 'Docker plugin'
  * docker-workflow:1.14 'Docker Pipeline'
  * durable-task:1.17 'Durable Task Plugin'
  * email-ext:2.61 'Email Extension Plugin'
  * emailext-template:1.0 'Email Extension Template Plugin'
  * envfile:1.2 'Jenkins Environment File Plugin'
  * envinject:2.1.5 'Environment Injector Plugin'
  * envinject-api:1.5 'EnvInject API Plugin'
  * exporter-jenkins-plugin:1.3.0 'Xunit exporter for QC'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * findbugs:4.71 'FindBugs Plug-in'
  * ftppublisher:1.2 'FTP publisher plugin'
  * git:3.7.0 'Jenkins Git plugin'
  * git-client:2.7.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * gitflow:1.0.1 'Gitflow Plugin'
  * github:1.28.1 'GitHub plugin'
  * github-api:1.90 'GitHub API Plugin'
  * github-branch-source:2.3.2 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.8.10.1 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * job-import-plugin:2.1 'Job Import Plugin'
  * jobgenerator:1.22 'Job Generator'
  * jquery:1.12.4-0 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.23 'JUnit Plugin'
  * ldap:1.18 'LDAP Plugin'
  * locks-and-latches:0.6 'Hudson Locks and Latches plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mask-passwords:2.10.1 'Mask Passwords Plugin'
  * matrix-auth:2.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.12 'Matrix Project Plugin'
  * maven-plugin:3.0 'Maven Integration plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * monitoring:1.70.0 'Monitoring'
  * msbuild:1.28 'Jenkins MSBuild Plugin'
  * mstest:0.23 'MSTest plugin'
  * nested-view:1.14 'Nested View Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * nuget:0.7 'Jenkins Nuget Plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.6 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.5 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.5 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.5 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.5 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * pmd:3.49 'PMD Plug-in'
  * powershell:1.3 'Jenkins PowerShell plugin'
  * preSCMbuildstep:0.3 'Pre SCM BuildStep Plugin'
  * promoted-builds:2.31 'Jenkins promoted builds plugin'
  * publish-over-ftp:1.12 'Publish Over FTP'
  * publish-over-ssh:1.17 'Publish Over SSH'
  * run-condition:1.0 'Run Condition Plugin'
  * rundeck:3.6.3 'Jenkins Rundeck plugin'
  * scm-api:2.2.6 'SCM API Plugin'
  * script-security:1.39 'Script Security Plugin'
  * shared-workspace:1.0.2 'Shared Workspace'
  * slack:2.3 'Slack Notification Plugin'
  * sonar:2.6.1 'SonarQube Scanner for Jenkins'
  * ssh:2.5 'Jenkins SSH plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.24 'Jenkins SSH Slaves plugin'
  * ssh2easy:1.4 'SSH2 Easy Plugin'
  * startup-trigger-plugin:2.8 'Startup Trigger'
  * structs:1.10 'Structs Plugin'
  * subversion:2.10.2 'Jenkins Subversion Plug-in'
  * support-core:2.44 'Support Core Plugin'
  * thinBackup:1.9 'ThinBackup'
  * token-macro:2.3 'Token Macro Plugin'
  * view-job-filters:1.27 'View Job Filters'
  * vs-code-metrics:1.7 'Jenkins Visual Studio Code Metrics Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.24 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.42 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.17 'Pipeline: Nodes and Processes'
  * workflow-job:2.16 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.14 'Pipeline: Step API'
  * workflow-support:2.16 'Pipeline: Supporting APIs'
  * xunit:1.102 'xUnit plugin'
