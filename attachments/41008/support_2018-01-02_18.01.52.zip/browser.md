Browser
=======

  * Screen size: 2133x1200
  * User Agent
      - Type:     Browser
      - Name:     IE
      - Family:   IE
      - Producer: Microsoft Corporation.
      - Version:  7.0
      - Raw:      `Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 10.0; WOW64; Trident/7.0; Touch; .NET4.0C; .NET4.0E; .NET CLR 2.0.50727; .NET CLR 3.0.30729; .NET CLR 3.5.30729)`
  * Operating System
      - Name:     Windows
      - Family:   WINDOWS
      - Producer: Microsoft Corporation.
      - Version:  10.0

