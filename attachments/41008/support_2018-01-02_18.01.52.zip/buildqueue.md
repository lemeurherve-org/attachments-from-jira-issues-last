Current build queue has 3 item(s).
---------------
 * Name of item: SornaQube » PreCrewing - Web
    - In queue for: 26 mn
    - Is blocked: false
    - Why in queue: Windows Slave est hors ligne
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@2a8efea
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@574041b3
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@46360501
    - Can run: null
----

 * Name of item: SornaQube » PreCrewing - Services
    - In queue for: 26 mn
    - Is blocked: false
    - Why in queue: Windows Slave est hors ligne
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@2a8efea
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@574041b3
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@46360501
    - Can run: null
----

 * Name of item: SornaQube » PreCrewing - Gateway
    - In queue for: 26 mn
    - Is blocked: false
    - Why in queue: Windows Slave est hors ligne
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
    - Current queue trigger cause: Lancé par un changement dans la base de code
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@2a8efea
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@574041b3
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@46360501
    - Can run: null
----

Is quieting down: false
