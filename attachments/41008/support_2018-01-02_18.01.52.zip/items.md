Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 8
    - Number of items per container: 4.625 [n=8, s=4.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 38
    - Number of builds per job: 79.44736842105263 [n=38, s=70.0]

Total job statistics
======================

  * Number of jobs: 38
  * Number of builds per job: 79.44736842105263 [n=38, s=70.0]
