Support Bundle Manifest
=======================

Generated on 2018-01-02 18:01:52.234+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2018-01-02_17.32.31.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Calculation of builds disk usage.log`

      - `other-logs/Calculation of builds disk usage.log.1`

      - `other-logs/Calculation of builds disk usage.log.2`

      - `other-logs/Calculation of builds disk usage.log.3`

      - `other-logs/Calculation of builds disk usage.log.4`

      - `other-logs/Calculation of builds disk usage.log.5`

      - `other-logs/Calculation of job directories (without builds).log`

      - `other-logs/Calculation of job directories (without builds).log.1`

      - `other-logs/Calculation of job directories (without builds).log.2`

      - `other-logs/Calculation of job directories (without builds).log.3`

      - `other-logs/Calculation of job directories (without builds).log.4`

      - `other-logs/Calculation of job directories (without builds).log.5`

      - `other-logs/Calculation of workspace usage.log`

      - `other-logs/Calculation of workspace usage.log.1`

      - `other-logs/Calculation of workspace usage.log.2`

      - `other-logs/Calculation of workspace usage.log.3`

      - `other-logs/Calculation of workspace usage.log.4`

      - `other-logs/Calculation of workspace usage.log.5`

      - `other-logs/Connection Activity monitoring to agents.log`

      - `other-logs/Connection Activity monitoring to agents.log.1`

      - `other-logs/Connection Activity monitoring to agents.log.2`

      - `other-logs/Connection Activity monitoring to agents.log.3`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Download metadata.log.2`

      - `other-logs/Download metadata.log.3`

      - `other-logs/Download metadata.log.4`

      - `other-logs/Download metadata.log.5`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Fingerprint cleanup.log.1`

      - `other-logs/Fingerprint cleanup.log.2`

      - `other-logs/Fingerprint cleanup.log.3`

      - `other-logs/Fingerprint cleanup.log.4`

      - `other-logs/Fingerprint cleanup.log.5`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/Workspace clean-up.log.1`

      - `other-logs/Workspace clean-up.log.2`

      - `other-logs/Workspace clean-up.log.3`

      - `other-logs/Workspace clean-up.log.4`

      - `other-logs/Workspace clean-up.log.5`

      - `other-logs/health-checker.log`

  * Agent Log Recorders

      - `nodes/slave/Windows Slave/jenkins.log`

      - `nodes/slave/Windows Slave/logs/all_memory_buffer.log`

  * Garbage Collection Logs

  * Agents config files (Encrypted secrets are redacted)

      - `nodes/slave/Windows Slave/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/com.cdk.soprasteria.exporterjenkinsplugin.XunitExporter.xml`

      - `jenkins-root-configuration-files/com.michelin.cio.hudson.plugins.maskpasswords.MaskPasswordsConfig.xml`

      - `jenkins-root-configuration-files/com.zanox.hudson.plugins.FTPPublisher.xml`

      - `jenkins-root-configuration-files/de.silpion.jenkins.plugins.gitflow.GitflowBuildWrapper.xml`

      - `jenkins-root-configuration-files/envInject.xml`

      - `jenkins-root-configuration-files/envinject-plugin-configuration.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.analysis.core.GlobalSettings.xml`

      - `jenkins-root-configuration-files/hudson.plugins.copyartifact.TriggeredBuildSelector.xml`

      - `jenkins-root-configuration-files/hudson.plugins.disk_usage.DiskUsageProjectActionFactory.xml`

      - `jenkins-root-configuration-files/hudson.plugins.disk_usage.DiskUsageProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.emailext.ExtendedEmailPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.locksandlatches.LockWrapper.xml`

      - `jenkins-root-configuration-files/hudson.plugins.msbuild.MsBuildBuilder.xml`

      - `jenkins-root-configuration-files/hudson.plugins.promoted_builds.GlobalBuildPromotedBuilds.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.MsBuildSQRunnerInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarRunnerInstallation.xml`

      - `jenkins-root-configuration-files/hudson.scm.SubversionSCM.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/jenkins.CLI.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.publish_over_ftp.BapFtpPublisherPlugin.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.publish_over_ssh.BapSshPublisherPlugin.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.SlackNotifier.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.webhook.GlobalConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.ssh2easy.gssh.GsshBuilderWrapper.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.UpdateSiteWarningsConfiguration.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.DependencyCheck.DependencyCheckBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.DependencyCheck.DependencyTrackPublisher.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.ansible.AnsibleInstallation.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.conditionalbuildstep.singlestep.SingleConditionalBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.configfiles.GlobalConfigFiles.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.commons.tools.DockerTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitApacheTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.nuget.NugetGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.pipeline.modeldefinition.config.GlobalConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.rundeck.RundeckNotifier.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.sharedworkspace.SharedWorkspace.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.vs_code_metrics.VsCodeMetricsBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.SSHBuildWrapper.xml`

      - `jenkins-root-configuration-files/proxy.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/support-core.xml`

      - `jenkins-root-configuration-files/thinBackup.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/Windows Slave/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/Windows Slave/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/Windows Slave/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * Master Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/Windows+Slave/gnuplot`

      - `load-stats/label/Windows+Slave/hour.csv`

      - `load-stats/label/Windows+Slave/min.csv`

      - `load-stats/label/Windows+Slave/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/Windows Slave/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/Windows Slave/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Root CAs

      - `nodes/master/RootCA.txt`

      - `nodes/slave/Windows Slave/RootCA.txt`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/Windows Slave/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/Windows Slave/thread-dump.txt`

