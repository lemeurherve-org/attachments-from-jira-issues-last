Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * maître: Linux (amd64)
   * Windows Slave: null
Différence entre les horloges
----
 - Is Ignored: false
 - Computers:
   * maître: Synchronisé
   * Windows Slave: null
Espace disque disponible
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * maître: Espace disque insuffisant.  Seulement 17.215 GB restant sur /jenkins
   * Windows Slave: null
Espace de swap disponible
----
 - Is Ignored: false
 - Computers:
   * maître: Memory:5420/32014MB  Swap:699/8191MB
   * Windows Slave: null
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * maître: Espace disque insuffisant.  Seulement 7.356 GB restant sur /tmp
   * Windows Slave: null
Temps de réponse
----
 - Is Ignored: false
 - Computers:
   * maître: 0ms
   * Windows Slave: Time out du dernier essai 1
