Node statistics
===============

  * Total number of nodes
      - Sample size:        116
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        116
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        116
      - Average (mean):     2.0000000000000004
      - Average (median):   2.0
      - Standard deviation: 4.440892098500626E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        116
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/home/jenkins/.jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.15
      - Java
          + Home:           `/opt/java/jdk1.8.0_121/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   948.50 MB (994574336)
          + Allocated memory: 948.50 MB (994574336)
          + Free memory:      846.73 MB (887860832)
          + In-use memory:    101.77 MB (106713504)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-514.26.2.el7.x86_64
      - Process ID: 98 (0x62)
      - Process started: 2018-01-02 17:32:29.206+0000
      - Process uptime: 29 mn
      - JVM startup parameters:
          + Boot classpath: `/opt/java/jdk1.8.0_121/jre/lib/resources.jar:/opt/java/jdk1.8.0_121/jre/lib/rt.jar:/opt/java/jdk1.8.0_121/jre/lib/sunrsasign.jar:/opt/java/jdk1.8.0_121/jre/lib/jsse.jar:/opt/java/jdk1.8.0_121/jre/lib/jce.jar:/opt/java/jdk1.8.0_121/jre/lib/charsets.jar:/opt/java/jdk1.8.0_121/jre/lib/jfr.jar:/opt/java/jdk1.8.0_121/jre/classes`
          + Classpath: `/home/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dhttp.proxyHost=colo.proxy.corp.sopra`
          + arg[1]: `-Dhttp.proxyPort=8080`
          + arg[2]: `-Dhttp.nonProxyHosts=localhost|127.0.0.1|.sopra|*.sopra`
          + arg[3]: `-Dhttps.proxyHost=colo.proxy.corp.sopra`
          + arg[4]: `-Dhttps.proxyPort=8080`
          + arg[5]: `-Dhttps.nonProxyHosts=localhost|127.0.0.1|.sopra|*.sopra`
          + arg[6]: `-Dcdk.project=PRE_CREWING-jenkins-lcolocdkairbus05`
          + arg[7]: `-Duser.timezone=Europe/Paris`
          + arg[8]: `-XX:MaxPermSize=128m`
          + arg[9]: `-Xmx1024m`

  * Windows Slave (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `D:\Jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

