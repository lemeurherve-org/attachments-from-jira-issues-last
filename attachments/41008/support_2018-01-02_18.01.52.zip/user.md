User
====

Authentication
--------------

  * Authenticated: true
  * Name: blaoueille
  * Authorities 
      - `authenticated`
      - `Utils DI ALM External`
      - `COMPANY SITE 010 toulouse colo 1 - b1&b2-emp`
      - `Utils DSI Arkadin RV`
      - `ROLE_COMPANY 010 SOPRA STERIA GROUP S.A.-EMP`
      - `COUNTRY france-emp`
      - `BU 106 mp sig pole common solution-emp`
      - `ROLE_SSG PROJ VIBES FTANG`
      - `ROLE_ALL USERS-EMP`
      - `ROLE_UTILS DSI ARKADIN POC`
      - `Utils DI Constell VIBESATTS-InternalManagers`
      - `SSG DI ALM`
      - `SSG 142 Academy mobile`
      - `ROLE_SOPRA 010 ARCHITECTES`
      - `COMPANY 010 sopra steria group s.a.-emp`
      - `Utils DI ALM Internal`
      - `ROLE_SOPRA COM SOPRA GROUP FRANCE`
      - `SITE toulouse colo 1 - b1&b2-emp`
      - `ROLE_SSG DI ALM`
      - `SSG PROJ Vibes Ftang`
      - `ROLE_SOPRA PROJ BUNDLE VIBES`
      - `SSG PROJ mig ark FR`
      - `ROLE_COUNTRY FRANCE-EMP`
      - `ROLE_COMPANY SITE 010 TOULOUSE COLO 1 - B1&B2-EMP`
      - `ROLE_SSG PROJ MIG ARK FR`
      - `ROLE_WE.SHARE.FRANCE`
      - `ROLE_REQUIREMENT MANAGER`
      - `ROLE_AIRBUS`
      - `ssg collaborateurs permanents`
      - `ROLE_UTILS DI CONSTELL VIBESOASIS-INTERNALMANAGERS`
      - `ROLE_COMPANY 010 SOPRA STERIA GROUP`
      - `ROLE_FD VERTICAL`
      - `UTILS DSI office365 users-all`
      - `requirement manager`
      - `ROLE_WESHARE 2017 FRANCE`
      - `ROLE_SSG PROJ AIRBUS BADGE OWNER`
      - `ROLE_BU 106 MP SIG POLE COMMON SOLUTION-EMP`
      - `Utils DI Constell VIBESOASIS-InternalManagers`
      - `ROLE_UTILS DI CONSTELL VIBESATTS-INTERNALMANAGERS`
      - `We.Share.France`
      - `ROLE_UTILS DI CONSTELL VIBESEVPT-INTERNALMANAGERS`
      - `Utils DSI Arkadin`
      - `utils.online.teams`
      - `ROLE_SSG PROJ EVPT PROJECT TEAM`
      - `Utils DSI EMM FR Online Container`
      - `Utils DMSI RemoteAccess CAST`
      - `COMPANY 010 sopra steria group`
      - `Sopra PROJ Bundle Vibes`
      - `WeShare 2017 France`
      - `ROLE_COM BULPAIE_SO`
      - `ROLE_UTILS DSI OFFICE365 USERS-ALL`
      - `SSG PROJ EVPT Project Team`
      - `SSG PROJ AIRBUS Badge Owner`
      - `ROLE_UTILS DSI EMM FR ONLINE CONTAINER`
      - `COM Bulpaie_SO`
      - `Utils DI Constell VIBESEVPT-InternalManagers`
      - `ROLE_UTILS.ONLINE.TEAMS`
      - `ROLE_SITE TOULOUSE COLO 1 - B1&B2-EMP`
      - `AIRBUS`
      - `FD VERTICAL`
      - `Sopra 010 Architectes`
      - `ROLE_SSG COLLABORATEURS PERMANENTS`
      - `ROLE_SSG 142 ACADEMY MOBILE`
      - `100-Aeroline SIG - continuous improvement_ro`
      - `ALL users-emp`
      - `ROLE_UTILS DI ALM EXTERNAL`
      - `ROLE_UTILS DSI ARKADIN RV`
      - `ROLE_UTILS DMSI REMOTEACCESS CAST`
      - `Utils DSI Arkadin POC`
      - `SOPRA COM Sopra Group France`
      - `ROLE_UTILS DI ALM INTERNAL`
      - `ROLE_100-AEROLINE SIG - CONTINUOUS IMPROVEMENT_RO`
      - `ROLE_UTILS DSI ARKADIN`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@91b42839: Username: org.acegisecurity.userdetails.ldap.LdapUserDetailsImpl@75d4d59e; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@b364: RemoteIpAddress: 172.29.181.60; SessionId: null; Granted Authorities: authenticated, Utils DI ALM External, COMPANY SITE 010 toulouse colo 1 - b1&b2-emp, Utils DSI Arkadin RV, ROLE_COMPANY 010 SOPRA STERIA GROUP S.A.-EMP, COUNTRY france-emp, BU 106 mp sig pole common solution-emp, ROLE_SSG PROJ VIBES FTANG, ROLE_ALL USERS-EMP, ROLE_UTILS DSI ARKADIN POC, Utils DI Constell VIBESATTS-InternalManagers, SSG DI ALM, SSG 142 Academy mobile, ROLE_SOPRA 010 ARCHITECTES, COMPANY 010 sopra steria group s.a.-emp, Utils DI ALM Internal, ROLE_SOPRA COM SOPRA GROUP FRANCE, SITE toulouse colo 1 - b1&b2-emp, ROLE_SSG DI ALM, SSG PROJ Vibes Ftang, ROLE_SOPRA PROJ BUNDLE VIBES, SSG PROJ mig ark FR, ROLE_COUNTRY FRANCE-EMP, ROLE_COMPANY SITE 010 TOULOUSE COLO 1 - B1&B2-EMP, ROLE_SSG PROJ MIG ARK FR, ROLE_WE.SHARE.FRANCE, ROLE_REQUIREMENT MANAGER, ROLE_AIRBUS, ssg collaborateurs permanents, ROLE_UTILS DI CONSTELL VIBESOASIS-INTERNALMANAGERS, ROLE_COMPANY 010 SOPRA STERIA GROUP, ROLE_FD VERTICAL, UTILS DSI office365 users-all, requirement manager, ROLE_WESHARE 2017 FRANCE, ROLE_SSG PROJ AIRBUS BADGE OWNER, ROLE_BU 106 MP SIG POLE COMMON SOLUTION-EMP, Utils DI Constell VIBESOASIS-InternalManagers, ROLE_UTILS DI CONSTELL VIBESATTS-INTERNALMANAGERS, We.Share.France, ROLE_UTILS DI CONSTELL VIBESEVPT-INTERNALMANAGERS, Utils DSI Arkadin, utils.online.teams, ROLE_SSG PROJ EVPT PROJECT TEAM, Utils DSI EMM FR Online Container, Utils DMSI RemoteAccess CAST, COMPANY 010 sopra steria group, Sopra PROJ Bundle Vibes, WeShare 2017 France, ROLE_COM BULPAIE_SO, ROLE_UTILS DSI OFFICE365 USERS-ALL, SSG PROJ EVPT Project Team, SSG PROJ AIRBUS Badge Owner, ROLE_UTILS DSI EMM FR ONLINE CONTAINER, COM Bulpaie_SO, Utils DI Constell VIBESEVPT-InternalManagers, ROLE_UTILS.ONLINE.TEAMS, ROLE_SITE TOULOUSE COLO 1 - B1&B2-EMP, AIRBUS, FD VERTICAL, Sopra 010 Architectes, ROLE_SSG COLLABORATEURS PERMANENTS, ROLE_SSG 142 ACADEMY MOBILE, 100-Aeroline SIG - continuous improvement_ro, ALL users-emp, ROLE_UTILS DI ALM EXTERNAL, ROLE_UTILS DSI ARKADIN RV, ROLE_UTILS DMSI REMOTEACCESS CAST, Utils DSI Arkadin POC, SOPRA COM Sopra Group France, ROLE_UTILS DI ALM INTERNAL, ROLE_100-AEROLINE SIG - CONTINUOUS IMPROVEMENT_RO, ROLE_UTILS DSI ARKADIN`

