﻿namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
#warning Test whether this warning shows up in the correct namespace
        }
    }
}
