Jenkins
=======

Version details
---------------

  * Version: `2.106`
  * Mode:    WAR
  * Url:     https://jenkins2.labnet/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_151
      - Maximum memory:   843.00 MB (883949568)
      - Allocated memory: 784.50 MB (822607872)
      - Free memory:      115.21 MB (120803520)
      - In-use memory:    669.29 MB (701804352)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.151-b12
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-514.2.2.el7.x86_64
  * Process ID: 7207 (0x1c27)
  * Process started: 2018-02-16 08:27:42.118+0000
  * Process uptime: 3 days 4 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-collector:1.52 'Static Analysis Collector Plug-in'
  * analysis-core:1.94 'Static Analysis Utilities'
  * ant:1.8 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.3-2.1 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bitbucket:1.1.8 'Jenkins Bitbucket Plugin'
  * blueocean:1.4.1 *(update available)* 'Blue Ocean'
  * blueocean-autofavorite:1.2.1 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.4.1 *(update available)* 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.4.1 *(update available)* 'Common API for Blue Ocean'
  * blueocean-config:1.4.1 *(update available)* 'Config API for Blue Ocean'
  * blueocean-core-js:1.4.1 *(update available)* 'Blue Ocean Core JS'
  * blueocean-dashboard:1.4.1 *(update available)* 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.2.0 'Display URL for Blue Ocean'
  * blueocean-events:1.4.1 *(update available)* 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.4.1 *(update available)* 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.4.1 *(update available)* 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.4.1 *(update available)* 'i18n for Blue Ocean'
  * blueocean-jira:1.4.1 *(update available)* 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.4.1 *(update available)* 'JWT for Blue Ocean'
  * blueocean-personalization:1.4.1 *(update available)* 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.4.1 *(update available)* 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.4.1 *(update available)* 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.4.1 *(update available)* 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.4.1 *(update available)* 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.4.1 *(update available)* 'REST Implementation for Blue Ocean'
  * blueocean-web:1.4.1 *(update available)* 'Web for Blue Ocean'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.18 'Branch API Plugin'
  * build-timeout:1.19 'Build Timeout'
  * built-on-column:1.1 'built-on-column'
  * checkstyle:3.50 'Checkstyle Plug-in'
  * chucknorris:1.1 'ChuckNorris Plugin'
  * cloudbees-bitbucket-branch-source:2.2.9 *(update available)* 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.3 'Folders Plugin'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:2.17 'Config File Provider Plugin'
  * convert-to-pipeline:1.0 'Convert To Pipeline'
  * cppcheck:1.21 'Jenkins Cppcheck Plug-in'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.15 'Credentials Binding Plugin'
  * custom-view-tabs:1.3 'Custom View Tabs Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * display-url-api:2.2.0 'Display URL API'
  * docker-commons:1.11 'Docker Commons Plugin'
  * docker-workflow:1.15 *(update available)* 'Docker Pipeline'
  * durable-task:1.17 *(update available)* 'Durable Task Plugin'
  * email-ext:2.61 'Email Extension Plugin'
  * envinject:2.1.5 'Environment Injector Plugin'
  * envinject-api:1.5 'EnvInject API Plugin'
  * extensible-choice-parameter:1.4.2 'Extensible Choice Parameter plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.1 'Favorite'
  * git:3.7.0 'Jenkins Git plugin'
  * git-client:2.7.1 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.29.0 'GitHub plugin'
  * github-api:1.90 'GitHub API Plugin'
  * github-branch-source:2.3.2 'GitHub Branch Source Plugin'
  * gradle:1.28 'Gradle Plugin'
  * greenballs:1.15 'Green Balls'
  * groovy:2.0 'Groovy'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.6-1.0 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * instant-messaging:1.35 'Jenkins instant-messaging plugin'
  * ircbot:2.30 'Jenkins IRC Plugin'
  * jackson2-api:2.8.11.1 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jenkins-design-language:1.4.1 *(update available)* 'Jenkins Design Language'
  * jenkins-multijob-plugin:1.28 'Jenkins Multijob plugin'
  * jira:2.5 'Jenkins JIRA plugin'
  * job-restrictions:0.6 'Jenkins Job Restrictions Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 *(update available)* 'Jenkins JSch dependency plugin'
  * junit:1.24 'JUnit Plugin'
  * ldap:1.19 'LDAP Plugin'
  * lockable-resources:2.1 'Lockable Resources plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.12 'Matrix Project Plugin'
  * maven-plugin:3.1 'Maven Integration plugin'
  * mercurial:2.2 'Jenkins Mercurial plugin'
  * metadata:1.1.0b 'Metadata plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * nested-view:1.14 'Nested View Plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * pipeline-aggregator-view:1.8 'Pipeline Aggregator'
  * pipeline-build-step:2.7 'Pipeline: Build Step'
  * pipeline-github:1.0 'Pipeline: GitHub'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.6 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-maven:3.3.0 *(update available)* 'Pipeline Maven Integration Plugin'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.7 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.7 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.7 'Pipeline: Declarative Extension Points API'
  * pipeline-multibranch-defaults:1.1 'Pipeline: Multibranch with defaults'
  * pipeline-npm:0.9.2 'Pipeline NPM Integration Plugin'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.7 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.5.1 *(update available)* 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * preSCMbuildstep:0.3 'Pre SCM BuildStep Plugin'
  * publish-over:0.21 'Infrastructure plugin for Publish Over X'
  * publish-over-ssh:1.18 'Publish Over SSH'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * rebuild:1.27 'Rebuilder'
  * resource-disposer:0.8 'Resource Disposer Plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * run-selector:1.0.0 'Run Selector Plugin'
  * scm-api:2.2.6 'SCM API Plugin'
  * script-security:1.41 'Script Security Plugin'
  * simple-build-for-pipeline:0.2 'Simple Build DSL for Pipeline'
  * simple-theme-plugin:0.3 *(update available)* 'Simple Theme Plugin'
  * simple-travis-runner:1.0 'Simple Travis Pipeline Runner Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.5 'Jenkins SSH plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.25.1 'Jenkins SSH Slaves plugin'
  * stash-pullrequest-builder:1.7.1-SNAPSHOT (private-9a5092df-jim) 'Stash Pullrequest Builder Plugin'
  * stashNotifier:1.13 'Stash Notifier'
  * structs:1.13 *(update available)* 'Structs Plugin'
  * subversion:2.10.2 'Jenkins Subversion Plug-in'
  * support-core:2.44 'Support Core Plugin'
  * tasks:4.52 'Task Scanner Plug-in'
  * thinBackup:1.9 'ThinBackup'
  * throttle-concurrents:2.0.1 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.8.9 'Timestamper'
  * token-macro:2.3 'Token Macro Plugin'
  * translation:1.16 'Jenkins Translation Assistance plugin'
  * variant:1.1 'Variant Plugin'
  * view-job-filters:1.27 'View Job Filters'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.65 'Warnings Plug-in'
  * webhook-step:1.3 'Webhook Step Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.25 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.44 *(update available)* 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.18 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.17 'Pipeline: Job'
  * workflow-multibranch:2.17 'Pipeline: Multibranch'
  * workflow-remote-loader:1.4 'Jenkins Pipeline Remote Loader Plugin'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.14 'Pipeline: Step API'
  * workflow-support:2.18 'Pipeline: Supporting APIs'
  * ws-cleanup:0.34 'Jenkins Workspace Cleanup Plugin'
