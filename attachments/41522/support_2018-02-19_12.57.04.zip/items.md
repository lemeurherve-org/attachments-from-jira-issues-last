Item statistics
===============

  * `com.tikal.jenkins.plugins.multijob.MultiJobProject`
    - Number of items: 18
    - Number of builds per job: 159.11111111111111 [n=18, s=300.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 127
    - Number of builds per job: 192.5275590551181 [n=127, s=730.0]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 3
    - Number of items per container: 14.666666666666666 [n=3, s=20.0]
  * `org.jenkinsci.plugins.pipeline.multibranch.defaults.PipelineMultiBranchDefaultsProject`
    - Number of items: 5
    - Number of items per container: 7.2 [n=5, s=10.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 661
    - Number of builds per job: 15.85930408472012 [n=661, s=96.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 52
    - Number of items per container: 12.0 [n=52, s=10.0]

Total job statistics
======================

  * Number of jobs: 806
  * Number of builds per job: 46.89578163771712 [n=806, s=310.0]
