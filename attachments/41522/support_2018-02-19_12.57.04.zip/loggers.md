Loggers currently enabled
=========================
org.apache.sshd - WARNING
winstone - 5
 - INFO
