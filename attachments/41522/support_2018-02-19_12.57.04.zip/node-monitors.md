Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * ipm-1.3-devel-21: Linux (amd64)
   * ipm-1.3-devel-22: Linux (amd64)
   * ipm-1.3-devel-23: Linux (amd64)
   * ipm-1.3-devel-24: Linux (amd64)
   * jenkins2-slave-01: Linux (amd64)
   * jenkins2-slave-02: Linux (amd64)
   * jenkins2-slave-03: Linux (amd64)
   * jenkins2-slave-04: Linux (amd64)
   * jenkins2-slave-11: Linux (amd64)
   * jenkins2-slave-12: Linux (amd64)
   * jenkins2-slave-13: Linux (amd64)
   * jenkins2-slave-14: Linux (amd64)
   * master-worker: Linux (amd64)
   * z_jenkins2-push-to-obs-01: Linux (amd64)
   * z_jenkins2-push-to-obs-11: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * ipm-1.3-devel-21: In sync
   * ipm-1.3-devel-22: In sync
   * ipm-1.3-devel-23: In sync
   * ipm-1.3-devel-24: In sync
   * jenkins2-slave-01: In sync
   * jenkins2-slave-02: In sync
   * jenkins2-slave-03: In sync
   * jenkins2-slave-04: In sync
   * jenkins2-slave-11: In sync
   * jenkins2-slave-12: In sync
   * jenkins2-slave-13: In sync
   * jenkins2-slave-14: In sync
   * master-worker: In sync
   * z_jenkins2-push-to-obs-01: In sync
   * z_jenkins2-push-to-obs-11: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 12.362GB left on /var/lib/jenkins.
   * ipm-1.3-devel-21: Disk space is too low. Only 15.662GB left on /tmp/jenkins.
   * ipm-1.3-devel-22: Disk space is too low. Only 15.741GB left on /tmp/jenkins.
   * ipm-1.3-devel-23: Disk space is too low. Only 16.062GB left on /tmp/jenkins.
   * ipm-1.3-devel-24: Disk space is too low. Only 16.087GB left on /tmp/jenkins.
   * jenkins2-slave-01: Disk space is too low. Only 15.247GB left on /tmp/jenkins.
   * jenkins2-slave-02: Disk space is too low. Only 16.057GB left on /tmp/jenkins.
   * jenkins2-slave-03: Disk space is too low. Only 16.087GB left on /tmp/jenkins.
   * jenkins2-slave-04: Disk space is too low. Only 14.712GB left on /tmp/jenkins.
   * jenkins2-slave-11: Disk space is too low. Only 15.741GB left on /tmp/jenkins.
   * jenkins2-slave-12: Disk space is too low. Only 13.638GB left on /tmp/jenkins.
   * jenkins2-slave-13: Disk space is too low. Only 15.013GB left on /tmp/jenkins.
   * jenkins2-slave-14: Disk space is too low. Only 15.741GB left on /tmp/jenkins.
   * master-worker: Disk space is too low. Only 12.362GB left on /home/abuild/master-worker.
   * z_jenkins2-push-to-obs-01: Disk space is too low. Only 15.919GB left on /tmp/jenkins.
   * z_jenkins2-push-to-obs-11: Disk space is too low. Only 15.553GB left on /tmp/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:1047/3789MB  Swap:3264/3983MB
   * ipm-1.3-devel-21: Memory:10484/31484MB  Swap:105061/105379MB
   * ipm-1.3-devel-22: Memory:10484/31484MB  Swap:105061/105379MB
   * ipm-1.3-devel-23: Memory:7885/8192MB  Swap:104296/104462MB
   * ipm-1.3-devel-24: Memory:7996/8192MB  Swap:104296/104462MB
   * jenkins2-slave-01: Memory:6822/8192MB  Swap:104296/104462MB
   * jenkins2-slave-02: Memory:7032/8192MB  Swap:104296/104462MB
   * jenkins2-slave-03: Memory:6843/8192MB  Swap:104296/104462MB
   * jenkins2-slave-04: Memory:6304/8192MB  Swap:104296/104462MB
   * jenkins2-slave-11: Memory:10484/31484MB  Swap:105061/105379MB
   * jenkins2-slave-12: Memory:10484/31484MB  Swap:105061/105379MB
   * jenkins2-slave-13: Memory:10484/31484MB  Swap:105061/105379MB
   * jenkins2-slave-14: Memory:10484/31484MB  Swap:105061/105379MB
   * master-worker: Memory:1047/3789MB  Swap:3264/3983MB
   * z_jenkins2-push-to-obs-01: Memory:7166/8192MB  Swap:104296/104462MB
   * z_jenkins2-push-to-obs-11: Memory:10484/31484MB  Swap:105061/105379MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 12.362GB left on /tmp.
   * ipm-1.3-devel-21: Disk space is too low. Only 15.662GB left on /tmp.
   * ipm-1.3-devel-22: Disk space is too low. Only 15.741GB left on /tmp.
   * ipm-1.3-devel-23: Disk space is too low. Only 16.062GB left on /tmp.
   * ipm-1.3-devel-24: Disk space is too low. Only 16.087GB left on /tmp.
   * jenkins2-slave-01: Disk space is too low. Only 15.247GB left on /tmp.
   * jenkins2-slave-02: Disk space is too low. Only 16.057GB left on /tmp.
   * jenkins2-slave-03: Disk space is too low. Only 16.087GB left on /tmp.
   * jenkins2-slave-04: Disk space is too low. Only 14.712GB left on /tmp.
   * jenkins2-slave-11: Disk space is too low. Only 15.741GB left on /tmp.
   * jenkins2-slave-12: Disk space is too low. Only 13.638GB left on /tmp.
   * jenkins2-slave-13: Disk space is too low. Only 15.013GB left on /tmp.
   * jenkins2-slave-14: Disk space is too low. Only 15.741GB left on /tmp.
   * master-worker: Disk space is too low. Only 12.362GB left on /tmp.
   * z_jenkins2-push-to-obs-01: Disk space is too low. Only 15.919GB left on /tmp.
   * z_jenkins2-push-to-obs-11: Disk space is too low. Only 15.553GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * ipm-1.3-devel-21: 20ms
   * ipm-1.3-devel-22: 17ms
   * ipm-1.3-devel-23: 14ms
   * ipm-1.3-devel-24: 16ms
   * jenkins2-slave-01: 15ms
   * jenkins2-slave-02: 14ms
   * jenkins2-slave-03: 12ms
   * jenkins2-slave-04: 14ms
   * jenkins2-slave-11: 9ms
   * jenkins2-slave-12: 10ms
   * jenkins2-slave-13: 9ms
   * jenkins2-slave-14: 10ms
   * master-worker: 10ms
   * z_jenkins2-push-to-obs-01: 10ms
   * z_jenkins2-push-to-obs-11: 9ms
