-----------
 * Name eth0
 ** Hardware Address - 00163e570e14
 ** Index - 1341
 ** InetAddress - /fe80:0:0:0:216:3eff:fe57:e14%eth0
 ** InetAddress - /10.130.53.153
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
