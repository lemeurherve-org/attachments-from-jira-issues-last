from conans import ConanFile, tools
import os
def git_repo_url():
    repo_url = ''
    if os.path.exists(".git"):
        from conans.client.runner import ConanRunner
        try:
            from StringIO import StringIO
        except ImportError:
            from io import StringIO
        output = StringIO() 
        ConanRunner()("git config --get remote.origin.url", output)
        repo_url = output.getvalue().strip()
        tools.save("repo_url.txt", "%s" % repo_url)
    elif os.path.exists("repo_url.txt"):
        repo_url = tools.load("repo_url.txt")
    return repo_url
package_git_url = git_repo_url()
class ProjectConan(ConanFile):
    scriptdir, _ = os.path.split(os.path.realpath(__file__))
    name = package_git_url.split('/')[-1][:-4]
    exports = "*repo_url.txt"
    version = "0.0.1"
    settings = "os", "build_type", "arch"
    description = "Integra-Video loader library"
    url = "None"
    license = "None"
    generators = "cmake"

    def build_requirements(self):
        self.build_requires("IVConanTools/[~0.0.0]@iv/stable")
        self.build_requires("inc/[~0.0.0]@iv/stable")

    def requirements(self):
        if self.settings.os == 'Linux':
            self.requires("gcc7.3.0-libs/[~0.0.0]@iv/stable", private=False, override=False)

    def build(self):
        with tools.pythonpath(self):
            import ivconantools
            ivconantools.cmake_build(self, build_tools_version=2010, build_folder='')

    def imports(self):
        self.copy("*", dst=self.scriptdir + "/inc", src="include")

    def package(self):
        self.copy("*.dll", dst="", src=self.build_folder)
        self.copy("*.so", dst="", src=self.build_folder)