#define BOOMODULE_NOT_USE_RUX
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#define ITS_AUTOLOADER

#include <booldog/boo_time_utils.h>
namespace iv
{	
  booinline ::booldog::uint32 tickcount()
	{
#ifdef __WINDOWS__
    return timeGetTime();
#else
    struct timespec ts = {0, 0};
		if(clock_gettime(CLOCK_MONOTONIC, &ts))
			clock_gettime(CLOCK_REALTIME, &ts);
		return (ts.tv_sec * 1000) + (ts.tv_nsec / 1000000);
#endif
	}
}
#define BOO_TICKCOUNT ::iv::tickcount()

#include <booldog/boo_base_loader.h>
#include <booldog/boo_io_file.h>
#include <booldog/boo_json.h>
#include <booldog/boo_utf8_consts.h>
#include <booldog/boo_error_format.h>
#include <booldog/boo_heap_allocator.h>
#include <booldog/boo_mixed_allocator.h>
#include <booldog/boo_doubly_linked_list.h>
#include <booldog/boo_console_utils.h>
#include <booldog/boo_executable_utils.h>
#include <booldog/boo_io_directory.h>
#include <booldog/boo_directory_utils.h>
#include <booldog/boo_lockfree_stack.h>
#include <booldog/boo_array.h>

#include <iv_common.h>
#include <iv_plugin.h>
#include <iv_log2.h>
#include <iv_tasks_noncritical.h>
#include <iv_exceptions.h>
#include <iv_stable.h>
#include <iv_hook.h>
#include "../inc/iv_version.h"
IVVERSION

#define BOOLDOG_WHO 80
#define BOO_MODULE_METKA AUTOLOADER_BEGIN_METKA
#include <iv_booldog.h>

#include <iv_cs.h>

IVBOOLDOG
IVCSFUNC
namespace iv
{	
	typedef void (*ruxlog_write_t)( int level , const char* format , va_list ap );
	typedef void (*temp_set_ruxlog_write_t)( ::iv::ruxlog_write_t ruxlog_write );

	typedef void (*ruxstatement_t)(void* udata, unsigned int& lineid, unsigned int label, int __booline__);
	typedef unsigned int (*ruxlineid_t)(void* udata, unsigned int label, const char* __boofile__, const char* __boofunction__ 
		, int __booline__);
	typedef void (*tempprivate_info_thread_t)(ruxlineid_t, ruxstatement_t, void*);
	typedef void (*exception_event_t)( int );
	typedef bool (*pre_dll_free_t)( const char* module_name );
	typedef void (*pre_pre_dll_free_t)();
	typedef void (*post_dll_init_t)();

	enum state
	{
		state_free = 0, 
		state_busy = 1,
		state_exec = 2,
		state_pending_in_init = 3, 
		state_pending_in_deinit = 4
	};

	struct autoloaderclass;
	boointernal ::iv::autoloaderclass* pautoloader = 0;
	boointernal ::booldog::interlocked::atomic autoloader_inited = 0;
	namespace booldog
	{
		boointernal ::booldog::allocators::easy::heap autoloaderheap;
		boointernal ::booldog::allocators::mixed< 32 * 1024, 16 > autoloadermixed(&::iv::booldog::autoloaderheap);		
	}
	boointernal char root_path[4096] = {0};
	boointernal const param_t* logparams = 0;
	boointernal iv_int32 stable_renamed = 0;
	boointernal void* SetHook = 0;
	boointernal void* GetHook = 0;
	struct module_free_unload
	{
		::iv::autoloaderclass* pautoloader;
		bool locked;
	};
	struct dependency
	{
		::booldog::interlocked::atomic _state;
		::booldog::interlocked::atomic _refs;
		::booldog::interlocked::atomic _inited_refs;

		::booldog::base::module* module;
		::booldog::result_mbchar dependent_modulepathname;
		::booldog::module_handle dependent_modhandle;
		
		::iv::dependency* _prev;
		dependency(::booldog::allocator* pallocator)
			: _state(::iv::state_pending_in_init), module(0), dependent_modulepathname(pallocator) 
			, dependent_modhandle(0), _refs(1), _inited_refs(0)
		{
		}
		~dependency()
		{
		}
	};
	struct global_data_struct
	{
		::booldog::uint64 _key_hash;
		char* _value;
		::iv::global_data_struct* _doubly_linked_list_prev;
		::iv::global_data_struct* _doubly_linked_list_next;
	};
	struct autoremove
		: public ::booldog::data::lockfree::intrusive::stack_item
	{
		::booldog::interlocked::atomic _state;
		::booldog::module_handle _hmod;
		::booldog::byte _new;
		union
		{
			::iv::autoremove_t _autoremove_____;
			::iv::autoremove2_t _autoremove2;
		};
		void* _removed;
		::iv::autoremove* _doubly_linked_list_prev;
		::iv::autoremove* _doubly_linked_list_next;
		bool before_dll_free;
		bool _need_explicity_unregister;
		autoremove()
			:  _state(::iv::state_busy)
		{
		}
	};
	struct exception_struct
	{
		::iv::exception_event_t _exception_filter;
		::iv::exception_struct* _prev;
		::iv::exception_struct* _next;
	};
	struct module_udata
	{
		::booldog::base::module* _module;
		::iv::exception_struct* _exception;
		::booldog::interlocked::atomic _pre_pre_dll_free_executed;
		::iv::autoloader_nm::module_struct* _module_struct_old;
		::iv::autoloader_nm::module_struct_ext* _module_struct_ext;
		bool _pre_dll_init;
	};
	static void onbeforefree(void* udata, ::booldog::base::module* mod);
	static void onbeforeunload(void* udata, ::booldog::base::module* mod);
	static void* methodinternal( void* module , const char* name );
	static void freeinternal( void* ptr );
	static char* get_filenameinternal( void* module );
	static const char* root_pathinternal();
	static void unloadinternal(void* any_module_address, void* module);

	struct autoloaderclass
	{
		Log* _log;
		Log* _ruxlog;

		::booldog::loader _loader;

		bool _stableloaded;
		bool _memloaded;
		bool _logloaded;
		bool _ruxengineloaded;
		bool _exceptionsloaded;
		::iv::tempprivate_info_thread_t _tempprivate_info_thread;
		::iv::temp_set_ruxlog_write_t _temp_set_ruxlog_write;
		void* _rux_info_task_handle;
		IV_CRITICAL_SECTION _lock;
		::iv::dependency* _depends;

		::booldog::data::lockfree::intrusive::stack< ::iv::autoremove > _avail_autoremoves;

		IV_CRITICAL_SECTION _lock_autoremoves;
		::booldog::data::doubly_linked_list< ::iv::autoremove > _autoremoves___00;
		IV_CRITICAL_SECTION _lock_autoremoves2;
		::booldog::data::doubly_linked_list< ::iv::autoremove > _autoremoves2___00;

		IV_CRITICAL_SECTION _lock_autoremoves3;
		::booldog::data::doubly_linked_list< ::iv::autoremove > _autoremoves3___00;

		IV_CRITICAL_SECTION _lock_exceptions;
		::iv::exception_struct* _exceptions;

		IV_RWLOCK _lock_global_datas;
		::booldog::data::doubly_linked_list< ::iv::global_data_struct > _global_datas;	
		::booldog::module_handle _stable_hmod;
		::booldog::array< char* > _stable_memory_errno;
		bool _cs_inited;
		static void ruxlog_write( int level , const char* format , va_list ap )
		{
			int III = 0, JJJ = rand() % 200; iv_int64 RESSS;
			RESSS = ::iv::pautoloader->_ruxlog->WriteV( level , III , JJJ , __FILE__ , __LOG4CXX_FUNC__ , __LINE__ 
				, format , ap );
			RESSS = RESSS;
		};
		::iv::autoremove* create_autoremove2( ::booldog::module_handle hmod , ::iv::autoremove_t pautoremove 
			, ::iv::autoremove2_t pautoremove2 , void* removed , bool before_dll_free , bool need_explicity_unregister )
		{
			IVBOO_FUNC(879);
			::iv::autoremove* autoremove = _avail_autoremoves.pop();
			IVBOO_METKA(878);
			if( autoremove == 0 )
				autoremove = ::iv::booldog::autoloadermixed.create< ::iv::autoremove >( debuginfo_macros );
			IVBOO_METKA(877);
			autoremove->_hmod = hmod;
			autoremove->_need_explicity_unregister = need_explicity_unregister;
			if( pautoremove )
			{
				autoremove->_autoremove_____ = pautoremove;
				autoremove->_new = 0;
			}
			else
			{
				autoremove->_autoremove2 = pautoremove2;
				autoremove->_new = 1;
			}
			autoremove->_removed = removed;
			autoremove->before_dll_free = before_dll_free;

			::booldog::interlocked::exchange( &autoremove->_state , ::iv::state_busy );

			IVBOO_METKA(876);
			if(_cs_inited)
				cs1Enter(&_lock_autoremoves2, 524);
			IVBOO_METKA(875);
			_autoremoves2___00.add( autoremove );
			IVBOO_METKA(874);
			if(_cs_inited)
				cs1Leave(&_lock_autoremoves2);
			return autoremove;
		};
		::iv::autoremove* create_autoremove3( ::booldog::module_handle hmod , ::iv::autoremove_t pautoremove
			, ::iv::autoremove2_t pautoremove2 , void* removed , bool before_dll_free , bool need_explicity_unregister )
		{
			IVBOO_FUNC(888);
			::iv::autoremove* autoremove = _avail_autoremoves.pop();
			IVBOO_METKA(887);
			if( autoremove == 0 )
				autoremove = ::iv::booldog::autoloadermixed.create< ::iv::autoremove >( debuginfo_macros );
			autoremove->_hmod = hmod;
			autoremove->_need_explicity_unregister = need_explicity_unregister;
			if( pautoremove )
			{
				autoremove->_autoremove_____ = pautoremove;
				autoremove->_new = 0;
			}
			else
			{
				autoremove->_autoremove2 = pautoremove2;
				autoremove->_new = 1;
			}
			autoremove->_removed = removed;
			autoremove->before_dll_free = before_dll_free;

			::booldog::interlocked::exchange( &autoremove->_state , ::iv::state_busy );

			IVBOO_METKA(884);
			if(_cs_inited)
				cs1Enter(&_lock_autoremoves3, 424);
			IVBOO_METKA(883);
			_autoremoves3___00.add( autoremove );
			IVBOO_METKA(882);
			if(_cs_inited)
				cs1Leave(&_lock_autoremoves3);
			IVBOO_METKA(881);
			return autoremove;
		};
		::iv::autoremove* create_autoremove( ::booldog::module_handle hmod , ::iv::autoremove_t pautoremove 
			, ::iv::autoremove2_t pautoremove2 , void* removed , bool before_dll_free , bool need_explicity_unregister )
		{
			IVBOO_FUNC(869);
			::iv::autoremove* autoremove = _avail_autoremoves.pop();
			IVBOO_METKA(868);
			if( autoremove == 0 )
				autoremove = ::iv::booldog::autoloadermixed.create< ::iv::autoremove >( debuginfo_macros );
			autoremove->_hmod = hmod;
			autoremove->_need_explicity_unregister = need_explicity_unregister;
			if( pautoremove )
			{
				autoremove->_autoremove_____ = pautoremove;
				autoremove->_new = 0;
			}
			else
			{
				autoremove->_autoremove2 = pautoremove2;
				autoremove->_new = 1;
			}
			autoremove->_removed = removed;
			autoremove->before_dll_free = before_dll_free;

			::booldog::interlocked::exchange( &autoremove->_state , ::iv::state_busy );

			IVBOO_METKA(867);
			if(_cs_inited)
			{
				cs1Enter(&_lock_autoremoves, 624);
			}
			IVBOO_METKA(866);
			_autoremoves___00.add( autoremove );
			IVBOO_METKA(865);
			if(_cs_inited)
				cs1Leave(&_lock_autoremoves);
			return autoremove;
		};
		::iv::dependency* create_dependency();
		static void rux_info_task( void* , void* udata )
		{
			IVBOO_FUNC2(111);
			{
				::iv::autoloaderclass* pautoloader = (::iv::autoloaderclass*)udata;
				pautoloader->_tempprivate_info_thread(::iv::debug::lineid, ::iv::debug::statement, &boolabel);
			}
		};
		static void onafterinit(void* udata, ::booldog::base::module* mod)
		{
			IVBOO_FUNC(43);
			::iv::autoloaderclass* pautoloader = (::iv::autoloaderclass*)udata;
			const char* module_name = 0;
			::booldog::result_mbchar __resmbchar(&::iv::booldog::autoloadermixed);
			module_udata* modudata = (module_udata*)mod->udata();
			::iv::autoloader_nm::module_struct* module_struct = modudata->_module_struct_old;
			if(modudata->_module_struct_ext)
				module_struct = &modudata->_module_struct_ext->_module_struct;
			if(module_struct)
			{
				module_name = module_struct->module_name;
				fast_register_autoremove(module_struct, 0, 0, threads_autoremove_stop, module_struct, true, 0, false, 0);
				fast_register_autoremove(module_struct, 0, 0, threads_autoremove_wait_for_stop, module_struct, true, 1, false, 0);
			}
			else
			{
				::booldog::utils::module::mbs::pathname< 32 >(&__resmbchar, &::iv::booldog::autoloadermixed, mod->handle()
					, debuginfo_macros);
				::booldog::utils::io::path::mbs::filename_without_extension(0, __resmbchar.mbchar, __resmbchar.mblen);
				module_name = __resmbchar.mbchar;
			}
			if(pautoloader->_log)
			{
				LOG_DEBUG(pautoloader->_log, "<autoloader>module(%pp,%pp) '%s' after dll_init"
					, mod, mod->handle(), module_name ? module_name : "exe");
			}
		};
		bool load_module(::booldog::result_module* resmod, const char* module, const char* module_search_path, bool dll_init_exec
			, param_t* dllinit_params, dll_exec_t pre_dll_init)
		{
			IVBOO_FUNC2(2);
      {
        BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s total load)"
          , module_search_path && module_search_path[0] != 0 ? module_search_path : ".", module);

			  ::booldog::param modsearch_paths_params[] =
			  {
				  BOOPARAM_PCHAR( module_search_path ) ,
				  BOOPARAM_NONE
			  };
			  ::booldog::named_param modload_params[] =
			  {
				  BOONAMED_PARAM_PPARAM( "search_paths" , modsearch_paths_params ) ,
				  BOONAMED_PARAM_BOOL( "exedir_as_root_path" , true ) ,
				  BOONAMED_PARAM_PCHAR("root_path", ::iv::root_path[0] ? ::iv::root_path : (const char*)0),
				  BOONAMED_PARAM_NONE
			  };
			  bool pre_dll_init_executed = false;
goto_begin:
        {
          BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s load)"
            , module_search_path && module_search_path[0] != 0 ? module_search_path : ".", module);
			    if(_loader.mbsload(resmod, &::iv::booldog::autoloadermixed, module, module_search_path ? modload_params : 0
				    , ::booldog::debug::info(__FILE__, __LINE__, 0, ::booldog::debug::info::statement_empty
				    , ::booldog::debug::info::lineid_empty, ::booldog::debug::info::sleep_empty, 0
				    , _ruxlog ? ruxlog_write : ::booldog::debug::info::write_log_empty)))
			    {
            module_search_path = module_search_path && module_search_path[0] != 0 ? module_search_path : ".";            

            mon.STOP();

				    pre_dll_init_executed = false;

            {
              BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s module lock)", module_search_path
                , module);
				      resmod->module->lock(debuginfo_macros);
            }
				    if(resmod->module->udata() == 0)
				    {
					    module_udata* modudata = ::iv::booldog::autoloadermixed.create< module_udata >(debuginfo_macros);
					    modudata->_pre_dll_init = false;
					    modudata->_module_struct_old = 0;
					    modudata->_module_struct_ext = 0;
					    modudata->_module = resmod->module;
					    modudata->_exception = 0;
					    modudata->_pre_pre_dll_free_executed = 0;

					    resmod->module->udata(modudata);

					    pre_dll_init_executed = true;
					    ::booldog::result_pointer resptr;
					    if(pre_dll_init || resmod->module->method(&resptr, &::iv::booldog::autoloadermixed, "pre_dll_init"
						    , debuginfo_macros))
					    {
                BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s pre_dll_init)"
                  , module_search_path, module);

						    if(pre_dll_init == 0)
							    pre_dll_init = (dll_exec_t)resptr.pres;

						    param_t exe[] = 
						    {
							    { PARAM_PVOID, "loader", &_loader },
							    { PARAM_PVOID, "mainheapallocator", &::iv::booldog::autoloaderheap },
							    { PARAM_PVOID, "mainmixedallocator", &::iv::booldog::autoloadermixed },
							    { PARAM_PVOID, "stack" , ::iv::booldog::autoloadermixed.holder.stack },
							    { 0, 0, 0 }
						    };
						    param_t iv[] = 
						    {
							    { PARAM_PVOID, "getmodulefunc", (void*)::iv::_getmodulefunc },
							    { PARAM_PVOID, "new_register_autoremove", (void*)::iv::_new_register_autoremove },
							    { PARAM_PVOID, "new_unregister_autoremove", (void*)::iv::_new_unregister_autoremove },
							    { PARAM_PVOID, "new_register_autoremove_with_return", (void*)::iv::_new_register_autoremove_with_return },
							    { PARAM_PVOID, "new_unregister_autoremove_with_return", (void*)::iv::_new_unregister_autoremove_with_return },
							    { PARAM_PVOID, "register_autoremove", (void*)::iv::_register_autoremove },
							    { PARAM_PVOID, "unregister_autoremove", (void*)::iv::_unregister_autoremove },
							    { PARAM_PVOID, "register_autoremove2", (void*)::iv::_register_autoremove2 },
							    { PARAM_PVOID, "unregister_autoremove2", (void*)::iv::_unregister_autoremove2 },
							    { PARAM_PVOID, "register_autoremove3", (void*)::iv::_register_autoremove3 },
							    {PARAM_PVOID, "fast_register_autoremove", (void*)::iv::_fast_register_autoremove},
							    {PARAM_PVOID, "fast_unregister_autoremove", (void*)::iv::_fast_unregister_autoremove},
							    {PARAM_PVOID, "initialize_module_struct", (void*)::iv::_initialize_module_struct},
							    {PARAM_PVOID, "global_data_set", (void*)::iv::autoloader_nm::_global_data_set},
							    {PARAM_PVOID, "global_data_get", (void*)::iv::autoloader_nm::_global_data_get},
							    {PARAM_PVOID, "dst_module_struct", (void*)&modudata->_module_struct_old},
							    {PARAM_PVOID, "dst_module_struct_ext", (void*)&modudata->_module_struct_ext},
							    { PARAM_PVOID, "unregister_autoremove3", (void*)::iv::_unregister_autoremove3 },
							    { PARAM_PVOID, "autoloader_unload" , (void*)::iv::unloadinternal },
							    { PARAM_PVOID, "autoloader_get_filename" , (void*)::iv::get_filenameinternal },
							    { PARAM_PVOID, "autoloader_root_path" , (void*)::iv::root_pathinternal },
							    { PARAM_PVOID, "autoloader_free" , (void*)::iv::freeinternal },
							    { PARAM_PVOID, "autoloader_method" , (void*)::iv::methodinternal },
							    { 0, 0, 0 }
						    };
						    param_t dllexecparams[] = 
						    {
							    { PARAM_PARAM, "exe", exe },
							    { PARAM_PARAM, "iv", iv },
							    { PARAM_PVOID, "SetHook", (void*)::iv::SetHook },
							    { PARAM_PVOID, "GetHook", (void*)::iv::GetHook },
							    { 0, 0, 0 }
						    };
						    IVBOO_NOTMY_FUNC(pre_dll_init, dllexecparams, 8, 9, module, "pre_dll_init", _a2_, thisfunct1);
						    modudata->_pre_dll_init = true;
						    LOG_DEBUG(_log, "<autoloader>module(%pp,%pp) '%s/%s' pre_dll_init", resmod->module
						      , resmod->module->handle(), module_search_path, module);
					    }
					    if( resmod->module->method( &resptr , &::iv::booldog::autoloadermixed , "exception_filter" , debuginfo_macros ) )
					    {
                BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s add exception_filter)"
                  , module_search_path, module);

						    ::iv::exception_struct* exception = ::iv::booldog::autoloadermixed.create< ::iv::exception_struct >(debuginfo_macros);
						    exception->_exception_filter = (::iv::exception_event_t)resptr.pres;

						    if(_cs_inited)
						    {
							    cs1Enter(&_lock_exceptions, 723);
						    }
						    exception->_prev = _exceptions;
						    exception->_next = 0;
						    if( _exceptions )
							    _exceptions->_next = exception;
						    _exceptions = exception;
						    if(_cs_inited)
							    cs1Leave(&_lock_exceptions);
						
						    module_udata* modudata = (module_udata*)resmod->module->udata();
						    modudata->_exception = exception;
					    }
					    resmod->module->unlock( debuginfo_macros );
              {
                BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s check module name)"
                  , module_search_path, module);

					      if( strcmp( module , "rux.engine" ) == 0 )
					      {
						      _ruxengineloaded = true;
						      if( resmod->module->method( &resptr , &::iv::booldog::autoloadermixed , "tempprivate_info_thread" 
							      , debuginfo_macros ) )
						      {
							      _tempprivate_info_thread 
								      = (::iv::tempprivate_info_thread_t)resptr.pres;
						      }
						      if( resmod->module->method( &resptr , &::iv::booldog::autoloadermixed , "temp_set_ruxlog_write" 
							      , debuginfo_macros ) )
						      {
							      _temp_set_ruxlog_write
								      = (::iv::temp_set_ruxlog_write_t)resptr.pres;
						      }
					      }
					      else if( strcmp( module , "stable" ) == 0 )
						      _stableloaded = true;
					      else if( strcmp( module , "mem" ) == 0 )
						      _memloaded = true;
					      else if( strcmp( module , "log-1" ) == 0 )
						      _logloaded = true;
					      else if( strcmp( module , "exceptions" ) == 0 )
						      _exceptionsloaded = true;
					      LOG_DEBUG(_log, "<autoloader>module(%pp,%pp) '%s/%s' is loaded", resmod->module, resmod->module->handle()
                  , module_search_path, module);
              }
				    }
				    else
					    resmod->module->unlock( debuginfo_macros );				
				    if( dll_init_exec )
				    {
					    IVBOO_NOTMY_FUNC_HELPER __ivboohelper(10, 11, module, "dll_init", _a2_, thisfunct1);
					    if( strcmp( module , "log-1" ) == 0 )
					    {
						    if( dllinit_params == 0 )
							    dllinit_params = (param_t*)::iv::logparams;
					    }
					    ::booldog::result res;

              BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s dll_init)"
                  , module_search_path, module);

					    if(resmod->module->init(&res, &::iv::booldog::autoloadermixed, dllinit_params, onafterinit, this, false, debuginfo_macros) == false)
					    {
                mon.STOP();

						    if(res.error_type == ::booldog::enums::result::error_type_booerr
							    && res.booerror == ::booldog::enums::result::booerr_type_module_is_deinitialized_and_must_be_unloaded)
						    {
                  BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s unload module need reload)"
                    , module_search_path, module);

							    ::iv::module_free_unload module_free_unload_struct = {this, false};
							    _loader.unload(&res, resmod->module, ::iv::onbeforeunload, &module_free_unload_struct, debuginfo_macros);

							    goto goto_begin;
						    }
						    else
						    {
                  BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s unload module dll_init error cause)"
                    , module_search_path, module);

							    resmod->copy(res);
							    ::iv::module_free_unload module_free_unload_struct = {this, false};
							    _loader.unload(&res, resmod->module, ::iv::onbeforeunload, &module_free_unload_struct, debuginfo_macros);
						    }
					    }
              else
                mon.STOP();
				    }
				    if(pre_dll_init_executed && resmod->succeeded())
				    {
					    ::booldog::result_pointer resptr;
					    if(resmod->module->method(&resptr, &::iv::booldog::autoloadermixed, "post_dll_init", debuginfo_macros))
					    {
                BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<loading>autoloader(%s/%s post_dll_init)"
                  , module_search_path, module);
						    ::iv::post_dll_init_t post_dll_init = (::iv::post_dll_init_t)resptr.pres;
						    IVBOO_NOTMY_FUNC( post_dll_init , 12 , 13 , module , "post_dll_init" , _a2_, thisfunct1);
						    LOG_DEBUG(_log , "<autoloader>module(%pp,%pp) '%s/%s' post_dll_init", resmod->module
                  , resmod->module->handle(), module_search_path, module);
					    }
				    }
			    }
			    else
			    {
            module_search_path = ".";

            mon.STOP();

				    ::booldog::result_mbchar reserror(&::iv::booldog::autoloadermixed); 
				    ::booldog::error::format(resmod, &::iv::booldog::autoloadermixed, reserror.mbchar, reserror.mblen, reserror.mbsize, debuginfo_macros);
				    LOG_ERROR(_log, "<autoloader>load_module, '%s/%s', '%s'", module_search_path, module, reserror.mbchar);
			    }
        }
			  return resmod->succeeded();
      }
		};
		static void oncheckmodules( void* thread , void* udata );
		void onbeforefree( ::booldog::base::module* mod );
		void onbeforefreeinternal( ::booldog::base::module* mod , ::booldog::module_handle hmod );
		void onbeforeunload( ::booldog::base::module* mod );
		void onbeforeunloadinternal( ::booldog::base::module* mod , ::booldog::module_handle hmod );

		static void new_register_autoremoveinternal( void* any_module_address , ::iv::autoremove2_t pautoremove , void* removed 
			, bool before_dll_free , int waveindex );
		static void new_unregister_autoremoveinternal( void* any_module_address , ::iv::autoremove2_t pautoremove 
			, void* removed , int waveindex );

		static void* new_register_autoremoveinternal_with_return( void* any_module_address , ::iv::autoremove2_t pautoremove 
			, void* removed , bool before_dll_free , int waveindex );
		static void new_unregister_autoremoveinternal_with_return( void* deleteautoremove , int waveindex );
		static bool remove_old_stable_and_memory(::iv::autoloaderclass* pautoloader);

		static void register_autoremoveinternal(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed, bool before_dll_free);
		static void register_autoremoveinternal2(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed, bool before_dll_free);
		static void register_autoremoveinternal3(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed, bool before_dll_free);
		static void unregister_autoremoveinternal(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed);
		static void unregister_autoremoveinternal2(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed);
		static void unregister_autoremoveinternal3(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed);
		static void* fast_register_autoremove(::iv::autoloader_nm::module_struct* module_struct, void* any_module_address, ::iv::autoremove_t poldautoremove, ::iv::autoremove2_t pnewautoremove
			, void* removed, bool before_dll_free, int waveindex, bool need_explicity_unregister, void* reserved);
		static void fast_unregister_autoremove(::iv::autoloader_nm::module_struct* module_struct, void* handle, void* any_module_address, ::iv::autoremove_t poldautoremove
			, ::iv::autoremove2_t pnewautoremove, void* removed, int waveindex, void* reserved);
		static void initialize_module_struct(::iv::autoloader_nm::module_struct* module_struct, void* reserved);
		static void global_data_set(const char* key, const char* value, void* reserved);
		static const char* global_data_get(const char* key, void* reserved);
		static void threads_autoremove_stop(::booldog::module_handle hmod, void* removed);
		static void threads_autoremove_wait_for_stop(::booldog::module_handle hmod, void* removed);
		static void threads_pool_autoremove_wait_for_stop(::booldog::module_handle hmod, void* removed);

		static void* getmodulefuncinternal( void* any_module_address , const char* module_name , const char* module_search_path , bool dll_init 
			, param_t* dll_init_params , const char* funcname , void** module );
		static void* load_and_create_deps(void* any_module_address, const char* module_name, const char* module_search_path
			, bool dll_init, param_t* dll_init_params, const char* funcname, void** module, dll_exec_t pre_dll_init);
		void unloadinternal( void* any_module_address , void* module );
		void freeinternal( void* ptr );
		void* methodinternal( void* module , const char* name );
		char* get_filenameinternal( void* module );
		void autoload(const char* js)
		{
			IVBOO_FUNC(3);

			LOG_DEBUG(_log, "<autoloader>autoload");

			::booldog::data::json::serializator serializator( &::iv::booldog::autoloadermixed );
			::booldog::data::json::result resjson( &serializator );
			if(::booldog::data::json::parse< 1 >( &resjson , &::iv::booldog::autoloadermixed , js ))
			{
				::booldog::data::json::object root = (*resjson.serializator);
				if(root.isarray())
				{
					::booldog::result_module resmod;
							
					param_t* parray = 0;
					size_t parraycount = 0;

					const char* module = 0 , * search_path = 0;
					bool dll_init_exec = false;
					::booldog::data::json::object node , param;
					for( size_t index = 0 ; index < root.count() ; index++ )
					{
						node = root[ index ];
						if( node.isobject() )
						{
							module = node( "module" ).value;
							search_path = node( "search_path" ).value;
							param_t* p = 0;
							dll_init_exec = node( "dll_init" )( "exec" ).value;
							if( dll_init_exec )
							{
								param = node( "dll_init" )( "param" );
								if( param.count() )
								{
									if( param.count() + 1 > parraycount )
									{
										parraycount = param.count() + 1;
										parray = ::iv::booldog::autoloadermixed.realloc_array< param_t >( parray , parraycount
											, debuginfo_macros );
									}
									p = parray;
									const char* type = 0 , * name = 0;
									for( size_t index0 = 0 ; index0 < param.count() ; index0++ )
									{
										type = param[ index0 ]( "type" ).value;
										name = param[ index0 ]( "name" ).value;
										if( type && name )
										{
											if( strcmp( type , "PARAM_PCHAR" ) == 0 )
											{
												parray[ index0 ].name = name;
												parray[ index0 ].val = (const char*)param[ index0 ]( "val" ).value;
												parray[ index0 ].type = PARAM_PCHAR;
											}
										}
										else
										{
											p = 0;
											break;
										}
									}
									parray[ param.count() ].name = 0;
									parray[ param.count() ].val = 0;
									parray[ param.count() ].type = PARAM_NONE;
								}
							}
							LOG_DEBUG(_log, "<autoloader>autoload, module(%s), search_path(%s)", module ? module : "null"
								, search_path ? search_path : "null");
							getmodulefuncinternal(&::iv::pautoloader, module, search_path, dll_init_exec, p, 0, 0);
						}
					}
					if( parray )
						::iv::booldog::autoloadermixed.free( parray );
				}
				else
					LOG_ERROR(_log, "<autoloader>json %s from file init/autoloader/autoloader.json is not array", js);
			}
			else
				LOG_ERROR(_log, "<autoloader>cannot parse json %s from file init/autoloader/autoloader.json", js);
		};
		void initialize()
		{
      IVBOO_FUNC(398);
			::booldog::result_file resfile;
			::booldog::param filesearch_paths_params[] =
			{
				BOOPARAM_PCHAR( "init/autoloader" ) ,
				BOOPARAM_NONE
			};
			::booldog::named_param fileload_params[] =
			{
				BOONAMED_PARAM_PPARAM( "search_paths" , filesearch_paths_params ) ,
				BOONAMED_PARAM_BOOL( "exedir_as_root_path" , true ) ,
				BOONAMED_PARAM_PCHAR("root_path", ::iv::root_path[0] ? ::iv::root_path : 0),
				BOONAMED_PARAM_NONE
			};

			LOG_DEBUG(_log, "<autoloader>initialize, %s", fileload_params[2].pcharvalue ? fileload_params[2].pcharvalue : "null");

			if(::booldog::io::file::mbsopen(&resfile, &::iv::booldog::autoloadermixed, "autoloader.json"
				, ::booldog::enums::io::file_mode_read, fileload_params))
			{
				::booldog::result_buffer resbuf( &::iv::booldog::autoloadermixed );
				if(resfile.file->readall< 1024 >( &resbuf , &::iv::booldog::autoloadermixed , debuginfo_macros ))
				{
					if(resbuf.buf[resbuf.bufdatasize - 1] != 0)
					{
						resbuf.bufdatasize++;
						if( resbuf.bufdatasize > resbuf.bufsize )
							resbuf.buf = resbuf.allocator->realloc_array< unsigned char >( resbuf.buf , resbuf.bufdatasize 
								, debuginfo_macros );
						resbuf.buf[ resbuf.bufdatasize - 1 ] = 0;
					}
					char* js = (char*)resbuf.buf;
					if( resbuf.bufdatasize > 3 && ::memcmp( resbuf.buf , ::booldog::consts::utf8::byte_order_mark , 3 ) == 0 )
						js = (char*)&resbuf.buf[ 3 ];
					autoload(js);
				}
				else
					LOG_ERROR(_log, "<autoloader>cannot readall from file init/autoloader/autoloader.json");
				resfile.file->close( &resfile );
			}
			else
				LOG_ERROR(_log, "<autoloader>cannot open file init/autoloader/autoloader.json");
		};
		static void exception( ::iv::exceptions::information* info )
		{
			::iv::exception_struct* remove = ::iv::pautoloader->_exceptions;
			for(;;)
			{
				if( remove == 0 )
					break;
				remove->_exception_filter(info->tid);
				remove = remove->_prev;
			}
		}
		autoloaderclass()
			: _depends(0), _exceptions(0), _log(0), _tempprivate_info_thread(0), _rux_info_task_handle(0)
			, _loader( &::iv::booldog::autoloadermixed ) , _stableloaded( false ) , _ruxlog( 0 ) , _temp_set_ruxlog_write( 0 ) 
			, _logloaded( false ) , _exceptionsloaded( false ) , _memloaded( false )
			, _ruxengineloaded( false ), _stable_hmod(0), _stable_memory_errno(&::iv::booldog::autoloadermixed), _cs_inited(false)
		{
		}
		~autoloaderclass()
		{
			::iv::module_free_unload module_free_unload_struct = {this, false};
			::booldog::result_module stablemod , logmod , exceptionsmod , memmod , ruxenginemod;
			if(_stableloaded)
			{
				if(load_module(&stablemod, "stable", "lib", true, 0, 0) == false)
					load_module(&stablemod, "stable", "../lib", true, 0, 0);
			}
			{
				IVBOO_FUNC2(609);
				{
					::booldog::result_mbchar resmbchar(&::iv::booldog::autoloadermixed), __resmbchar(&::iv::booldog::autoloadermixed);
					::booldog::result res;
					::booldog::module_handle curmodhandle = ::iv::autoloader_nm::_module_struct_ext._module_struct.module_handle;
					bool exists_modules = true;
					::booldog::array< ::booldog::module_handle > exists_modules_excepts(&::iv::booldog::autoloadermixed);
					if(_memloaded)
					{
						if(load_module(&memmod, "mem", "lib", true, 0, 0) == false)
							load_module(&memmod, "mem", "../lib", true, 0, 0);
						if(memmod.module)
							exists_modules_excepts.add(memmod.module->handle());
					}
					if( _logloaded )
					{
						if(load_module(&logmod, "log-1", "", true, 0, 0) == false)
							load_module(&logmod, "log-1", "..", true, 0, 0);
						if(logmod.module)
							exists_modules_excepts.add(logmod.module->handle());
					}
					if( _exceptionsloaded )
					{
						if(load_module(&exceptionsmod, "exceptions", "lib", true, 0, 0) == false)
							load_module(&exceptionsmod, "exceptions", "../lib", true, 0, 0);
						if(exceptionsmod.module)
							exists_modules_excepts.add(exceptionsmod.module->handle());
					}
					if(_ruxengineloaded)
					{
						if(load_module(&ruxenginemod, "rux.engine", "", true, 0, 0) == false)
							load_module(&ruxenginemod, "rux.engine", "..", true, 0, 0);
						if(ruxenginemod.module)
							exists_modules_excepts.add(ruxenginemod.module->handle());
					}
					fill_exists_modules_excepts(exists_modules_excepts);
					{
						::booldog::allocators::single_threaded::mixed<1024> mixed(&::iv::booldog::autoloaderheap);
						{
							if( _rux_info_task_handle )
							{
								::iv::tasks::noncritical::remove( _rux_info_task_handle );
								_rux_info_task_handle = 0;
							}
							if( ::iv::pautoloader->_temp_set_ruxlog_write )
								::iv::pautoloader->_temp_set_ruxlog_write( 0 );							

							onbeforefreeinternal(0, curmodhandle);
							onbeforeunloadinternal(0, curmodhandle);
							onbeforefreeinternal(0, 0);
							onbeforeunloadinternal(0, 0);
							if(_cs_inited)
							{
								cs1Enter(&_lock, 819);
							}

							::iv::dependency* depend = _depends;
							for(;;)
							{
								if(depend == 0)
									break;
								if(::booldog::interlocked::compare_exchange(&depend->_state, 0, 0) == ::iv::state_busy)
								{
									module_udata* modudata = (module_udata*)depend->module->udata();

									if(::booldog::interlocked::compare_exchange(&modudata->_pre_pre_dll_free_executed, 1, 0) == 0)
									{
										::booldog::result_pointer resptr;
										if(depend->module->method(&resptr, &::iv::booldog::autoloadermixed
											, "pre_pre_dll_free", debuginfo_macros))
										{
                      BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(%s pre_pre_dll_free)"
                        , resmbchar.mbchar);

											if(resmbchar.mbchar)
												resmbchar.mbchar[0] = 0;
											resmbchar.mblen = 0;				
											::booldog::utils::module::mbs::pathname< 32 >(&resmbchar, &::iv::booldog::autoloadermixed
												, depend->module->handle(), debuginfo_macros);
											::booldog::utils::io::path::mbs::filename_without_extension(0, resmbchar.mbchar
												, resmbchar.mblen);

											pre_pre_dll_free_t pre_pre_dll_free = (pre_pre_dll_free_t)resptr.pres;
											if(_cs_inited)
												cs1Leave(&_lock);
											IVBOO_NOTMY_FUNC(pre_pre_dll_free, 114, 115, resmbchar.mbchar, "pre_pre_dll_free", _a2_, thisfunct1);
											if(_cs_inited)
											{
												cs1Enter(&_lock, 818);
											}
										}
									}
								}
								depend = depend->_prev;
							}
				
							depend = _depends;
							for(;;)
							{
								if(depend == 0)
									break;
								if(::booldog::interlocked::compare_exchange(&depend->_state, 0, 0) == ::iv::state_busy)
								{
									bool unload = false;
									::iv::dependency* depend_pre_dll_free = _depends;
									for(;;)
									{
										if(depend_pre_dll_free == 0)
											break;
										if(::booldog::interlocked::compare_exchange(&depend_pre_dll_free->_state, 0, 0)
											== ::iv::state_busy)
										{
											if(depend_pre_dll_free->module->handle() == depend->dependent_modhandle)
											{
												if( resmbchar.mbchar )
													resmbchar.mbchar[ 0 ] = 0;
												resmbchar.mblen = 0;				
												::booldog::utils::module::mbs::pathname< 32 >( &resmbchar , &::iv::booldog::autoloadermixed
													, depend->module->handle() , debuginfo_macros );
												::booldog::utils::io::path::mbs::filename_without_extension( 0 , resmbchar.mbchar , resmbchar.mblen );

												::booldog::result_pointer resptr;
												if( depend_pre_dll_free->module->method( &resptr , &::iv::booldog::autoloadermixed
													, "pre_dll_free" , debuginfo_macros ) )
												{
													pre_dll_free_t pre_dll_free = (pre_dll_free_t)resptr.pres;
													if(_cs_inited)
														cs1Leave(&_lock);
                          {
                            BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(%s pre_dll_free)"
                              , depend->dependent_modulepathname.mbchar);
													  unload = IVBOO_NOTMY_FUNC_RES< bool >( pre_dll_free , resmbchar.mbchar , 14 , 15 
														  , depend->dependent_modulepathname.mbchar , "pre_dll_free" , _a2_, thisfunct1);
                          }

													if( unload == false && strncmp( resmbchar.mbchar , "lib" , 3 ) == 0 )
													{
														::booldog::mem::remove< char >( 0 , resmbchar.mbchar , resmbchar.mbsize , 3 );
														resmbchar.mblen -= 3;
                            {
                              BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(%s pre_dll_free)"
                                , depend->dependent_modulepathname.mbchar);
														  unload = IVBOO_NOTMY_FUNC_RES< bool >( pre_dll_free , resmbchar.mbchar , 16 , 17 
															  , depend->dependent_modulepathname.mbchar , "pre_dll_free" , _a2_, thisfunct1);
                            }
													}
													if(_cs_inited)
													{
														cs1Enter(&_lock, 817);
													}
												}
												break;
											}
										}
										depend_pre_dll_free = depend_pre_dll_free->_prev;
									}
									if( unload )
									{
										::booldog::interlocked::exchange( &depend->_state , ::iv::state_pending_in_deinit );
										if(_cs_inited)
											cs1Leave(&_lock);
										if( ::booldog::interlocked::compare_exchange( &depend->_inited_refs , 0 , 0 ) )
										{
                      BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(%s dll_free)"
                        , resmbchar.mbchar);
											IVBOO_NOTMY_FUNC_HELPER __ivboohelper(18, 19, resmbchar.mbchar, "dll_free", _a2_, thisfunct1);
											do
											{
												depend->module->free(&res, &::iv::booldog::autoloadermixed, ::iv::onbeforefree
													, &module_free_unload_struct, debuginfo_macros );
											}
											while( ::booldog::interlocked::decrement( &depend->_inited_refs ) );
										}
										{
                      BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(%s unload)"
                        , resmbchar.mbchar);
											IVBOO_NOTMY_FUNC_HELPER __ivboohelper(20, 21, resmbchar.mbchar, "unload", _a2_, thisfunct1);
											do
											{
												_loader.unload(&res, depend->module, ::iv::onbeforeunload, &module_free_unload_struct
													, debuginfo_macros);
											}
											while( ::booldog::interlocked::decrement( &depend->_refs ) );
										}
										::booldog::interlocked::exchange( &depend->_state , ::iv::state_free );
										if(_cs_inited)
										{
											cs1Enter(&_lock, 816);
										}
									}
								}
								depend = depend->_prev;
							}

							exists_modules = true;							
							try_unload_modules(true, true, resmbchar, __resmbchar, res, module_free_unload_struct, curmodhandle
								, exists_modules, exists_modules_excepts);
							if(exists_modules)
							{
								::booldog::result_mbchar filename(&mixed), pathname(&mixed);
								::booldog::utils::executable::mbs::pathname<16>(&pathname, pathname.mballocator, debuginfo_macros);
								::booldog::utils::io::path::mbs::filename(&filename, filename.mballocator, pathname.mbchar,
									0, SIZE_MAX, debuginfo_macros);
								::booldog::utils::string::mbs::assign<16>(0, filename.mballocator, false, filename.mblen
									, filename.mbchar, filename.mblen, filename.mbsize, ".snapshot", 0, SIZE_MAX, debuginfo_macros);

								::booldog::result_file resfile;
								if(::booldog::io::file::mbsopen(&resfile, &mixed, filename.mbchar
									, ::booldog::enums::io::file_mode_append|::booldog::enums::io::file_mode_write
									, "stable", true) == false)
								{
									::booldog::io::file::mbsopen(&resfile, &mixed, filename.mbchar
										, ::booldog::enums::io::file_mode_create|::booldog::enums::io::file_mode_append|::booldog::enums::io::file_mode_write
										, "stable", true);
								}
								const char* logtext = "\nUnresolved module dependency(es), see log/booter/log001.txt\n";
								if(resfile.succeeded())
								{
									size_t written = 0;
									resfile.file->write(0, (::booldog::byte*)logtext, strlen(logtext), SIZE_MAX, written);
                  ::booldog::utils::console::err::mbs::printf(0, &mixed, ::booldog::enums::console::red, debuginfo_macros, logtext);
								
									depend = _depends;
									for(;;)
									{
										if(depend == 0)
											break;
										if(::booldog::interlocked::compare_exchange(&depend->_state, 0, 0) == ::iv::state_busy)
										{
											if(resmbchar.mbchar)
												resmbchar.mbchar[0] = 0;
											resmbchar.mblen = 0;
											::booldog::utils::module::mbs::pathname< 32 >(&resmbchar
												, &::iv::booldog::autoloadermixed, depend->module->handle(), debuginfo_macros);
											::booldog::utils::io::path::mbs::filename_without_extension(0, resmbchar.mbchar
												, resmbchar.mblen);
											if(depend->dependent_modulepathname.mblen)
												::booldog::utils::io::path::mbs::filename_without_extension(&__resmbchar
												, __resmbchar.mballocator, depend->dependent_modulepathname.mbchar, 0, SIZE_MAX
												, debuginfo_macros);
											else
												::booldog::utils::string::mbs::assign< 16 >(0, __resmbchar.mballocator, false, 0
												, __resmbchar.mbchar, __resmbchar.mblen, __resmbchar.mbsize, "check for unload"
												, 0, SIZE_MAX, debuginfo_macros);

											::booldog::utils::string::mbs::format(&filename, filename.mballocator
												, debuginfo_macros, "module(%p,%p) '%s' depends on module '%s'\n"
												, depend->module, depend->module->handle()
												, __resmbchar.mbchar ? __resmbchar.mbchar : "exe"
												, resmbchar.mbchar ? resmbchar.mbchar : "null");

											resfile.file->write(0, (::booldog::byte*)filename.mbchar, filename.mblen, SIZE_MAX
												, written);
                      ::booldog::utils::console::err::mbs::printf(0, &mixed, ::booldog::enums::console::red, debuginfo_macros, filename.mbchar);
										}
										depend = depend->_prev;
									}

									resfile.file->close( &resfile );
								}
								int crush = printf("%s, module dependency bug, EXCEPT!!!\n", __FILE__);
								printf("%d\n", crush / (crush / 170070));
							}
							if(_cs_inited)
								cs1Leave(&_lock);
						}
					}
					if(ruxenginemod.module)
					{
            {
              BOO_MONITORING mon(_log, "<unloading>autoloader(rux.engine dll_free)");
              ruxenginemod.module->free(0, &::iv::booldog::autoloadermixed, ::iv::onbeforefree, &module_free_unload_struct, debuginfo_macros);
            }
            {
              BOO_MONITORING mon(_log, "<unloading>autoloader(rux.engine unload)");
						  _loader.unload(0, ruxenginemod.module, ::iv::onbeforeunload, &module_free_unload_struct, debuginfo_macros);
            }
						try_unload_modules(false, true, resmbchar, __resmbchar, res, module_free_unload_struct, curmodhandle
							, exists_modules, exists_modules_excepts);
					}
					if(exceptionsmod.module)
					{
            {
              BOO_MONITORING mon(_log, "<unloading>autoloader(exceptions free)");
              exceptionsmod.module->free(0, &::iv::booldog::autoloadermixed, ::iv::onbeforefree, &module_free_unload_struct, debuginfo_macros );
            }
            {
              BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(exceptions unload)");
              _loader.unload(0, exceptionsmod.module, ::iv::onbeforeunload, &module_free_unload_struct, debuginfo_macros);
            }
						try_unload_modules(false, true, resmbchar, __resmbchar, res, module_free_unload_struct, curmodhandle
							, exists_modules, exists_modules_excepts);
					}
					if( _ruxlog )
					{
						delete _ruxlog;
						_ruxlog = 0;
					}
					if( _log )
					{
						delete _log;
						_log = 0;
					}
					if(logmod.module)
					{
						logmod.module->free(0, &::iv::booldog::autoloadermixed, ::iv::onbeforefree, &module_free_unload_struct, debuginfo_macros);
						_loader.unload(0, logmod.module, ::iv::onbeforeunload, &module_free_unload_struct, debuginfo_macros);
						try_unload_modules(false, true, resmbchar, __resmbchar, res, module_free_unload_struct, curmodhandle
							, exists_modules, exists_modules_excepts);
					}
					if(memmod.module)
					{
						memmod.module->free(0, &::iv::booldog::autoloadermixed, ::iv::onbeforefree, &module_free_unload_struct, debuginfo_macros);
						_loader.unload(0, memmod.module, ::iv::onbeforeunload, &module_free_unload_struct, debuginfo_macros);
						try_unload_modules(false, true, resmbchar, __resmbchar, res, module_free_unload_struct, curmodhandle
							, exists_modules, exists_modules_excepts);
					}
				}
			}
			IV_RWLOCKDESTROY(&_lock_global_datas);
			cs1Delete(&_lock_autoremoves3);
			cs1Delete(&_lock_autoremoves2);
			cs1Delete(&_lock_autoremoves);
			cs1Delete(&_lock_exceptions);
			cs1Delete(&_lock);
			_cs_inited = false;
			if(stablemod.module)
			{
        ST2_MONITORING_WRITE("<unloading>end stop app");

				_stable_hmod = stablemod.module->handle();
				stablemod.module->free(0, &::iv::booldog::autoloadermixed, ::iv::onbeforefree, &module_free_unload_struct, debuginfo_macros);
				pStableContainer.empty(E_GetDWHashS, E_AddActive, E_SetThreadName, E_SetThreadName2, E_SetActive, E_SetActiveFAST
          , E_RemoveActive, E_StableInit, E_StableFree, E_StablePrint, E_SetLimitStackFunction, E_exception_filter
					, E_Print_thread_context, E_SetThreadFamily, E_RemoveThreadFamily, E_GetThreadFamily, E_SetThreadTRACK
          , E_sbl_SetOptForThread, E_GetDWHashSFAST, E_WaitAnotherThread, E_AddThreadTrack, E_RemoveThreadTrack, E_sbl_GetCPU
          , E_sbl_GetCPUSNAP, E_sbl_FreeSNAP, E_rs_GetContainer, E_rs_FreeContainer, E_rs_Close, E_rs_Open, 0, 0, 0, 0, 0, 0);
				_loader.unload(0, stablemod.module, ::iv::onbeforeunload, &module_free_unload_struct, debuginfo_macros);
			}
			{
				::iv::autoremove* autoremove = _autoremoves___00.first();
				for( ; ; )
				{
					if( autoremove == 0 )
						break;
					::iv::autoremove* prev = autoremove->_doubly_linked_list_next;
					::iv::booldog::autoloadermixed.destroy( autoremove );
					autoremove = prev;
				}

				autoremove = _autoremoves2___00.first();
				for( ; ; )
				{
					if( autoremove == 0 )
						break;
					::iv::autoremove* prev = autoremove->_doubly_linked_list_next;
					::iv::booldog::autoloadermixed.destroy( autoremove );
					autoremove = prev;
				}
				autoremove = _autoremoves3___00.first();
				for(;;)
				{
					if( autoremove == 0 )
						break;
					::iv::autoremove* prev = autoremove->_doubly_linked_list_next;
					::iv::booldog::autoloadermixed.destroy( autoremove );
					autoremove = prev;
				}
				autoremove = _avail_autoremoves.pop();
				while(autoremove)
				{
					::iv::booldog::autoloadermixed.destroy( autoremove );
					autoremove = _avail_autoremoves.pop();
				}
			}

			{
				::iv::dependency* depend = _depends;
				for( ; ; )
				{
					if( depend == 0 )
						break;
					::iv::dependency* prev = depend->_prev;
					::iv::booldog::autoloadermixed.destroy( depend );
					depend = prev;
				}
			}
			{
				::iv::global_data_struct* global_data = _global_datas.first();
				while(global_data)
				{
					::iv::global_data_struct* toremove = global_data;
					global_data = global_data->_doubly_linked_list_next;
					::iv::booldog::autoloadermixed.free(toremove->_value);
					::iv::booldog::autoloadermixed.destroy(toremove);
				}
			}
			{
				for(size_t index = 0;index < _stable_memory_errno.count();++index)
					::iv::booldog::autoloadermixed.free(_stable_memory_errno[index]);
			}
		}
		void fill_exists_modules_excepts(::booldog::array< ::booldog::module_handle >& exists_modules_excepts)
		{
			IVBOO_FUNC2(929);
			{
				if(exists_modules_excepts.count())
				{
					if(_cs_inited)
					{
						cs1Enter(&_lock, 899);
					}
					size_t first_index = 0, last_index = 0;
					do
					{
						first_index = last_index;
						::iv::dependency* depend = _depends;
						while(depend)
						{
							if(::booldog::interlocked::compare_exchange(&depend->_state, 0, 0) == ::iv::state_busy)
							{
								for(size_t index = first_index;index < exists_modules_excepts.count();++index)
								{										
									if(depend->dependent_modhandle == exists_modules_excepts[index])
									{
										::booldog::module_handle handle = depend->module->handle();
										for(index = 0;index < exists_modules_excepts.count();++index)
										{
											if(handle == exists_modules_excepts[index])
											{
												handle = 0;
												break;
											}
										}
										if(handle)
										{
											exists_modules_excepts.add(handle);
											if(first_index == last_index)
												last_index = exists_modules_excepts.count() - 1;
										}
										break;
									}										
								}
							}
							depend = depend->_prev;
						}
					}
					while(first_index != last_index);
					if(_cs_inited)
						cs1Leave(&_lock);
				}
			}
		}
		void try_unload_modules(bool locked, bool isdestructor, ::booldog::results::mbchar& resmbchar
			, ::booldog::results::mbchar& __resmbchar, ::booldog::result& res, ::iv::module_free_unload& module_free_unload_struct
			, ::booldog::module_handle curmodhandle, bool& exists_modules, ::booldog::array< ::booldog::module_handle >& exists_modules_excepts)
		{
			IVBOO_FUNC2(919);
			{
				if(locked == false && _cs_inited)
				{
					cs1Enter(&_lock, 899);
				}
				bool was_unloaded = true;
				while(was_unloaded)
				{
					was_unloaded = false;
					exists_modules = false;
					::iv::dependency* depend = _depends;
					while(depend)
					{
						if(::booldog::interlocked::compare_exchange(&depend->_state, 0, 0) == ::iv::state_busy)
						{
							if(resmbchar.mbchar)
								resmbchar.mbchar[0] = 0;
							resmbchar.mblen = 0;
							::booldog::utils::module::mbs::pathname< 32 >(&resmbchar, &::iv::booldog::autoloadermixed
								, depend->module->handle(), debuginfo_macros);
							::booldog::utils::io::path::mbs::filename_without_extension(0, resmbchar.mbchar, resmbchar.mblen);

							if(depend->dependent_modulepathname.mblen)
								::booldog::utils::io::path::mbs::filename_without_extension(&__resmbchar, __resmbchar.mballocator
								, depend->dependent_modulepathname.mbchar, 0, SIZE_MAX, debuginfo_macros);
							else
								::booldog::utils::string::mbs::assign< 16 >(0, __resmbchar.mballocator, false, 0, __resmbchar.mbchar
								, __resmbchar.mblen, __resmbchar.mbsize, "check for unload", 0, SIZE_MAX, debuginfo_macros);

							IVBOO_NOTMY_FUNC_HELPER __ivboohelper(22, 23, resmbchar.mbchar, __resmbchar.mbchar, _a2_, thisfunct1);
							if(_log)
								LOG_DEBUG(_log, "<autoloader>module(%pp,%pp) '%s' depends on module '%s', check for unload"
								, depend->module, depend->module->handle(), __resmbchar.mbchar ? __resmbchar.mbchar : "exe"
								, resmbchar.mbchar ? resmbchar.mbchar : "null");

							bool unload = false;
							if(isdestructor && depend->dependent_modhandle == 0)
								unload = true;
							else if(isdestructor && depend->dependent_modhandle == curmodhandle)
								unload = true;
							else
							{
								::booldog::module_handle modhandle = ::booldog::utils::module::mbs::handle(&res
									, &::iv::booldog::autoloadermixed, depend->dependent_modulepathname.mblen
									? depend->dependent_modulepathname.mbchar : 0, debuginfo_macros);
								if(depend->dependent_modhandle != modhandle)
									unload = true;
								if(modhandle)
									::booldog::utils::module::free(&res, &::iv::booldog::autoloadermixed, modhandle, debuginfo_macros);
							}
							if(unload)
							{
								was_unloaded = true;
								::booldog::interlocked::exchange(&depend->_state, ::iv::state_pending_in_deinit);
								if(_cs_inited)
									cs1Leave(&_lock);
								if(::booldog::interlocked::compare_exchange(&depend->_inited_refs, 0, 0))
								{
									IVBOO_NOTMY_FUNC_HELPER __ivboohelper(24, 25, resmbchar.mbchar, "dll_free", _a2_, thisfunct1);
									do
									{
										depend->module->free(&res, &::iv::booldog::autoloadermixed, ::iv::onbeforefree
											, &module_free_unload_struct, debuginfo_macros);
									}
									while(::booldog::interlocked::decrement(&depend->_inited_refs));
								}
								{
									IVBOO_NOTMY_FUNC_HELPER __ivboohelper(26, 27, resmbchar.mbchar, "unload", _a2_, thisfunct1);
									do
									{
										_loader.unload(&res, depend->module, ::iv::onbeforeunload, &module_free_unload_struct
											, debuginfo_macros);
									}
									while(::booldog::interlocked::decrement(&depend->_refs));
								}
								::booldog::interlocked::exchange(&depend->_state, ::iv::state_free);
								if(_cs_inited)
								{
									cs1Enter(&_lock, 815);
								}
							}
							else if(exists_modules == false)
							{
								exists_modules = true;
								for(size_t index = 0;index < exists_modules_excepts.count();++index)
								{										
									if(depend->dependent_modhandle == exists_modules_excepts[index])
									{
										exists_modules = false;
										break;
									}										
								}
							}
						}
						depend = depend->_prev;
					}
				}
				if(locked == false && _cs_inited)
					cs1Leave(&_lock);
			}
		}
	};
	struct listdir_info
	{
		::iv::autoloaderclass* pautoloader;
		::booldog::result_mbchar* stable_toremove_mbchar;
		int stable_count;
		::booldog::result_mbchar* memory_toremove_mbchar;
		int memory_count;
		::booldog::result_mbchar* mbchar0;
		::booldog::result_mbchar* mbchar1;
	};
	bool listdir_remove(::booldog::allocator* allocator, void* udata, const char* pathname
		, const char* entry_name, ::booldog::enums::io::entry_type entry_type)
	{
    IVBOO_FUNC(397);
		{
			listdir_info* info00 = (listdir_info*)udata;
			LOG_DEBUG(info00->pautoloader->_log, "end listdir_remove");
			if(entry_type == ::booldog::enums::io::directory)
			{
				::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false, 0
					, info00->memory_toremove_mbchar->mbchar, info00->memory_toremove_mbchar->mblen
					, info00->memory_toremove_mbchar->mbsize, pathname, 0, SIZE_MAX);
				if(info00->memory_toremove_mbchar->mbchar[info00->memory_toremove_mbchar->mblen - 1] != '/'
					&& info00->memory_toremove_mbchar->mbchar[info00->memory_toremove_mbchar->mblen - 1] != '\\')
				{
					::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false
						, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbchar
						, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbsize
						, &::booldog::io::mbs::slash, 0, 1);
				}
				::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false
					, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbchar
					, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbsize, entry_name, 0
					, SIZE_MAX);

				::booldog::io::directory::mbs::listdir(0, info00->memory_toremove_mbchar->mballocator
					, info00->memory_toremove_mbchar->mbchar, listdir_remove, info00);

				::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false, 0
					, info00->memory_toremove_mbchar->mbchar, info00->memory_toremove_mbchar->mblen
					, info00->memory_toremove_mbchar->mbsize, pathname, 0, SIZE_MAX);
				if(info00->memory_toremove_mbchar->mbchar[info00->memory_toremove_mbchar->mblen - 1] != '/'
					&& info00->memory_toremove_mbchar->mbchar[info00->memory_toremove_mbchar->mblen - 1] != '\\')
				{
					::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false
						, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbchar
						, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbsize
						, &::booldog::io::mbs::slash, 0, 1);
				}
				::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false
					, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbchar
					, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbsize, entry_name, 0
					, SIZE_MAX);
				::booldog::result res;
				if(::booldog::utils::io::mbs::rmdir(&res, info00->memory_toremove_mbchar->mbchar) == false)
				{
					::booldog::result_mbchar reserror(allocator); 
					::booldog::error::format(&res, allocator, reserror.mbchar, reserror.mblen, reserror.mbsize);
					LOG_DEBUG(info00->pautoloader->_log, "rmdir %s, errno %s", info00->memory_toremove_mbchar->mbchar, reserror.mbchar);
				}
			}
			else if(entry_type == ::booldog::enums::io::file)
			{
				::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false, 0
					, info00->memory_toremove_mbchar->mbchar, info00->memory_toremove_mbchar->mblen
					, info00->memory_toremove_mbchar->mbsize, pathname, 0, SIZE_MAX);
				if(info00->memory_toremove_mbchar->mbchar[info00->memory_toremove_mbchar->mblen - 1] != '/'
					&& info00->memory_toremove_mbchar->mbchar[info00->memory_toremove_mbchar->mblen - 1] != '\\')
				{
					::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false
						, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbchar
						, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbsize
						, &::booldog::io::mbs::slash, 0, 1);
				}
				::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false
					, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbchar
					, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbsize, entry_name, 0
					, SIZE_MAX);
				::booldog::result res;
				if(::booldog::utils::io::file::mbs::remove(&res, allocator, info00->memory_toremove_mbchar->mbchar
					, info00->memory_toremove_mbchar->mblen) == false)
				{
					::booldog::result_mbchar reserror(allocator); 
					::booldog::error::format(&res, allocator, reserror.mbchar, reserror.mblen, reserror.mbsize);
					LOG_DEBUG(info00->pautoloader->_log, "remove %s, errno %s", info00->memory_toremove_mbchar->mbchar, reserror.mbchar);
				}
			}
			LOG_DEBUG(info00->pautoloader->_log, "end listdir_remove");
		}
		return true;
	};
	bool listdir_count(::booldog::allocator* allocator, void* udata, const char* pathname
		, const char* entry_name, ::booldog::enums::io::entry_type entry_type)
	{
    IVBOO_FUNC(396);
		{
			if(entry_type == ::booldog::enums::io::directory)
			{
				listdir_info* info00 = (listdir_info*)udata;
				size_t index = 0;
				for(;index < info00->pautoloader->_stable_memory_errno.count();++index)
				{
					if(strcmp(info00->pautoloader->_stable_memory_errno[index], entry_name) == 0)
						break;
				}
				if(index >= info00->pautoloader->_stable_memory_errno.count())
				{
					::booldog::result_size ressize;
					if(info00->stable_toremove_mbchar)
						::booldog::utils::string::mbs::indexof(&ressize, false, entry_name, 0, SIZE_MAX, "stable_", 0
						, SIZE_MAX);
					else
						ressize.sres = SIZE_MAX;
					if(ressize.sres == 0)
					{
						if(strcmp(entry_name, "stable_last") == 0)
						{
							::booldog::result_mbchar mbchar(allocator), toremove_mbchar(allocator);
							::booldog::utils::string::mbs::assign<16>(0, mbchar.mballocator, false, 0
								, mbchar.mbchar, mbchar.mblen
								, mbchar.mbsize, pathname, 0, SIZE_MAX);
							if(mbchar.mbchar[mbchar.mblen - 1] != '/'
								&& mbchar.mbchar[mbchar.mblen - 1] != '\\')
							{
								::booldog::utils::string::mbs::assign<16>(0, mbchar.mballocator, false
									, mbchar.mblen, mbchar.mbchar
									, mbchar.mblen, mbchar.mbsize
									, &::booldog::io::mbs::slash, 0, 1);
							}
							::booldog::utils::string::mbs::assign<16>(0, mbchar.mballocator, false
								, mbchar.mblen, mbchar.mbchar
								, mbchar.mblen, mbchar.mbsize, entry_name, 0
								, SIZE_MAX);
					
							listdir_info info_;
							info_.pautoloader = info00->pautoloader;
							info_.mbchar0 = info00->mbchar0;
							info_.mbchar1 = info00->mbchar1;
							info_.memory_toremove_mbchar = &toremove_mbchar;					
							::booldog::io::directory::mbs::listdir(0, allocator, mbchar.mbchar, listdir_remove, &info_);
							::booldog::result res;
							if(::booldog::utils::io::mbs::rmdir(&res, mbchar.mbchar) == false)
							{
								::booldog::result_mbchar reserror(allocator); 
								::booldog::error::format(&res, allocator, reserror.mbchar, reserror.mblen, reserror.mbsize);
								LOG_DEBUG(info00->pautoloader->_log, "rmdir %s, errno %s", mbchar.mbchar, reserror.mbchar);
							}
						}
						else
						{
							++info00->stable_count;
							bool next = false;
							if(info00->stable_toremove_mbchar->mblen == 0)
								next = true;
							else
							{
								::booldog::utils::io::path::mbs::filename(info00->mbchar0, info00->mbchar0->mballocator
									, info00->stable_toremove_mbchar->mbchar, 0, SIZE_MAX);
								next = strcmp(info00->mbchar0->mbchar, entry_name) > 0;
							}
							if(next)
							{
								::booldog::utils::string::mbs::assign<16>(0, info00->stable_toremove_mbchar->mballocator, false, 0
									, info00->stable_toremove_mbchar->mbchar, info00->stable_toremove_mbchar->mblen
									, info00->stable_toremove_mbchar->mbsize, pathname, 0, SIZE_MAX);
								if(info00->stable_toremove_mbchar->mbchar[info00->stable_toremove_mbchar->mblen - 1] != '/'
									&& info00->stable_toremove_mbchar->mbchar[info00->stable_toremove_mbchar->mblen - 1] != '\\')
								{
									::booldog::utils::string::mbs::assign<16>(0, info00->stable_toremove_mbchar->mballocator, false
										, info00->stable_toremove_mbchar->mblen, info00->stable_toremove_mbchar->mbchar
										, info00->stable_toremove_mbchar->mblen, info00->stable_toremove_mbchar->mbsize
										, &::booldog::io::mbs::slash, 0, 1);
								}
								::booldog::utils::string::mbs::assign<16>(0, info00->stable_toremove_mbchar->mballocator, false
									, info00->stable_toremove_mbchar->mblen, info00->stable_toremove_mbchar->mbchar
									, info00->stable_toremove_mbchar->mblen, info00->stable_toremove_mbchar->mbsize, entry_name, 0
									, SIZE_MAX);
							}
						}
					}
					else
					{
						if(info00->memory_toremove_mbchar)
							::booldog::utils::string::mbs::indexof(&ressize, false, entry_name, 0, SIZE_MAX, "memory_", 0
							, SIZE_MAX);
						else
							ressize.sres = SIZE_MAX;
						if(ressize.sres == 0)
						{
							if(strcmp(entry_name, "memory_last") == 0)
							{
								::booldog::result_mbchar mbchar(allocator), toremove_mbchar(allocator);
								::booldog::utils::string::mbs::assign<16>(0, mbchar.mballocator, false, 0
									, mbchar.mbchar, mbchar.mblen
									, mbchar.mbsize, pathname, 0, SIZE_MAX);
								if(mbchar.mbchar[mbchar.mblen - 1] != '/'
									&& mbchar.mbchar[mbchar.mblen - 1] != '\\')
								{
									::booldog::utils::string::mbs::assign<16>(0, mbchar.mballocator, false
										, mbchar.mblen, mbchar.mbchar
										, mbchar.mblen, mbchar.mbsize
										, &::booldog::io::mbs::slash, 0, 1);
								}
								::booldog::utils::string::mbs::assign<16>(0, mbchar.mballocator, false
									, mbchar.mblen, mbchar.mbchar
									, mbchar.mblen, mbchar.mbsize, entry_name, 0
									, SIZE_MAX);
					
								listdir_info info_;
								info_.pautoloader = info00->pautoloader;
								info_.mbchar0 = info00->mbchar0;
								info_.mbchar1 = info00->mbchar1;
								info_.memory_toremove_mbchar = &toremove_mbchar;					
								::booldog::io::directory::mbs::listdir(0, allocator, mbchar.mbchar, listdir_remove, &info_);
								::booldog::result res;
								if(::booldog::utils::io::mbs::rmdir(&res, mbchar.mbchar) == false)
								{
									::booldog::result_mbchar reserror(allocator);
									::booldog::error::format(&res, allocator, reserror.mbchar, reserror.mblen, reserror.mbsize);
									LOG_DEBUG(info00->pautoloader->_log, "rmdir %s, errno %s", mbchar.mbchar, reserror.mbchar);
								}
							}
							else
							{
								++info00->memory_count;
								bool next = false;
								if(info00->memory_toremove_mbchar->mblen == 0)
									next = true;
								else
								{
									::booldog::utils::io::path::mbs::filename(info00->mbchar0, info00->mbchar0->mballocator
										, info00->memory_toremove_mbchar->mbchar, 0, SIZE_MAX);
									next = strcmp(info00->mbchar0->mbchar, entry_name) > 0;
								}
								if(next)
								{									
									::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false, 0
										, info00->memory_toremove_mbchar->mbchar, info00->memory_toremove_mbchar->mblen
										, info00->memory_toremove_mbchar->mbsize, pathname, 0, SIZE_MAX);
									if(info00->memory_toremove_mbchar->mbchar[info00->memory_toremove_mbchar->mblen - 1] != '/'
										&& info00->memory_toremove_mbchar->mbchar[info00->memory_toremove_mbchar->mblen - 1] != '\\')
									{
										::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false
											, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbchar
											, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbsize
											, &::booldog::io::mbs::slash, 0, 1);
									}
									::booldog::utils::string::mbs::assign<16>(0, info00->memory_toremove_mbchar->mballocator, false
										, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbchar
										, info00->memory_toremove_mbchar->mblen, info00->memory_toremove_mbchar->mbsize, entry_name, 0
										, SIZE_MAX);
								}
							}
						}
					}
				}
			}
		}
		return true;
	}
	booinline void rename_stable_and_memory(::booldog::result_mbchar* mbchar0)
	{
		::booldog::result res;
		::booldog::result_bool resbool;
		::booldog::result_mbchar exe_dir(mbchar0->mballocator), time_mbchar(mbchar0->mballocator), dst(mbchar0->mballocator);

		::booldog::utils::executable::mbs::directory<16>(&exe_dir, exe_dir.mballocator);
			
		::booldog::utils::string::mbs::assign<16>(0, exe_dir.mballocator, false, exe_dir.mblen, exe_dir.mbchar
			, exe_dir.mblen, exe_dir.mbsize, &::booldog::io::mbs::slash, 0, 1);

		size_t exe_dir_len = exe_dir.mblen;
		
		::booldog::uint64 now = ::booldog::utils::time::posix::now_as_utc();
		now = ::booldog::utils::time::posix::tolocal(now);		
		::booldog::utils::time::posix::mbs::tostring<16>(time_mbchar, "_%Y%m%d_%H%M%S%MS", now);
		
		::booldog::utils::string::mbs::assign<16>(0, dst.mballocator, false, 0, dst.mbchar
			, dst.mblen, dst.mbsize, exe_dir.mbchar, 0, SIZE_MAX);

		::booldog::utils::string::mbs::assign<16>(0, exe_dir.mballocator, false, exe_dir_len, exe_dir.mbchar
			, exe_dir.mblen, exe_dir.mbsize, "stable", 0, SIZE_MAX);
		::booldog::utils::io::directory::mbs::exists(&resbool, mbchar0->mballocator, exe_dir.mbchar, debuginfo_macros);
		if(resbool.bres)
		{
			::booldog::utils::string::mbs::assign<16>(0, dst.mballocator, false, exe_dir_len, dst.mbchar
				, dst.mblen, dst.mbsize, "stable", 0, SIZE_MAX);
			::booldog::utils::string::mbs::assign<16>(0, dst.mballocator, false, dst.mblen, dst.mbchar
				, dst.mblen, dst.mbsize, time_mbchar.mbchar, 0, SIZE_MAX);
			if(::booldog::utils::io::mbs::rename(&res, exe_dir.mbchar, dst.mbchar))
			{
#ifdef __WINDOWS__
				::_chmod(dst.mbchar, 0777);
#else
				::chmod(dst.mbchar, 0777);
#endif
			}
		}
		::booldog::utils::string::mbs::assign<16>(0, exe_dir.mballocator, false, exe_dir_len, exe_dir.mbchar
			, exe_dir.mblen, exe_dir.mbsize, "memory", 0, SIZE_MAX);
		::booldog::utils::io::directory::mbs::exists(&resbool, mbchar0->mballocator, exe_dir.mbchar, debuginfo_macros);
		if(resbool.bres)
		{
			::booldog::utils::string::mbs::assign<16>(0, dst.mballocator, false, exe_dir_len, dst.mbchar
				, dst.mblen, dst.mbsize, "memory", 0, SIZE_MAX);
			::booldog::utils::string::mbs::assign<16>(0, dst.mballocator, false, dst.mblen, dst.mbchar
				, dst.mblen, dst.mbsize, time_mbchar.mbchar, 0, SIZE_MAX);
			if(::booldog::utils::io::mbs::rename(&res, exe_dir.mbchar, dst.mbchar))
			{
#ifdef __WINDOWS__
				::_chmod(dst.mbchar, 0777);
#else
				::chmod(dst.mbchar, 0777);
#endif
			}
		}
	}
	bool autoloaderclass::remove_old_stable_and_memory(::iv::autoloaderclass* pautoloader)
	{
    IVBOO_FUNC(399);
		::booldog::allocators::single_threaded::mixed<1024> mixed(&::iv::booldog::autoloaderheap);
		{
			bool allright = true;
			::booldog::result res;
			::booldog::result_mbchar mbchar0(&mixed), mbchar1(&mixed), exe_dir(&mixed), memory_toremove_mbchar(&mixed)
				, stable_toremove_mbchar(&mixed), toremove_mbchar(&mixed);
			::booldog::utils::executable::mbs::directory<16>(&exe_dir, exe_dir.mballocator);
			
			listdir_info info;
			info.pautoloader = pautoloader;
			info.mbchar0 = &mbchar0;
			info.mbchar1 = &mbchar1;
			info.stable_count = 0;
			info.memory_count = 0;
			info.memory_toremove_mbchar = &memory_toremove_mbchar;
			info.stable_toremove_mbchar = &stable_toremove_mbchar;

			::booldog::io::directory::mbs::listdir(0, mbchar0.mballocator, exe_dir.mbchar, listdir_count, &info);

			LOG_DEBUG(pautoloader->_log, "after stable listdir_count");

			if(info.stable_count >= 4)
			{
				info.memory_toremove_mbchar = &toremove_mbchar;

				LOG_DEBUG(pautoloader->_log, "before stable listdir_remove");

				::booldog::io::directory::mbs::listdir(0, mbchar0.mballocator, stable_toremove_mbchar.mbchar
					, listdir_remove, &info);

				LOG_DEBUG(pautoloader->_log, "after stable listdir_remove");

				if(::booldog::utils::io::mbs::rmdir(&res, stable_toremove_mbchar.mbchar) == false)
				{
					::booldog::result_mbchar reserror(mbchar0.mballocator), entry_name(&::iv::booldog::autoloadermixed);
					::booldog::error::format(&res, mbchar0.mballocator, reserror.mbchar, reserror.mblen, reserror.mbsize);
					LOG_DEBUG(pautoloader->_log, "rmdir %s, errno %s", stable_toremove_mbchar.mbchar, reserror.mbchar);
					
					::booldog::utils::io::path::mbs::filename(&entry_name, entry_name, stable_toremove_mbchar.mbchar, 0, SIZE_MAX);
					pautoloader->_stable_memory_errno.add(entry_name.detach());
				}
				allright = false;
			}
			if(info.memory_count >= 4)
			{
				info.memory_toremove_mbchar = &toremove_mbchar;

				LOG_DEBUG(pautoloader->_log, "before memory listdir_remove");

				::booldog::io::directory::mbs::listdir(0, mbchar0.mballocator, memory_toremove_mbchar.mbchar
					, listdir_remove, &info);

				LOG_DEBUG(pautoloader->_log, "after memory listdir_remove");

				if(::booldog::utils::io::mbs::rmdir(&res, memory_toremove_mbchar.mbchar) == false)
				{
					::booldog::result_mbchar reserror(mbchar0.mballocator), entry_name(&::iv::booldog::autoloadermixed);
					::booldog::error::format(&res, mbchar0.mballocator, reserror.mbchar, reserror.mblen, reserror.mbsize);
					LOG_DEBUG(pautoloader->_log, "rmdir %s, errno %s", memory_toremove_mbchar.mbchar, reserror.mbchar);

					::booldog::utils::io::path::mbs::filename(&entry_name, entry_name, memory_toremove_mbchar.mbchar, 0, SIZE_MAX);
					pautoloader->_stable_memory_errno.add(entry_name.detach());
				}
				allright = false;
			}
			return allright;
		}
	}
	void autoloaderclass::oncheckmodules( void* thread , void* udata )
	{
		thread = thread;
    IVBOO_FUNC(395);
    {
		  ::iv::autoloaderclass* pautoloader = (::iv::autoloaderclass*)udata;
		  ::iv::autoloaderclass::remove_old_stable_and_memory(pautoloader);
    }
	}
	void autoloaderclass::freeinternal( void* ptr )
	{
		::iv::booldog::autoloadermixed.free( ptr );
	};
	void* autoloaderclass::methodinternal( void* module , const char* name )
	{
		IVBOO_FUNC( 5 );

		::booldog::base::module* mod = (::booldog::base::module*)module;
		::booldog::result_pointer resptr;
		mod->method( &resptr , &::iv::booldog::autoloadermixed , name , debuginfo_macros );
		return resptr.pres;
	};
	char* autoloaderclass::get_filenameinternal( void* module )
	{
		IVBOO_FUNC( 6 );

		::booldog::base::module* mod = (::booldog::base::module*)module;		
		::booldog::result_mbchar resmbchar( &::iv::booldog::autoloadermixed );
		::booldog::utils::module::mbs::pathname< 64 >( &resmbchar , &::iv::booldog::autoloadermixed , mod->handle() 
			, debuginfo_macros );
		return resmbchar.detach();
	};
	void autoloaderclass::unloadinternal(void* any_module_address, void* module)
	{
		IVBOO_FUNC(7);

		::booldog::result_mbchar resmbchar(&::iv::booldog::autoloadermixed);
		::booldog::result res;
#ifdef __WINDOWS__
		::booldog::module_handle modhandle = ::booldog::utils::module::handle( &res , &::iv::booldog::autoloadermixed
			, any_module_address , debuginfo_macros );
		if( modhandle )
			::booldog::utils::module::mbs::pathname< 32 >( &resmbchar , &::iv::booldog::autoloadermixed , modhandle , debuginfo_macros );
#else
		::booldog::module_handle modhandle = 0;
		if( ::booldog::utils::module::mbs::pathname_from_address< 32 >( &resmbchar , &::iv::booldog::autoloadermixed , any_module_address 
			, debuginfo_macros ) )
		{
			modhandle = ::booldog::utils::module::mbs::handle( &res , &::iv::booldog::autoloadermixed , resmbchar.mbchar 
				, debuginfo_macros );
		}
#endif	
		::booldog::base::module* base_module = (::booldog::base::module*)module;
		if(base_module == 0 || modhandle != base_module->handle())
		{
			if(_cs_inited)
			{
				cs1Enter(&_lock, 814);
			}
			::iv::module_free_unload module_free_unload_struct = {this, true};
			::iv::dependency* depend = _depends;
			for(;;)
			{
				if( depend == 0 )
					break;
				if( ::booldog::interlocked::compare_exchange( &depend->_state , 0 , 0 ) == ::iv::state_busy 
					&& depend->module == module && depend->dependent_modhandle == modhandle
					&& ( ( resmbchar.mbchar == 0 && depend->dependent_modulepathname.mblen == 0 )
					|| ( depend->dependent_modulepathname.mbchar && resmbchar.mbchar 
					&& strcmp( depend->dependent_modulepathname.mbchar , resmbchar.mbchar ) == 0 ) ) )
				{
					depend->module->lock( debuginfo_macros );
					if(_cs_inited)
						cs1Leave(&_lock);

					::booldog::utils::module::mbs::pathname< 32 >(&resmbchar, &::iv::booldog::autoloadermixed
						, depend->module->handle(), debuginfo_macros);
					::booldog::utils::io::path::mbs::filename_without_extension(0, resmbchar.mbchar
						, resmbchar.mblen);
					if(::booldog::interlocked::decrement(&depend->_refs) == 0)
					{
						::booldog::interlocked::exchange(&depend->_state, ::iv::state_pending_in_deinit);
						
						if(::booldog::interlocked::compare_exchange(&depend->_inited_refs, 0, 0))
						{
              BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(%s dll_free)"
                , resmbchar.mbchar);
							IVBOO_NOTMY_FUNC_HELPER __ivboohelper(28, 29, resmbchar.mbchar, "dll_free", _a2_, thisfunct1);
							depend->module->free(&res, &::iv::booldog::autoloadermixed, ::iv::onbeforefree, &module_free_unload_struct
								, debuginfo_macros);
							if(module_free_unload_struct.locked == false)
							{
								depend->module->lock(debuginfo_macros);
								module_free_unload_struct.locked = true;
							}
						}
						{
              BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(%s unload)", resmbchar.mbchar);
							IVBOO_NOTMY_FUNC_HELPER __ivboohelper(30, 31, resmbchar.mbchar, "unload", _a2_, thisfunct1);
							_loader.unload( &res , depend->module , ::iv::onbeforeunload , &module_free_unload_struct 
								, debuginfo_macros );
							if(module_free_unload_struct.locked == false)
							{
								depend->module->lock(debuginfo_macros);
								module_free_unload_struct.locked = true;
							}
						}
						::booldog::interlocked::exchange(&depend->_state, ::iv::state_free);
					}
					else
					{
						if( ::booldog::interlocked::compare_exchange( &depend->_inited_refs , 0 , 0 ) )
						{
							if( ::booldog::interlocked::decrement( &depend->_inited_refs ) )
							{
                BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(%s dll_free)", resmbchar.mbchar);
								IVBOO_NOTMY_FUNC_HELPER __ivboohelper(32, 33, resmbchar.mbchar, "dll_free", _a2_, thisfunct1);
								depend->module->free(&res, &::iv::booldog::autoloadermixed, ::iv::onbeforefree, &module_free_unload_struct, debuginfo_macros);
								if(module_free_unload_struct.locked == false)
								{
									depend->module->lock(debuginfo_macros);
									module_free_unload_struct.locked = true;
								}
							}
						}
						{
              BOO_MONITORING mon(_log, &::iv::booldog::autoloadermixed, "<unloading>autoloader(%s unload)", resmbchar.mbchar);
							IVBOO_NOTMY_FUNC_HELPER __ivboohelper(34, 35, resmbchar.mbchar, "unload", _a2_, thisfunct1);
							_loader.unload(&res, depend->module, ::iv::onbeforeunload, &module_free_unload_struct, debuginfo_macros);
							if(module_free_unload_struct.locked == false)
							{
								depend->module->lock(debuginfo_macros);
								module_free_unload_struct.locked = true;
							}
						}
					}
					depend->module->unlock( debuginfo_macros );
					if(_cs_inited)
					{
						cs1Enter(&_lock, 813);
					}
					break;
				}
				depend = depend->_prev;
			}
			if(_cs_inited)
				cs1Leave(&_lock);
		}
		if(modhandle)
			::booldog::utils::module::free(&res, &::iv::booldog::autoloadermixed, modhandle, debuginfo_macros);
	}
	void autoloaderclass::threads_pool_autoremove_wait_for_stop(::booldog::module_handle hmod, void* removed)
	{	
		if(::iv::pautoloader->_stable_hmod && hmod == ::iv::pautoloader->_stable_hmod)
		{
			::iv::autoloader_nm::module_struct* module_struct = (::iv::autoloader_nm::module_struct*)removed;
			{
				LOG_INFO(::iv::pautoloader->_log, "<autoloader>module(%pp, %pp), threads_pool_autoremove_wait_for_stop"
					, module_struct, hmod);
				while(::booldog::interlocked::compare_exchange(&module_struct->threads_pool_count, 0, 0) != 0)
					::booldog::threading::sleep(1);
			}
		}
		else
		{
			IVBOO_FUNC(987);
			::iv::autoloader_nm::module_struct* module_struct = (::iv::autoloader_nm::module_struct*)removed;
			{
				LOG_INFO(::iv::pautoloader->_log, "<autoloader>module(%pp, %pp), threads_pool_autoremove_wait_for_stop"
					, module_struct, hmod);
				while(::booldog::interlocked::compare_exchange(&module_struct->threads_pool_count, 0, 0) != 0)
					::booldog::threading::sleep(1);
			}
		}
	}
	void autoloaderclass::threads_autoremove_stop(::booldog::module_handle hmod, void* removed)
	{
		if(::iv::pautoloader->_stable_hmod && hmod == ::iv::pautoloader->_stable_hmod)
		{
			::iv::autoloader_nm::module_struct* module_struct = (::iv::autoloader_nm::module_struct*)removed;
			{
				LOG_INFO(::iv::pautoloader->_log, "<autoloader>module(%pp, %pp), threads_autoremove_stop"
					, module_struct, hmod);
				::booldog::interlocked::exchange(&module_struct->threads_wait_for_stopped, 1);
			}
		}
		else
		{
			IVBOO_FUNC(986);
			::iv::autoloader_nm::module_struct* module_struct = (::iv::autoloader_nm::module_struct*)removed;
			{
				LOG_INFO(::iv::pautoloader->_log, "<autoloader>module(%pp, %pp), threads_autoremove_stop"
					, module_struct, hmod);
				::booldog::interlocked::exchange(&module_struct->threads_wait_for_stopped, 1);
			}
		}
	}
	void autoloaderclass::threads_autoremove_wait_for_stop(::booldog::module_handle hmod, void* removed)
	{
		if(::iv::pautoloader->_stable_hmod && hmod == ::iv::pautoloader->_stable_hmod)
		{
			::iv::autoloader_nm::module_struct* module_struct = (::iv::autoloader_nm::module_struct*)removed;
			{
				LOG_INFO(::iv::pautoloader->_log, "<autoloader>module(%pp, %pp), threads_autoremove_wait_for_stop"
					, module_struct, hmod);
				while(::booldog::interlocked::compare_exchange(&module_struct->threads_count, 0, 0) != 0)
					::booldog::threading::sleep(1);
			}
		}
		else
		{
			IVBOO_FUNC(985);
			::iv::autoloader_nm::module_struct* module_struct = (::iv::autoloader_nm::module_struct*)removed;
			{
				LOG_INFO(::iv::pautoloader->_log, "<autoloader>module(%pp, %pp), threads_autoremove_wait_for_stop"
					, module_struct, hmod);
				while(::booldog::interlocked::compare_exchange(&module_struct->threads_count, 0, 0) != 0)
					::booldog::threading::sleep(1);
			}
		}
	}
	void autoloaderclass::initialize_module_struct(::iv::autoloader_nm::module_struct* module_struct, void* reserved)
	{
		reserved = reserved;		
		::booldog::allocators::easy::heap heap;
		{
			::iv::autoloader_nm::module_struct_ext* module_struct_ext = (::iv::autoloader_nm::module_struct_ext*)reserved;
			if(module_struct_ext)
			{
				module_struct = &module_struct_ext->_module_struct;
				if(module_struct_ext->has((void*)&module_struct_ext->autoloader_inited))
					module_struct_ext->autoloader_inited = &::iv::autoloader_inited;
			}
			::booldog::interlocked::exchange(&module_struct->threads_wait_for_stopped, 0);
			::booldog::result_mbchar resmbchar(&heap);
#ifdef __WINDOWS__
			module_struct->module_handle = 
				::booldog::utils::module::handle(0, &heap, module_struct);
			::booldog::utils::module::mbs::pathname< 32 >(&resmbchar, &heap, module_struct->module_handle);
#else				
			if(::booldog::utils::module::mbs::pathname_from_address< 32 >(&resmbchar, &heap, module_struct))
				module_struct->module_handle = ::booldog::utils::module::mbs::handle(0, &heap, resmbchar.mbchar);
#endif
			if(resmbchar.mbchar == 0)
				::booldog::utils::executable::mbs::pathname< 32 >(&resmbchar, &heap);
			::booldog::utils::io::path::mbs::filename_without_extension(0, resmbchar.mbchar, resmbchar.mblen);
			if(resmbchar.mbchar)
			{
				const char* ptr = resmbchar.mbchar;
				char* dst = module_struct->module_name;
				while( *ptr != 0 )
				{
					if(ptr - resmbchar.mbchar > sizeof(module_struct->module_name) - 2)
						break;
					*dst++ = *ptr++;
				}
				*dst = 0;
			}
			if(module_struct->module_handle)
				::booldog::utils::module::free(0, &heap, module_struct->module_handle);
			if(::iv::pautoloader->_log)
				LOG_INFO(::iv::pautoloader->_log, "<autoloader>module(%pp, %pp), '%s', initialize_module_struct"
				, module_struct, module_struct->module_handle, module_struct->module_name);			
			fast_register_autoremove(module_struct, 0, 0, threads_pool_autoremove_wait_for_stop, module_struct, false, 0, false, 0);
			fast_register_autoremove(module_struct, 0, 0, threads_autoremove_stop, module_struct, false, 0, false, 0);
			fast_register_autoremove(module_struct, 0, 0, threads_autoremove_wait_for_stop, module_struct, false, 1, false, 0);
		}
	}
	void autoloaderclass::global_data_set(const char* key, const char* value, void* reserved)
	{
		reserved = reserved;
		IVBOO_FUNC(479);
		::iv::global_data_struct* global_data = ::iv::booldog::autoloadermixed.create< ::iv::global_data_struct >();
		global_data->_key_hash = ::booldog::hash::times33::calculate(key, SIZE_MAX);
		global_data->_value = 0;
		size_t dstlen = 0, dstsize = 0;
		::booldog::utils::string::mbs::assign< 16 >(0, &::iv::booldog::autoloadermixed, false, 0, global_data->_value, dstlen, dstsize
			, value, 0, SIZE_MAX);
		if(::iv::pautoloader->_cs_inited)
			iv_rwlock_wrlock(&::iv::pautoloader->_lock_global_datas, 329);
		::iv::pautoloader->_global_datas.add(global_data);
		if(::iv::pautoloader->_cs_inited)
			iv_rwlock_wrunlock(&::iv::pautoloader->_lock_global_datas);
	}
	const char* autoloaderclass::global_data_get(const char* key, void* reserved)
	{
		reserved = reserved;
		IVBOO_FUNC(469);
		const char* value = 0;
		::booldog::uint64 hash = ::booldog::hash::times33::calculate(key, SIZE_MAX);
		if(::iv::pautoloader->_cs_inited)
			iv_rwlock_rdlock(&::iv::pautoloader->_lock_global_datas, 328);
		::iv::global_data_struct* global_data = ::iv::pautoloader->_global_datas.first();
		while(global_data)
		{
			if(global_data->_key_hash == hash)
			{
				value = global_data->_value;
				break;
			}
			global_data = global_data->_doubly_linked_list_next;
		}
		if(::iv::pautoloader->_cs_inited)
			iv_rwlock_rdunlock(&::iv::pautoloader->_lock_global_datas);
		return value;
	}
	void* autoloaderclass::fast_register_autoremove(::iv::autoloader_nm::module_struct* module_struct, void* any_module_address
		, ::iv::autoremove_t poldautoremove, ::iv::autoremove2_t pnewautoremove, void* removed, bool before_dll_free, int waveindex
		, bool need_explicity_unregister, void* reserved)
	{
		reserved = reserved;
		::booldog::module_handle modhandle = 0;
		if(module_struct)
			modhandle = module_struct->module_handle;
		else
		{
			::booldog::result res;
#ifdef __WINDOWS__
			modhandle = ::booldog::utils::module::handle( &res , &::iv::booldog::autoloadermixed
				, any_module_address , debuginfo_macros );
#else
			::booldog::result_mbchar resmbchar(&::iv::booldog::autoloadermixed);
			if( ::booldog::utils::module::mbs::pathname_from_address< 32 >(&resmbchar, &::iv::booldog::autoloadermixed
				, any_module_address, debuginfo_macros))
			{
				modhandle = ::booldog::utils::module::mbs::handle(&res, &::iv::booldog::autoloadermixed, resmbchar.mbchar
					, debuginfo_macros);
			}
#endif
			if(modhandle)
				::booldog::utils::module::free(0, &::iv::booldog::autoloadermixed, modhandle, debuginfo_macros); 
		}
		::iv::autoremove* autoremove = 0;
		switch(waveindex)
		{
		case 0:
			autoremove = ::iv::pautoloader->create_autoremove(modhandle, poldautoremove, pnewautoremove, removed, before_dll_free
				, need_explicity_unregister);
			break;
		case 1:
			autoremove = ::iv::pautoloader->create_autoremove2(modhandle, poldautoremove, pnewautoremove, removed, before_dll_free
				, need_explicity_unregister);
			break;
		case 2:
			autoremove = ::iv::pautoloader->create_autoremove3(modhandle, poldautoremove, pnewautoremove, removed, before_dll_free
				, need_explicity_unregister);
			break;
		}
		return autoremove;
	}
	void* autoloaderclass::new_register_autoremoveinternal_with_return( void* any_module_address , ::iv::autoremove2_t pautoremove 
		, void* removed , bool before_dll_free , int waveindex )
	{
		return fast_register_autoremove(0, any_module_address, 0, pautoremove, removed, before_dll_free, waveindex, true, 0);
	};
	void autoloaderclass::new_unregister_autoremoveinternal_with_return( void* handle , int waveindex )
	{
		fast_unregister_autoremove(0, handle, 0, 0, 0, 0, waveindex, 0);
	};
	void autoloaderclass::new_register_autoremoveinternal(void* any_module_address, ::iv::autoremove2_t pautoremove, void* removed
		, bool before_dll_free, int waveindex)
	{
		fast_register_autoremove(0, any_module_address, 0, pautoremove, removed, before_dll_free, waveindex, false, 0);
	}
	void autoloaderclass::fast_unregister_autoremove(::iv::autoloader_nm::module_struct* module_struct, void* handle, void* any_module_address, ::iv::autoremove_t poldautoremove
			, ::iv::autoremove2_t pnewautoremove, void* removed, int waveindex, void* reserved)
	{
		IVBOO_FUNC2(611);
		{
			reserved = reserved;
			if(handle)
			{
				::iv::autoremove* deleteautoremove = (::iv::autoremove*)handle;
				switch(waveindex)
				{
				case 0:
					if(::iv::pautoloader->_cs_inited)
					{
						cs1Enter(&::iv::pautoloader->_lock_autoremoves, 622);
					}
					::iv::pautoloader->_autoremoves___00.remove(deleteautoremove);
					if(::iv::pautoloader->_cs_inited)
						cs1Leave(&::iv::pautoloader->_lock_autoremoves);
					break;
				case 1:
					if(::iv::pautoloader->_cs_inited)
						cs1Enter(&::iv::pautoloader->_lock_autoremoves2, 522);
					::iv::pautoloader->_autoremoves2___00.remove(deleteautoremove);
					if(::iv::pautoloader->_cs_inited)
						cs1Leave(&::iv::pautoloader->_lock_autoremoves2);
					break;
				case 2:
					if(::iv::pautoloader->_cs_inited)
						cs1Enter(&::iv::pautoloader->_lock_autoremoves3, 422);
					::iv::pautoloader->_autoremoves3___00.remove(deleteautoremove);
					if(::iv::pautoloader->_cs_inited)
						cs1Leave(&::iv::pautoloader->_lock_autoremoves3);
					break;
				}
				::iv::pautoloader->_avail_autoremoves.push(deleteautoremove);
			}
			else
			{
				::booldog::module_handle modhandle = 0;
				if(module_struct)
					modhandle = module_struct->module_handle;
				else
				{
					::booldog::result res;
	#ifdef __WINDOWS__
					modhandle = ::booldog::utils::module::handle(&res, &::iv::booldog::autoloadermixed
						, any_module_address, debuginfo_macros);
	#else
					::booldog::result_mbchar resmbchar(&::iv::booldog::autoloadermixed);
					if(::booldog::utils::module::mbs::pathname_from_address< 32 >(&resmbchar, &::iv::booldog::autoloadermixed
						, any_module_address, debuginfo_macros))
					{
						modhandle = ::booldog::utils::module::mbs::handle(&res, &::iv::booldog::autoloadermixed, resmbchar.mbchar
						, debuginfo_macros);
					}
	#endif
					if(modhandle)
						::booldog::utils::module::free(0, &::iv::booldog::autoloadermixed,  modhandle, debuginfo_macros);
				}
				::iv::autoremove* deleteautoremove = 0;
				switch(waveindex)
				{
				case 0:
					if(::iv::pautoloader->_cs_inited)
					{
						cs1Enter(&::iv::pautoloader->_lock_autoremoves, 621);
					}
					deleteautoremove = ::iv::pautoloader->_autoremoves___00.first();
					break;
				case 1:
					if(::iv::pautoloader->_cs_inited)
						cs1Enter(&::iv::pautoloader->_lock_autoremoves2, 521);
					deleteautoremove = ::iv::pautoloader->_autoremoves2___00.first();
					break;
				case 2:
					if(::iv::pautoloader->_cs_inited)
						cs1Enter(&::iv::pautoloader->_lock_autoremoves3, 421);
					deleteautoremove = ::iv::pautoloader->_autoremoves3___00.first();
					break;
				}
				if(pnewautoremove)
				{
					while(deleteautoremove)
					{
						if(deleteautoremove->_hmod == modhandle && deleteautoremove->_autoremove2 == pnewautoremove
							&& deleteautoremove->_removed == removed 
							&& ::booldog::interlocked::compare_exchange(&deleteautoremove->_state, ::iv::state_free, ::iv::state_busy)
							== ::iv::state_busy)
							break;
						deleteautoremove = deleteautoremove->_doubly_linked_list_next;
					}
				}
				else
				{
					while(deleteautoremove)
					{
						if(deleteautoremove->_hmod == modhandle && deleteautoremove->_autoremove_____ == poldautoremove
							&& deleteautoremove->_removed == removed 
							&& ::booldog::interlocked::compare_exchange(&deleteautoremove->_state, ::iv::state_free, ::iv::state_busy)
							== ::iv::state_busy)
							break;
						deleteautoremove = deleteautoremove->_doubly_linked_list_next;
					}
				}
				if(deleteautoremove)
				{
					switch(waveindex)
					{
					case 0:
						::iv::pautoloader->_autoremoves___00.remove(deleteautoremove);
						if(::iv::pautoloader->_cs_inited)
							cs1Leave(&::iv::pautoloader->_lock_autoremoves);
						break;
					case 1:
						::iv::pautoloader->_autoremoves2___00.remove(deleteautoremove);
						if(::iv::pautoloader->_cs_inited)
							cs1Leave(&::iv::pautoloader->_lock_autoremoves2);
						break;
					case 2:
						::iv::pautoloader->_autoremoves3___00.remove(deleteautoremove);
						if(::iv::pautoloader->_cs_inited)
							cs1Leave(&::iv::pautoloader->_lock_autoremoves3);
						break;
					}
					::iv::pautoloader->_avail_autoremoves.push(deleteautoremove);
				}
				else
				{
					switch(waveindex)
					{
					case 0:
						if(::iv::pautoloader->_cs_inited)
							cs1Leave(&::iv::pautoloader->_lock_autoremoves);
						break;
					case 1:
						if(::iv::pautoloader->_cs_inited)
							cs1Leave(&::iv::pautoloader->_lock_autoremoves2);
						break;
					case 2:
						if(::iv::pautoloader->_cs_inited)
							cs1Leave(&::iv::pautoloader->_lock_autoremoves3);
						break;
					}
				}
			}
		}
	}
	void autoloaderclass::new_unregister_autoremoveinternal( void* any_module_address , ::iv::autoremove2_t pautoremove 
		, void* removed , int waveindex )
	{
		fast_unregister_autoremove(0, 0, any_module_address, 0, pautoremove, removed, waveindex, 0);
	}
	void autoloaderclass::register_autoremoveinternal(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed
		, bool before_dll_free)
	{
		fast_register_autoremove(0, any_module_address, pautoremove, 0, removed, before_dll_free, 0, false, 0);
	}
	void autoloaderclass::register_autoremoveinternal2(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed
		, bool before_dll_free)
	{
		fast_register_autoremove(0, any_module_address, pautoremove, 0, removed, before_dll_free, 1, false, 0);
	}
	void autoloaderclass::register_autoremoveinternal3(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed
		, bool before_dll_free)
	{
		fast_register_autoremove(0, any_module_address, pautoremove, 0, removed, before_dll_free, 2, false, 0);
	}
	void autoloaderclass::unregister_autoremoveinternal(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed)
	{
		IVBOO_FUNC(839);
		fast_unregister_autoremove(0, 0, any_module_address, pautoremove, 0, removed, 0, 0);
	};
	void autoloaderclass::unregister_autoremoveinternal2(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed)
	{
		IVBOO_FUNC(859);
		fast_unregister_autoremove(0, 0, any_module_address, pautoremove, 0, removed, 1, 0);
	};
	void autoloaderclass::unregister_autoremoveinternal3(void* any_module_address, ::iv::autoremove_t pautoremove, void* removed)
	{
		IVBOO_FUNC(849);
		fast_unregister_autoremove(0, 0, any_module_address, pautoremove, 0, removed, 2, 0);
	}
	void autoloaderclass::onbeforefreeinternal( ::booldog::base::module* mod , ::booldog::module_handle hmod )
	{
		IVBOO_FUNC( 36 );
		::booldog::result_mbchar __resmbchar( &::iv::booldog::autoloadermixed );
		::booldog::utils::module::mbs::pathname< 32 >( &__resmbchar , &::iv::booldog::autoloadermixed , hmod , debuginfo_macros );
		::booldog::utils::io::path::mbs::filename_without_extension( 0 , __resmbchar.mbchar , __resmbchar.mblen );
		if( _log )
		{
			LOG_INFO( _log , "<autoloader>module(%pp,%pp) '%s' before dll_free" 
				, mod , hmod , __resmbchar.mbchar ? __resmbchar.mbchar : "exe" );
		}

		if(mod)
		{
			module_udata* modudata = (module_udata*)mod->udata();
			if(::booldog::interlocked::compare_exchange(&modudata->_pre_pre_dll_free_executed, 1, 0) == 0)
			{
				::booldog::result_pointer resptr;
				if(mod->method(&resptr, &::iv::booldog::autoloadermixed, "pre_pre_dll_free", debuginfo_macros))
				{
					pre_pre_dll_free_t pre_pre_dll_free = (pre_pre_dll_free_t)resptr.pres;
					IVBOO_NOTMY_FUNC(pre_pre_dll_free, 564, 565, __resmbchar.mbchar, "pre_pre_dll_free", _a2_, thisfunct1);
				}
			}
		}

		if(__resmbchar.mbchar && strcmp(__resmbchar.mbchar, "log-1") == 0)
			_log = 0;

		::iv::autoremove* deleteautoremove = 0;
		if(_cs_inited)
		{
			cs1Enter(&_lock_autoremoves, 620);
		}
		deleteautoremove = _autoremoves___00.first();
		for( ; ; )
		{
			if( deleteautoremove == 0 )
				break;
			if( deleteautoremove->before_dll_free && ( ( hmod && deleteautoremove->_hmod == hmod ) 
				|| ( hmod == 0 && deleteautoremove->_hmod == 0 ) ) )
			{
				if( ::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_exec 
					, ::iv::state_busy ) == ::iv::state_busy )
				{
					if( deleteautoremove->_need_explicity_unregister == false )
						_autoremoves___00.remove( deleteautoremove );
					if(_cs_inited)
						cs1Leave(&_lock_autoremoves);
					{
						IVBOO_NOTMY_FUNC_HELPER __ivboohelper(37, 38, __resmbchar.mbchar, "autoremove before free", _a2_, thisfunct1);
						if( deleteautoremove->_new )
							deleteautoremove->_autoremove2( deleteautoremove->_hmod , deleteautoremove->_removed );
						else
							deleteautoremove->_autoremove_____( deleteautoremove->_removed );
					}
					::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_free
						, ::iv::state_exec );

					if( deleteautoremove->_need_explicity_unregister == false )
						_avail_autoremoves.push(deleteautoremove);
					if(_cs_inited)
					{
						cs1Enter(&_lock_autoremoves, 619);
					}

					deleteautoremove = _autoremoves___00.first();
					continue;
				}
			}
			deleteautoremove = deleteautoremove->_doubly_linked_list_next;
		}
		if(_cs_inited)
			cs1Leave(&_lock_autoremoves);

		if(_cs_inited)
			cs1Enter(&_lock_autoremoves2, 520);
		deleteautoremove = _autoremoves2___00.first();
		for( ; ; )
		{
			if( deleteautoremove == 0 )
				break;
			if( deleteautoremove->before_dll_free && ( ( hmod && deleteautoremove->_hmod == hmod ) 
				|| ( hmod == 0 && deleteautoremove->_hmod == 0 ) ) )
			{
				if( ::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_exec 
					, ::iv::state_busy ) == ::iv::state_busy )
				{
					if( deleteautoremove->_need_explicity_unregister == false )
						_autoremoves2___00.remove( deleteautoremove );
					if(_cs_inited)
						cs1Leave(&_lock_autoremoves2);
					{
						IVBOO_NOTMY_FUNC_HELPER __ivboohelper(39, 40, __resmbchar.mbchar, "autoremove2 before free", _a2_, thisfunct1);
						if( deleteautoremove->_new )
							deleteautoremove->_autoremove2( deleteautoremove->_hmod , deleteautoremove->_removed );
						else
							deleteautoremove->_autoremove_____( deleteautoremove->_removed );
					}
					::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_free
						, ::iv::state_exec );

					if( deleteautoremove->_need_explicity_unregister == false )
						_avail_autoremoves.push(deleteautoremove);

					if(_cs_inited)
						cs1Enter(&_lock_autoremoves2, 519);

					deleteautoremove = _autoremoves2___00.first();
					continue;
				}
			}
			deleteautoremove = deleteautoremove->_doubly_linked_list_next;
		}
		if(_cs_inited)
			cs1Leave(&_lock_autoremoves2);

		if(_cs_inited)
			cs1Enter(&_lock_autoremoves3, 420);
		deleteautoremove = _autoremoves3___00.first();
		for( ; ; )
		{
			if( deleteautoremove == 0 )
				break;
			if( deleteautoremove->before_dll_free && ( ( hmod && deleteautoremove->_hmod == hmod ) 
				|| ( hmod == 0 && deleteautoremove->_hmod == 0 ) ) )
			{
				if( ::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_exec 
					, ::iv::state_busy ) == ::iv::state_busy )
				{
					if( deleteautoremove->_need_explicity_unregister == false )
						_autoremoves3___00.remove( deleteautoremove );
					if(_cs_inited)
						cs1Leave(&_lock_autoremoves3);
					{
						IVBOO_NOTMY_FUNC_HELPER __ivboohelper(41, 42, __resmbchar.mbchar, "autoremove3 before free", _a2_, thisfunct1);
						if( deleteautoremove->_new )
							deleteautoremove->_autoremove2( deleteautoremove->_hmod , deleteautoremove->_removed );
						else
							deleteautoremove->_autoremove_____( deleteautoremove->_removed );
					}
					::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_free
						, ::iv::state_exec );

					if(deleteautoremove->_need_explicity_unregister == false)
						_avail_autoremoves.push(deleteautoremove);

					if(_cs_inited)
						cs1Enter(&_lock_autoremoves3, 419);

					deleteautoremove = _autoremoves3___00.first();
					continue;
				}
			}
			deleteautoremove = deleteautoremove->_doubly_linked_list_next;
		}
		if(_cs_inited)
			cs1Leave(&_lock_autoremoves3);
	};
	void autoloaderclass::onbeforefree(::booldog::base::module* mod)
	{	
		onbeforefreeinternal( mod , mod->handle() );
	}
	void autoloaderclass::onbeforeunloadinternal( ::booldog::base::module* mod , ::booldog::module_handle hmod )
	{
		IVBOO_FUNC2(608);
		{
			::booldog::result_mbchar __resmbchar( &::iv::booldog::autoloadermixed );
			if( __resmbchar.mbchar )
				__resmbchar.mbchar[ 0 ] = 0;
			__resmbchar.mblen = 0;
			::booldog::utils::module::mbs::pathname< 32 >( &__resmbchar , &::iv::booldog::autoloadermixed , hmod , debuginfo_macros );
			::booldog::utils::io::path::mbs::filename_without_extension( 0 , __resmbchar.mbchar , __resmbchar.mblen );
			if(_log)
			{
				LOG_INFO(_log, "<autoloader>module(%pp,%pp) '%s' before unload"
					, mod, hmod, __resmbchar.mbchar ? __resmbchar.mbchar : "exe");
			}

			::iv::autoremove* deleteautoremove = 0;
			if(_cs_inited)
			{
				cs1Enter(&_lock_autoremoves, 618);
			}
			deleteautoremove = _autoremoves___00.first();
			for( ; ; )
			{
				if( deleteautoremove == 0 )
					break;
				if( deleteautoremove->before_dll_free == false && ( ( hmod && deleteautoremove->_hmod == hmod ) 
					|| ( hmod == 0 && deleteautoremove->_hmod == 0 ) ) )
				{
					if( ::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_exec 
						, ::iv::state_busy ) == ::iv::state_busy )
					{
						if( deleteautoremove->_need_explicity_unregister == false )
							_autoremoves___00.remove( deleteautoremove );
						if(_cs_inited)
							cs1Leave(&_lock_autoremoves);
					
						if( deleteautoremove->_new )
							deleteautoremove->_autoremove2( deleteautoremove->_hmod , deleteautoremove->_removed );
						else
							deleteautoremove->_autoremove_____( deleteautoremove->_removed );

						::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_free
							, ::iv::state_exec );

						if( deleteautoremove->_need_explicity_unregister == false )
							_avail_autoremoves.push(deleteautoremove);
						if(_cs_inited)
						{
							cs1Enter(&_lock_autoremoves, 617);
						}

						deleteautoremove = _autoremoves___00.first();
						continue;
					}
				}
				deleteautoremove = deleteautoremove->_doubly_linked_list_next;
			}
			if(_cs_inited)
				cs1Leave(&_lock_autoremoves);

			if(_cs_inited)
				cs1Enter(&_lock_autoremoves2, 517);
			deleteautoremove = _autoremoves2___00.first();
			for( ; ; )
			{
				if( deleteautoremove == 0 )
					break;
				if( deleteautoremove->before_dll_free == false && ( ( hmod && deleteautoremove->_hmod == hmod ) 
					|| ( hmod == 0 && deleteautoremove->_hmod == 0 ) ) )
				{
					if( ::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_exec 
						, ::iv::state_busy ) == ::iv::state_busy )
					{
						if( deleteautoremove->_need_explicity_unregister == false )
							_autoremoves2___00.remove( deleteautoremove );
						if(_cs_inited)
							cs1Leave(&_lock_autoremoves2);
					
						if( deleteautoremove->_new )
							deleteautoremove->_autoremove2( deleteautoremove->_hmod , deleteautoremove->_removed );
						else
							deleteautoremove->_autoremove_____( deleteautoremove->_removed );

						::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_free
							, ::iv::state_exec );

						if( deleteautoremove->_need_explicity_unregister == false )
							_avail_autoremoves.push(deleteautoremove);

						if(_cs_inited)
							cs1Enter(&_lock_autoremoves2, 518);

						deleteautoremove = _autoremoves2___00.first();
						continue;
					}
				}
				deleteautoremove = deleteautoremove->_doubly_linked_list_next;
			}
			if(_cs_inited)
				cs1Leave(&_lock_autoremoves2);

			if(_cs_inited)
				cs1Enter(&_lock_autoremoves3, 418);
			deleteautoremove = _autoremoves3___00.first();
			for( ; ; )
			{
				if( deleteautoremove == 0 )
					break;
				if( deleteautoremove->before_dll_free == false && ( ( hmod && deleteautoremove->_hmod == hmod ) 
					|| ( hmod == 0 && deleteautoremove->_hmod == 0 ) ) )
				{
					if( ::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_exec 
						, ::iv::state_busy ) == ::iv::state_busy )
					{
						if( deleteautoremove->_need_explicity_unregister == false )
							_autoremoves3___00.remove( deleteautoremove );
						if(_cs_inited)
							cs1Leave(&_lock_autoremoves3);
					
						if( deleteautoremove->_new )
							deleteautoremove->_autoremove2( deleteautoremove->_hmod , deleteautoremove->_removed );
						else
							deleteautoremove->_autoremove_____( deleteautoremove->_removed );

						::booldog::interlocked::compare_exchange( &deleteautoremove->_state , ::iv::state_free
							, ::iv::state_exec );

						if( deleteautoremove->_need_explicity_unregister == false )
							_avail_autoremoves.push(deleteautoremove);

						if(_cs_inited)
							cs1Enter(&_lock_autoremoves3, 417);

						deleteautoremove = _autoremoves3___00.first();
						continue;
					}
				}
				deleteautoremove = deleteautoremove->_doubly_linked_list_next;
			}
			if(_cs_inited)
				cs1Leave(&_lock_autoremoves3);
		}
	};
	void autoloaderclass::onbeforeunload(::booldog::base::module* mod)
	{
		IVBOO_FUNC2(722);
		{
			onbeforeunloadinternal( mod , mod->handle() );
			{
				mod->lock( debuginfo_macros );
				module_udata* modudata = (module_udata*)mod->udata();
				if(modudata->_exception)
				{
					::iv::exception_struct* exception = modudata->_exception;
					if(_cs_inited)
					{
						cs1Enter(&pautoloader->_lock_exceptions, 724);
					}
					if( exception->_next )
						exception->_next->_prev = exception->_prev;
					else
						pautoloader->_exceptions = exception->_prev;
					if( exception->_prev )
						exception->_prev->_next = exception->_next;
					if(_cs_inited)
						cs1Leave(&pautoloader->_lock_exceptions);
					::iv::booldog::autoloadermixed.destroy( exception );
				}
				::iv::booldog::autoloadermixed.destroy(modudata);
				mod->unlock( debuginfo_macros );
			}
		}
	}
	::iv::dependency* autoloaderclass::create_dependency()
	{
		IVBOO_FUNC2(809);
		{
			if(_cs_inited)
			{
				cs1Enter(&_lock, 812);
			}
			::iv::dependency* depend = _depends;
			for( ; ; )
			{
				if( depend == 0 )
					break;
				if( ::booldog::interlocked::compare_exchange( &depend->_state , ::iv::state_pending_in_init , ::iv::state_free ) 
					== ::iv::state_free )
				{
					if( depend->dependent_modulepathname.mbchar )
						depend->dependent_modulepathname.mbchar[ 0 ] = 0;
					depend->dependent_modulepathname.mblen = 0;	
					depend->_refs = 1;
					depend->_inited_refs = 0;
					depend->dependent_modhandle = 0;
					depend->module = 0;
					break;
				}
				depend = depend->_prev;
			}
			if( depend == 0 )
			{
				depend = ::iv::booldog::autoloadermixed.create< ::iv::dependency >( &::iv::booldog::autoloadermixed
					, debuginfo_macros );

				depend->_prev = _depends;
				_depends = depend;
			}
			if(_cs_inited)
				cs1Leave(&_lock);
			return depend;
		}
	}
	void* autoloaderclass::load_and_create_deps(void* any_module_address, const char* module_name, const char* module_search_path
		, bool dll_init, param_t* dll_init_params, const char* funcname, void** module, dll_exec_t pre_dll_init)
	{
		IVBOO_FUNC2(311);
		{
			::booldog::result_pointer resptr;
			::booldog::result_module resmod;
			if(::iv::pautoloader->load_module(&resmod, module_name, module_search_path, dll_init, dll_init_params, pre_dll_init))
			{
				if(funcname)
					resmod.module->method(&resptr, &::iv::booldog::autoloadermixed, funcname, debuginfo_macros);

				::iv::dependency* depend_candidate = ::iv::pautoloader->create_dependency();

				::booldog::result res;
#ifdef __WINDOWS__
				::booldog::module_handle modhandle = ::booldog::utils::module::handle(&res, &::iv::booldog::autoloadermixed
					, any_module_address, debuginfo_macros);
				if(modhandle)
					::booldog::utils::module::mbs::pathname< 32 >(&depend_candidate->dependent_modulepathname
					,&::iv::booldog::autoloadermixed, modhandle, debuginfo_macros);
#else
				::booldog::module_handle modhandle = 0;
				if( ::booldog::utils::module::mbs::pathname_from_address< 32 >( &depend_candidate->dependent_modulepathname
					, &::iv::booldog::autoloadermixed , any_module_address , debuginfo_macros ) )
				{
					modhandle = ::booldog::utils::module::mbs::handle(&res, &::iv::booldog::autoloadermixed
						, depend_candidate->dependent_modulepathname.mbchar, debuginfo_macros);
				}
#endif
				if(modhandle == resmod.module->handle())
				{
					if(module)
						*module = resmod.module;
					::iv::module_free_unload module_free_unload_struct = {::iv::pautoloader, true};
					if(dll_init)
					{
						IVBOO_NOTMY_FUNC_HELPER __ivboohelper(228, 292, module_name, "dll_free", _a2_, thisfunct1);
						resmod.module->free(&res, &::iv::booldog::autoloadermixed, ::iv::onbeforefree
							, &module_free_unload_struct, debuginfo_macros);
						if(module_free_unload_struct.locked == false)
						{
							resmod.module->lock(debuginfo_macros);
							module_free_unload_struct.locked = true;
						}
					}
					{
						IVBOO_NOTMY_FUNC_HELPER __ivboohelper(330, 312, module_name, "unload", _a2_, thisfunct1);
						::iv::pautoloader->_loader.unload(&res, resmod.module, ::iv::onbeforeunload
							, &module_free_unload_struct, debuginfo_macros);
						if(module_free_unload_struct.locked == false)
						{
							resmod.module->lock(debuginfo_macros);
							module_free_unload_struct.locked = true;
						}
					}
					::booldog::interlocked::exchange(&depend_candidate->_state, ::iv::state_free);					
				}
				else
				{
					if(::iv::pautoloader->_cs_inited)
					{
						cs1Enter(&::iv::pautoloader->_lock, 811);
					}

					::iv::dependency* depend = ::iv::pautoloader->_depends;
					for( ; ; )
					{
						if(depend == 0)
							break;
						if(::booldog::interlocked::compare_exchange(&depend->_state, 0, 0) == ::iv::state_busy
							&& depend->module == resmod.module && depend->dependent_modhandle == modhandle
							&& ( ( depend_candidate->dependent_modulepathname.mblen == 0 
							&& depend->dependent_modulepathname.mblen == 0 )
							|| strcmp( depend->dependent_modulepathname.mbchar , depend_candidate->dependent_modulepathname.mbchar ) == 0 ) )
							break;
						depend = depend->_prev;
					}
					if( depend == 0 )
					{
						if( dll_init )
							::booldog::interlocked::increment( &depend_candidate->_inited_refs );
						depend_candidate->module = resmod.module;
						depend_candidate->dependent_modhandle = modhandle;
						if(::iv::pautoloader->_cs_inited)
							cs1Leave(&::iv::pautoloader->_lock);

						if( module )
							*module = resmod.module;

						::booldog::interlocked::exchange( &depend_candidate->_state , ::iv::state_busy );
					}
					else
					{
						if( dll_init )
							::booldog::interlocked::increment( &depend->_inited_refs );
						::booldog::interlocked::increment( &depend->_refs );
						if(::iv::pautoloader->_cs_inited)
							cs1Leave(&::iv::pautoloader->_lock);

						::booldog::interlocked::exchange( &depend_candidate->_state , ::iv::state_free );

						if( module )
							*module = depend->module;
					}
				}
				if(modhandle)
					::booldog::utils::module::free(&res, &::iv::booldog::autoloadermixed, modhandle
						, debuginfo_macros);
			}
			return resptr.pres;
		}
	}
	void* autoloaderclass::getmodulefuncinternal(void* any_module_address, const char* module_name, const char* module_search_path
		, bool dll_init, param_t* dll_init_params, const char* funcname, void** module)
	{
		IVBOO_FUNC(298);
		if( strcmp( module_name , "autoloader" ) == 0 )
		{
			if( funcname )
			{
				if( strcmp( funcname , "autoloader_unload" ) == 0 )
					return (void*)::iv::unloadinternal;
				else if( strcmp( funcname , "autoloader_get_filename" ) == 0 )
					return (void*)::iv::get_filenameinternal;
				else if( strcmp( funcname , "autoloader_root_path" ) == 0 )
					return (void*)::iv::root_pathinternal;
				else if( strcmp( funcname , "autoloader_free" ) == 0 )
					return (void*)::iv::freeinternal;
				else if( strcmp( funcname , "autoloader_method" ) == 0 )
					return (void*)::iv::methodinternal;
			}
			return 0;
		}
		else
		{
			return load_and_create_deps(any_module_address, module_name, module_search_path, dll_init, dll_init_params, funcname
				, module, 0);
		}
	}
	static void freeinternal( void* ptr )
	{
		pautoloader->freeinternal( ptr );
	};
	static void onbeforeunload(void* udata, ::booldog::base::module* mod)
	{
		::iv::module_free_unload* t = (::iv::module_free_unload*)udata;
		if(t->locked)
		{
			mod->unlock();
			t->locked = false;
		}
		t->pautoloader->onbeforeunload(mod);
	}
	static void onbeforefree(void* udata, ::booldog::base::module* mod)
	{
		::iv::module_free_unload* t = (::iv::module_free_unload*)udata;
		if(t->locked)
		{
			mod->unlock();
			t->locked = false;
		}
		t->pautoloader->onbeforefree(mod);
	}
	static void* methodinternal( void* module , const char* name )
	{
		return pautoloader->methodinternal( module , name );
	};
	static const char* root_pathinternal(void)
	{
		return ::iv::root_path;
	};
	static char* get_filenameinternal( void* module )
	{
		return pautoloader->get_filenameinternal( module );
	};
	static void unloadinternal( void* any_module_address , void* module )
	{
		pautoloader->unloadinternal( any_module_address , module );
	};
};
booexport int dll_init(const param_t*)
{
	::iv::pautoloader = ::iv::booldog::autoloadermixed.create< ::iv::autoloaderclass >( debuginfo_macros );	
	::iv::booldog::holder.stack = ::iv::booldog::autoloadermixed.holder.stack;
	::iv::autoloader_nm::initialize_module_struct();
	::booldog::results::mbchar mbchar0(&::iv::booldog::autoloadermixed);
	if(::iv::stable_renamed == 0)
		::iv::rename_stable_and_memory(&mbchar0);
	IVMEMORYINIT(0);
	::iv::exceptions::create(::iv::autoloaderclass::exception);
	IVSTABLEINIT(0);	
	iv_uint64 t[] =
	{
		3 , //count
		32768 , //_stbl_stackfunlimitFORWHO
		80 //_stbl_stackfunlimitWHO
	};
	//pStableContainer.pSetLimitStackFunction( 4096 , 4096 , t );
	pStableContainer.pSetLimitStackFunction(32768, 4096, t);	
	{
		IVBOO_FUNC2(826);
		{
			cs1Init(&::iv::pautoloader->_lock, 825);
			cs1Init(&::iv::pautoloader->_lock_exceptions, 725);
			cs1Init(&::iv::pautoloader->_lock_autoremoves, 625);
			cs1Init(&::iv::pautoloader->_lock_autoremoves2, 525);
			cs1Init(&::iv::pautoloader->_lock_autoremoves3, 425);
			IV_RWLOCKINIT(&::iv::pautoloader->_lock_global_datas);
			::iv::pautoloader->_cs_inited = true;
	
			void* mod = 0;
			::iv::autoloaderclass::getmodulefuncinternal(&::iv::_getmodulefunc, "threads", "lib", true, 0, 0, &mod);
			if(mod == 0)
				::iv::autoloaderclass::getmodulefuncinternal(&::iv::_getmodulefunc, "threads", "../lib", true, 0, 0, &mod);
			mod = 0;
			::iv::autoloaderclass::getmodulefuncinternal(&::iv::_getmodulefunc, "threads.pool", "lib", true, 0, 0, &mod);
			if(mod == 0)
				::iv::autoloaderclass::getmodulefuncinternal(&::iv::_getmodulefunc, "threads.pool", "../lib", true, 0, 0, &mod);

			::booldog::interlocked::exchange(&::iv::autoloader_inited, 1);

			::iv::pautoloader->_log = ::iv::log::init("booter", ::iv::logparams, false);
			::iv::pautoloader->_ruxlog = ::iv::log::init("rux", ::iv::logparams, false);
	
			if(::iv::pautoloader->_tempprivate_info_thread)
				::iv::pautoloader->_rux_info_task_handle = ::iv::tasks::noncritical::add3("rux::info", ::iv::autoloaderclass::rux_info_task
				, ::iv::pautoloader, 60000, true, false);
			if( ::iv::pautoloader->_temp_set_ruxlog_write && ::iv::pautoloader->_ruxlog )
				::iv::pautoloader->_temp_set_ruxlog_write( ::iv::autoloaderclass::ruxlog_write );
			::iv::tasks::noncritical::add("autoloader::oncheckmodules", ::iv::autoloaderclass::oncheckmodules, ::iv::pautoloader, 15000);
		}
	}
	return 0;
}
booexport const char* autoloader_root_path(void)
{
	return ::iv::root_path;
};
booexport int pre_dll_init( const param_t* p )
{
	::iv::_getmodulefunc = ::iv::autoloaderclass::getmodulefuncinternal;
	::iv::_new_register_autoremove_with_return = ::iv::autoloaderclass::new_register_autoremoveinternal_with_return;
	::iv::_new_unregister_autoremove_with_return = ::iv::autoloaderclass::new_unregister_autoremoveinternal_with_return;
	::iv::_new_register_autoremove = ::iv::autoloaderclass::new_register_autoremoveinternal;
	::iv::_new_unregister_autoremove = ::iv::autoloaderclass::new_unregister_autoremoveinternal;
	::iv::_register_autoremove = ::iv::autoloaderclass::register_autoremoveinternal;
	::iv::_unregister_autoremove = ::iv::autoloaderclass::unregister_autoremoveinternal;
	::iv::_register_autoremove2 = ::iv::autoloaderclass::register_autoremoveinternal2;
	::iv::_unregister_autoremove2 = ::iv::autoloaderclass::unregister_autoremoveinternal2;
	::iv::_register_autoremove3 = ::iv::autoloaderclass::register_autoremoveinternal3;
	::iv::_unregister_autoremove3 = ::iv::autoloaderclass::unregister_autoremoveinternal3;
	::iv::autoloader_nm::_unload = ::iv::unloadinternal;
	::iv::autoloader_nm::_get_filename = ::iv::get_filenameinternal;
	::iv::autoloader_nm::_root_path = ::iv::root_pathinternal;
	::iv::autoloader_nm::_free = ::iv::freeinternal;
	::iv::autoloader_nm::_method = ::iv::methodinternal;
	::iv::_fast_register_autoremove = ::iv::autoloaderclass::fast_register_autoremove;
	::iv::_fast_unregister_autoremove = ::iv::autoloaderclass::fast_unregister_autoremove;	
	::iv::_initialize_module_struct = ::iv::autoloaderclass::initialize_module_struct;
	::iv::autoloader_nm::_global_data_get = ::iv::autoloaderclass::global_data_get;
	::iv::autoloader_nm::_global_data_set = ::iv::autoloaderclass::global_data_set;
	param_t* exe = 0;
	for( param_for_param( p ) )
	{
		param_start;
		param_get_config( exe );
	}
	if( exe )
	{
		callback_t* init = 0;
		void* SetHook = 0 , * GetHook = 0 , * logparams = 0;
		const char* root_path = 0;
		iv_int32* stable_renamed = 0;
		for( param_for_param( exe ) )
		{
			param_start;
			param_get_callback( init );
			param_get_pvoid( SetHook );
			param_get_pvoid( GetHook );
			param_get_pvoid( logparams );
			param_get_pchar(root_path);
			param_get_pint32(stable_renamed);
		}
		::iv::SetHook = SetHook;
		::iv::GetHook = GetHook;
		::iv::logparams = (const param_t*)logparams;
		if(stable_renamed)
			::iv::stable_renamed = *stable_renamed;
		if(root_path)
#ifdef __WINDOWS__
			strcpy_s(::iv::root_path, 4096, root_path);
#else
			strcpy(::iv::root_path, root_path);
#endif
		else
			::iv::root_path[0] = 0;
		if( SetHook && GetHook )
		{
			::iv::hook::_SetHook = (::iv::hook::SetHook_t)SetHook;
			::iv::hook::_GetHook = (::iv::hook::GetHook_t)GetHook;
		}
		if( init && init->func )
		{
			param_t iv[] = 
			{
				{ PARAM_PVOID, "getmodulefunc", (void*)::iv::_getmodulefunc },
				{ PARAM_PVOID, "new_register_autoremove", (void*)::iv::_new_register_autoremove },
				{ PARAM_PVOID, "new_unregister_autoremove", (void*)::iv::_new_unregister_autoremove },
				{ PARAM_PVOID, "new_register_autoremove_with_return", (void*)::iv::_new_register_autoremove_with_return },
				{ PARAM_PVOID, "new_unregister_autoremove_with_return", (void*)::iv::_new_unregister_autoremove_with_return },
				{ PARAM_PVOID, "register_autoremove", (void*)::iv::_register_autoremove },
				{ PARAM_PVOID, "unregister_autoremove", (void*)::iv::_unregister_autoremove },
				{ PARAM_PVOID, "register_autoremove2", (void*)::iv::_register_autoremove2 },
				{ PARAM_PVOID, "unregister_autoremove2", (void*)::iv::_unregister_autoremove2 },
				{ PARAM_PVOID, "register_autoremove3", (void*)::iv::_register_autoremove3 },
				{PARAM_PVOID, "fast_register_autoremove", (void*)::iv::_fast_register_autoremove},
				{PARAM_PVOID, "fast_unregister_autoremove", (void*)::iv::_fast_unregister_autoremove},
				{PARAM_PVOID, "initialize_module_struct", (void*)::iv::_initialize_module_struct},
				{PARAM_PVOID, "global_data_set", (void*)::iv::autoloader_nm::_global_data_set},
				{PARAM_PVOID, "global_data_get", (void*)::iv::autoloader_nm::_global_data_get},
				{ PARAM_PVOID, "unregister_autoremove3", (void*)::iv::_unregister_autoremove3 },
				{ PARAM_PVOID, "autoloader_unload" , (void*)::iv::unloadinternal },
				{ PARAM_PVOID, "autoloader_get_filename" , (void*)::iv::get_filenameinternal },
				{ PARAM_PVOID, "autoloader_root_path" , (void*)::iv::root_pathinternal },
				{ PARAM_PVOID, "autoloader_free" , (void*)::iv::freeinternal },
				{ PARAM_PVOID, "autoloader_method" , (void*)::iv::methodinternal },
				{ 0, 0, 0 }
			};
			param_t pp[] = 
			{
				{ PARAM_PARAM, "exe", exe },
				{ PARAM_PARAM, "iv", iv },
				{ 0, 0, 0 }
			};
			init->func( init->data , pp );
		}
	}
	return 0;
};
booexport int dll_exec( const param_t* p )
{
	param_t* exe = 0;
	for( param_for_param( p ) )
	{
		param_start;
		param_get_config( exe );
	}
	if( exe )
	{
		const char* cmd = 0;
		for( param_for_param( exe ) )
		{
			param_start;
			param_get_pchar( cmd );
		}
		if( cmd )
		{
 			if( strcmp( cmd , "autoload" ) == 0 )
				::iv::pautoloader->initialize();
		}
	}
	return 0;
};
booexport int dll_free( void )
{
	::iv::booldog::autoloadermixed.destroy(	::iv::pautoloader );
	return 0;
};
booexport bool autoloader_delay_init(void* any_module_address, dll_exec_t pre_dll_init, void* reserved)
{
	reserved = reserved;
	IVBOO_FUNC(89);
	::booldog::allocators::single_threaded::mixed< 1024 > mixed(&::iv::booldog::autoloaderheap);
	{
		::booldog::result_mbchar modulepathname(&mixed);
		::booldog::result res;
#ifdef __WINDOWS__
		::booldog::module_handle modhandle = ::booldog::utils::module::handle(&res, &mixed, any_module_address, debuginfo_macros);
		if(modhandle)
		{
			::booldog::utils::module::mbs::pathname< 32 >(&modulepathname, modulepathname.mballocator, modhandle, debuginfo_macros);
			::booldog::utils::module::free(&res, &mixed, modhandle, debuginfo_macros);
		}
#else
		::booldog::utils::module::mbs::pathname_from_address< 32 >(&modulepathname, modulepathname.mballocator, any_module_address 
			, debuginfo_macros);
#endif
		if(modulepathname.mblen)
		{
			void* module = 0;
			::iv::autoloaderclass::load_and_create_deps(&::iv::_getmodulefunc, modulepathname.mbchar, 0, true, 0, 0, &module
				, pre_dll_init);
			if(module)
				return true;
		}
		return false;
	}
}