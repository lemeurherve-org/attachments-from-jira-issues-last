#ifndef VERSION_H
#define VERSION_H

#include "../inc/iv_version.h"

#define VER_INTERNAL_NAME "config"
#define VER_FILE_DESCRIPTION "Integra Video 7.0 config library"

#define VERSION_H_STR(n) VERSION_H_STRINGIFY_HELPER(n)
#define VERSION_H_STRINGIFY_HELPER(n) #n

#define VERSION_STRING \
  VERSION_H_STR(MAJOR_VERSION) "." \
  VERSION_H_STR(MINOR_VERSION) "." \
  VERSION_H_STR(PATCH_VERSION) "." \
  VERSION_H_STR(SVN_BUILD_NUMBER)

#endif
