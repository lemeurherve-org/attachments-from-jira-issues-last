#!/usr/bin/env groovy

def call(boolean qt) {
    try {
        if(qt) {

        } else {
            pipeline {
                agent { label 'docker' }
                stages {
                    stage ('variables') {
                        steps {
                            catchError {
                                script {
                                    conan.prepare()
                                }
                            }
                        }
                    }
                    stage('build')
                    {
                        failFast true
                        parallel {
                            stage('debian-6 x64 release') {
                                agent {
                                    dockerfile {
                                    filename 'debian-6.dockerfile'
                                    dir "Docker"
                                    label "docker"  
                                    }            
                                }
                                steps {
                                    catchError {
                                        script {              
                                            // echo "${repo_owner}"                          
                                            conan.build("linux-x64-release")
                                        }
                                    }
                                }
                                post {
                                    success {  
                                        catchError {                                  
                                            script {
                                                conan.success()
                                                cleanWs()
                                            }
                                        }
                                    }
                                    failure {  
                                        catchError {      
                                            script {
                                                conan.failure()
                                            }
                                        }
                                    }
                                }
                            }
                            stage('debian-6 x64 debug') {
                                agent {
                                    dockerfile {
                                    filename 'debian-6.dockerfile'
                                    dir "Docker"
                                    label "docker"  
                                    }            
                                }
                                steps {
                                    catchError {
                                        script {
                                            conan.build("linux-x64-debug")
                                        }
                                    }
                                }
                                post {
                                    success {    
                                        catchError {    
                                            script {
                                                conan.success()
                                                cleanWs()
                                            }
                                        }
                                    }
                                    failure {        
                                        catchError {
                                            script {
                                                conan.failure()
                                            }
                                        }
                                    }
                                }
                            }
                            stage('windows x64 release') {
                                agent {
                                    label 'windows'
                                }                    
                                steps {   
                                    catchError {     
                                        script {
                                            conan.build("windows-x64-release")
                                        }
                                    }
                                }
                                post {
                                    success {    
                                        catchError {    
                                            script {
                                                conan.success()
                                                cleanWs()
                                            }
                                        }
                                    }
                                    failure {        
                                        catchError {
                                            script {
                                                conan.failure()
                                            }
                                        }
                                    }
                                }
                            }
                            stage('windows x64 debug') {
                                agent {
                                    label 'windows'
                                }                    
                                steps {
                                    catchError {
                                        script {
                                            conan.build("windows-x64-debug")
                                        }
                                    }
                                }
                                post {
                                    success {   
                                        catchError {     
                                            script {
                                                conan.success()
                                                cleanWs()
                                            }
                                        }
                                    }
                                    failure {        
                                        catchError {
                                            script {
                                                conan.failure()
                                            }
                                        }
                                    }
                                }
                            }
                            stage('windows x86 debug') {
                                agent {
                                    label 'windows'
                                }
                                steps {
                                    catchError {
                                        script {
                                            conan.build("windows-x86-debug")
                                        }
                                    }
                                }
                                post {
                                    success {   
                                        catchError {     
                                            script {
                                                conan.success()
                                                cleanWs()
                                            }
                                        }
                                    }
                                    failure {  
                                        catchError {      
                                            script {
                                                conan.failure()
                                            }
                                        }
                                    }
                                }
                            }
                            stage('windows x86 release') {
                                agent {
                                    label 'windows'
                                }
                                steps {
                                    catchError {
                                        script {
                                            conan.build("windows-x86-release")
                                        }
                                    }
                                }
                                post {
                                    success {   
                                        catchError {     
                                            script {
                                                conan.success()
                                                cleanWs()
                                            }
                                        }
                                    }
                                    failure {        
                                        catchError {
                                            script {
                                                conan.failure()
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                post {
                    success { 
                        catchError {       
                            script {
                                conan.jenkinsfile_success()
                                cleanWs()
                            }
                        }
                    }
                    failure {        
                        catchError {
                            script {
                                conan.jenkinsfile_failure()
                            }
                        }
                    }
                }
            }
        }
    }
    catch(error) {
        echo "buildAll ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}