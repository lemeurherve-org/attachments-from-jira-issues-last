#!/usr/bin/env groovy

@NonCPS
def convert_windows_to_git_bash(text) {
    def List tag_name_lines = text.split('\\\\')
    def disk = tag_name_lines[0]
    disk = disk[0..-2]
    def changed_disk = "/${disk}"
    tag_name_lines[0] = changed_disk
    tag_name_lines.join('/')
}
@NonCPS
def get_second_line(text) {
    def List tag_name_lines = text.split('\n')
    tag_name_lines[1]
}
def withSSHAgent(passphrase, keyfile, command) {
    def output = sh(returnStdout: true, script: """
    echo "#!/bin/sh" > ./ssh_pass.sh
    echo "echo '${passphrase}'" >> ./ssh_pass.sh
    chmod +x ./ssh_pass.sh
    eval \$(ssh-agent)
    DISPLAY=: SSH_ASKPASS=./ssh_pass.sh ssh-add "${keyfile}"
    echo "SSH_AGENT_PID=\$SSH_AGENT_PID;export SSH_AGENT_PID;SSH_AUTH_SOCK=\$SSH_AUTH_SOCK;export SSH_AUTH_SOCK"
    """)
    output = get_second_line(output)
    try {
        sh(script: """${output}
        ${command}
        """)
    }
    finally {
        sh(script: """${output}
        trap 'ssh-agent -k' EXIT
        if [ -e ./ssh_pass.sh ]
        then
            rm ./ssh_pass.sh
        fi
        """)
    }
}
def build_shell(passphrase, keyfile, workspace, repo_owner, conan_profile) {
    try {
        withEnv(["CONAN_USER_HOME=${env.WORKSPACE}", "CONAN_USERNAME=${repo_owner}"
        , "CONAN_CHANNEL=stable"]) {
            // withSSHAgent(passphrase, keyfile, 
            // """rm -rf \"${workspace}/build\"
            // git --version
            // conan remote add conan-local https://conan.iv.integra-s.com False || true
            // conan user -r conan-local -p 1 conan || true
            // conan remote remove conan-center || true
            // conan remote remove conan-transit || true    
            // conan remove '*' -f || true
            // conan install . -if build -pr=./conan_profiles/${conan_profile}
            // conan build . -if build -bf build
            // conan export-pkg -f -bf build . ${repo_owner}/stable
            // """)
            sh(script: "conan remote add conan-local https://conan.iv.integra-s.com False || true")
            sh(script: "conan user -r conan-local -p 1 conan || true")
            sh(script: "conan remote remove conan-center || true")
            sh(script: "conan remote remove conan-transit || true")   
            sh(script: "conan remove '*' -f || true")
            // withSSHAgent(passphrase, keyfile, 
            // """conan install . -if build -pr=./conan_profiles/${conan_profile}
            // conan build . -if build -bf build
            // conan export-pkg -f -bf build . ${repo_owner}/stable
            // """)
            sh(script: "conan install . -if build -pr=./conan_profiles/${conan_profile}")
            // withSSHAgent(passphrase, keyfile, 
            // """conan build . -if build -bf build""")
            if(isUnix()) {
                sh(script: "conan build -if build -bf build .")
            }
            else {
                bat(script: "chcp 1251 && conan build -if build -bf build .")
            }
        }
    }
    catch(error) {
        echo "build_shell ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}
def header_only_export_shell(passphrase, keyfile, workspace, repo_owner) {
    try {
        withEnv(["CONAN_USER_HOME=${env.WORKSPACE}", "CONAN_USERNAME=${repo_owner}"
        , "CONAN_CHANNEL=stable"]) {
            withSSHAgent(passphrase, keyfile, 
            """rm -rf \"${workspace}/build\"
            conan remote add conan-local https://conan.iv.integra-s.com False || true
            conan user -r conan-local -p 1 conan || true
            conan remote remove conan-center || true
            conan remote remove conan-transit || true    
            conan remove '*' -f || true
            conan export . ${repo_owner}/stable
            """)
        }
    }
    catch(error) {
        echo "header_only_export_shell ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}
def prepare() {
    try {
        def repo_url = sh(returnStdout: true, script: "git config --get remote.origin.url")
        repo_url = repo_url.trim()
        def List list = repo_url.split('/')
        repo_name = list[-1]
        repo_name = repo_name[0..-5]
        repo_owner = list[-2]
        if(repo_owner == "IntegraVideo") {
            repo_owner = "iv"
        }
    }
    catch(error) {
        echo "prepare ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}
def success() {
    try {
        withEnv(["CONAN_USER_HOME=${env.WORKSPACE}", "CONAN_USERNAME=${repo_owner}"
        , "CONAN_CHANNEL=stable"]) {
            // sh "conan upload --force --all -c -r conan-local '${repo_name}/*'"
        }
        //cleanWs()
    }
    catch(error) {
        echo "success ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}
def failure() {
    try {
        withEnv(["CONAN_USER_HOME=${env.WORKSPACE}", "CONAN_USERNAME=${repo_owner}"
        , "CONAN_CHANNEL=stable"]) {
            echo "conan_failure"
        }
        //cleanWs()
    }
    catch(error) {
        echo "failure ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}
def build(conan_profile) {
    try {
        withCredentials([sshUserPrivateKey(credentialsId: 'arnold', passphraseVariable: 'GOGS_PASSPHRASE'
        , usernameVariable: 'GOGS_USER', keyFileVariable: 'GOGS_KEY')]) {
            script {
                if(isUnix()) {
                    build_shell(env.GOGS_PASSPHRASE, env.GOGS_KEY, env.WORKSPACE, repo_owner, conan_profile)
                }
                else {
                    def GIT_BASH_GOGS_KEY = convert_windows_to_git_bash(env.GOGS_KEY)
                    def workspace = convert_windows_to_git_bash(env.WORKSPACE)
                    build_shell(env.GOGS_PASSPHRASE, GIT_BASH_GOGS_KEY, workspace, repo_owner, conan_profile)
                }
            }
        }
    }
    catch(error) {
        echo "build ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}
def header_only_export() {
    try {
        withCredentials([sshUserPrivateKey(credentialsId: 'arnold', passphraseVariable: 'GOGS_PASSPHRASE'
        , usernameVariable: 'GOGS_USER', keyFileVariable: 'GOGS_KEY')]) {
            script {
                if(isUnix()) {
                    header_only_export_shell(env.GOGS_PASSPHRASE, env.GOGS_KEY, env.WORKSPACE, repo_owner)
                }
                else {
                    def GIT_BASH_GOGS_KEY = convert_windows_to_git_bash(env.GOGS_KEY)
                    def workspace = convert_windows_to_git_bash(env.WORKSPACE)
                    header_only_export_shell(env.GOGS_PASSPHRASE, GIT_BASH_GOGS_KEY, workspace, repo_owner)
                }
            }
        }    
    }
    catch(error) {
        echo "header_only_export ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}
def jenkinsfile_success() {
    try {
        slackSend(color: 'good', message: "Build ${env.JOB_NAME} is succeeded(${env.BUILD_URL})")
        //cleanWs()
    }
    catch(error) {
        echo "jenkinsfile_success ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}
def jenkinsfile_failure() {
    try {
        withEnv(["CONAN_USER_HOME=${env.WORKSPACE}", "CONAN_USERNAME=${repo_owner}"
        , "CONAN_CHANNEL=stable"]) {
            echo "jenkinsfile_failure" 
        }
        slackSend(color: 'danger', message: "Something wrong with build ${env.JOB_NAME}(${env.BUILD_URL})")
        //cleanWs()
    }
    catch(error) {
        echo "jenkinsfile_failure ${error}"
        currentBuild.result = "FAILURE"
    }
    finally {
    }
}