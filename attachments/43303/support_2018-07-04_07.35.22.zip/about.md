Jenkins
=======

Version details
---------------

  * Version: `2.128`
  * Mode:    WAR
  * Url:     http://jenkinssecure:8081/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/java/jdk1.8.0_40/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_40
      - Maximum memory:   1.78 GB (1908932608)
      - Allocated memory: 1.13 GB (1211629568)
      - Free memory:      498.15 MB (522347672)
      - In-use memory:    657.35 MB (689281896)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.40-b25
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-504.16.2.el6.x86_64
      - Distribution: "CentOS release 6.6 (Final)"
      - LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
  * Process ID: 29480 (0x7328)
  * Process started: 2018-07-04 05:50:26.969+0000
  * Process uptime: 1 hr 44 min
  * JVM startup parameters:
      - Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
      - Classpath: `/var/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Xmx2048m`
      - arg[1]: `-XX:MaxPermSize=256m`
      - arg[2]: `-Dcors.origin=*`
      - arg[3]: `-Dcors.methods=GET,POST,PUT,DELETE`
      - arg[4]: `-Dcors.headers=Authorization`
      - arg[5]: `-Djava.io.tmpdir=/var/tmp`
      - arg[6]: `-DJENKINS_HOME=/var/jenkins`
      - arg[7]: `-Dhudson.model.ParametersAction.keepUndefinedParameters=false`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.7 'Jenkins Active Directory plugin'
  * ansicolor:0.5.2 'AnsiColor'
  * ant:1.8 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.5-3.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * artifactory:2.16.1 'Jenkins Artifactory Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * backup:1.6.1 'Backup plugin'
  * badge:1.4 'Badge'
  * blueocean:1.6.0 'Blue Ocean'
  * blueocean-autofavorite:1.2.2 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.6.0 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.6.0 'Common API for Blue Ocean'
  * blueocean-config:1.6.0 'Config API for Blue Ocean'
  * blueocean-core-js:1.6.0 'Blue Ocean Core JS'
  * blueocean-dashboard:1.6.0 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.2.0 'Display URL for Blue Ocean'
  * blueocean-events:1.6.0 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.6.0 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.6.0 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.6.0 'i18n for Blue Ocean'
  * blueocean-jira:1.6.0 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.6.0 'JWT for Blue Ocean'
  * blueocean-personalization:1.6.0 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.6.0 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.6.0 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.6.0 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.6.0 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.6.0 'REST Implementation for Blue Ocean'
  * blueocean-web:1.6.0 'Web for Blue Ocean'
  * bouncycastle-api:2.16.3 'bouncycastle API Plugin'
  * branch-api:2.0.20 'Branch API Plugin'
  * build-blocker-plugin:1.7.3 'Build Blocker Plugin'
  * build-metrics:1.3 'build-metrics'
  * build-pipeline-plugin:1.5.8 'Build Pipeline Plugin'
  * build-timeout:1.19 'Build Timeout'
  * build-user-vars-plugin:1.5 'Jenkins user build vars plugin'
  * buildgraph-view:1.8 'buildgraph-view'
  * built-on-column:1.1 'built-on-column'
  * chucknorris:1.1 'ChuckNorris Plugin'
  * claim:2.15 'Jenkins Claim Plugin'
  * cloudbees-bitbucket-branch-source:2.2.11 'Bitbucket Branch Source Plugin'
  * cloudbees-disk-usage-simple:0.9 'CloudBees Disk Usage Simple Plugin'
  * cloudbees-folder:6.4 'Folders Plugin'
  * cobertura:1.12.1 'Jenkins Cobertura Plugin'
  * collapsing-console-sections:1.7.0 'Jenkins Collapsing Console Sections Plugin'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * compact-columns:1.10 'Compact Columns'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:2.18 'Config File Provider Plugin'
  * configurationslicing:1.47 'Configuration Slicing plugin'
  * confluence-publisher:2.0.1 'Confluence Publisher'
  * console-column-plugin:1.5 'Console Column Plugin'
  * convert-to-pipeline:1.0 'Convert To Pipeline'
  * copyartifact:1.40 'Copy Artifact Plugin'
  * cors-filter:1.1 'CORS support for Jenkins'
  * cppcheck:1.21 'Jenkins Cppcheck Plug-in'
  * cppunit:1.4 'Hudson cppunit plugin'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.16 'Credentials Binding Plugin'
  * cvs:2.14 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.11 'Dashboard View'
  * delivery-pipeline-plugin:1.2.0 'Delivery Pipeline Plugin'
  * display-url-api:2.2.0 'Display URL API'
  * docker-commons:1.13 'Docker Commons Plugin'
  * docker-workflow:1.17 'Docker Pipeline'
  * downstream-buildview:1.9 'Downstream build view'
  * downstream-ext:1.8 'Downstream-Ext'
  * durable-task:1.22 'Durable Task Plugin'
  * email-ext:2.62 'Email Extension Plugin'
  * embeddable-build-status:1.9 'embeddable-build-status'
  * envinject:2.1.5 'Environment Injector Plugin'
  * envinject-api:1.5 'EnvInject API Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * ez-templates:1.3.2 'EZ Templates'
  * favorite:2.3.2 'Favorite'
  * flexible-publish:0.15.2 'Flexible Publish Plugin'
  * git:3.9.1 'Jenkins Git plugin'
  * git-client:2.7.2 'Jenkins Git client plugin'
  * git-parameter:0.9.2 'Git Parameter Plug-In'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.29.1 'GitHub plugin'
  * github-api:1.92 'GitHub API Plugin'
  * github-branch-source:2.3.6 'GitHub Branch Source Plugin'
  * github-oauth:0.29 'GitHub Authentication plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * global-build-stats:1.5 'Hudson global-build-stats plugin'
  * gradle:1.28 'Gradle Plugin'
  * greenballs:1.15 'Green Balls'
  * groovy-postbuild:2.4.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.6-1.0 'Handy Uri Templates 2.x API Plugin'
  * heavy-job:1.1 'Heavy Job Plugin'
  * hipchat:2.1.1 'Jenkins HipChat Plugin'
  * htmlpublisher:1.16 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * ivy:1.28 'Ivy Plugin'
  * jackson2-api:2.8.11.3 'Jackson 2 API Plugin'
  * jacoco:3.0.1 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jdk-tool:1.1 'JDK Tool Plugin'
  * jenkins-design-language:1.6.0 'Jenkins Design Language'
  * jenkins-multijob-plugin:1.30 'Jenkins Multijob plugin'
  * jira:3.0.0 'Jenkins JIRA plugin'
  * jobConfigHistory:2.18 'Jenkins Job Configuration History Plugin'
  * jquery:1.12.4-0 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.2 'Jenkins JSch dependency plugin'
  * junit:1.24 'JUnit Plugin'
  * keyboard-shortcuts-plugin:1.2 'Keyboard Shortcuts Plugin'
  * label-linked-jobs:5.1.2 'Label Linked Jobs Plugin'
  * ldap:1.20 'LDAP Plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * mailer:1.21 'Jenkins Mailer Plugin'
  * managed-scripts:1.4 'Managed Scripts'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.13 'Matrix Project Plugin'
  * maven-plugin:3.1.2 'Maven Integration plugin'
  * mercurial:2.3 'Jenkins Mercurial plugin'
  * metrics:3.1.2.12 'Metrics Plugin'
  * modernstatus:1.2 'Modern Status'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * monitoring:1.73.0 'Monitoring'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * nested-view:1.14 'Nested View Plugin'
  * nodejs:1.2.6 'NodeJS Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * performance:3.10 'Performance Plugin'
  * pipeline-build-step:2.7 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-githubnotify-step:1.0.4 'Pipeline GitHub Notify Step Plugin'
  * pipeline-graph-analysis:1.6 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.10 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.10 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:2.1.0 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * platformlabeler:2.0 'Jenkins platformlabeler plugin'
  * plot:2.1.0 'Plot plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * postbuildscript:2.7.0 'Jenkins PostBuildScript Plugin'
  * PrioritySorter:3.6.0 'Jenkins Priority Sorter Plugin'
  * promoted-builds:3.2 'Jenkins promoted builds plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * python:1.3 'Python Plugin'
  * rebuild:1.28 'Rebuilder'
  * resource-disposer:0.9 'Resource Disposer Plugin'
  * ruby-runtime:0.13 'ruby-runtime'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.2.7 'SCM API Plugin'
  * script-security:1.44 'Script Security Plugin'
  * sectioned-view:1.24 'Sectioned View Plugin'
  * shelve-project-plugin:1.5 'Shelve Project Plugin'
  * sonar:2.7.1 'SonarQube Scanner for Jenkins'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.6.1 'Jenkins SSH plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.26 'Jenkins SSH Slaves plugin'
  * status-view:1.0 'Status View Plugin'
  * structs:1.14 'Structs Plugin'
  * subversion:2.11.0 'Jenkins Subversion Plug-in'
  * support-core:2.47 'Support Core Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * thinBackup:1.9 'ThinBackup'
  * timestamper:1.8.10 'Timestamper'
  * token-macro:2.5 'Token Macro Plugin'
  * validating-string-parameter:2.4 'Validating String Parameter Plugin'
  * variant:1.1 'Variant Plugin'
  * versioncolumn:2.0 'Jenkins Versions Node Monitors plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.28 'Pipeline: API'
  * workflow-basic-steps:2.9 'Pipeline: Basic Steps'
  * workflow-cps:2.53 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.19 'Pipeline: Nodes and Processes'
  * workflow-job:2.21 'Pipeline: Job'
  * workflow-multibranch:2.19 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.15 'Pipeline: Step API'
  * workflow-support:2.18 'Pipeline: Supporting APIs'
  * ws-cleanup:0.34 'Jenkins Workspace Cleanup Plugin'
  * xunit:2.0.2 'xUnit plugin'
  * xvfb:1.1.3 'Jenkins Xvfb plugin'
