Monitors
========

`hudson.plugins.active_directory.ActiveDirectorySecurityRealm$TlsConfigurationAdministrativeMonitor`
--------------
(active and enabled)

`jenkins.CLI`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

`jenkins.security.s2m.MasterKillSwitchWarning`
--------------
(active and enabled)
