Current build queue has 1 item(s).
---------------
 * Name of item: part of rndtest_glimpse_sl » develop #96
    - In queue for: 6 min 47 sec
    - Is blocked: false
    - Why in queue: Waiting for next available executor on ‘secure’
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@630afb39
    - Can run: null
  * Task Dispatcher: hudson.plugins.buildblocker.BuildBlockerQueueTaskDispatcher@5373eff0
    - Can run: null
  * Task Dispatcher: jenkins.advancedqueue.RunExclusiveThrottler$RunExclusiveDispatcher@26a3dfb2
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@601a702c
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@547d9c25
    - Can run: null
----

Is quieting down: false
