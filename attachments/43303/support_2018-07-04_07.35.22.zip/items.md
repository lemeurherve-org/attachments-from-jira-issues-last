Item statistics
===============

  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 146
    - Number of builds per job: 11.157534246575343 [n=146, s=18.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 30
    - Number of items per container: 4.8 [n=30, s=10.0]

Total job statistics
======================

  * Number of jobs: 146
  * Number of builds per job: 11.157534246575343 [n=146, s=18.0]
