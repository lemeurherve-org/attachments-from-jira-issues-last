Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * expert: Linux (amd64)
   * grub: Linux (amd64)
   * overtake: Linux (amd64)
   * secure: Linux (amd64)
   * thumper: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * expert: In sync
   * grub: In sync
   * overtake: In sync
   * secure: In sync
   * thumper: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 26.650GB left on /var/jenkins.
   * expert: Disk space is too low. Only 52.952GB left on /fast/jenkinssecure.
   * grub: Disk space is too low. Only 336.944GB left on /var/jenkinssecure.
   * overtake: Disk space is too low. Only 129.947GB left on /var/jenkinssecure.
   * secure: Disk space is too low. Only 79.742GB left on /var/jenkinssecure.
   * thumper: Disk space is too low. Only 20.312GB left on /scratch/jenkinssecure.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:326/7871MB  Swap:9962/10048MB
   * expert: Memory:2858/64318MB  Swap:33895/34178MB
   * grub: Memory:2633/24091MB  Swap:24394/26139MB
   * overtake: Memory:35739/64321MB  Swap:66369/66369MB
   * secure: Memory:4408/24011MB  Swap:25873/26191MB
   * thumper: Memory:554/24013MB  Swap:25990/26191MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 26.650GB left on /var/tmp.
   * expert: Disk space is too low. Only 52.952GB left on /tmp.
   * grub: Disk space is too low. Only 336.944GB left on /tmp.
   * overtake: Disk space is too low. Only 129.947GB left on /tmp.
   * secure: Disk space is too low. Only 79.742GB left on /tmp.
   * thumper: Disk space is too low. Only 3.382GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * expert: 215ms
   * grub: 492ms
   * overtake: 557ms
   * secure: 334ms
   * thumper: 557ms
JVM Version
----
 - Is Ignored: false
 - Computers:
   * master: 1.8.0_40
   * expert: 1.8.0_40
   * grub: 1.8.0_151
   * overtake: 1.8.0_151
   * secure: 1.8.0_40
   * thumper: 1.8.0_40
Remoting Version
----
 - Is Ignored: false
 - Computers:
   * master: 3.21
   * expert: 3.21
   * grub: 3.21
   * overtake: 3.21
   * secure: 3.21
   * thumper: 3.21
