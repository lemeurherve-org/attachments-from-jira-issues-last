Node statistics
===============

  * Total number of nodes
      - Sample size:        418
      - Average (mean):     6.000000000000001
      - Average (median):   6.0
      - Standard deviation: 8.881784197001252E-16
      - Minimum:            6
      - Maximum:            6
      - 95th percentile:    6.0
      - 99th percentile:    6.0
  * Total number of nodes online
      - Sample size:        418
      - Average (mean):     5.998290980462704
      - Average (median):   6.0
      - Standard deviation: 0.04130494872915602
      - Minimum:            5
      - Maximum:            6
      - 95th percentile:    6.0
      - 99th percentile:    6.0
  * Total number of executors
      - Sample size:        418
      - Average (mean):     15.993163921850812
      - Average (median):   16.0
      - Standard deviation: 0.16521979491662403
      - Minimum:            12
      - Maximum:            16
      - 95th percentile:    16.0
      - 99th percentile:    16.0
  * Total number of executors in use
      - Sample size:        418
      - Average (mean):     6.0018444947227945
      - Average (median):   6.0
      - Standard deviation: 0.12195867004932354
      - Minimum:            0
      - Maximum:            12
      - 95th percentile:    6.0
      - 99th percentile:    6.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/jenkins`
      - Labels:         restricted mastermind sydney Sydney uiTests
      - Usage:          `NORMAL`
      - Slave Version:  3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   1.78 GB (1908932608)
          + Allocated memory: 1.13 GB (1211629568)
          + Free memory:      493.63 MB (517603896)
          + In-use memory:    661.87 MB (694025672)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.16.2.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 29480 (0x7328)
      - Process started: 2018-07-04 05:50:26.969+0000
      - Process uptime: 1 hr 44 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
          + Classpath: `/var/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2048m`
          + arg[1]: `-XX:MaxPermSize=256m`
          + arg[2]: `-Dcors.origin=*`
          + arg[3]: `-Dcors.methods=GET,POST,PUT,DELETE`
          + arg[4]: `-Dcors.headers=Authorization`
          + arg[5]: `-Djava.io.tmpdir=/var/tmp`
          + arg[6]: `-DJENKINS_HOME=/var/jenkins`
          + arg[7]: `-Dhudson.model.ParametersAction.keepUndefinedParameters=false`

  * expert (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/fast/jenkinssecure`
      - Labels:         CentOSNR sydney Sydney performanceTest uiTests
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   13.96 GB (14987821056)
          + Allocated memory: 496.50 MB (520617984)
          + Free memory:      476.23 MB (499358136)
          + In-use memory:    20.27 MB (21259848)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.12.2.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 92616 (0x169c8)
      - Process started: 2018-07-04 05:50:46.720+0000
      - Process uptime: 1 hr 44 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * grub (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/var/jenkinssecure`
      - Labels:         CentOSNR sydney Sydney performanceTest uiTests
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_151/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_151
          + Maximum memory:   5.23 GB (5615124480)
          + Allocated memory: 362.50 MB (380108800)
          + Free memory:      319.97 MB (335514856)
          + In-use memory:    42.53 MB (44593944)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.151-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-693.el7.x86_64
          + Distribution: "CentOS Linux release 7.4.1708 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 6338 (0x18c2)
      - Process started: 2018-07-04 07:28:45.070+0000
      - Process uptime: 6 min 39 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_151/jre/lib/resources.jar:/usr/java/jdk1.8.0_151/jre/lib/rt.jar:/usr/java/jdk1.8.0_151/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_151/jre/lib/jsse.jar:/usr/java/jdk1.8.0_151/jre/lib/jce.jar:/usr/java/jdk1.8.0_151/jre/lib/charsets.jar:/usr/java/jdk1.8.0_151/jre/lib/jfr.jar:/usr/java/jdk1.8.0_151/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * overtake (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/var/jenkinssecure`
      - Labels:         CentOSNR sydney Sydney performanceTest uiTests
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_151/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_151
          + Maximum memory:   13.96 GB (14989918208)
          + Allocated memory: 476.50 MB (499646464)
          + Free memory:      275.34 MB (288712632)
          + In-use memory:    201.16 MB (210933832)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.151-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-693.el7.x86_64
          + Distribution: "CentOS Linux release 7.4.1708 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch`
      - Process ID: 134133 (0x20bf5)
      - Process started: 2018-07-04 05:50:47.075+0000
      - Process uptime: 1 hr 44 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_151/jre/lib/resources.jar:/usr/java/jdk1.8.0_151/jre/lib/rt.jar:/usr/java/jdk1.8.0_151/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_151/jre/lib/jsse.jar:/usr/java/jdk1.8.0_151/jre/lib/jce.jar:/usr/java/jdk1.8.0_151/jre/lib/charsets.jar:/usr/java/jdk1.8.0_151/jre/lib/jfr.jar:/usr/java/jdk1.8.0_151/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * secure (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/var/jenkinssecure`
      - Labels:         CentOSNR sydney Sydney performanceTest uiTests rnd_coretools
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   5.21 GB (5596250112)
          + Allocated memory: 171.00 MB (179306496)
          + Free memory:      153.27 MB (160717368)
          + In-use memory:    17.73 MB (18589128)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.30.3.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 8806 (0x2266)
      - Process started: 2018-07-04 05:50:47.313+0000
      - Process uptime: 1 hr 44 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * thumper (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/scratch/jenkinssecure`
      - Labels:         CentOSNR sydney Sydney performanceTest uiTests
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   5.21 GB (5596250112)
          + Allocated memory: 179.50 MB (188219392)
          + Free memory:      136.11 MB (142723240)
          + In-use memory:    43.39 MB (45496152)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.16.2.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 3067 (0xbfb)
      - Process started: 2018-07-04 05:50:47.162+0000
      - Process uptime: 1 hr 44 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

