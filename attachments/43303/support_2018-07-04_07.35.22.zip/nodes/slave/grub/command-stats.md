# Totals
* Writes: 13802
  * sent 48.6Mb
* Reads: 40420
  * received 61.7Mb
* Responses: 9338
  * waited 1 min 59 sec

# Commands sent
* `Pipe.Chunk`: 51
  * sent 0.2Mb
* `ProxyOutputStream.Ack`: 1354
  * sent 0.2Mb
* `ProxyOutputStream.EOF`: 36
  * sent 0.1Mb
* `ProxyWriter.Ack`: 4
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 1742
  * sent 4.7Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 32
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 7
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 136
  * sent 0.3Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 22
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 2
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 15
  * sent 0.0Mb
* `Unexport`: 1061
  * sent 1.9Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 297
  * sent 3.6Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 28
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 28
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 11
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 32
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 28
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 28
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 15
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 8
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Chmod`: 333
  * sent 2.0Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 35
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyTo`: 54
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 303
  * sent 1.0Mb
* `UserRequest:hudson.FilePath$Exists`: 187
  * sent 0.6Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 1695
  * sent 5.2Mb
* `UserRequest:hudson.FilePath$LastModified`: 261
  * sent 0.8Mb
* `UserRequest:hudson.FilePath$Length`: 88
  * sent 0.3Mb
* `UserRequest:hudson.FilePath$ListGlob`: 30
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 764
  * sent 4.5Mb
* `UserRequest:hudson.FilePath$Read`: 176
  * sent 0.6Mb
* `UserRequest:hudson.FilePath$RenameTo`: 8
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Touch`: 36
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Write`: 297
  * sent 2.0Mb
* `UserRequest:hudson.FilePath$WritePipe`: 36
  * sent 0.1Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 297
  * sent 3.6Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 16
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 4
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 4
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 4
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 4
  * sent 0.0Mb
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 4
  * sent 0.0Mb
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 4
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 22
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 3
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 3
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 126
  * sent 0.7Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 16
  * sent 0.1Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 3
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 3
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 109
  * sent 0.3Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 3
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 3
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 3
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 297
  * sent 1.8Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1562
  * sent 5.2Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 1857
  * sent 6.1Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 3
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 3
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 32
  * sent 0.2Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 84
  * sent 0.6Mb
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 35
  * sent 0.1Mb
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 3
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 1354
  * received 1.9Mb
* `Pipe.Flush`: 1044
  * received 0.2Mb
* `ProxyOutputStream.Ack`: 51
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 265
  * received 0.5Mb
* `ProxyOutputStream.Unexport`: 2261
  * received 3.0Mb
* `ProxyWriter.Chunk`: 4
  * received 0.0Mb
* `ProxyWriter.EOF`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 1742
  * received 1.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 32
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 7
  * received 0.0Mb
* `Response`: 9338
  * received 17.8Mb
* `Unexport`: 24132
  * received 36.2Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 136
  * received 1.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 22
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 2
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 15
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 297
  * waited 0.82 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 28
  * waited 1.5 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 28
  * waited 0.54 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 11
  * waited 0.24 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 32
  * waited 72 ms
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 28
  * waited 0.34 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 28
  * waited 5.7 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 3
  * waited 8 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 3
  * waited 8.9 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 15
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 3
  * waited 0.39 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 3
  * waited 0.13 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 3
  * waited 0.14 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 3
  * waited 36 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 3
  * waited 0.28 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 3
  * waited 35 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 2
  * waited 94 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 6
  * waited 7 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * waited 0.44 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 2
  * waited 22 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 3
  * waited 0.14 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * waited 43 ms
* `UserRequest:hudson.EnvVars$GetEnvVars`: 3
  * waited 0.37 sec
* `UserRequest:hudson.FilePath$CallableWith`: 8
  * waited 4.5 sec
* `UserRequest:hudson.FilePath$Chmod`: 333
  * waited 0.67 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 35
  * waited 0.48 sec
* `UserRequest:hudson.FilePath$CopyTo`: 54
  * waited 0.16 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 303
  * waited 0.89 sec
* `UserRequest:hudson.FilePath$Exists`: 187
  * waited 0.37 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 1695
  * waited 10 sec
* `UserRequest:hudson.FilePath$LastModified`: 261
  * waited 0.43 sec
* `UserRequest:hudson.FilePath$Length`: 88
  * waited 0.14 sec
* `UserRequest:hudson.FilePath$ListGlob`: 30
  * waited 0.76 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 764
  * waited 2.3 sec
* `UserRequest:hudson.FilePath$Read`: 176
  * waited 0.41 sec
* `UserRequest:hudson.FilePath$RenameTo`: 8
  * waited 17 ms
* `UserRequest:hudson.FilePath$Touch`: 36
  * waited 0.2 sec
* `UserRequest:hudson.FilePath$Write`: 297
  * waited 1.7 sec
* `UserRequest:hudson.FilePath$WritePipe`: 36
  * waited 73 ms
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 297
  * waited 1.5 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 14
  * waited 1.3 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 4
  * waited 1.6 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 4
  * waited 0.82 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 4
  * waited 1.9 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 4
  * waited 2.2 sec
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 4
  * waited 2 sec
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 4
  * waited 1.1 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 22
  * waited 0.15 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 3
  * waited 0.65 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 3
  * waited 23 ms
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 126
  * waited 0.36 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 16
  * waited 0.51 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 3
  * waited 1.4 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 3
  * waited 4.1 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 109
  * waited 4.9 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 3
  * waited 79 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 3
  * waited 7.7 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 3
  * waited 0.65 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 297
  * waited 0.62 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1562
  * waited 2.6 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 1857
  * waited 3.2 sec
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 3
  * waited 0.78 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 3
  * waited 39 ms
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 32
  * waited 6.4 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 84
  * waited 18 sec
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 35
  * waited 1.1 sec
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 3
  * waited 0.25 sec

# JARs sent
* `jna-4.2.1.jar`: 1137285b
* `libpam4j-1.8.jar`: 19925b
* `support-core.jar`: 284176b
* `launchd-slave-installer-1.2.jar`: 22663b
* `systemd-slave-installer-1.1.jar`: 11541b
* `monitoring.jar`: 41563b
* `slave-installer-1.6.jar`: 27374b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `versioncolumn.jar`: 24498b
* `envinject.jar`: 153357b
* `commons-codec-1.9.jar`: 263965b
* `envinject-lib-1.29.jar`: 20599b
* `platformlabeler.jar`: 10838b
* `git-client.jar`: 212094b
* `org.eclipse.jgit-4.5.4.201711221230-r.jar`: 2384093b
* `xpp3-1.1.4c.jar`: 120069b
* `icon-set-1.0.5.jar`: 17567b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `git.jar`: 638384b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `durable-task.jar`: 48525b
* `pipeline-utility-steps.jar`: 458150b
* `workflow-step-api.jar`: 75707b
* `junit.jar`: 441990b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `commons-lang-2.6.jar`: 284220b
* `jcl-over-slf4j-1.7.25.jar`: 16515b
* `task-reactor-1.5.jar`: 22114b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `antlr-2.7.6.jar`: 443432b
* `stapler-jelly-1.254.jar`: 87292b
