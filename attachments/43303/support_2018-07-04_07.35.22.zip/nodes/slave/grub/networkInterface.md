-----------
 * Name virbr0
 ** Hardware Address - 525400fc6776
 ** Index - 3
 ** InetAddress - /192.168.122.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name ens4
 ** Hardware Address - 001b213c4e1d
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:21b:21ff:fe3c:4e1d%ens4
 ** InetAddress - /192.168.102.24
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
