# Totals
* Writes: 11722
  * sent 43.3Mb
* Reads: 32406
  * received 49.7Mb
* Responses: 8410
  * waited 1 min 12 sec

# Commands sent
* `Pipe.Chunk`: 38
  * sent 0.1Mb
* `ProxyOutputStream.Ack`: 1435
  * sent 0.2Mb
* `ProxyOutputStream.EOF`: 35
  * sent 0.1Mb
* `ProxyWriter.Ack`: 2
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 756
  * sent 2.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 55
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 21
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 14
  * sent 0.0Mb
* `Unexport`: 937
  * sent 1.8Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 319
  * sent 3.8Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 30
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 30
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 14
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 30
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 30
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 30
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 15
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 8
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Chmod`: 354
  * sent 2.2Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 44
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$CopyTo`: 54
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 330
  * sent 1.0Mb
* `UserRequest:hudson.FilePath$Exists`: 224
  * sent 0.7Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 1317
  * sent 4.0Mb
* `UserRequest:hudson.FilePath$LastModified`: 159
  * sent 0.5Mb
* `UserRequest:hudson.FilePath$Length`: 74
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$ListGlob`: 42
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 817
  * sent 4.8Mb
* `UserRequest:hudson.FilePath$Read`: 181
  * sent 0.6Mb
* `UserRequest:hudson.FilePath$RenameTo`: 12
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Touch`: 35
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Write`: 319
  * sent 2.1Mb
* `UserRequest:hudson.FilePath$WritePipe`: 35
  * sent 0.1Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 319
  * sent 3.9Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 14
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 4
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 4
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 4
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 4
  * sent 0.0Mb
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 4
  * sent 0.0Mb
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 4
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 21
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 3
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 141
  * sent 0.8Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 22
  * sent 0.1Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 113
  * sent 0.3Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 319
  * sent 1.9Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1194
  * sent 3.9Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 1512
  * sent 5.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 30
  * sent 0.2Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 89
  * sent 0.6Mb
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 44
  * sent 0.1Mb
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 1435
  * received 2.0Mb
* `Pipe.Flush`: 1164
  * received 0.2Mb
* `ProxyOutputStream.Ack`: 38
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 280
  * received 0.5Mb
* `ProxyOutputStream.Unexport`: 1788
  * received 2.3Mb
* `ProxyWriter.Chunk`: 2
  * received 0.0Mb
* `ProxyWriter.EOF`: 14
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 756
  * received 0.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * received 0.0Mb
* `Response`: 8410
  * received 16.0Mb
* `Unexport`: 18410
  * received 27.6Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 55
  * received 0.4Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 21
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 14
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 319
  * waited 0.75 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 30
  * waited 0.97 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 30
  * waited 0.11 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 14
  * waited 92 ms
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 30
  * waited 81 ms
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 30
  * waited 0.23 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 30
  * waited 5.7 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 3
  * waited 5 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.7 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 15
  * waited 0.69 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 3
  * waited 0.25 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 3
  * waited 74 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 3
  * waited 59 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 3
  * waited 22 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 3
  * waited 0.17 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 3
  * waited 21 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 2
  * waited 89 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 6
  * waited 2.9 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * waited 0.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 2
  * waited 18 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 3
  * waited 0.17 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * waited 32 ms
* `UserRequest:hudson.EnvVars$GetEnvVars`: 2
  * waited 0.21 sec
* `UserRequest:hudson.FilePath$2`: 1
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$CallableWith`: 8
  * waited 3.6 sec
* `UserRequest:hudson.FilePath$Chmod`: 354
  * waited 0.6 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 44
  * waited 0.29 sec
* `UserRequest:hudson.FilePath$CopyTo`: 54
  * waited 0.13 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 330
  * waited 0.66 sec
* `UserRequest:hudson.FilePath$Exists`: 224
  * waited 0.35 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 1317
  * waited 2.8 sec
* `UserRequest:hudson.FilePath$LastModified`: 159
  * waited 0.24 sec
* `UserRequest:hudson.FilePath$Length`: 74
  * waited 0.1 sec
* `UserRequest:hudson.FilePath$ListGlob`: 42
  * waited 1.4 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 817
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$Read`: 181
  * waited 0.35 sec
* `UserRequest:hudson.FilePath$RenameTo`: 12
  * waited 20 ms
* `UserRequest:hudson.FilePath$Touch`: 35
  * waited 0.2 sec
* `UserRequest:hudson.FilePath$Write`: 319
  * waited 1.4 sec
* `UserRequest:hudson.FilePath$WritePipe`: 35
  * waited 60 ms
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 319
  * waited 1.6 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 14
  * waited 0.67 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 4
  * waited 1 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 4
  * waited 0.12 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 4
  * waited 1.6 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 4
  * waited 1.8 sec
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 4
  * waited 1.7 sec
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 4
  * waited 0.23 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 21
  * waited 62 ms
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.5 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 3
  * waited 13 ms
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 141
  * waited 0.41 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 22
  * waited 0.38 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.7 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 1.4 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 113
  * waited 2.2 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 29 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.86 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 0.84 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 319
  * waited 0.58 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1194
  * waited 1.7 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 1512
  * waited 2.2 sec
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 81 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 8 ms
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 30
  * waited 6.6 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 89
  * waited 14 sec
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 44
  * waited 0.74 sec
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 1
  * waited 61 ms

# JARs sent
* `jna-4.2.1.jar`: 1137285b
* `libpam4j-1.8.jar`: 19925b
* `launchd-slave-installer-1.2.jar`: 22663b
* `support-core.jar`: 284176b
* `monitoring.jar`: 41563b
* `systemd-slave-installer-1.1.jar`: 11541b
* `slave-installer-1.6.jar`: 27374b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `envinject.jar`: 153357b
* `envinject-lib-1.29.jar`: 20599b
* `platformlabeler.jar`: 10838b
* `commons-codec-1.9.jar`: 263965b
* `versioncolumn.jar`: 24498b
* `git-client.jar`: 212094b
* `org.eclipse.jgit-4.5.4.201711221230-r.jar`: 2384093b
* `xpp3-1.1.4c.jar`: 120069b
* `icon-set-1.0.5.jar`: 17567b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `git.jar`: 638384b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `durable-task.jar`: 48525b
* `pipeline-utility-steps.jar`: 458150b
* `workflow-step-api.jar`: 75707b
* `junit.jar`: 441990b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
