# Totals
* Writes: 5801
  * sent 19.9Mb
* Reads: 15964
  * received 24.1Mb
* Responses: 3483
  * waited 37 sec

# Commands sent
* `Pipe.Chunk`: 37
  * sent 0.1Mb
* `ProxyOutputStream.Ack`: 851
  * sent 0.1Mb
* `ProxyOutputStream.EOF`: 33
  * sent 0.1Mb
* `ProxyWriter.Ack`: 3
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 757
  * sent 2.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 56
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 21
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 13
  * sent 0.0Mb
* `Unexport`: 528
  * sent 1.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 132
  * sent 1.6Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 23
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 23
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 9
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 26
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 23
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 23
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 15
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 3
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 8
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Chmod`: 165
  * sent 0.9Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 12
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 54
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 141
  * sent 0.4Mb
* `UserRequest:hudson.FilePath$Exists`: 94
  * sent 0.3Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 395
  * sent 1.2Mb
* `UserRequest:hudson.FilePath$LastModified`: 71
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Length`: 16
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$ListGlob`: 24
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 416
  * sent 2.2Mb
* `UserRequest:hudson.FilePath$Read`: 61
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$RenameTo`: 9
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Touch`: 33
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Write`: 132
  * sent 0.9Mb
* `UserRequest:hudson.FilePath$WritePipe`: 33
  * sent 0.1Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 132
  * sent 1.6Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 13
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 4
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 4
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 4
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 4
  * sent 0.0Mb
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 4
  * sent 0.0Mb
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 4
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 21
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 3
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 72
  * sent 0.4Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 12
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 112
  * sent 0.3Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 132
  * sent 0.8Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 361
  * sent 1.2Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 493
  * sent 1.6Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 26
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 70
  * sent 0.5Mb
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 12
  * sent 0.0Mb
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 851
  * received 0.6Mb
* `Pipe.Flush`: 831
  * received 0.1Mb
* `ProxyOutputStream.Ack`: 37
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 128
  * received 0.2Mb
* `ProxyOutputStream.Unexport`: 739
  * received 1.0Mb
* `ProxyWriter.Chunk`: 3
  * received 0.0Mb
* `ProxyWriter.EOF`: 12
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 757
  * received 0.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * received 0.0Mb
* `Response`: 3483
  * received 7.6Mb
* `Unexport`: 9014
  * received 13.5Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 56
  * received 0.4Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 21
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 13
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 132
  * waited 0.36 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 23
  * waited 0.64 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 23
  * waited 0.29 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 9
  * waited 83 ms
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 26
  * waited 60 ms
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 23
  * waited 0.17 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 23
  * waited 3.4 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 3
  * waited 7 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 0.83 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 15
  * waited 0.61 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 3
  * waited 0.19 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 3
  * waited 86 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 3
  * waited 76 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 3
  * waited 29 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 3
  * waited 0.13 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 3
  * waited 24 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 2
  * waited 69 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 6
  * waited 0.83 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * waited 0.16 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 2
  * waited 25 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 3
  * waited 0.12 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * waited 32 ms
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$2`: 1
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$CallableWith`: 8
  * waited 0.68 sec
* `UserRequest:hudson.FilePath$Chmod`: 165
  * waited 0.32 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 12
  * waited 0.21 sec
* `UserRequest:hudson.FilePath$CopyTo`: 54
  * waited 0.14 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 141
  * waited 0.38 sec
* `UserRequest:hudson.FilePath$Exists`: 94
  * waited 0.16 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 395
  * waited 0.92 sec
* `UserRequest:hudson.FilePath$LastModified`: 71
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$Length`: 16
  * waited 26 ms
* `UserRequest:hudson.FilePath$ListGlob`: 24
  * waited 1 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 416
  * waited 0.87 sec
* `UserRequest:hudson.FilePath$Read`: 61
  * waited 0.14 sec
* `UserRequest:hudson.FilePath$RenameTo`: 9
  * waited 17 ms
* `UserRequest:hudson.FilePath$Touch`: 33
  * waited 76 ms
* `UserRequest:hudson.FilePath$Write`: 132
  * waited 0.28 sec
* `UserRequest:hudson.FilePath$WritePipe`: 33
  * waited 62 ms
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 132
  * waited 1 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 13
  * waited 0.8 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 4
  * waited 0.12 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 4
  * waited 38 ms
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 4
  * waited 0.29 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 4
  * waited 0.36 sec
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 4
  * waited 0.29 sec
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 4
  * waited 16 ms
* `UserRequest:hudson.remoting.PingThread$Ping`: 21
  * waited 72 ms
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.14 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 3
  * waited 15 ms
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 72
  * waited 0.25 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 12
  * waited 0.29 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.48 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.34 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 112
  * waited 1.8 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 11 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.54 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 0.13 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * waited 48 ms
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 132
  * waited 0.36 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 361
  * waited 0.74 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 493
  * waited 0.86 sec
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 0.16 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 11 ms
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 26
  * waited 2.3 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 70
  * waited 11 sec
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 12
  * waited 0.39 sec
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 1
  * waited 51 ms

# JARs sent
* `jna-4.2.1.jar`: 1137285b
* `libpam4j-1.8.jar`: 19925b
* `launchd-slave-installer-1.2.jar`: 22663b
* `support-core.jar`: 284176b
* `slave-installer-1.6.jar`: 27374b
* `systemd-slave-installer-1.1.jar`: 11541b
* `upstart-slave-installer-1.1.jar`: 10798b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `envinject.jar`: 153357b
* `envinject-lib-1.29.jar`: 20599b
* `platformlabeler.jar`: 10838b
* `monitoring.jar`: 41563b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `commons-codec-1.9.jar`: 263965b
* `versioncolumn.jar`: 24498b
* `git-client.jar`: 212094b
* `org.eclipse.jgit-4.5.4.201711221230-r.jar`: 2384093b
* `xpp3-1.1.4c.jar`: 120069b
* `icon-set-1.0.5.jar`: 17567b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `git.jar`: 638384b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `durable-task.jar`: 48525b
* `pipeline-utility-steps.jar`: 458150b
* `workflow-step-api.jar`: 75707b
* `junit.jar`: 441990b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
