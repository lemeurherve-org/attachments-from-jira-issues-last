-----------
 * Name docker0
 ** Hardware Address - 5a1572422449
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:5815:72ff:fe42:2449%docker0
 ** InetAddress - /172.17.42.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 18a90520e882
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:1aa9:5ff:fe20:e882%eth0
 ** InetAddress - /192.168.102.223
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
