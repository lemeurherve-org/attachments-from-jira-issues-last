Jenkins
=======

Version details
---------------

  * Version: `2.176.3.2`
  * Mode:    WAR
  * Url:     http://jenkins.example.com/teams-dse-team-apac/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8-openjdk/jre`
      - Vendor:           IcedTea
      - Version:          1.8.0&#95;212
      - Maximum memory:   2.00 GB (2147483648)
      - Allocated memory: 2.00 GB (2147483648)
      - Free memory:      768.63 MB (805965200)
      - In-use memory:    1.25 GB (1341518448)
      - GC strategy:      G1
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  IcedTea
      - Version: 25.212-b04
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.14.137+
  * Process ID: 6 (0x6)
  * Process started: 2019-09-11 03:53:41.695+0000
  * Process uptime: 1 day 20 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/share/jenkins/alpn-boot.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/resources.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/rt.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jce.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8-openjdk/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64/server:/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64:/usr/lib/jvm/java-1.8-openjdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dhudson.slaves.NodeProvisioner.initialDelay=0`
      - arg[1]: `-Xbootclasspath/p:/usr/share/jenkins/alpn-boot.jar`
      - arg[2]: `-Duser.home=/var/jenkins_home`
      - arg[3]: `-Xmx2048m`
      - arg[4]: `-Xms2048m`
      - arg[5]: `-Djenkins.model.Jenkins.slaveAgentPort=50003`
      - arg[6]: `-Djenkins.install.runSetupWizard=true`
      - arg[7]: `-Dhudson.lifecycle=hudson.lifecycle.ExitLifecycle`
      - arg[8]: `-DMASTER_NAME=dse-team-apac`
      - arg[9]: `-Dcb.BeekeeperProp.autoInstallIncremental=true`
      - arg[10]: `-Djenkins.model.Jenkins.slaveAgentPortEnforce=true`
      - arg[11]: `-DMASTER_GRANT_ID=4bc7edf2-a664-4682-b0a7-78efab132b9f`
      - arg[12]: `-Dcb.IMProp.warProfiles.cje=kubernetes.json`
      - arg[13]: `-DMASTER_INDEX=2`
      - arg[14]: `-Dcb.IMProp.warProfiles=bluesteel-core.json`
      - arg[15]: `-DMASTER_OPERATIONSCENTER_ENDPOINT=http://cjoc.cje-support-general.svc.cluster.local/cjoc/`
      - arg[16]: `-Dcb.BeekeeperProp.noFullUpgrade=true`
      - arg[17]: `-Dhudson.DNSMultiCast.disabled=true`
      - arg[18]: `-DMASTER_ENDPOINT=http://jenkins.example.com/teams-dse-team-apac/`
      - arg[19]: `-Dkubernetes.websocket.ping.interval=30000`
      - arg[20]: `-XX:MaxRAMFraction=1`
      - arg[21]: `-XX:+AlwaysPreTouch`
      - arg[22]: `-XX:+UseG1GC`
      - arg[23]: `-XX:+ExplicitGCInvokesConcurrent`
      - arg[24]: `-XX:+ParallelRefProcEnabled`
      - arg[25]: `-XX:+UseStringDeduplication`
      - arg[26]: `-XX:+UseGCLogFileRotation`
      - arg[27]: `-XX:NumberOfGCLogFiles=5`
      - arg[28]: `-XX:GCLogFileSize=40m`
      - arg[29]: `-Xloggc:/var/jenkins_home/gc.log`
      - arg[30]: `-XX:+PrintGCDetails`
      - arg[31]: `-XX:+PrintGCDateStamps`
      - arg[32]: `-XX:+PrintHeapAtGC`
      - arg[33]: `-XX:+PrintGCCause`
      - arg[34]: `-XX:+PrintTenuringDistribution`
      - arg[35]: `-XX:+PrintReferenceGC`
      - arg[36]: `-XX:+PrintAdaptiveSizePolicy`
      - arg[37]: `-Dhudson.slaves.NodeProvisioner.initialDelay=0`
      - arg[38]: `-Dcb.distributable.name=Docker Common CJE`
      - arg[39]: `-Dcb.distributable.commit_sha=49e35b48176fc789078f52e12f8fb09382da938a`

Important configuration
---------------

  * Security realm: `com.cloudbees.opscenter.security.OperationsCenterSecurityRealm`
  * Authorization strategy: `com.cloudbees.opscenter.bluesteel.security.BlueSteelAuthorisationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.5-3.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * async-http-client:1.7.24.2 'Async Http Client'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * authorize-project:1.3.0 'Authorize Project'
  * aws-credentials:1.27 'CloudBees AWS Credentials Plugin'
  * aws-java-sdk:1.11.562 'Amazon Web Services SDK'
  * blueocean:1.18.1 'Blue Ocean'
  * blueocean-autofavorite:1.2.4 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.18.1 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.18.1 'Common API for Blue Ocean'
  * blueocean-config:1.18.1 'Config API for Blue Ocean'
  * blueocean-core-js:1.18.1 'Blue Ocean Core JS'
  * blueocean-dashboard:1.18.1 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.3.0 'Display URL for Blue Ocean'
  * blueocean-events:1.18.1 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.18.1 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.18.1 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.18.1 'i18n for Blue Ocean'
  * blueocean-jira:1.18.1 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.18.1 'JWT for Blue Ocean'
  * blueocean-personalization:1.18.1 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.18.1 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.18.1 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.18.1 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.18.1 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.18.1 'REST Implementation for Blue Ocean'
  * blueocean-web:1.18.1 'Web for Blue Ocean'
  * bluesteel-master:1.2.22 'Managed Master New User Experience'
  * bouncycastle-api:2.17 'bouncycastle API Plugin'
  * branch-api:2.5.4 'Branch API Plugin'
  * cloudbees-administrative-monitors:1.0.1 'CloudBees Administrative Monitors Plugin'
  * cloudbees-assurance:2.138.0.8 'Beekeeper Upgrade Assistant Plugin'
  * cloudbees-bitbucket-branch-source:2.4.4 'Bitbucket Branch Source Plugin'
  * cloudbees-blueocean-default-theme:0.5 'CloudBees Blue Ocean Default Theme'
  * cloudbees-folder:6.10-SNAPSHOT (private-02e32a63-allan) 'Folders Plugin'
  * cloudbees-folders-plus:3.8 'CloudBees Folders Plus Plugin'
  * cloudbees-license:9.34 'CloudBees License Manager'
  * cloudbees-ssh-slaves:2.3 'CloudBees SSH Build Agents Plugin'
  * cloudbees-support:3.22 'CloudBees Support Plugin'
  * cloudbees-uc-data-api:4.42 'CloudBees Update Center Data API'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * configuration-as-code:1.29 'Configuration as Code Plugin'
  * credentials:2.2.0 'Credentials Plugin'
  * credentials-binding:1.20 'Credentials Binding Plugin'
  * display-url-api:2.3.1 'Display URL API'
  * docker-commons:1.15 'Docker Commons Plugin'
  * docker-workflow:1.18 'Docker Pipeline'
  * durable-task:1.30 'Durable Task Plugin'
  * extended-choice-parameter:0.78 'Extended Choice Parameter Plug-In'
  * external-workspace-manager:1.2.0 'External Workspace Manager Plugin'
  * favorite:2.3.1 'Favorite'
  * form-element-path:1.8 'Form element path plugin'
  * git:3.11.0 'Jenkins Git plugin'
  * git-client:2.7.7 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.29.3 'GitHub plugin'
  * github-api:1.95 'GitHub API Plugin'
  * github-branch-source:2.5.5 'GitHub Branch Source Plugin'
  * gravatar:2.1 'Jenkins Gravatar plugin'
  * handy-uri-templates-2-api:2.1.6-1.0 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.16 'HTML Publisher plugin'
  * ibm-ucdeploy-build-steps:2.14.1027735 'IBM UrbanCode Deploy Pipeline (Build Steps) Plugin'
  * infradna-backup:3.38.13 'CloudBees Backup Plugin'
  * jackson2-api:2.9.9.1 'Jackson 2 API Plugin'
  * javadoc:1.5 'Javadoc Plugin'
  * jaxb:2.3.0.1 'JAXB plugin'
  * jdk-tool:1.3 'Oracle Java SE Development Kit Installer Plugin'
  * jenkins-design-language:1.18.1 'Jenkins Design Language'
  * jira:3.0.8 'Jenkins JIRA plugin'
  * job-restrictions:0.8 'Job Restrictions Plugin'
  * jquery:1.12.4-0 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.55 'Jenkins JSch dependency plugin'
  * junit:1.28 'JUnit Plugin'
  * kube-agent-management:1.1.14 'Kube Agent Management plugin'
  * kubernetes:1.17.2 'Kubernetes plugin'
  * kubernetes-credentials:0.4.0 'Kubernetes Credentials Plugin'
  * m2release:0.15.0 'Jenkins Maven Release Plug-in Plug-in'
  * mailer:1.23 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mask-passwords:2.12.0 'Mask Passwords Plugin'
  * matrix-auth:2.4.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.14 'Matrix Project Plugin'
  * maven-plugin:3.4 'Maven Integration plugin'
  * mercurial:2.8 'Jenkins Mercurial plugin'
  * metrics:4.0.2.5 'Metrics Plugin'
  * multibranch-build-strategy-extension:1.0.10 'Pipeline: Multibranch build strategy extension'
  * nectar-license:8.23 'CloudBees Jenkins Enterprise License Entitlement Check'
  * nectar-rbac:5.27 'CloudBees Role-Based Access Control Plugin'
  * nexus-jenkins-plugin:3.7.20190823-091836.9f85050 'Nexus Platform Plugin'
  * notification-api:1.2 'Notification API'
  * operations-center-agent:2.176.0.1 'Operations Center Agent'
  * operations-center-client:2.176.0.2 'Operations Center Client Plugin'
  * operations-center-context:2.176.0.5 'Operations Center Context'
  * operations-center-notification:1.0 'Operations Center Notification'
  * pipeline-aws:1.38 'Pipeline: AWS Steps'
  * pipeline-build-step:2.9 'Pipeline: Build Step'
  * pipeline-event-step:1.5 'Pipeline Event Step'
  * pipeline-graph-analysis:1.10 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.10 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.9 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.9 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.9 'Pipeline: Declarative Extension Points API'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.9 'Pipeline: Stage Tags Metadata'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * scm-api:2.6.3 'SCM API Plugin'
  * script-security:1.62 'Script Security Plugin'
  * sse-gateway:1.17 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.17.1 'SSH Credentials Plugin'
  * ssh-slaves:1.30.0 'Jenkins SSH Slaves plugin'
  * structs:1.20 'Structs Plugin'
  * support-core:2.61-SNAPSHOT (private-5124068a-allan) 'Support Core Plugin'
  * token-macro:2.8 'Token Macro Plugin'
  * trigger-restrictions:1.2 'Trigger Restrictions'
  * unique-id:2.1.3 'Unique ID Library Plugin'
  * user-activity-monitoring:1.1.5 'User Activity Monitoring Plugin'
  * variant:1.2 'Variant Plugin'
  * windows-slaves:1.4 'WMI Windows Agents Plugin'
  * workflow-api:2.36 'Pipeline: API'
  * workflow-basic-steps:2.18 'Pipeline: Basic Steps'
  * workflow-cps:2.73 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.15 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.33 'Pipeline: Nodes and Processes'
  * workflow-job:2.33 'Pipeline: Job'
  * workflow-multibranch:2.21 'Pipeline: Multibranch'
  * workflow-scm-step:2.9 'Pipeline: SCM Step'
  * workflow-step-api:2.20 'Pipeline: Step API'
  * workflow-support:3.3 'Pipeline: Supporting APIs'

Packaging details
-----------------

CloudBees Core: Managed Master


CloudBees Product Description
-----------------------------

 * Product Distribution: rolling 
 * Product Id: core-mm 
 * Product Name: CloudBees Core Managed Master 
 * Product Solution: CloudBees Core on modern cloud platforms 
 * Product Userfacingsolution: CloudBees Core 
 * Product Version: 2.176.3.2 

CloudBees Distributable Description
-----------------------------------

 * Distributable Name: Docker Common CJE
 * UDR Commit SHA: 49e35b48176fc789078f52e12f8fb09382da938a

License details
---------------

 * Jenkins Instance ID:  `cef112a978c7f9990284116a6118c726`
 * Licensed Instance ID: `a57692d335dfb99beb0b329613243ee1`
 * Expires:              2019-09-14 04:55:07.000+0000
 * Issued to:            CloudBees
 * Organization:         CloudBees
     - Team Management
     - Security
     - Early Adopter Program
     - Developer Productivity
     - Core
     - Optimized Utilization
     - Enterprise Edition: Enterprise Management
     - Operations Center managed CloudBees Jenkins Enterprise license for 100 users
