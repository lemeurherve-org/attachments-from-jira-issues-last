Loggers currently enabled
=========================
org.csanchez.jenkins.plugins.kubernetes - ALL
org.jenkinsci.plugins.durabletask - ALL
org.jenkinsci.plugins.workflow.steps.durable_task.DurableTaskStep - ALL
org.apache.sshd - WARNING
winstone - INFO
 - INFO
