CloudBees Support Bundle Manifest
=================================

Generated on 2019-09-13 00:50:40.271+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2019-09-03_05.39.57.log`

      - `nodes/master/logs/all_2019-09-05_05.13.19.log`

      - `nodes/master/logs/all_2019-09-10_04.32.54.log`

      - `nodes/master/logs/all_2019-09-10_07.03.18.log`

      - `nodes/master/logs/all_2019-09-11_02.44.04.log`

      - `nodes/master/logs/all_2019-09-11_02.50.54.log`

      - `nodes/master/logs/all_2019-09-11_03.01.25.log`

      - `nodes/master/logs/all_2019-09-11_03.54.13.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/custom/durable.log`

      - `nodes/master/logs/custom/kubernetes.log`

      - `nodes/master/logs/jenkins.log`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj/exportTable.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * All loggers currently enabled.

      - `loggers.md`

  * Node monitors

      - `node-monitors.md`

  * Agent Command Statistics

      - `nodes/slave/dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj/command-stats.md`

  * Out Of Memory Errors

      - `/nodes/master/oome.md`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj/thread-dump.txt`

