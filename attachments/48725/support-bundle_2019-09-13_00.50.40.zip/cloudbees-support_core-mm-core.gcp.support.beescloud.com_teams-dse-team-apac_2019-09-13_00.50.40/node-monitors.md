Node monitors
=============
Approved Folders
----
 - Is Ignored: false
 - Computers:
   * master: null
   * dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj: null
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj: 1 sec ahead
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 3.676GB left on /var/jenkins_home.
   * dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj: Disk space is too low. Only 92.420GB left on /home/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:5627/15037MB  Swap:0/0MB
   * dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj: Memory:3637/7478MB  Swap:0/0MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 91.849GB left on /tmp.
   * dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj: Disk space is too low. Only 92.420GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj: 2801ms
