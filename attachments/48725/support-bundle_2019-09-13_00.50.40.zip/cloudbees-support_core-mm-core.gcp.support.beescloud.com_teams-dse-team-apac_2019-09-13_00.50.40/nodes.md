Node statistics
===============

  * Total number of nodes
      - Sample size:        10785
      - Average (mean):     1.9999750514572174
      - Average (median):   2.0
      - Standard deviation: 0.04295327152539428
      - Minimum:            1
      - Maximum:            3
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        10785
      - Average (mean):     1.0056622694060458
      - Average (median):   1.0
      - Standard deviation: 0.07503471270831616
      - Minimum:            1
      - Maximum:            2
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        10785
      - Average (mean):     1.005662269406046
      - Average (median):   1.0
      - Standard deviation: 0.07503471270831615
      - Minimum:            1
      - Maximum:            2
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors in use
      - Sample size:        10785
      - Average (mean):     0.004752251599449251
      - Average (median):   0.0
      - Standard deviation: 0.06877257959524845
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      1
      - FS root:        `/var/jenkins_home`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.29
      - Java
          + Home:           `/usr/lib/jvm/java-1.8-openjdk/jre`
          + Vendor:           IcedTea
          + Version:          1.8.0&#95;212
          + Maximum memory:   2.00 GB (2147483648)
          + Allocated memory: 2.00 GB (2147483648)
          + Free memory:      767.05 MB (804311568)
          + In-use memory:    1.25 GB (1343172080)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  IcedTea
          + Version: 25.212-b04
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.14.137+
      - Process ID: 6 (0x6)
      - Process started: 2019-09-11 03:53:41.695+0000
      - Process uptime: 1 day 20 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/share/jenkins/alpn-boot.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/resources.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/rt.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jce.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8-openjdk/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64/server:/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64:/usr/lib/jvm/java-1.8-openjdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dhudson.slaves.NodeProvisioner.initialDelay=0`
          + arg[1]: `-Xbootclasspath/p:/usr/share/jenkins/alpn-boot.jar`
          + arg[2]: `-Duser.home=/var/jenkins_home`
          + arg[3]: `-Xmx2048m`
          + arg[4]: `-Xms2048m`
          + arg[5]: `-Djenkins.model.Jenkins.slaveAgentPort=50003`
          + arg[6]: `-Djenkins.install.runSetupWizard=true`
          + arg[7]: `-Dhudson.lifecycle=hudson.lifecycle.ExitLifecycle`
          + arg[8]: `-DMASTER_NAME=dse-team-apac`
          + arg[9]: `-Dcb.BeekeeperProp.autoInstallIncremental=true`
          + arg[10]: `-Djenkins.model.Jenkins.slaveAgentPortEnforce=true`
          + arg[11]: `-DMASTER_GRANT_ID=4bc7edf2-a664-4682-b0a7-78efab132b9f`
          + arg[12]: `-Dcb.IMProp.warProfiles.cje=kubernetes.json`
          + arg[13]: `-DMASTER_INDEX=2`
          + arg[14]: `-Dcb.IMProp.warProfiles=bluesteel-core.json`
          + arg[15]: `-DMASTER_OPERATIONSCENTER_ENDPOINT=http://cjoc.cje-support-general.svc.cluster.local/cjoc/`
          + arg[16]: `-Dcb.BeekeeperProp.noFullUpgrade=true`
          + arg[17]: `-Dhudson.DNSMultiCast.disabled=true`
          + arg[18]: `-DMASTER_ENDPOINT=http://jenkins.example.com/teams-dse-team-apac/`
          + arg[19]: `-Dkubernetes.websocket.ping.interval=30000`
          + arg[20]: `-XX:MaxRAMFraction=1`
          + arg[21]: `-XX:+AlwaysPreTouch`
          + arg[22]: `-XX:+UseG1GC`
          + arg[23]: `-XX:+ExplicitGCInvokesConcurrent`
          + arg[24]: `-XX:+ParallelRefProcEnabled`
          + arg[25]: `-XX:+UseStringDeduplication`
          + arg[26]: `-XX:+UseGCLogFileRotation`
          + arg[27]: `-XX:NumberOfGCLogFiles=5`
          + arg[28]: `-XX:GCLogFileSize=40m`
          + arg[29]: `-Xloggc:/var/jenkins_home/gc.log`
          + arg[30]: `-XX:+PrintGCDetails`
          + arg[31]: `-XX:+PrintGCDateStamps`
          + arg[32]: `-XX:+PrintHeapAtGC`
          + arg[33]: `-XX:+PrintGCCause`
          + arg[34]: `-XX:+PrintTenuringDistribution`
          + arg[35]: `-XX:+PrintReferenceGC`
          + arg[36]: `-XX:+PrintAdaptiveSizePolicy`
          + arg[37]: `-Dhudson.slaves.NodeProvisioner.initialDelay=0`
          + arg[38]: `-Dcb.distributable.name=Docker Common CJE`
          + arg[39]: `-Dcb.distributable.commit_sha=49e35b48176fc789078f52e12f8fb09382da938a`

  * `dse-team-apac-aburdajewicz-testscenario-4-10xd4-558nc-5khzj` (`org.csanchez.jenkins.plugins.kubernetes.KubernetesSlave`)
      - Description:    _dse-team-apac&#95;aburdajewicz&#95;testScenario&#95;4-10xd4-558nc_
      - Executors:      1
      - Remote FS root: ``
      - Labels:         dse-team-apac&#95;aburdajewicz&#95;testScenario&#95;4-10xd4
      - Usage:          `EXCLUSIVE`
      - Launch method:  `com.cloudbees.jenkins.plugins.kube.ListenableKubernetesLauncher`
      - Availability:   `org.jenkinsci.plugins.durabletask.executors.OnceRetentionStrategy`
      - Status:         off-line

