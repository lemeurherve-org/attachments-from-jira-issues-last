# Totals
* Writes: 1316
  * sent 9.3Mb
* Reads: 1685
  * received 1.0Mb
* Responses: 32
  * waited 1 min 30 sec

# Commands sent
* `Pipe.Chunk`: 1002
  * sent 8.3Mb
* `ProxyOutputStream.Ack`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 201
  * sent 0.6Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 42
  * sent 0.2Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 13
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 22
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 1
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Write`: 1
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 3
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 2
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 1
  * received 0.0Mb
* `Pipe.Flush`: 1
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 1120
  * received 0.2Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 201
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 42
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 1
  * received 0.0Mb
* `Response`: 32
  * received 0.1Mb
* `Unexport`: 251
  * received 0.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 13
  * received 0.1Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 22
  * received 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 1
  * waited 0.1 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 13 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 4.2 sec
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * waited 14 sec
* `UserRequest:hudson.FilePath$Exists`: 1
  * waited 11 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 2
  * waited 2.7 sec
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * waited 92 ms
* `UserRequest:hudson.FilePath$Mkdirs`: 2
  * waited 4.6 sec
* `UserRequest:hudson.FilePath$Write`: 1
  * waited 99 ms
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 1
  * waited 5.2 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 3
  * waited 1.3 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * waited 2.1 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * waited 1.7 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * waited 2.8 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * waited 5 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 1
  * waited 0.19 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.69 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.2 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 10 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 0.29 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 0.69 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 0.5 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * waited 0.3 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 1
  * waited 6.7 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1
  * waited 94 ms
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 1
  * waited 0.6 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 1
  * waited 0.19 sec

# JARs sent
* `support-core.jar`: 351341b
* `ant-1.9.2.jar`: 2000557b
* `commons-io-2.6.jar`: 214788b
* `durable-task.jar`: 61399b
* `memory-monitor-1.9.jar`: 17292b
* `commons-compress-1.10.jar`: 409475b
* `guava-11.0.1.jar`: 1649781b
* `stapler-1.257.2.jar`: 441356b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `support-log-formatter-1.0.jar`: 6818b
* `launchd-slave-installer-1.2.jar`: 22663b
* `slave-installer-1.6.jar`: 27374b
* `localizer-1.26.jar`: 8600b
* `systemd-slave-installer-1.1.jar`: 11541b
* `akuma-1.10.jar`: 19673b
* `upstart-slave-installer-1.1.jar`: 10798b
* `commons-lang-2.6.jar`: 284220b
* `jna-4.5.2.jar`: 1484022b
* `workflow-api.jar`: 176385b
* `acegi-security-1.0.7.jar`: 548722b
* `spring-core-2.5.6.SEC03.jar`: 285605b
* `libpam4j-1.11.jar`: 21038b
