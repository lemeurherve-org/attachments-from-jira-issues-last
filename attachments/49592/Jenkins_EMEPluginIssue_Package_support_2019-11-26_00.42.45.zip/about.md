Jenkins
=======

Version details
---------------

  * Version: `2.150.3`
  * Mode:    Webapp Directory
  * Url:     http://dcrda24l.unix.anz:8080/jenkins/
  * Servlet container
      - Specification: 3.1
      - Name:          `Apache Tomcat/8.0.52`
  * Java
      - Home:           `/app/tomcat/software/JAVA/jdk1.8.0_201/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;201
      - Maximum memory:   6.95 GB (7460618240)
      - Allocated memory: 3.93 GB (4215275520)
      - Free memory:      2.18 GB (2340634160)
      - In-use memory:    1.75 GB (1874641360)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.201-b09
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-862.37.1.el7.x86&#95;64
      - Distribution: "Red Hat Enterprise Linux Server release 7.5 (Maipo)"
      - LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
  * Process ID: 22193 (0x56b1)
  * Process started: 2019-10-25 03:19:02.757+0000
  * Process uptime: 1 mo 1 day
  * JVM startup parameters:
      - Boot classpath: `/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/resources.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/rt.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/sunrsasign.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/jsse.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/jce.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/charsets.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/jfr.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/classes`
      - Classpath: `/app/tomcat/apache-tomcat-8.0.52/bin/bootstrap.jar:/app/tomcat/apache-tomcat-8.0.52/bin/tomcat-juli.jar`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.util.logging.config.file=/app/tomcat/apache-tomcat-8.0.52/conf/logging.properties`
      - arg[1]: `-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager`
      - arg[2]: `-Djdk.tls.ephemeralDHKeySize=2048`
      - arg[3]: `-Djava.protocol.handler.pkgs=org.apache.catalina.webresources`
      - arg[4]: `-Dignore.endorsed.dirs=`
      - arg[5]: `-Dcatalina.base=/app/tomcat/apache-tomcat-8.0.52`
      - arg[6]: `-Dcatalina.home=/app/tomcat/apache-tomcat-8.0.52`
      - arg[7]: `-Djava.io.tmpdir=/app/tomcat/apache-tomcat-8.0.52/temp`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: true

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.9 'Ant Plugin'
  * apache-httpcomponents-client-4-api:4.5.5-3.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.17 'bouncycastle API Plugin'
  * branch-api:2.2.0 'Branch API Plugin'
  * cloudbees-folder:6.7 'Folders Plugin'
  * command-launcher:1.3 'Command Agent Launcher Plugin'
  * credentials:2.1.18 'Credentials Plugin'
  * credentials-binding:1.18 'Credentials Binding Plugin'
  * display-url-api:2.3.0 'Display URL API'
  * docker-commons:1.13 'Docker Commons Plugin'
  * docker-workflow:1.17 'Docker Pipeline'
  * durable-task:1.29 'Durable Task Plugin'
  * EMEJenkinsPlugin:ip_tasty_table 'Ab Initio EME TR Plugin'
  * git-client:2.7.6 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * jackson2-api:2.9.8 'Jackson 2 API Plugin'
  * jdk-tool:1.2 'JDK Tool Plugin'
  * jenkins-jira-issue-updater:1.18 'Jenkins Jira Issue Updater'
  * jira:3.0.10 'Jenkins JIRA plugin'
  * jira-steps:1.5.1 'JIRA Pipeline Steps'
  * jira-trigger:1.0.0 'JIRA Trigger Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.55 'Jenkins JSch dependency plugin'
  * junit:1.27 'JUnit Plugin'
  * lockable-resources:2.4 'Lockable Resources plugin'
  * mailer:1.23 'Jenkins Mailer Plugin'
  * matrix-project:1.14 'Matrix Project Plugin'
  * metrics:ip_archaeological_adult 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pipeline-build-step:2.8 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.9 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.10 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.7 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.7 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.7 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.10 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.7 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.10 'Pipeline: Stage View Plugin'
  * plain-credentials:1.5 'Plain Credentials Plugin'
  * scm-api:2.4.0 'SCM API Plugin'
  * script-security:1.55 'Script Security Plugin'
  * ssh:2.6.1 'Jenkins SSH plugin'
  * ssh-credentials:1.15 'SSH Credentials Plugin'
  * ssh-slaves:1.29.4 'Jenkins SSH Slaves plugin'
  * structs:1.17 'Structs Plugin'
  * support-core:2.56 'Support Core Plugin'
  * variant:1.2 'Variant Plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.33 'Pipeline: API'
  * workflow-basic-steps:2.15 'Pipeline: Basic Steps'
  * workflow-cps:2.64 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.13 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.29 'Pipeline: Nodes and Processes'
  * workflow-job:2.32 'Pipeline: Job'
  * workflow-multibranch:2.21 'Pipeline: Multibranch'
  * workflow-scm-step:2.7 'Pipeline: SCM Step'
  * workflow-step-api:2.19 'Pipeline: Step API'
  * workflow-support:3.2 'Pipeline: Supporting APIs'
