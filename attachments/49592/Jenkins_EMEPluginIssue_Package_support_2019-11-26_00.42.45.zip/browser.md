Browser
=======

  * Screen size: 942x530
  * User Agent
      - Type:     Browser
      - Name:     Mozilla
      - Family:   MOZILLA
      - Producer: Mozilla Foundation
      - Version:  rv:11.0
      - Raw:      `Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko`
  * Operating System
      - Name:     Windows
      - Family:   WINDOWS
      - Producer: Microsoft Corporation.
      - Version:  10.0

