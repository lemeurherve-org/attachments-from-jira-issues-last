Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 10
    - Number of builds per job: 60.7 [n=10, s=100.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 4
    - Number of builds per job: 0.75 [n=4, s=0.5]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 2
    - Number of items per container: 1.0 [n=2, s=0.0]

Total job statistics
======================

  * Number of jobs: 14
  * Number of builds per job: 43.57142857142857 [n=14, s=80.0]
