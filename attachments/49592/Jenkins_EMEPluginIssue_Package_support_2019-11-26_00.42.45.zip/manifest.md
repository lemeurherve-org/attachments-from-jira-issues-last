Support Bundle Manifest
=======================

Generated on 2019-11-26 00:42:45.706+0000

Requested components:

  * Agent Log Recorders

      - `nodes/slave/computer_vigorous_demand/jenkins.log`

      - `nodes/slave/computer_vigorous_demand/logs/all_2019-05-06_11.36.13.log`

      - `nodes/slave/computer_vigorous_demand/logs/all_2019-05-27_07.29.21.log`

      - `nodes/slave/computer_vigorous_demand/logs/all_2019-06-01_14.56.32.log`

      - `nodes/slave/computer_vigorous_demand/logs/all_2019-06-01_21.39.23.log`

      - `nodes/slave/computer_vigorous_demand/logs/all_2019-08-08_12.23.30.log`

      - `nodes/slave/computer_vigorous_demand/logs/all_2019-09-12_06.34.53.log`

      - `nodes/slave/computer_vigorous_demand/logs/all_2019-10-24_04.11.42.log`

      - `nodes/slave/computer_vigorous_demand/logs/all_2019-10-25_03.19.39.log`

      - `nodes/slave/computer_vigorous_demand/logs/all_memory_buffer.log`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/computer_vigorous_demand/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Administrative monitors

      - `admin-monitors.md`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/computer_vigorous_demand/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/computer_vigorous_demand/file-descriptors.txt`

  * Load Statistics

      - `load-stats/label/computer_vigorous_demand/gnuplot`

      - `load-stats/label/computer_vigorous_demand/hour.csv`

      - `load-stats/label/computer_vigorous_demand/min.csv`

      - `load-stats/label/computer_vigorous_demand/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/computer_vigorous_demand/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Agent Command Statistics

      - `nodes/slave/computer_vigorous_demand/command-stats.md`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/computer_vigorous_demand/system.properties`

  * Update Center

      - `update-center.md`

  * Deadlock Records

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/computer_vigorous_demand/thread-dump.txt`

