Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * computer_vigorous_demand: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * computer_vigorous_demand: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 2.263GB left on /home/aucrdhtomdga/.jenkins.
   * computer_vigorous_demand: Disk space is too low. Only 4.703GB left on /app/abinitio/software/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:21739/32013MB  Swap:5119/5119MB
   * computer_vigorous_demand: Memory:2368/515821MB  Swap:688/5119MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 88.338GB left on /app/tomcat/apache-tomcat-8.0.52/temp.
   * computer_vigorous_demand: Disk space is too low. Only 2.006GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * computer_vigorous_demand: 3ms
