Node statistics
===============

  * Total number of nodes
      - Sample size:        183692
      - Average (mean):     1.9999999999999996
      - Average (median):   2.0
      - Standard deviation: 4.4408920985006257E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        183692
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors
      - Sample size:        183692
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 0.0
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors in use
      - Sample size:        183692
      - Average (mean):     1.1728303221675015E-16
      - Average (median):   0.0
      - Standard deviation: 1.0829729092491193E-8
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/home/aucrdhtomdga/.jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.27
      - Java
          + Home:           `/app/tomcat/software/JAVA/jdk1.8.0_201/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;201
          + Maximum memory:   6.95 GB (7460618240)
          + Allocated memory: 3.93 GB (4215275520)
          + Free memory:      2.17 GB (2329166480)
          + In-use memory:    1.76 GB (1886109040)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.201-b09
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-862.37.1.el7.x86&#95;64
          + Distribution: "Red Hat Enterprise Linux Server release 7.5 (Maipo)"
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 22193 (0x56b1)
      - Process started: 2019-10-25 03:19:02.757+0000
      - Process uptime: 1 mo 1 day
      - JVM startup parameters:
          + Boot classpath: `/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/resources.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/rt.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/sunrsasign.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/jsse.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/jce.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/charsets.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/lib/jfr.jar:/app/tomcat/software/JAVA/jdk1.8.0_201/jre/classes`
          + Classpath: `/app/tomcat/apache-tomcat-8.0.52/bin/bootstrap.jar:/app/tomcat/apache-tomcat-8.0.52/bin/tomcat-juli.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.util.logging.config.file=/app/tomcat/apache-tomcat-8.0.52/conf/logging.properties`
          + arg[1]: `-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager`
          + arg[2]: `-Djdk.tls.ephemeralDHKeySize=2048`
          + arg[3]: `-Djava.protocol.handler.pkgs=org.apache.catalina.webresources`
          + arg[4]: `-Dignore.endorsed.dirs=`
          + arg[5]: `-Dcatalina.base=/app/tomcat/apache-tomcat-8.0.52`
          + arg[6]: `-Dcatalina.home=/app/tomcat/apache-tomcat-8.0.52`
          + arg[7]: `-Djava.io.tmpdir=/app/tomcat/apache-tomcat-8.0.52/temp`

  * `computer_vigorous_demand` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/app/abinitio/software/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.27
      - Java
          + Home:           `/app/abinitio/software/JAVA/jdk1.8.0_201/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;201
          + Maximum memory:   26.67 GB (28631367680)
          + Allocated memory: 1.41 GB (1512046592)
          + Free memory:      1.36 GB (1455702568)
          + In-use memory:    53.73 MB (56344024)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.201-b09
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-693.50.3.el7.x86&#95;64
          + Distribution: "Red Hat Enterprise Linux Server release 7.4 (Maipo)"
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 13130 (0x334a)
      - Process started: 2019-10-25 03:19:35.714+0000
      - Process uptime: 1 mo 1 day
      - JVM startup parameters:
          + Boot classpath: `/app/abinitio/software/JAVA/jdk1.8.0_201/jre/lib/resources.jar:/app/abinitio/software/JAVA/jdk1.8.0_201/jre/lib/rt.jar:/app/abinitio/software/JAVA/jdk1.8.0_201/jre/lib/sunrsasign.jar:/app/abinitio/software/JAVA/jdk1.8.0_201/jre/lib/jsse.jar:/app/abinitio/software/JAVA/jdk1.8.0_201/jre/lib/jce.jar:/app/abinitio/software/JAVA/jdk1.8.0_201/jre/lib/charsets.jar:/app/abinitio/software/JAVA/jdk1.8.0_201/jre/lib/jfr.jar:/app/abinitio/software/JAVA/jdk1.8.0_201/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

