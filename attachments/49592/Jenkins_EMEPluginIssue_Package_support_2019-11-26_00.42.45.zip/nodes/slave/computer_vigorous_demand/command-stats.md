# Totals
* Writes: 314497
  * sent 633.4Mb
* Reads: 736663
  * received 1290.9Mb
* Responses: 195852
  * waited 3 hr 28 min

# Commands sent
* `GC`: 19
  * sent 0.0Mb
* `Pipe.Chunk`: 38
  * sent 0.3Mb
* `ProxyOutputStream.Ack`: 87732
  * sent 13.5Mb
* `ProxyOutputStream.Dead`: 25
  * sent 0.2Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 582
  * sent 1.5Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 14
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 36
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 512
  * sent 1.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 9185
  * sent 17.8Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 20495
  * sent 31.3Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 512
  * sent 2.8Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 512
  * sent 2.7Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 512
  * sent 2.7Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 764
  * sent 1.8Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 4578
  * sent 12.6Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 764
  * sent 1.9Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 764
  * sent 1.9Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 764
  * sent 1.9Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 764
  * sent 2.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 764
  * sent 1.9Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 764
  * sent 1.9Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 763
  * sent 1.8Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 1528
  * sent 5.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 1526
  * sent 4.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 763
  * sent 1.9Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 764
  * sent 1.8Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 3052
  * sent 7.6Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 1532
  * sent 3.6Mb
* `UserRequest:hudson.FilePath$CopyTo`: 18312
  * sent 48.9Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Delete`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 71824
  * sent 217.8Mb
* `UserRequest:hudson.FilePath$IsDescendant`: 2305
  * sent 18.3Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 1312
  * sent 6.0Mb
* `UserRequest:hudson.FilePath$IsUnix`: 29615
  * sent 75.2Mb
* `UserRequest:hudson.FilePath$LastModified`: 18688
  * sent 48.7Mb
* `UserRequest:hudson.FilePath$Length`: 49
  * sent 0.4Mb
* `UserRequest:hudson.FilePath$ListFilter`: 462
  * sent 1.6Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 76
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Read`: 11394
  * sent 38.0Mb
* `UserRequest:hudson.FilePath$ValidateAntFileMask`: 64
  * sent 0.5Mb
* `UserRequest:hudson.FilePath$Write`: 6192
  * sent 19.9Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 512
  * sent 3.0Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 60
  * sent 0.2Mb
* `UserRequest:hudson.model.DirectoryBrowserSupport$BuildChildPaths`: 420
  * sent 3.2Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 766
  * sent 1.6Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 766
  * sent 1.6Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 766
  * sent 1.8Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 766
  * sent 1.6Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 9185
  * sent 16.9Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$DetectOS`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$LoadingCount`: 4
  * sent 0.1Mb
* `UserRequest:hudson.slaves.SlaveComputer$LoadingPrefetchCacheCount`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$LoadingTime`: 4
  * sent 0.1Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 764
  * sent 1.8Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveVersion`: 2
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 22
  * sent 0.1Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 67
  * sent 0.2Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetThreadDump`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.branch.WorkspaceLocatorImpl$WriteAtomic`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb

# Commands received
* `GC`: 1
  * received 0.0Mb
* `Pipe.Chunk`: 87732
  * received 79.8Mb
* `Pipe.Flush`: 1580
  * received 0.3Mb
* `ProxyOutputStream.Ack`: 38
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 29706
  * received 55.7Mb
* `ProxyOutputStream.Unexport`: 1015
  * received 1.3Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 582
  * received 0.3Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 14
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * received 0.0Mb
* `Response`: 195852
  * received 518.9Mb
* `Unexport`: 410404
  * received 616.0Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 36
  * received 0.2Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 512
  * received 1.4Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 9185
  * received 16.9Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 512
  * waited 2.7 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 512
  * waited 2.5 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 512
  * waited 3 hr 4 min
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 764
  * waited 2.2 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.3 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 4578
  * waited 2 min 29 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 764
  * waited 52 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 764
  * waited 4.9 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 764
  * waited 3.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 764
  * waited 2.6 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 764
  * waited 5.8 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 764
  * waited 2.4 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 763
  * waited 3.4 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 1528
  * waited 14 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 1526
  * waited 6.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 763
  * waited 2.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 764
  * waited 27 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 3052
  * waited 12 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 2
  * waited 0.13 sec
* `UserRequest:hudson.FilePath$CallableWith`: 1532
  * waited 9.4 sec
* `UserRequest:hudson.FilePath$CopyTo`: 18312
  * waited 1 min 4 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 22
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$Delete`: 22
  * waited 0.1 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 2
  * waited 6.7 sec
* `UserRequest:hudson.FilePath$Exists`: 71824
  * waited 9 min 25 sec
* `UserRequest:hudson.FilePath$IsDescendant`: 2305
  * waited 12 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 1312
  * waited 11 sec
* `UserRequest:hudson.FilePath$IsUnix`: 29615
  * waited 2 min 36 sec
* `UserRequest:hudson.FilePath$LastModified`: 18688
  * waited 47 sec
* `UserRequest:hudson.FilePath$Length`: 49
  * waited 0.2 sec
* `UserRequest:hudson.FilePath$ListFilter`: 462
  * waited 2.3 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 76
  * waited 0.7 sec
* `UserRequest:hudson.FilePath$Read`: 11394
  * waited 1 min 8 sec
* `UserRequest:hudson.FilePath$ValidateAntFileMask`: 64
  * waited 2 sec
* `UserRequest:hudson.FilePath$Write`: 6192
  * waited 30 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 512
  * waited 6.4 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 60
  * waited 11 sec
* `UserRequest:hudson.model.DirectoryBrowserSupport$BuildChildPaths`: 420
  * waited 3.6 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 766
  * waited 3.4 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 766
  * waited 3.2 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 766
  * waited 6.1 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 766
  * waited 4 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 9185
  * waited 39 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 73 ms
* `UserRequest:hudson.slaves.SlaveComputer$DetectOS`: 2
  * waited 12 ms
* `UserRequest:hudson.slaves.SlaveComputer$LoadingCount`: 4
  * waited 40 ms
* `UserRequest:hudson.slaves.SlaveComputer$LoadingPrefetchCacheCount`: 2
  * waited 16 ms
* `UserRequest:hudson.slaves.SlaveComputer$LoadingTime`: 4
  * waited 64 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 764
  * waited 6.7 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveVersion`: 2
  * waited 7 ms
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 22
  * waited 0.13 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 67
  * waited 1 min 25 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 2
  * waited 48 ms
* `UserRequest:hudson.util.RemotingDiagnostics$GetThreadDump`: 2
  * waited 0.23 sec
* `UserRequest:jenkins.branch.WorkspaceLocatorImpl$WriteAtomic`: 2
  * waited 0.14 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.38 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 26 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 72 ms
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 43 ms

# JARs sent
* `branch-api.jar`: 307198b
