Jenkins
=======

Version details
---------------

  * Version: `2.222.3`
  * Instance ID: `5c96df05b0bdfa5a9ee8624039816283`
  * Mode:    WAR
  * Url:     http://dcx-jenkins.agcocorp.com/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.27.v20200227`
  * Java
      - Home:           `/opt/jdk1.8.0_191/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;191
      - Maximum memory:   3.48 GB (3739746304)
      - Allocated memory: 2.93 GB (3145728000)
      - Free memory:      819.81 MB (859637208)
      - In-use memory:    2.13 GB (2286090792)
      - GC strategy:      ParallelGC
      - Available CPUs:   4
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.191-b12
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.4.0-178-generic
      - Distribution: Ubuntu 16.04 LTS
  * Process ID: 22786 (0x5902)
  * Process started: 2020-05-18 10:53:29.491+0000
  * Process uptime: 4 hr 12 min
  * JVM startup parameters:
      - Boot classpath: `/opt/jdk1.8.0_191/jre/lib/resources.jar:/opt/jdk1.8.0_191/jre/lib/rt.jar:/opt/jdk1.8.0_191/jre/lib/sunrsasign.jar:/opt/jdk1.8.0_191/jre/lib/jsse.jar:/opt/jdk1.8.0_191/jre/lib/jce.jar:/opt/jdk1.8.0_191/jre/lib/charsets.jar:/opt/jdk1.8.0_191/jre/lib/jfr.jar:/opt/jdk1.8.0_191/jre/classes:/opt/dynatrace/oneagent/agent/bin/1.191.217.20200514-103405/any/java/oneagentjava.jar:/opt/dynatrace/oneagent/agent/bin/1.191.217.20200514-103405/any/java/oneagentjava.rmi.jar:/opt/dynatrace/oneagent/agent/bin/1.191.217.20200514-103405/any/java/oneagentjava.sql.jar`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Dhudson.model.DirectoryBrowserSupport.CSP=default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self';`
      - arg[2]: `-agentpath:/opt/dynatrace/oneagent/agent/bin/1.191.217.20200514-103405/linux-x86-64/liboneagentloader.so=loglevelcon=none,tenant=lgf19795,tenanttoken=GLGr48a5N8dZ3QZX,server=https://10.85.65.163:9999/communication;https://ip-10-85-65-163.eu-west-1.compute.internal:9999/communication;https://sg-eu-west-1-34-248-26-181-prod13-ireland.live.ruxit.com/communication;https://sg-eu-west-1-54-77-219-214-prod13-ireland.live.ruxit.com/communication;https://sg-eu-west-1-52-19-113-184-prod13-ireland.live.ruxit.com/communication;https://sg-eu-west-1-52-31-60-170-prod13-ireland.live.ruxit.com/communication;https://sg-eu-west-1-34-242-17-158-prod13-ireland.live.ruxit.com/communication;https://lgf19795.live.dynatrace.com:443/communication`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.16 'Jenkins Active Directory plugin'
  * analysis-core:1.96 'Static Analysis Utilities'
  * ant:1.11 'Ant Plugin'
  * antisamy-markup-formatter:2.0 'OWASP Markup Formatter Plugin'
  * any-buildstep:0.1 'Any Build Step Plugin'
  * apache-httpcomponents-client-4-api:4.5.10-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * appcenter:0.9.2 'App Center'
  * artifactory:3.6.2 'Jenkins Artifactory Plugin'
  * async-http-client:1.9.40.0 'Async Http Client'
  * audit-trail:3.5 'Audit Trail'
  * audit2db:0.5 'Jenkins Audit to Database Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * aws-credentials:1.28 'CloudBees AWS Credentials Plugin'
  * aws-java-sdk:1.11.723 'Amazon Web Services SDK'
  * aws-parameter-store:1.2.2 'AWS Parameter Store Build Wrapper'
  * backup:1.6.1 'Backup plugin'
  * bitbucket:1.1.11 'Jenkins Bitbucket Plugin'
  * bitbucket-pullrequest-builder:1.5.0 'Bitbucket Pullrequest Builder Plugin'
  * blueocean:1.23.2 'Blue Ocean'
  * blueocean-autofavorite:1.2.4 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.23.2 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.23.2 'Common API for Blue Ocean'
  * blueocean-config:1.23.2 'Config API for Blue Ocean'
  * blueocean-core-js:1.23.2 'Blue Ocean Core JS'
  * blueocean-dashboard:1.23.2 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.3.1 'Display URL for Blue Ocean'
  * blueocean-events:1.23.2 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.23.2 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.23.2 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.23.2 'i18n for Blue Ocean'
  * blueocean-jira:1.23.2 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.23.2 'JWT for Blue Ocean'
  * blueocean-personalization:1.23.2 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.23.2 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.23.2 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.23.2 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.23.2 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.23.2 'REST Implementation for Blue Ocean'
  * blueocean-web:1.23.2 'Web for Blue Ocean'
  * bouncycastle-api:2.18 'bouncycastle API Plugin'
  * branch-api:2.5.6 'Branch API Plugin'
  * build-blocker-plugin:1.7.3 'Build Blocker Plugin'
  * build-failure-analyzer:1.26.0 'Build Failure Analyzer'
  * build-monitor-plugin:1.12+build.201809061734 'Build Monitor View'
  * build-name-setter:2.1.0 'Build Name and Description Setter'
  * build-pipeline-plugin:1.5.8 'Build Pipeline Plugin'
  * build-timeout:1.19.1 'Build Timeout'
  * build-user-vars-plugin:1.5 'Jenkins user build vars plugin'
  * built-on-column:1.1 'built-on-column'
  * claim:2.16 'Jenkins Claim Plugin'
  * cloudbees-bitbucket-branch-source:2.8.0 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.12 'Folders Plugin'
  * codedeploy:1.23 'AWS CodeDeploy Plugin for Jenkins'
  * command-launcher:1.4 'Command Agent Launcher Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:3.6.3 'Config File Provider Plugin'
  * configurationslicing:1.47 'Configuration Slicing plugin'
  * convert-to-pipeline:1.0 'Convert To Pipeline'
  * copyartifact:1.44 'Copy Artifact Plugin'
  * credentials:2.3.7 'Credentials Plugin'
  * credentials-binding:1.23 'Credentials Binding Plugin'
  * crx-content-package-deployer:1.9 'CRX Content Package Deployer Plugin'
  * custom-tools-plugin:0.7 'Jenkins Custom Tools Plugin'
  * cvs:2.16 'Jenkins CVS Plug-in'
  * dashboard-view:2.12 'Dashboard View'
  * deploy:1.15 'Deploy to container Plugin'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * display-url-api:2.3.2 'Display URL API'
  * docker-commons:1.16 'Docker Commons Plugin'
  * docker-workflow:1.23 'Docker Pipeline'
  * doclinks:0.6.1 'Jenkins DocLinks plugin'
  * downstream-buildview:1.9 'Downstream build view'
  * dtkit-api:2.1.2 'DTKit 2 API.'
  * durable-task:1.34 'Durable Task Plugin'
  * ec2:1.50.3 'Amazon EC2 plugin'
  * email-ext:2.69 'Email Extension Plugin'
  * emailext-template:1.1 'Email Extension Template Plugin'
  * embeddable-build-status:2.0.3 'Embeddable Build Status Plugin'
  * envinject:2.3.0 'Environment Injector Plugin'
  * envinject-api:1.7 'EnvInject API Plugin'
  * extended-choice-parameter:0.78 'Extended Choice Parameter Plug-In'
  * extensible-choice-parameter:1.6.0 'Extensible Choice Parameter plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * extra-columns:1.21 'Extra Columns Plugin'
  * favorite:2.3.2 'Favorite'
  * flexible-publish:0.15.2 'Flexible Publish Plugin'
  * fortify:19.2.30 'Fortify'
  * ftppublisher:1.2 'FTP publisher plugin'
  * gatling:1.3.0 'Gatling Jenkins Plugin'
  * generic-webhook-trigger:1.67 'Generic Webhook Trigger Plugin'
  * gerrit-trigger:2.30.5 'Gerrit Trigger'
  * ghprb:1.42.1 'GitHub Pull Request Builder'
  * git:4.2.2 'Jenkins Git plugin'
  * git-client:3.2.1 'Jenkins Git client plugin'
  * git-parameter:0.9.12 'Git Parameter Plug-In'
  * git-server:1.9 'Jenkins GIT server Plugin'
  * github:1.30.0 'GitHub plugin'
  * github-api:1.111 'GitHub API Plugin'
  * github-branch-source:2.7.1 'GitHub Branch Source Plugin'
  * gradle:1.36 'Gradle Plugin'
  * greenballs:1.15 'Green Balls'
  * groovy:2.2 'Groovy'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.8-1.0 'Handy Uri Templates 2.x API Plugin'
  * hp-application-automation-tools-plugin:6.2 'Micro Focus Application Automation Tools'
  * htmlpublisher:1.23 'HTML Publisher plugin'
  * http-post:1.2 'HTTP POST Plugin'
  * http_request:1.8.26 'HTTP Request Plugin'
  * ivy:2.1 'Ivy Plugin'
  * jackson2-api:2.11.0 'Jackson 2 API Plugin'
  * jacoco:3.0.5 'Jenkins JaCoCo plugin'
  * javadoc:1.5 'Javadoc Plugin'
  * jdk-tool:1.4 'Oracle Java SE Development Kit Installer Plugin'
  * JDK_Parameter_Plugin:1.0 'JDK Parameter Plugin'
  * jenkins-design-language:1.23.2 'Jenkins Design Language'
  * jenkins-multijob-plugin:1.33 'Jenkins Multijob plugin'
  * jira:3.0.15 'Jenkins Jira plugin'
  * job-dsl:1.77 'Job DSL'
  * job-restrictions:0.8 'Job Restrictions Plugin'
  * jobConfigHistory:2.26 'Jenkins Job Configuration History Plugin'
  * jobgenerator:1.22 'Job Generator'
  * jquery:1.12.4-1 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.55.2 'Jenkins JSch dependency plugin'
  * junit:1.29 'JUnit Plugin'
  * jython:1.9 'Jython Plugin'
  * ldap:1.24 'LDAP Plugin'
  * locale:1.4 'Locale plugin'
  * lockable-resources:2.8 'Lockable Resources plugin'
  * logfilesizechecker:1.5 'Jenkins build log file size checker plugin'
  * logstash:2.3.2 'Logstash'
  * m2release:0.16.2 'Jenkins Maven Release Plug-in Plug-in'
  * mailer:1.32 'Jenkins Mailer Plugin'
  * managed-scripts:1.4 'Managed Scripts'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mask-passwords:2.13 'Mask Passwords Plugin'
  * matrix-auth:2.6.1 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.14 'Matrix Project Plugin'
  * maven-artifact-choicelistprovider:1.5.1 'Maven Artifact ChoiceListProvider (Nexus)'
  * maven-plugin:3.6 'Maven Integration plugin'
  * mercurial:2.10 'Jenkins Mercurial plugin'
  * metrics:4.0.2.6 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * monitoring:1.83.0 'Monitoring'
  * mq-notifier:1.2.9 'MQ Notifier'
  * msbuild:1.29 'Jenkins MSBuild Plugin'
  * mstest:1.0.0 'MSTest plugin'
  * mstestrunner:1.3.0 'Jenkins MSTestRunner plugin'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * naginator:1.18 'Naginator'
  * nant:1.4.3 'NAnt Plugin'
  * next-executions:1.0.15 'next-executions'
  * nexus-artifact-uploader:2.11 'Nexus Artifact Uploader'
  * node-iterator-api:1.5.0 'Node Iterator API Plugin'
  * nodejs:1.3.5 'NodeJS Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * nunit:0.26 'Jenkins NUnit plugin'
  * Office-365-Connector:4.12.4 'Office 365 Connector'
  * p4:1.10.12 'P4 Plugin'
  * pam-auth:1.6 'PAM Authentication plugin'
  * Parameterized-Remote-Trigger:3.1.3 'Parameterized Remote Trigger Plugin'
  * parameterized-trigger:2.36 'Jenkins Parameterized Trigger plugin'
  * pegdown-formatter:1.3 'PegDown Formatter Plugin'
  * performance:3.17 'Performance Plugin'
  * pipeline-aws:1.41 'Pipeline: AWS Steps'
  * pipeline-build-step:2.12 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.10 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.11 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.6.0 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.6.0 'Pipeline: Declarative'
  * pipeline-model-extensions:1.6.0 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.13 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.6.0 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.13 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:2.5.0 'Pipeline Utility Steps'
  * plain-credentials:1.7 'Plain Credentials Plugin'
  * plugin-usage-plugin:1.0 'Plugin Usage - Plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * postbuildscript:2.9.1 'Jenkins PostBuildScript Plugin'
  * powershell:1.4 'Jenkins PowerShell plugin'
  * PrioritySorter:3.6.0 'Jenkins Priority Sorter Plugin'
  * project-inheritance:19.08.02 'Project Inheritance Plugin'
  * promoted-builds:3.5 'Jenkins promoted builds plugin'
  * publish-over:0.22 'Infrastructure plugin for Publish Over X'
  * publish-over-ssh:1.20.1 'Publish Over SSH'
  * pubsub-light:1.13 'Jenkins Pub-Sub "light" Bus'
  * purge-build-queue-plugin:1.0 'Purge Build Queue Plugin'
  * python:1.3 'Python Plugin'
  * rabbitmq-consumer:2.8 'RabbitMQ Consumer Plugin'
  * rebuild:1.31 'Rebuilder'
  * repository-connector:1.2.6 'Repository Connector'
  * resource-disposer:0.14 'Resource Disposer Plugin'
  * ruby-runtime:0.12 'ruby-runtime'
  * run-condition:1.3 'Run Condition Plugin'
  * rvm:0.6 'Rvm'
  * s3:0.11.5 'Jenkins S3 publisher plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:2.6.3 'SCM API Plugin'
  * script-security:1.72 'Script Security Plugin'
  * shelve-project-plugin:3.0 'Shelve Project Plugin'
  * slack:2.40 'Slack Notification Plugin'
  * sonar:2.11 'SonarQube Scanner for Jenkins'
  * sonar-quality-gates:1.3.1 'Sonar Quality Gates Plugin'
  * sse-gateway:1.23 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.6.1 'Jenkins SSH plugin'
  * ssh-agent:1.19 'SSH Agent Plugin'
  * ssh-credentials:1.18.1 'SSH Credentials Plugin'
  * ssh-slaves:1.31.2 'SSH Build Agents plugin'
  * ssh-steps:2.0.0 'SSH Pipeline Steps'
  * structs:1.20 'Structs Plugin'
  * subversion:2.13.1 'Jenkins Subversion Plug-in'
  * support-core:2.68 'Support Core Plugin'
  * template-project:1.5.2 'Template Project plugin'
  * terraform:1.0.10 'Terraform Plugin'
  * test-results-analyzer:0.3.5 'Test Results Analyzer Plugin'
  * testng-plugin:1.15 'TestNG Results Plugin'
  * tfs:5.157.1 'Team Foundation Server Plug-in'
  * thinBackup:1.9 'ThinBackup'
  * timestamper:1.11.3 'Timestamper'
  * token-macro:2.12 'Token Macro Plugin'
  * translation:1.16 'Jenkins Translation Assistance plugin'
  * trilead-api:1.0.6 'Trilead API Plugin'
  * uno-choice:2.3 'Active Choices Plug-in'
  * variant:1.3 'Variant Plugin'
  * veracode-jenkins-plugin:18.11.5.8 'Veracode Jenkins Plugin'
  * view-job-filters:2.2 'View Job Filters'
  * vsphere-cloud:2.23 'vSphere Plugin'
  * windows-slaves:1.6 'WMI Windows Agents Plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.40 'Pipeline: API'
  * workflow-basic-steps:2.20 'Pipeline: Basic Steps'
  * workflow-cps:2.80 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.16 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.35 'Pipeline: Nodes and Processes'
  * workflow-job:2.39 'Pipeline: Job'
  * workflow-multibranch:2.21 'Pipeline: Multibranch'
  * workflow-scm-step:2.11 'Pipeline: SCM Step'
  * workflow-step-api:2.22 'Pipeline: Step API'
  * workflow-support:3.4 'Pipeline: Supporting APIs'
  * ws-cleanup:0.38 'Jenkins Workspace Cleanup Plugin'
  * xunit:2.3.9 'xUnit plugin'
