Browser
=======

  * Screen size: 1920x1080
  * User Agent
      - Type:     Browser
      - Name:     Chrome
      - Family:   CHROME
      - Producer: Google Inc.
      - Version:  81.0.4044.138
      - Raw:      `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36`
  * Operating System
      - Name:     Windows
      - Family:   WINDOWS
      - Producer: Microsoft Corporation.
      - Version:  10.0

