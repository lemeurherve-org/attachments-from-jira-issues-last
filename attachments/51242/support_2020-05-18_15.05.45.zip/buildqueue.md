Current build queue has 3 item(s).
---------------
 * Name of item: PIM UI Autotest (PROD)
    - In queue for: 5.5 sec
    - Is blocked: false
    - Why in queue: Finished waiting
    - Current queue trigger cause: Started by upstream project "dcx-pim-health-check-prod" build number 18,792
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@cde9b44
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.dependency.DependencyQueueTaskDispatcher@2d077445
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.replication.ReplicationQueueTaskDispatcher@49c30481
    - Can run: null
  * Task Dispatcher: hudson.plugins.buildblocker.BuildBlockerQueueTaskDispatcher@189dd7e3
    - Can run: null
  * Task Dispatcher: jenkins.advancedqueue.RunExclusiveThrottler$RunExclusiveDispatcher@60616b0f
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@76528e1a
    - Can run: null
  * Task Dispatcher: org.jenkins.plugins.lockableresources.queue.LockableResourcesQueueTaskDispatcher@27e46b5d
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@5130828d
    - Can run: null
----

 * Name of item: dcx-ecomm-aws-environment-health-check
    - In queue for: 3.6 sec
    - Is blocked: false
    - Why in queue: In the quiet period. Expires in 1.3 sec
    - Current queue trigger cause: Started by upstream project "dcx-ecomm-aws-instances-health-check-prod" build number 14,948
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@cde9b44
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.dependency.DependencyQueueTaskDispatcher@2d077445
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.replication.ReplicationQueueTaskDispatcher@49c30481
    - Can run: null
  * Task Dispatcher: hudson.plugins.buildblocker.BuildBlockerQueueTaskDispatcher@189dd7e3
    - Can run: null
  * Task Dispatcher: jenkins.advancedqueue.RunExclusiveThrottler$RunExclusiveDispatcher@60616b0f
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@76528e1a
    - Can run: null
  * Task Dispatcher: org.jenkins.plugins.lockableresources.queue.LockableResourcesQueueTaskDispatcher@27e46b5d
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@5130828d
    - Can run: null
----

 * Name of item: CEP UI Autotest (TEST)
    - In queue for: 7 min 27 sec
    - Is blocked: true
    - Why in queue: Build #2,197 is already in progress (ETA: N/A)
    - Current queue trigger cause: Started by upstream project "dcx-cep-health-check-test" build number 2,015
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@cde9b44
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.dependency.DependencyQueueTaskDispatcher@2d077445
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.replication.ReplicationQueueTaskDispatcher@49c30481
    - Can run: null
  * Task Dispatcher: hudson.plugins.buildblocker.BuildBlockerQueueTaskDispatcher@189dd7e3
    - Can run: null
  * Task Dispatcher: jenkins.advancedqueue.RunExclusiveThrottler$RunExclusiveDispatcher@60616b0f
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@76528e1a
    - Can run: null
  * Task Dispatcher: org.jenkins.plugins.lockableresources.queue.LockableResourcesQueueTaskDispatcher@27e46b5d
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@5130828d
    - Can run: null
----

Is quieting down: false
