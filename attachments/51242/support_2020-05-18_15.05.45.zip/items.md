Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 1
    - Number of items per container: 4 [n=1]
  * `com.tikal.jenkins.plugins.multijob.MultiJobProject`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]
  * `hudson.matrix.MatrixProject`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]
    - Number of items per container: 1 [n=1]
  * `hudson.maven.MavenModule`
    - Number of items: 383
    - Number of builds per job: 27.4177545691906 [n=383, s=39.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 87
    - Number of builds per job: 36.264367816091955 [n=87, s=50.0]
    - Number of items per container: 4.402298850574713 [n=87, s=4.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 233
    - Number of builds per job: 43.44635193133047 [n=233, s=55.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 476
    - Number of builds per job: 20.596638655462186 [n=476, s=34.0]

Total job statistics
======================

  * Number of jobs: 1182
  * Number of builds per job: 28.412013536379018 [n=1182, s=42.36875285873092]
