Loggers currently enabled
=========================
org.apache.sshd - WARNING
com.cloudbees.jenkins.plugins.bitbucket.hooks - ALL
winstone - INFO
 - INFO
