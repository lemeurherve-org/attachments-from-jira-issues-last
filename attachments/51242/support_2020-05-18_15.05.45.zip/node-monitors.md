Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * HPE_LoadRunner: Windows Server 2016 (amd64)
   * HPE_LoadRunnerStaging: Windows Server 2019 (amd64)
   * Load runner: null
   * healthcheck-agent-01: Linux (amd64)
   * hp_lr_test: null
   * linux-agent-01: Linux (amd64)
   * linux-agent-02: Linux (amd64)
   * linux-agent-stg-ecommpim-deploy: Linux (amd64)
   * osx-agent-01: Mac OS X (x86_64)
   * prod_deploy: Linux (amd64)
   * windows-agent-01: Windows Server 2012 R2 (amd64)
   * windows-agent-02: Windows Server 2012 R2 (amd64)
   * windows-agent-03: Windows Server 2012 R2 (amd64)
   * windows-agent-modelling: Windows Server 2016 (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * HPE_LoadRunner: In sync
   * HPE_LoadRunnerStaging: In sync
   * Load runner: null
   * healthcheck-agent-01: In sync
   * hp_lr_test: null
   * linux-agent-01: In sync
   * linux-agent-02: In sync
   * linux-agent-stg-ecommpim-deploy: In sync
   * osx-agent-01: 49 sec ahead
   * prod_deploy: In sync
   * windows-agent-01: 1.1 sec ahead
   * windows-agent-02: 20 sec behind
   * windows-agent-03: 2.1 sec behind
   * windows-agent-modelling: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: 151.148GB left on /opt/jenkins.
   * HPE_LoadRunner: 134.740GB left on D:\jenkins.
   * HPE_LoadRunnerStaging: 135.487GB left on D:\jenkins2.
   * Load runner: null
   * healthcheck-agent-01: 109.103GB left on /app/jenkins.
   * hp_lr_test: null
   * linux-agent-01: 28.663GB left on /opt/jenkins.
   * linux-agent-02: 73.145GB left on /opt/jenkins.
   * linux-agent-stg-ecommpim-deploy: 20.798GB left on /home/jenkins.
   * osx-agent-01: 175.669GB left on /Users/devops/jenkins-agent/jenkins-agent.
   * prod_deploy: 115.932GB left on /opt/jenkins.
   * windows-agent-01: 251.523GB left on D:\Jenkins.
   * windows-agent-02: 164.894GB left on D:\Jenkins.
   * windows-agent-03: 225.135GB left on D:\Jenkins.
   * windows-agent-modelling: 160.746GB left on D:\Jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:315/16047MB  Swap:3903/3903MB
   * HPE_LoadRunner: Memory:8539/15615MB  Swap:9598/17919MB
   * HPE_LoadRunnerStaging: Memory:12938/15615MB  Swap:15247/17919MB
   * Load runner: null
   * healthcheck-agent-01: Memory:13173/16038MB  Swap:0/0MB
   * hp_lr_test: null
   * linux-agent-01: Memory:4575/15883MB  Swap:0/0MB
   * linux-agent-02: Memory:2004/15883MB  Swap:0/0MB
   * linux-agent-stg-ecommpim-deploy: Memory:6049/7896MB  Swap:0/0MB
   * osx-agent-01: Memory:0/0MB  Swap:0/0MB
   * prod_deploy: Memory:3221/7819MB  Swap:0/0MB
   * windows-agent-01: Memory:9087/16383MB  Swap:15870/24575MB
   * windows-agent-02: Memory:6556/16383MB  Swap:12905/24575MB
   * windows-agent-03: Memory:10274/16383MB  Swap:17722/25599MB
   * windows-agent-modelling: Memory:54022/64723MB  Swap:62848/73939MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: 3.549GB left on /tmp.
   * HPE_LoadRunner: 8.956GB left on C:\Users\jenkins\AppData\Local\Temp.
   * HPE_LoadRunnerStaging: 10.030GB left on C:\Windows\Temp.
   * Load runner: null
   * healthcheck-agent-01: 14.617GB left on /tmp.
   * hp_lr_test: null
   * linux-agent-01: 12.439GB left on /tmp.
   * linux-agent-02: 12.961GB left on /tmp.
   * linux-agent-stg-ecommpim-deploy: 20.798GB left on /tmp.
   * osx-agent-01: 175.669GB left on /private/var/folders/t0/wvql8q2j2h770620jjf108b80000gr/T.
   * prod_deploy: 14.141GB left on /tmp.
   * windows-agent-01: 31.037GB left on C:\Users\jenkins\AppData\Local\Temp.
   * windows-agent-02: 31.418GB left on C:\Users\jenkins\AppData\Local\Temp.
   * windows-agent-03: 10.275GB left on C:\Users\jenkins\AppData\Local\Temp.
   * windows-agent-modelling: 38.154GB left on C:\Users\jenkins\AppData\Local\Temp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * HPE_LoadRunner: 193ms
   * HPE_LoadRunnerStaging: 119ms
   * Load runner: null
   * healthcheck-agent-01: 119ms
   * hp_lr_test: null
   * linux-agent-01: 191ms
   * linux-agent-02: 119ms
   * linux-agent-stg-ecommpim-deploy: 119ms
   * osx-agent-01: 210ms
   * prod_deploy: 188ms
   * windows-agent-01: 117ms
   * windows-agent-02: 188ms
   * windows-agent-03: 117ms
   * windows-agent-modelling: 187ms
