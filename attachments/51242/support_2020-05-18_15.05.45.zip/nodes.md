Node statistics
===============

  * Total number of nodes
      - Sample size:        1004
      - Average (mean):     14.0
      - Average (median):   14.0
      - Standard deviation: 0.0
      - Minimum:            14
      - Maximum:            14
      - 95th percentile:    14.0
      - 99th percentile:    14.0
  * Total number of nodes online
      - Sample size:        1004
      - Average (mean):     12.0
      - Average (median):   12.0
      - Standard deviation: 1.8576948142884605E-46
      - Minimum:            1
      - Maximum:            12
      - 95th percentile:    12.0
      - 99th percentile:    12.0
  * Total number of executors
      - Sample size:        1004
      - Average (mean):     91.0
      - Average (median):   91.0
      - Standard deviation: 9.288059336106103E-46
      - Minimum:            4
      - Maximum:            91
      - 95th percentile:    91.0
      - 99th percentile:    91.0
  * Total number of executors in use
      - Sample size:        1004
      - Average (mean):     15.203800749334171
      - Average (median):   14.0
      - Standard deviation: 2.0835423843077665
      - Minimum:            0
      - Maximum:            24
      - 95th percentile:    18.0
      - 99th percentile:    18.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/var/lib/jenkins`
      - Labels:         master
      - Usage:          `NORMAL`
      - Slave Version:  4.2
      - Java
          + Home:           `/opt/jdk1.8.0_191/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;191
          + Maximum memory:   3.48 GB (3739746304)
          + Allocated memory: 2.93 GB (3145728000)
          + Free memory:      815.35 MB (854957816)
          + In-use memory:    2.13 GB (2290770184)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.191-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.0-178-generic
          + Distribution: Ubuntu 16.04 LTS
      - Process ID: 22786 (0x5902)
      - Process started: 2020-05-18 10:53:29.491+0000
      - Process uptime: 4 hr 12 min
      - JVM startup parameters:
          + Boot classpath: `/opt/jdk1.8.0_191/jre/lib/resources.jar:/opt/jdk1.8.0_191/jre/lib/rt.jar:/opt/jdk1.8.0_191/jre/lib/sunrsasign.jar:/opt/jdk1.8.0_191/jre/lib/jsse.jar:/opt/jdk1.8.0_191/jre/lib/jce.jar:/opt/jdk1.8.0_191/jre/lib/charsets.jar:/opt/jdk1.8.0_191/jre/lib/jfr.jar:/opt/jdk1.8.0_191/jre/classes:/opt/dynatrace/oneagent/agent/bin/1.191.217.20200514-103405/any/java/oneagentjava.jar:/opt/dynatrace/oneagent/agent/bin/1.191.217.20200514-103405/any/java/oneagentjava.rmi.jar:/opt/dynatrace/oneagent/agent/bin/1.191.217.20200514-103405/any/java/oneagentjava.sql.jar`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Dhudson.model.DirectoryBrowserSupport.CSP=default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self';`
          + arg[2]: `-agentpath:/opt/dynatrace/oneagent/agent/bin/1.191.217.20200514-103405/linux-x86-64/liboneagentloader.so=loglevelcon=none,tenant=lgf19795,tenanttoken=GLGr48a5N8dZ3QZX,server=https://10.85.65.163:9999/communication;https://ip-10-85-65-163.eu-west-1.compute.internal:9999/communication;https://sg-eu-west-1-34-248-26-181-prod13-ireland.live.ruxit.com/communication;https://sg-eu-west-1-54-77-219-214-prod13-ireland.live.ruxit.com/communication;https://sg-eu-west-1-52-19-113-184-prod13-ireland.live.ruxit.com/communication;https://sg-eu-west-1-52-31-60-170-prod13-ireland.live.ruxit.com/communication;https://sg-eu-west-1-34-242-17-158-prod13-ireland.live.ruxit.com/communication;https://lgf19795.live.dynatrace.com:443/communication`

  * `HPE_LoadRunner` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `D:\jenkins`
      - Labels:         hp&#95;loadrunner
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.25
      - Java
          + Home:           `D:\Program Files\Java\jdk1.8.0_201\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;201
          + Maximum memory:   3.39 GB (3639083008)
          + Allocated memory: 1.32 GB (1419247616)
          + Free memory:      915.20 MB (959661904)
          + In-use memory:    438.30 MB (459585712)
          + GC strategy:      ParallelGC
          + Available CPUs:   2
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.201-b09
      - Operating system
          + Name:         Windows Server 2016
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 96592 (0x17950)
      - Process started: 2020-05-18 11:45:26.124+0000
      - Process uptime: 3 hr 20 min
      - JVM startup parameters:
          + Boot classpath: `D:\Program Files\Java\jdk1.8.0_201\jre\lib\resources.jar;D:\Program Files\Java\jdk1.8.0_201\jre\lib\rt.jar;D:\Program Files\Java\jdk1.8.0_201\jre\lib\sunrsasign.jar;D:\Program Files\Java\jdk1.8.0_201\jre\lib\jsse.jar;D:\Program Files\Java\jdk1.8.0_201\jre\lib\jce.jar;D:\Program Files\Java\jdk1.8.0_201\jre\lib\charsets.jar;D:\Program Files\Java\jdk1.8.0_201\jre\lib\jfr.jar;D:\Program Files\Java\jdk1.8.0_201\jre\classes`
          + Classpath: `D:\Jenkins\slave.jar`
          + Library path: `D:\Program Files\Java\jdk1.8.0_201\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Windows\System32\OpenSSH\;C:\Program Files\Amazon\cfn-bootstrap\;D:\ProgramFiles\LoadRunner\bin;C:\Program Files\Git\cmd;C:\Program Files\Amazon\AWSCLI\bin\;C:\Users\jenkins\AppData\Local\Microsoft\WindowsApps;D:\Program Files\Java\jdk1.8.0_201\bin;C:\Users\jenkins\AppData\Local\Programs\Python\Python37;.`
          + arg[0]: `-Xrs`

  * `HPE_LoadRunnerStaging` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `D:\jenkins2`
      - Labels:         hp&#95;loadrunnerStaging
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.27
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_251`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;251
          + Maximum memory:   3.39 GB (3639083008)
          + Allocated memory: 228.50 MB (239599616)
          + Free memory:      176.66 MB (185240488)
          + In-use memory:    51.84 MB (54359128)
          + GC strategy:      ParallelGC
          + Available CPUs:   2
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.251-b08
      - Operating system
          + Name:         Windows Server 2019
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 5748 (0x1674)
      - Process started: 2020-05-18 11:45:25.889+0000
      - Process uptime: 3 hr 20 min
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_251\lib\resources.jar;C:\Program Files\Java\jre1.8.0_251\lib\rt.jar;C:\Program Files\Java\jre1.8.0_251\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_251\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_251\lib\jce.jar;C:\Program Files\Java\jre1.8.0_251\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_251\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_251\classes`
          + Classpath: `D:\jenkins2\slave.jar`
          + Library path: `C:\Program Files\Java\jre1.8.0_251\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Windows\System32\OpenSSH\;C:\Program Files\Amazon\cfn-bootstrap\;D:\ProgramFiles\LoadRunner\bin;C:\Program Files\Git\cmd;C:\Program Files\Amazon\AWSCLI\bin\;C:\Windows\system32\config\systemprofile\AppData\Local\Microsoft\WindowsApps;.`
          + arg[0]: `-Xrs`

  * `Load runner` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `C:\Jenkins`
      - Labels:         loadrunner
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `healthcheck-agent-01` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      20
      - Remote FS root: `/app/jenkins`
      - Labels:         healthcheck
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2
      - Java
          + Home:           `/usr/java/jdk1.8.0_181-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   3.48 GB (3737649152)
          + Allocated memory: 57.00 MB (59768832)
          + Free memory:      25.97 MB (27232232)
          + In-use memory:    31.03 MB (32536600)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.14.177-139.254.amzn2.x86&#95;64
          + Distribution: "Amazon Linux release 2 (Karoo)"
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch`
      - Process ID: 8089 (0x1f99)
      - Process started: 2020-05-18 10:54:58.081+0000
      - Process uptime: 4 hr 10 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_181-amd64/jre/lib/resources.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/rt.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jsse.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jce.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/charsets.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jfr.jar:/usr/java/jdk1.8.0_181-amd64/jre/classes`
          + Classpath: `/app/jenkins/agent.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * `hp_lr_test` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `C:\Jenkins`
      - Labels:         hp&#95;lr&#95;test
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `linux-agent-01` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      8
      - Remote FS root: `/var/jenkins`
      - Labels:         linux-agent
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;232
          + Maximum memory:   3.45 GB (3702521856)
          + Allocated memory: 333.00 MB (349175808)
          + Free memory:      88.63 MB (92933816)
          + In-use memory:    244.37 MB (256241992)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.232-b09
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-1062.9.1.el7.x86&#95;64
          + Distribution: "Red Hat Enterprise Linux Server release 7.7 (Maipo)"
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch`
      - Process ID: 25028 (0x61c4)
      - Process started: 2020-05-18 10:57:08.499+0000
      - Process uptime: 4 hr 8 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/classes`
          + Classpath: `/opt/jenkins/agent.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * `linux-agent-02` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      8
      - Remote FS root: `/var/jenkins`
      - Labels:         linux-agent
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;232
          + Maximum memory:   3.45 GB (3702521856)
          + Allocated memory: 101.50 MB (106430464)
          + Free memory:      47.49 MB (49794008)
          + In-use memory:    54.01 MB (56636456)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.232-b09
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-1062.9.1.el7.x86&#95;64
          + Distribution: "Red Hat Enterprise Linux Server release 7.7 (Maipo)"
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch`
      - Process ID: 32010 (0x7d0a)
      - Process started: 2020-05-18 10:56:49.387+0000
      - Process uptime: 4 hr 8 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64/jre/classes`
          + Classpath: `/opt/jenkins/agent.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * `linux-agent-stg-ecommpim-deploy` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      8
      - Remote FS root: `/home/jenkins`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.amzn2.0.1.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;252
          + Maximum memory:   1.72 GB (1841823744)
          + Allocated memory: 65.00 MB (68157440)
          + Free memory:      29.28 MB (30706592)
          + In-use memory:    35.72 MB (37450848)
          + GC strategy:      ParallelGC
          + Available CPUs:   2
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.252-b09
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.14.177-139.254.amzn2.x86&#95;64
      - Process ID: 4767 (0x129f)
      - Process started: 2020-05-18 10:54:48.058+0000
      - Process uptime: 4 hr 10 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.amzn2.0.1.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.amzn2.0.1.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.amzn2.0.1.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.amzn2.0.1.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.amzn2.0.1.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.amzn2.0.1.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.amzn2.0.1.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.amzn2.0.1.x86_64/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * `osx-agent-01` (`hudson.slaves.DumbSlave`)
      - Description:    _SalesApp IOS build node_
      - Executors:      4
      - Remote FS root: `/Users/devops/jenkins-agent/jenkins-agent`
      - Labels:         osx
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home/jre`
          + Vendor:           AdoptOpenJDK
          + Version:          1.8.0&#95;222
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 233.00 MB (244318208)
          + Free memory:      204.66 MB (214596864)
          + In-use memory:    28.34 MB (29721344)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  AdoptOpenJDK
          + Version: 25.222-b10
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86&#95;64
          + Version:      10.14.6
      - Process ID: 54980 (0xd6c4)
      - Process started: 2020-05-18 10:55:25.770+0000
      - Process uptime: 4 hr 11 min
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/Users/devops/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`

  * `prod_deploy` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      20
      - Remote FS root: `/var/jenkins`
      - Labels:         prod&#95;deployment
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;252
          + Maximum memory:   1.70 GB (1823473664)
          + Allocated memory: 63.50 MB (66584576)
          + Free memory:      20.96 MB (21983232)
          + In-use memory:    42.54 MB (44601344)
          + GC strategy:      ParallelGC
          + Available CPUs:   2
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.252-b09
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-1127.8.2.el7.x86&#95;64
          + Distribution: "Red Hat Enterprise Linux Server release 7.8 (Maipo)"
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch`
      - Process ID: 620 (0x26c)
      - Process started: 2020-05-18 10:54:58.107+0000
      - Process uptime: 4 hr 10 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64/jre/classes`
          + Classpath: `/var/jenkins/agent.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * `windows-agent-01` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `D:/Jenkins`
      - Labels:         windows-agent
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2
      - Java
          + Home:           `C:\Program Files\Java\jdk1.8.0_161\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;161
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 465.50 MB (488112128)
          + Free memory:      112.52 MB (117982888)
          + In-use memory:    352.98 MB (370129240)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.161-b12
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 6380 (0x18ec)
      - Process started: 2020-05-18 11:11:34.397+0000
      - Process uptime: 3 hr 54 min
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jdk1.8.0_161\jre\lib\resources.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\rt.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\sunrsasign.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\jsse.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\jce.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\charsets.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\jfr.jar;C:\Program Files\Java\jdk1.8.0_161\jre\classes`
          + Classpath: `d:\Jenkins\slave.jar`
          + Library path: `C:\Program Files\Java\jdk1.8.0_161\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Program Files\HPE_Security\Fortify_SCA_and_Apps_19.1.2\bin;C:\Program Files\Micro Focus\NV\lib\shunra\vcat;C:\Program Files\HPE_Security\Fortify_SCA_and_Apps_17.20\bin;D:\jq;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Amazon\cfn-bootstrap\;C:\Program Files\Java\jdk1.8.0_161\bin;C:\Program Files (x86)\Microsoft Visual Studio\2017\BuildTools\MSBuild\15.0\Bin;C:\apache-maven-3.5.3\bin;d:\Program Files (x86)\WinSCP\;C:\Program Files\dotnet\;d:\nuget_4.7.0;C:\Program Files (x86)\dotnet\;c:\Program Files\7-Zip;C:\Program Files\Amazon\AWSCLI\;d:\vtc;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Git\cmd;C:\Program Files\TortoiseGit\bin;D:\nodejs\;C:\Users\jenkins\.dotnet\tools;C:\Users\jenkins\AppData\Roaming\npm;.`
          + arg[0]: `-Xrs`

  * `windows-agent-02` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      6
      - Remote FS root: `D:/Jenkins`
      - Labels:         windows-agent
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2
      - Java
          + Home:           `C:\Program Files\Java\jdk1.8.0_161\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;161
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 1.08 GB (1161297920)
          + Free memory:      677.69 MB (710610528)
          + In-use memory:    429.81 MB (450687392)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.161-b12
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 15228 (0x3b7c)
      - Process started: 2020-05-18 10:44:07.447+0000
      - Process uptime: 4 hr 21 min
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jdk1.8.0_161\jre\lib\resources.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\rt.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\sunrsasign.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\jsse.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\jce.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\charsets.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\jfr.jar;C:\Program Files\Java\jdk1.8.0_161\jre\classes`
          + Classpath: `D:\Jenkins\slave.jar`
          + Library path: `C:\Program Files\Java\jdk1.8.0_161\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Program Files\HPE_Security\Fortify_SCA_and_Apps_19.1.2\bin;C:\Program Files\Micro Focus\NV\lib\shunra\vcat;C:\Program Files\HPE_Security\Fortify_SCA_and_Apps_17.20\bin;D:\jq;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Amazon\cfn-bootstrap\;C:\Program Files\Java\jdk1.8.0_161\bin;C:\Git\cmd;C:\Program Files (x86)\Microsoft Visual Studio\2017\BuildTools\MSBuild\15.0\Bin;C:\apache-maven-3.5.3\bin;C:\Program Files\dotnet\;d:\nuget_4.7.0;C:\Program Files (x86)\dotnet\;C:\Program Files\TortoiseGit\bin;c:\Program Files\7-Zip;C:\Program Files\Amazon\AWSCLI\;d:\vtc;c:\Users\jenkins\AppData\Roaming\npm\node_modules\@angular\cli\bin;c:\Users\jenkins\AppData\Roaming\npm;D:\nodejs\;C:\Users\jenkins\.dotnet\tools;c:\vtc;C:\Users\jenkins\AppData\Roaming\npm;.`
          + arg[0]: `-Xrs`

  * `windows-agent-03` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `D:\Jenkins`
      - Labels:         windows-agent-03
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.14
      - Java
          + Home:           `C:\Program Files\Java\jdk1.8.0_161\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;161
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 239.50 MB (251133952)
          + Free memory:      197.49 MB (207085472)
          + In-use memory:    42.01 MB (44048480)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.161-b12
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 11936 (0x2ea0)
      - Process started: 2020-05-18 10:54:56.558+0000
      - Process uptime: 4 hr 10 min
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jdk1.8.0_161\jre\lib\resources.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\rt.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\sunrsasign.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\jsse.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\jce.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\charsets.jar;C:\Program Files\Java\jdk1.8.0_161\jre\lib\jfr.jar;C:\Program Files\Java\jdk1.8.0_161\jre\classes`
          + Classpath: `D:\Jenkins\slave.jar`
          + Library path: `C:\Program Files\Java\jdk1.8.0_161\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Program Files\Micro Focus\NV\lib\shunra\vcat;C:\Program Files\HPE_Security\Fortify_SCA_and_Apps_17.20\bin;D:\jq;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Amazon\cfn-bootstrap\;C:\Program Files\Java\jdk1.8.0_161\bin;C:\Git\cmd;D:\Microsoft Visual Studio\2019\Community\MSBuild\Current\Bin;C:\apache-maven-3.5.3\bin;C:\Program Files\dotnet\;d:\nuget_4.7.0;C:\Program Files (x86)\dotnet\;C:\Program Files\TortoiseGit\bin;c:\Program Files\7-Zip;C:\Program Files\Amazon\AWSCLI\;d:\vtc;D:\sonarqubescanner;D:\curl\bin;C:\Program Files\OpenSSL-Win64\bin;C:\Program Files\nodejs\;C:\Program Files (x86)\PreEmptive Solutions\Dotfuscator Professional Edition 6.0.0\;C:\Program Files (x86)\Microsoft Visual Studio\2017\BuildTools\MSBuild\15.0\Bin;D:\nodejs\;C:\Users\jenkins\.dotnet\tools;c:\vtc;.`
          + arg[0]: `-Xrs`

  * `windows-agent-modelling` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `D:/Jenkins`
      - Labels:         cpq-modelling
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2
      - Java
          + Home:           `c:\Program Files\Java\jdk1.8.0_181\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   14.05 GB (15082717184)
          + Allocated memory: 459.00 MB (481296384)
          + Free memory:      272.85 MB (286102768)
          + In-use memory:    186.15 MB (195193616)
          + GC strategy:      ParallelGC
          + Available CPUs:   8
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Windows Server 2016
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 6184 (0x1828)
      - Process started: 2020-05-18 11:02:26.925+0000
      - Process uptime: 4 hr 3 min
      - JVM startup parameters:
          + Boot classpath: `c:\Program Files\Java\jdk1.8.0_181\jre\lib\resources.jar;c:\Program Files\Java\jdk1.8.0_181\jre\lib\rt.jar;c:\Program Files\Java\jdk1.8.0_181\jre\lib\sunrsasign.jar;c:\Program Files\Java\jdk1.8.0_181\jre\lib\jsse.jar;c:\Program Files\Java\jdk1.8.0_181\jre\lib\jce.jar;c:\Program Files\Java\jdk1.8.0_181\jre\lib\charsets.jar;c:\Program Files\Java\jdk1.8.0_181\jre\lib\jfr.jar;c:\Program Files\Java\jdk1.8.0_181\jre\classes`
          + Classpath: `D:\Jenkins\slave.jar`
          + Library path: `c:\Program Files\Java\jdk1.8.0_181\jre\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;c:\Program Files\Java\jdk1.8.0_181\bin;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Amazon\cfn-bootstrap\;d:\apache-maven-3.6.0\bin;c:\Program Files\7-Zip;C:\Git\cmd;d:\nuget_4.7.0\;C:\Program Files\dotnet\;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;c:\Program Files (x86)\Microsoft Visual Studio\2017\BuildTools\MSBuild\15.0\Bin\;d:\vtc;D:\nodejs\;C:\Program Files\Amazon\AWSCLI\bin\;C:\Program Files\PowerShell\7\;C:\Users\jenkins\AppData\Local\Microsoft\WindowsApps;.`
          + arg[0]: `-Xrs`

