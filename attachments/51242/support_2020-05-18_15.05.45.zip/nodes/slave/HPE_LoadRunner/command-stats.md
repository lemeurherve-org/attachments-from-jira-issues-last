# Totals
* Writes: 29113
  * sent 13.4Mb
* Reads: 30925
  * received 40.5Mb
* Responses: 633
  * waited 47 min

# Commands sent
* `Pipe.Chunk`: 577
  * sent 4.1Mb
* `ProxyOutputStream.Ack`: 26536
  * sent 4.1Mb
* `ProxyOutputStream.EOF`: 6
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 12
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 877
  * sent 2.5Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 13
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 22
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 5
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 68
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 12
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 4
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 296
  * sent 0.4Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 4
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 4
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 4
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 4
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Archive`: 8
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 34
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Delete`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Digest`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 38
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsUnix`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$ListFilter`: 11
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 11
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$RenameTo`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$WritePipe`: 6
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 4
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 2
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 2
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 272
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 26536
  * received 21.3Mb
* `Pipe.Flush`: 8
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 577
  * received 0.1Mb
* `ProxyOutputStream.EOF`: 57
  * received 0.1Mb
* `ProxyOutputStream.Unexport`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 877
  * received 0.5Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 13
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 22
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 5
  * received 0.0Mb
* `Response`: 632
  * received 14.7Mb
* `Unexport`: 2060
  * received 3.1Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 68
  * received 0.5Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 12
  * received 0.1Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 4
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 4
  * waited 0.17 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 4
  * waited 0.16 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 4
  * waited 45 min
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.2 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * waited 3.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 1.8 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 23 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.33 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.36 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 1.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 5.6 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.32 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 1.5 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 85 ms
* `UserRequest:hudson.FilePath$2`: 4
  * waited 0.3 sec
* `UserRequest:hudson.FilePath$Archive`: 8
  * waited 7.8 sec
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * waited 3.6 sec
* `UserRequest:hudson.FilePath$CopyTo`: 34
  * waited 1.7 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 2
  * waited 92 ms
* `UserRequest:hudson.FilePath$Delete`: 2
  * waited 87 ms
* `UserRequest:hudson.FilePath$DeleteRecursive`: 2
  * waited 1.2 sec
* `UserRequest:hudson.FilePath$Digest`: 2
  * waited 1.8 sec
* `UserRequest:hudson.FilePath$Exists`: 38
  * waited 8.2 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 5
  * waited 0.24 sec
* `UserRequest:hudson.FilePath$IsUnix`: 2
  * waited 0.1 sec
* `UserRequest:hudson.FilePath$ListFilter`: 11
  * waited 0.52 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 2
  * waited 0.15 sec
* `UserRequest:hudson.FilePath$Read`: 11
  * waited 0.96 sec
* `UserRequest:hudson.FilePath$RenameTo`: 2
  * waited 85 ms
* `UserRequest:hudson.FilePath$WritePipe`: 6
  * waited 1.4 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 4
  * waited 1.2 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 2
  * waited 18 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * waited 0.19 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * waited 1.2 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * waited 0.56 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * waited 1.3 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * waited 4.8 sec
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 2
  * waited 1 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.3 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * waited 0.61 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveInitializer`: 1
  * waited 58 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.29 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 2
  * waited 7.9 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * waited 0.19 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * waited 4.4 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * waited 0.2 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 272
  * waited 23 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * waited 0.2 sec
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * waited 0.58 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * waited 0.68 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 2
  * waited 0.56 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 2
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 4
  * waited 1.7 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * waited 0.75 sec

# JARs sent
* `support-core.jar`: 434579b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
* `envinject.jar`: 152990b
* `commons-beanutils-1.9.3.jar`: 246174b
* `stapler-jelly-1.258.jar`: 88175b
* `jcl-over-slf4j-1.7.26.jar`: 16461b
* `slf4j-api-1.7.26.jar`: 41139b
* `slf4j-jdk14-1.7.26.jar`: 8476b
* `winp-1.28.jar`: 224963b
* `junit.jar`: 440340b
* `dom4j-2.1.1.jar`: 323600b
