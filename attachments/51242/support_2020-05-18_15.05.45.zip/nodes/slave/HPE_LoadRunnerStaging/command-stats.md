# Totals
* Writes: 1573
  * sent 5.5Mb
* Reads: 2437
  * received 9.9Mb
* Responses: 495
  * waited 1 min 0 sec

# Commands sent
* `Pipe.Chunk`: 254
  * sent 2.1Mb
* `ProxyOutputStream.Ack`: 12
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 4
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 470
  * sent 1.5Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 4
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 10
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 2
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 4
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Unexport`: 218
  * sent 0.3Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Digest`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsUnix`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 2
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 271
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 12
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 254
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 7
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 470
  * received 0.3Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 4
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 10
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 2
  * received 0.0Mb
* `Response`: 495
  * received 7.5Mb
* `Unexport`: 1079
  * received 1.6Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * received 0.3Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 4
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb

# Responses received
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.22 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * waited 3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 1.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 0.98 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.8 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.38 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 1.5 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.37 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$2`: 5
  * waited 0.45 sec
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * waited 2.4 sec
* `UserRequest:hudson.FilePath$Digest`: 2
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$Exists`: 6
  * waited 6.2 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 5
  * waited 0.29 sec
* `UserRequest:hudson.FilePath$IsUnix`: 2
  * waited 0.13 sec
* `UserRequest:hudson.FilePath$Read`: 2
  * waited 0.19 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * waited 0.45 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * waited 1.5 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * waited 0.5 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * waited 1.3 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * waited 4.4 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.3 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * waited 0.36 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.29 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * waited 0.18 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * waited 2.9 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * waited 0.18 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 271
  * waited 18 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * waited 0.7 sec
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * waited 0.49 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * waited 0.79 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 2
  * waited 0.44 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 2
  * waited 1.1 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * waited 0.48 sec

# JARs sent
* `support-core.jar`: 434579b
* `envinject.jar`: 152990b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
