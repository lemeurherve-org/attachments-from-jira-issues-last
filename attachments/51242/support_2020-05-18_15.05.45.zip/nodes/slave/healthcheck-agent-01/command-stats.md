# Totals
* Writes: 277812
  * sent 631.2Mb
* Reads: 643047
  * received 2086.0Mb
* Responses: 127328
  * waited 2 hr 7 min

# Commands sent
* `GC`: 12
  * sent 0.0Mb
* `Pipe.Chunk`: 821
  * sent 6.8Mb
* `ProxyInputStream.EOF`: 5934
  * sent 12.8Mb
* `ProxyOutputStream.Ack`: 121253
  * sent 18.7Mb
* `ProxyOutputStream.Dead`: 3
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 12
  * sent 0.0Mb
* `ProxyWriter.Ack`: 2848
  * sent 0.4Mb
* `Request.Cancel`: 3
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 961
  * sent 2.6Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 15
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 17
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 53
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 12
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 792
  * sent 1.6Mb
* `Response:UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 2547
  * sent 4.9Mb
* `Unexport`: 15145
  * sent 28.4Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 2970
  * sent 37.1Mb
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 2547
  * sent 15.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 1729
  * sent 11.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.clean[boolean]`: 133
  * sent 0.8Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 1729
  * sent 9.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 236
  * sent 1.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 3452
  * sent 19.9Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 1729
  * sent 9.7Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 1729
  * sent 9.7Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 1726
  * sent 10.7Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 220
  * sent 0.8Mb
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 2967
  * sent 9.2Mb
* `UserRequest:hudson.FilePath$Exists`: 1274
  * sent 3.9Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 18578
  * sent 55.1Mb
* `UserRequest:hudson.FilePath$LastModified`: 70
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 7669
  * sent 45.3Mb
* `UserRequest:hudson.FilePath$Read`: 718
  * sent 2.3Mb
* `UserRequest:hudson.FilePath$Write`: 3086
  * sent 22.9Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 2970
  * sent 37.1Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 1618
  * sent 4.5Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:jenkins.plugins.http_request.HttpRequestExecution`: 867
  * sent 3.9Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 274
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 2970
  * sent 19.1Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$1`: 865
  * sent 3.2Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 17855
  * sent 58.1Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 20818
  * sent 58.2Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 20818
  * sent 67.1Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 1729
  * sent 12.4Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 3691
  * sent 24.6Mb

# Commands received
* `GC`: 34
  * received 0.1Mb
* `Pipe.Chunk`: 121253
  * received 846.5Mb
* `Pipe.Flush`: 20910
  * received 3.6Mb
* `ProxyOutputStream.Ack`: 821
  * received 0.1Mb
* `ProxyOutputStream.EOF`: 1003
  * received 2.1Mb
* `ProxyOutputStream.Unexport`: 26344
  * received 34.5Mb
* `ProxyWriter.Chunk`: 2848
  * received 6.2Mb
* `ProxyWriter.EOF`: 236
  * received 0.5Mb
* `ProxyWriter.Flush`: 236
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 961
  * received 0.6Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 17
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * received 0.0Mb
* `Response`: 127328
  * received 246.9Mb
* `Unexport`: 337581
  * received 506.7Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 53
  * received 0.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 12
  * received 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 792
  * received 2.0Mb
* `UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 2547
  * received 435.7Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 2970
  * waited 2 min 11 sec
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 2547
  * waited 1 min 53 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 1729
  * waited 1 min 20 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.clean[boolean]`: 133
  * waited 8.9 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 1729
  * waited 1 min 29 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 236
  * waited 11 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 3452
  * waited 2 min 57 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 1729
  * waited 1 min 17 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 1729
  * waited 1 min 28 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 1726
  * waited 1 min 25 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.26 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.5 sec
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * waited 0.88 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 0.97 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.8 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.31 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * waited 0.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 0.28 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 0.55 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 0.75 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * waited 0.46 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.27 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 0.99 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * waited 0.44 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 83 ms
* `UserRequest:hudson.FilePath$2`: 5
  * waited 0.23 sec
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * waited 2 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 220
  * waited 4 min 27 sec
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * waited 2.6 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 2967
  * waited 2 min 9 sec
* `UserRequest:hudson.FilePath$Exists`: 1274
  * waited 57 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 18578
  * waited 13 min
* `UserRequest:hudson.FilePath$LastModified`: 70
  * waited 2.9 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 7669
  * waited 5 min 44 sec
* `UserRequest:hudson.FilePath$Read`: 718
  * waited 32 sec
* `UserRequest:hudson.FilePath$Write`: 3086
  * waited 2 min 14 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 2970
  * waited 2 min 18 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 1618
  * waited 10 min
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 0.23 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * waited 0.72 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * waited 0.45 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * waited 0.89 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * waited 1.1 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.3 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.18 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.35 sec
* `UserRequest:jenkins.plugins.http_request.HttpRequestExecution`: 867
  * waited 5 min 52 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 91 ms
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 2.9 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 99 ms
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 274
  * waited 47 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 94 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.32 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 0.28 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 2970
  * waited 2 min 9 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$1`: 865
  * waited 37 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 17855
  * waited 12 min
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 20818
  * waited 14 min
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 20818
  * waited 14 min
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * waited 0.54 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 0.17 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 1729
  * waited 1 min 35 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 3691
  * waited 16 min

# JARs sent
* `support-core.jar`: 434579b
* `envinject.jar`: 152990b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
* `git-client.jar`: 218600b
* `credentials.jar`: 619610b
* `org.eclipse.jgit-5.6.1.202002131546-r.jar`: 2839536b
* `ssh-credentials.jar`: 65368b
* `git.jar`: 655623b
* `http_request.jar`: 69045b
* `httpmime-4.5.10.jar`: 41792b
* `credentials-binding.jar`: 102820b
