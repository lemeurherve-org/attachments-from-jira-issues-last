# Totals
* Writes: 591266
  * sent 185.4Mb
* Reads: 631409
  * received 511.8Mb
* Responses: 14420
  * waited 2 hr 4 min

# Commands sent
* `GC`: 1
  * sent 0.0Mb
* `Pipe.Chunk`: 7575
  * sent 37.7Mb
* `Pipe.Connect`: 1
  * sent 0.0Mb
* `Pipe.Flush`: 1882
  * sent 0.3Mb
* `ProxyInputStream.EOF`: 50
  * sent 0.1Mb
* `ProxyOutputStream.Ack`: 563063
  * sent 86.7Mb
* `ProxyOutputStream.EOF`: 4
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 63
  * sent 0.1Mb
* `ProxyWriter.Ack`: 85
  * sent 0.0Mb
* `Request.Cancel`: 2
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 2375
  * sent 6.4Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 48
  * sent 0.4Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 68
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 9
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 150
  * sent 0.3Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 63
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 85
  * sent 0.2Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 5
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 12
  * sent 0.0Mb
* `Unexport`: 1252
  * sent 2.2Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 111
  * sent 0.8Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 85
  * sent 0.4Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 85
  * sent 0.4Mb
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.accept[]`: 1
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.getPort[]`: 1
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 12
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 138
  * sent 0.9Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.clean[boolean]`: 3
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.getWorkTree[]`: 2
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 113
  * sent 0.6Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 107
  * sent 0.6Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 220
  * sent 1.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 139
  * sent 0.8Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 112
  * sent 0.6Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tagExists[java.lang.String]`: 26
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tag[java.lang.String,java.lang.String]`: 26
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 112
  * sent 0.7Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 4
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Absolutize`: 4
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Archive`: 4
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 64
  * sent 0.8Mb
* `UserRequest:hudson.FilePath$Delete`: 64
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 63
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Digest`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 2146
  * sent 6.5Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 2109
  * sent 6.2Mb
* `UserRequest:hudson.FilePath$LastModified`: 64
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$ListGlob`: 4
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 252
  * sent 0.9Mb
* `UserRequest:hudson.FilePath$Read`: 12
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$ReadToString`: 152
  * sent 0.6Mb
* `UserRequest:hudson.FilePath$RenameTo`: 37
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$ValidateAntFileMask`: 10
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Write`: 25
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$WritePipe`: 3
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 111
  * sent 0.8Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 115
  * sent 0.3Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * sent 0.0Mb
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetCharset`: 1
  * sent 0.0Mb
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetRemotingJar`: 1
  * sent 0.0Mb
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$SocketHandler`: 1
  * sent 0.0Mb
* `UserRequest:hudson.maven.Maven3ProcessFactory$GetClassWorldsJar`: 1
  * sent 0.0Mb
* `UserRequest:hudson.maven.MavenBuild$CanonicalPath`: 8
  * sent 0.0Mb
* `UserRequest:hudson.maven.MavenModuleSetBuild$PomParser`: 1
  * sent 0.0Mb
* `UserRequest:hudson.maven.MavenVersionCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 66
  * sent 0.2Mb
* `UserRequest:hudson.plugins.ws_cleanup.Cleanup`: 27
  * sent 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Ant$AntInstallation$GetExecutable`: 20
  * sent 0.1Mb
* `UserRequest:hudson.tasks.Maven$MavenInstallation$GetExecutable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 64
  * sent 0.2Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 8
  * sent 0.0Mb
* `UserRequest:jenkins.plugins.http_request.HttpRequestExecution`: 51
  * sent 0.2Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 273
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 25
  * sent 0.2Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 2094
  * sent 6.8Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 2117
  * sent 5.9Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 2117
  * sent 6.8Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 63
  * sent 0.2Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 65
  * sent 0.2Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 22
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 139
  * sent 0.8Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 411
  * sent 2.7Mb
* `UserRequest:sp.sd.nexusartifactuploader.NexusArtifactUploader$1`: 6
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 563063
  * received 405.6Mb
* `Pipe.Flush`: 1133
  * received 0.2Mb
* `ProxyOutputStream.Ack`: 7575
  * received 1.2Mb
* `ProxyOutputStream.EOF`: 84
  * received 0.2Mb
* `ProxyOutputStream.Unexport`: 2495
  * received 3.3Mb
* `ProxyWriter.Chunk`: 85
  * received 0.2Mb
* `ProxyWriter.EOF`: 107
  * received 0.2Mb
* `ProxyWriter.Flush`: 107
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 2375
  * received 1.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 48
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 68
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 9
  * received 0.0Mb
* `Response`: 14420
  * received 36.2Mb
* `Unexport`: 39472
  * received 59.2Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 150
  * received 1.2Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 63
  * received 0.3Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 85
  * received 0.2Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 5
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 12
  * received 2.3Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 111
  * waited 4.6 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 85
  * waited 3.5 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 85
  * waited 1 hr 31 min
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.accept[]`: 1
  * waited 90 ms
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.getPort[]`: 1
  * waited 39 ms
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 12
  * waited 0.58 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 138
  * waited 9.1 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.clean[boolean]`: 3
  * waited 23 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.getWorkTree[]`: 2
  * waited 86 ms
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 113
  * waited 5.5 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 107
  * waited 5.5 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 220
  * waited 10 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 139
  * waited 6.2 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 112
  * waited 5.9 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tagExists[java.lang.String]`: 26
  * waited 1.2 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tag[java.lang.String,java.lang.String]`: 26
  * waited 1.2 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 112
  * waited 10 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.21 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * waited 2.8 sec
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * waited 1.6 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 1.9 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.74 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * waited 0.46 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 0.31 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 0.8 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 1.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * waited 0.47 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 1.2 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * waited 0.45 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 94 ms
* `UserRequest:hudson.FilePath$2`: 4
  * waited 0.23 sec
* `UserRequest:hudson.FilePath$Absolutize`: 4
  * waited 0.16 sec
* `UserRequest:hudson.FilePath$Archive`: 4
  * waited 1 min 44 sec
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * waited 3.5 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 3
  * waited 4.7 sec
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * waited 2.5 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 64
  * waited 3.5 sec
* `UserRequest:hudson.FilePath$Delete`: 64
  * waited 2.6 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 63
  * waited 29 sec
* `UserRequest:hudson.FilePath$Digest`: 3
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$Exists`: 2146
  * waited 1 min 37 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 2109
  * waited 1 min 42 sec
* `UserRequest:hudson.FilePath$LastModified`: 64
  * waited 2.6 sec
* `UserRequest:hudson.FilePath$ListGlob`: 4
  * waited 3.1 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 252
  * waited 11 sec
* `UserRequest:hudson.FilePath$Read`: 12
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$ReadToString`: 152
  * waited 6.5 sec
* `UserRequest:hudson.FilePath$RenameTo`: 37
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$ValidateAntFileMask`: 10
  * waited 0.9 sec
* `UserRequest:hudson.FilePath$Write`: 25
  * waited 1 sec
* `UserRequest:hudson.FilePath$WritePipe`: 3
  * waited 0.11 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 111
  * waited 6.3 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 115
  * waited 12 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * waited 0.44 sec
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetCharset`: 1
  * waited 89 ms
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetRemotingJar`: 1
  * waited 43 ms
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$SocketHandler`: 1
  * waited 0.52 sec
* `UserRequest:hudson.maven.Maven3ProcessFactory$GetClassWorldsJar`: 1
  * waited 0.12 sec
* `UserRequest:hudson.maven.MavenBuild$CanonicalPath`: 8
  * waited 0.38 sec
* `UserRequest:hudson.maven.MavenModuleSetBuild$PomParser`: 1
  * waited 45 sec
* `UserRequest:hudson.maven.MavenVersionCallable`: 1
  * waited 2 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * waited 1.1 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * waited 0.5 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * waited 1.4 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * waited 1.9 sec
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 66
  * waited 46 sec
* `UserRequest:hudson.plugins.ws_cleanup.Cleanup`: 27
  * waited 2 min 34 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.2 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * waited 0.38 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.25 sec
* `UserRequest:hudson.tasks.Ant$AntInstallation$GetExecutable`: 20
  * waited 1.2 sec
* `UserRequest:hudson.tasks.Maven$MavenInstallation$GetExecutable`: 1
  * waited 85 ms
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 64
  * waited 2.7 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 8
  * waited 22 sec
* `UserRequest:jenkins.plugins.http_request.HttpRequestExecution`: 51
  * waited 15 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * waited 0.18 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * waited 5.8 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * waited 0.19 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 273
  * waited 1 min 31 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * waited 0.2 sec
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * waited 0.59 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * waited 0.58 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 25
  * waited 1.3 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 2094
  * waited 1 min 38 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 2117
  * waited 1 min 38 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 2117
  * waited 1 min 41 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 63
  * waited 2.6 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 65
  * waited 3.7 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * waited 0.28 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 22
  * waited 1.2 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 139
  * waited 16 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 411
  * waited 11 min
* `UserRequest:sp.sd.nexusartifactuploader.NexusArtifactUploader$1`: 6
  * waited 1 min 5 sec

# JARs sent
* `support-core.jar`: 434579b
* `envinject.jar`: 152990b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
* `git-client.jar`: 218600b
* `credentials.jar`: 619610b
* `org.eclipse.jgit-5.6.1.202002131546-r.jar`: 2839536b
* `ssh-credentials.jar`: 65368b
* `git.jar`: 655623b
* `http_request.jar`: 69045b
* `httpmime-4.5.10.jar`: 41792b
* `httpcore-4.4.12.jar`: 328347b
* `httpclient-4.5.10.jar`: 774640b
* `maven-plugin.jar`: 10249910b
* `lib-jenkins-maven-embedder-3.15.jar`: 25685b
* `plexus-classworlds-2.6.0.jar`: 52873b
* `maven-resolver-api-1.1.1.jar`: 146201b
* `maven-core-3.5.4.jar`: 630101b
* `maven-artifact-3.5.4.jar`: 54893b
* `maven-settings-builder-3.5.4.jar`: 43145b
* `maven-plugin-api-3.5.4.jar`: 47639b
* `maven-embedder-3.5.4.jar`: 98372b
* `wagon-file-3.3.2.jar`: 11565b
* `maven32-interceptor-1.13.jar`: 20161b
* `plexus-cipher-1.8.jar`: 13614b
* `maven31-interceptor-1.13.jar`: 19802b
* `maven-model-builder-3.5.4.jar`: 177426b
* `wagon-http-3.3.2.jar`: 11407b
* `maven3-interceptor-1.13.jar`: 15152b
* `maven33-interceptor-1.13.jar`: 20823b
* `maven35-interceptor-1.13.jar`: 21140b
* `wagon-ssh-common-3.3.2.jar`: 26682b
* `maven-compat-3.5.4.jar`: 290368b
* `plexus-sec-dispatcher-1.4.jar`: 27703b
* `wagon-ssh-external-3.3.2.jar`: 15396b
* `wagon-webdav-jackrabbit-3.3.2.jar`: 20721b
* `wagon-ftp-3.3.2.jar`: 18819b
* `wagon-ssh-3.3.2.jar`: 32080b
* `maven-interceptor-1.13.jar`: 22676b
* `maven-resolver-transport-wagon-1.1.1.jar`: 30919b
* `plexus-utils-3.1.0.jar`: 261617b
* `wagon-provider-api-3.3.2.jar`: 55886b
* `maven3-interceptor-commons-1.13.jar`: 6837b
* `jsch-0.1.55.jar`: 282591b
* `maven-resolver-impl-1.1.1.jar`: 184592b
* `maven-resolver-connector-basic-1.1.1.jar`: 42804b
* `maven-resolver-provider-3.5.4.jar`: 67004b
* `maven-resolver-spi-1.1.1.jar`: 35811b
* `maven-repository-metadata-3.5.4.jar`: 27457b
* `maven-model-3.5.4.jar`: 164976b
* `wagon-http-shared-3.3.2.jar`: 38426b
* `jackrabbit-webdav-2.14.4.jar`: 364983b
* `plexus-interpolation-1.24.jar`: 78876b
* `maven-builder-support-3.5.4.jar`: 14781b
* `maven-settings-3.5.4.jar`: 44566b
* `commons-net-3.6.jar`: 307410b
* `commons-cli-1.4.jar`: 53820b
* `maven-resolver-util-1.1.1.jar`: 158902b
* `commons-lang3-3.7.jar`: 499634b
* `credentials-binding.jar`: 102820b
* `ant.jar`: 97757b
* `junit.jar`: 440340b
* `nexus-artifact-uploader.jar`: 48030b
