# Totals
* Writes: 44272
  * sent 72.0Mb
* Reads: 58777
  * received 100.3Mb
* Responses: 6317
  * waited 20 min

# Commands sent
* `Pipe.Chunk`: 7890
  * sent 37.9Mb
* `Pipe.Connect`: 2
  * sent 0.0Mb
* `Pipe.Flush`: 2275
  * sent 0.4Mb
* `ProxyInputStream.EOF`: 40
  * sent 0.1Mb
* `ProxyOutputStream.Ack`: 24286
  * sent 3.7Mb
* `ProxyOutputStream.EOF`: 5
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 58
  * sent 0.1Mb
* `ProxyWriter.Ack`: 191
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 1914
  * sent 5.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 39
  * sent 0.3Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 63
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 8
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 126
  * sent 0.2Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 58
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 50
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 2
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 6
  * sent 0.0Mb
* `Unexport`: 889
  * sent 1.5Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 72
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 50
  * sent 0.3Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 50
  * sent 0.3Mb
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.accept[]`: 2
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.getPort[]`: 2
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 6
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 64
  * sent 0.4Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.clean[boolean]`: 2
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.getWorkTree[]`: 1
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 42
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 38
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 84
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 64
  * sent 0.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 42
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tagExists[java.lang.String]`: 22
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tag[java.lang.String,java.lang.String]`: 22
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 42
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 41
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Delete`: 41
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 49
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Digest`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 2186
  * sent 6.6Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 450
  * sent 1.3Mb
* `UserRequest:hudson.FilePath$LastModified`: 61
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 143
  * sent 0.6Mb
* `UserRequest:hudson.FilePath$Read`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$ReadToString`: 131
  * sent 0.5Mb
* `UserRequest:hudson.FilePath$RenameTo`: 28
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Write`: 20
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$WritePipe`: 3
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 72
  * sent 0.6Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 42
  * sent 0.1Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * sent 0.0Mb
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetCharset`: 2
  * sent 0.0Mb
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetRemotingJar`: 2
  * sent 0.0Mb
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$SocketHandler`: 2
  * sent 0.0Mb
* `UserRequest:hudson.maven.Maven3ProcessFactory$GetClassWorldsJar`: 2
  * sent 0.0Mb
* `UserRequest:hudson.maven.MavenBuild$CanonicalPath`: 16
  * sent 0.0Mb
* `UserRequest:hudson.maven.MavenModuleSetBuild$PomParser`: 2
  * sent 0.0Mb
* `UserRequest:hudson.maven.MavenVersionCallable`: 2
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 45
  * sent 0.1Mb
* `UserRequest:hudson.plugins.ws_cleanup.Cleanup`: 8
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Maven$MavenInstallation$GetExecutable`: 9
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 41
  * sent 0.1Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 273
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 20
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 445
  * sent 1.5Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 465
  * sent 1.3Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 465
  * sent 1.5Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 39
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 41
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 14
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 64
  * sent 0.4Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 178
  * sent 1.2Mb

# Commands received
* `Pipe.Chunk`: 24286
  * received 52.1Mb
* `Pipe.Flush`: 183
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 7890
  * received 1.2Mb
* `ProxyOutputStream.EOF`: 71
  * received 0.1Mb
* `ProxyOutputStream.Unexport`: 563
  * received 0.7Mb
* `ProxyWriter.Chunk`: 191
  * received 0.4Mb
* `ProxyWriter.EOF`: 38
  * received 0.1Mb
* `ProxyWriter.Flush`: 38
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 1914
  * received 1.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 39
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 63
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 8
  * received 0.0Mb
* `Response`: 6317
  * received 16.5Mb
* `Unexport`: 16881
  * received 25.3Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 126
  * received 1.0Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 58
  * received 0.3Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 50
  * received 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 2
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 6
  * received 1.1Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 72
  * waited 4.5 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 50
  * waited 2 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 50
  * waited 8 min 7 sec
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.accept[]`: 2
  * waited 0.18 sec
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.getPort[]`: 2
  * waited 77 ms
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 6
  * waited 0.29 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 64
  * waited 5.5 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.clean[boolean]`: 2
  * waited 1.1 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.getWorkTree[]`: 1
  * waited 51 ms
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 42
  * waited 2 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 38
  * waited 1.7 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 84
  * waited 3.9 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 64
  * waited 2.8 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 42
  * waited 2 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tagExists[java.lang.String]`: 22
  * waited 0.97 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tag[java.lang.String,java.lang.String]`: 22
  * waited 1 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 42
  * waited 6.7 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.2 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * waited 3 sec
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * waited 1.5 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 1.9 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 0.54 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.72 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.29 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * waited 0.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 0.29 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 0.79 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 0.76 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * waited 0.38 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.28 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 0.94 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * waited 0.44 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 77 ms
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * waited 3.5 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 6
  * waited 13 sec
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * waited 2.5 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 41
  * waited 2.1 sec
* `UserRequest:hudson.FilePath$Delete`: 41
  * waited 1.6 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 49
  * waited 6.3 sec
* `UserRequest:hudson.FilePath$Digest`: 6
  * waited 0.29 sec
* `UserRequest:hudson.FilePath$Exists`: 2186
  * waited 1 min 37 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 450
  * waited 22 sec
* `UserRequest:hudson.FilePath$LastModified`: 61
  * waited 2.4 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 143
  * waited 6.5 sec
* `UserRequest:hudson.FilePath$Read`: 3
  * waited 0.49 sec
* `UserRequest:hudson.FilePath$ReadToString`: 131
  * waited 5.6 sec
* `UserRequest:hudson.FilePath$RenameTo`: 28
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$Write`: 20
  * waited 0.83 sec
* `UserRequest:hudson.FilePath$WritePipe`: 3
  * waited 0.12 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 72
  * waited 3.7 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 42
  * waited 7.5 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * waited 0.46 sec
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetCharset`: 2
  * waited 0.12 sec
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetRemotingJar`: 2
  * waited 92 ms
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$SocketHandler`: 2
  * waited 0.41 sec
* `UserRequest:hudson.maven.Maven3ProcessFactory$GetClassWorldsJar`: 2
  * waited 0.15 sec
* `UserRequest:hudson.maven.MavenBuild$CanonicalPath`: 16
  * waited 0.67 sec
* `UserRequest:hudson.maven.MavenModuleSetBuild$PomParser`: 2
  * waited 45 sec
* `UserRequest:hudson.maven.MavenVersionCallable`: 2
  * waited 1.9 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * waited 1 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * waited 0.56 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * waited 1.3 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * waited 1.9 sec
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 45
  * waited 7.2 sec
* `UserRequest:hudson.plugins.ws_cleanup.Cleanup`: 8
  * waited 4.2 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.2 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * waited 0.37 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.23 sec
* `UserRequest:hudson.tasks.Maven$MavenInstallation$GetExecutable`: 9
  * waited 0.4 sec
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 41
  * waited 1.8 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * waited 0.17 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * waited 5.7 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * waited 0.18 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 273
  * waited 1 min 27 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * waited 0.27 sec
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * waited 0.73 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * waited 0.62 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 20
  * waited 1.1 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 445
  * waited 21 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 465
  * waited 21 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 465
  * waited 23 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 39
  * waited 1.6 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 41
  * waited 2.5 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * waited 0.36 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 14
  * waited 0.88 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 64
  * waited 11 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 178
  * waited 4 min 13 sec

# JARs sent
* `support-core.jar`: 434579b
* `envinject.jar`: 152990b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
* `git-client.jar`: 218600b
* `credentials.jar`: 619610b
* `org.eclipse.jgit-5.6.1.202002131546-r.jar`: 2839536b
* `ssh-credentials.jar`: 65368b
* `git.jar`: 655623b
* `maven-plugin.jar`: 10249910b
* `lib-jenkins-maven-embedder-3.15.jar`: 25685b
* `plexus-classworlds-2.6.0.jar`: 52873b
* `maven-resolver-api-1.1.1.jar`: 146201b
* `maven-core-3.5.4.jar`: 630101b
* `maven-artifact-3.5.4.jar`: 54893b
* `maven-settings-builder-3.5.4.jar`: 43145b
* `maven-plugin-api-3.5.4.jar`: 47639b
* `maven-embedder-3.5.4.jar`: 98372b
* `wagon-file-3.3.2.jar`: 11565b
* `maven32-interceptor-1.13.jar`: 20161b
* `plexus-cipher-1.8.jar`: 13614b
* `maven31-interceptor-1.13.jar`: 19802b
* `maven-model-builder-3.5.4.jar`: 177426b
* `wagon-http-3.3.2.jar`: 11407b
* `maven3-interceptor-1.13.jar`: 15152b
* `maven33-interceptor-1.13.jar`: 20823b
* `maven35-interceptor-1.13.jar`: 21140b
* `wagon-ssh-common-3.3.2.jar`: 26682b
* `maven-compat-3.5.4.jar`: 290368b
* `plexus-sec-dispatcher-1.4.jar`: 27703b
* `wagon-ssh-external-3.3.2.jar`: 15396b
* `wagon-webdav-jackrabbit-3.3.2.jar`: 20721b
* `wagon-ftp-3.3.2.jar`: 18819b
* `wagon-ssh-3.3.2.jar`: 32080b
* `maven-interceptor-1.13.jar`: 22676b
* `maven-resolver-transport-wagon-1.1.1.jar`: 30919b
* `plexus-utils-3.1.0.jar`: 261617b
* `wagon-provider-api-3.3.2.jar`: 55886b
* `maven3-interceptor-commons-1.13.jar`: 6837b
* `jsch-0.1.55.jar`: 282591b
* `maven-resolver-impl-1.1.1.jar`: 184592b
* `maven-resolver-connector-basic-1.1.1.jar`: 42804b
* `maven-resolver-provider-3.5.4.jar`: 67004b
* `maven-resolver-spi-1.1.1.jar`: 35811b
* `wagon-http-shared-3.3.2.jar`: 38426b
* `httpcore-4.4.12.jar`: 328347b
* `httpclient-4.5.10.jar`: 774640b
* `jackrabbit-webdav-2.14.4.jar`: 364983b
* `maven-model-3.5.4.jar`: 164976b
* `commons-net-3.6.jar`: 307410b
* `maven-settings-3.5.4.jar`: 44566b
* `maven-repository-metadata-3.5.4.jar`: 27457b
* `commons-cli-1.4.jar`: 53820b
* `maven-builder-support-3.5.4.jar`: 14781b
* `plexus-interpolation-1.24.jar`: 78876b
* `maven-resolver-util-1.1.1.jar`: 158902b
* `commons-lang3-3.7.jar`: 499634b
* `credentials-binding.jar`: 102820b
