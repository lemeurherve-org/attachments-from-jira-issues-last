# Totals
* Writes: 66372
  * sent 139.2Mb
* Reads: 133017
  * received 425.5Mb
* Responses: 23486
  * waited 19 min

# Commands sent
* `GC`: 2
  * sent 0.0Mb
* `Pipe.Chunk`: 3929
  * sent 32.8Mb
* `ProxyInputStream.EOF`: 1132
  * sent 2.4Mb
* `ProxyOutputStream.Ack`: 34700
  * sent 5.3Mb
* `ProxyOutputStream.Unexport`: 51
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 746
  * sent 2.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 57
  * sent 0.3Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 40
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 51
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 2107
  * sent 3.8Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 567
  * sent 7.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 63
  * sent 0.4Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 63
  * sent 0.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 126
  * sent 0.7Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 63
  * sent 0.4Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 63
  * sent 0.4Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 63
  * sent 0.4Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 63
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 566
  * sent 1.8Mb
* `UserRequest:hudson.FilePath$Exists`: 229
  * sent 0.7Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 4188
  * sent 12.5Mb
* `UserRequest:hudson.FilePath$LastModified`: 61
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 1197
  * sent 7.8Mb
* `UserRequest:hudson.FilePath$Read`: 103
  * sent 0.3Mb
* `UserRequest:hudson.FilePath$Write`: 567
  * sent 3.8Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 567
  * sent 6.5Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 62
  * sent 0.2Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 11
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 11
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 11
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 11
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 276
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 567
  * sent 3.6Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$1`: 63
  * sent 0.2Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 4120
  * sent 13.5Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 4684
  * sent 13.1Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 4684
  * sent 15.2Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 63
  * sent 0.4Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 126
  * sent 0.8Mb

# Commands received
* `Pipe.Chunk`: 34700
  * received 276.1Mb
* `Pipe.Flush`: 817
  * received 0.1Mb
* `ProxyOutputStream.Ack`: 4034
  * received 0.6Mb
* `ProxyOutputStream.EOF`: 226
  * received 0.5Mb
* `ProxyOutputStream.Unexport`: 5251
  * received 6.9Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 746
  * received 0.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 57
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * received 0.0Mb
* `Response`: 23486
  * received 44.8Mb
* `Unexport`: 63539
  * received 95.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 40
  * received 0.3Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 50
  * received 0.2Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 567
  * waited 25 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 63
  * waited 5.3 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 63
  * waited 3.3 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 126
  * waited 6 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 63
  * waited 3 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 63
  * waited 3 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 63
  * waited 10 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.19 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.8 sec
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * waited 0.93 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 0.48 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 0.58 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.75 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.31 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * waited 0.36 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 0.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 0.66 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * waited 0.45 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.28 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 0.91 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * waited 0.42 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 80 ms
* `UserRequest:hudson.FilePath$CallableWith`: 22
  * waited 2.5 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 63
  * waited 1 min 33 sec
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * waited 2.7 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 566
  * waited 23 sec
* `UserRequest:hudson.FilePath$Exists`: 229
  * waited 12 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 4188
  * waited 2 min 52 sec
* `UserRequest:hudson.FilePath$LastModified`: 61
  * waited 2.5 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 1197
  * waited 50 sec
* `UserRequest:hudson.FilePath$Read`: 103
  * waited 4.8 sec
* `UserRequest:hudson.FilePath$Write`: 567
  * waited 23 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 567
  * waited 28 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 62
  * waited 7.2 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 0.59 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 11
  * waited 1 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 11
  * waited 0.54 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 11
  * waited 1 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 11
  * waited 1.3 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.3 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.16 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.24 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 1.4 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.62 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 80 ms
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 276
  * waited 30 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 81 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 1 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 0.15 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 567
  * waited 25 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$1`: 63
  * waited 2.8 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 4120
  * waited 2 min 52 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 4684
  * waited 3 min 11 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 4684
  * waited 3 min 12 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * waited 0.29 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 0.18 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 63
  * waited 12 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 126
  * waited 29 sec

# JARs sent
* `stapler-1.258.jar`: 441318b
* `jna-5.3.1.jar`: 1505196b
* `libpam4j-1.11.jar`: 21038b
* `ant-1.9.14.jar`: 2069867b
* `commons-io-2.6.jar`: 214788b
* `commons-compress-1.19.jar`: 615064b
* `guava-11.0.1.jar`: 1649781b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `support-core.jar`: 434579b
* `launchd-slave-installer-1.2.jar`: 22663b
* `systemd-slave-installer-1.1.jar`: 11541b
* `slave-installer-1.7.jar`: 28570b
* `akuma-1.10.jar`: 19673b
* `winstone8550735590855648651.jar`: 3140849b
* `localizer-1.26.jar`: 8600b
* `envinject.jar`: 152990b
* `envinject-lib-1.29.jar`: 20599b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `memory-monitor-1.9.jar`: 17292b
* `commons-lang-2.6.jar`: 284220b
* `git-client.jar`: 218600b
* `workflow-api.jar`: 175785b
* `acegi-security-1.0.7.jar`: 548722b
* `spring-core-2.5.6.SEC03.jar`: 285605b
* `credentials.jar`: 619610b
* `org.eclipse.jgit-5.6.1.202002131546-r.jar`: 2839536b
* `antlr4-runtime-4.5.jar`: 374032b
* `ssh-credentials.jar`: 65368b
* `xstream-1.4.7-jenkins-1.jar`: 533110b
* `robust-http-client-1.2.jar`: 4414b
* `xpp3-1.1.4c.jar`: 120069b
* `icon-set-1.0.5.jar`: 17567b
* `commons-beanutils-1.9.3.jar`: 246174b
* `jcl-over-slf4j-1.7.26.jar`: 16461b
* `slf4j-api-1.7.26.jar`: 41139b
* `slf4j-jdk14-1.7.26.jar`: 8476b
* `git.jar`: 655623b
* `durable-task.jar`: 5303920b
* `credentials-binding.jar`: 102820b
* `workflow-step-api.jar`: 82244b
* `jzlib-1.1.3-kohsuke-1.jar`: 71852b
* `task-reactor-1.5.jar`: 22114b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `ezmorph-1.0.6.jar`: 86487b
* `antlr-2.7.6.jar`: 443432b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `stapler-jelly-1.258.jar`: 88175b
