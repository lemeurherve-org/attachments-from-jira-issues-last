# Totals
* Writes: 177241
  * sent 380.0Mb
* Reads: 395490
  * received 1178.1Mb
* Responses: 76225
  * waited 1 hr 11 min

# Commands sent
* `GC`: 7
  * sent 0.0Mb
* `Pipe.Chunk`: 957
  * sent 8.0Mb
* `ProxyInputStream.EOF`: 5154
  * sent 11.1Mb
* `ProxyOutputStream.Ack`: 83270
  * sent 12.8Mb
* `ProxyOutputStream.Unexport`: 14
  * sent 0.0Mb
* `ProxyWriter.Ack`: 702
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 954
  * sent 2.6Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 18
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 20
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 52
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 14
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 160
  * sent 0.3Mb
* `Response:UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 551
  * sent 1.1Mb
* `Unexport`: 9087
  * sent 16.7Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 2578
  * sent 32.3Mb
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 551
  * sent 3.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 285
  * sent 1.8Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 285
  * sent 1.5Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 92
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 570
  * sent 3.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 285
  * sent 1.6Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 285
  * sent 1.6Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 285
  * sent 1.8Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 175
  * sent 0.7Mb
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 2577
  * sent 7.9Mb
* `UserRequest:hudson.FilePath$Exists`: 807
  * sent 2.5Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 11780
  * sent 34.9Mb
* `UserRequest:hudson.FilePath$LastModified`: 60
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 5441
  * sent 35.7Mb
* `UserRequest:hudson.FilePath$Read`: 329
  * sent 1.0Mb
* `UserRequest:hudson.FilePath$Write`: 2578
  * sent 17.3Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 2578
  * sent 29.5Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 284
  * sent 0.8Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:jenkins.plugins.http_request.HttpRequestExecution`: 517
  * sent 1.9Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 274
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 2578
  * sent 16.6Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$1`: 307
  * sent 1.1Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 11447
  * sent 37.2Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 14021
  * sent 39.2Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 14021
  * sent 45.2Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 285
  * sent 1.6Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 662
  * sent 4.4Mb

# Commands received
* `GC`: 6
  * received 0.0Mb
* `Pipe.Chunk`: 83270
  * received 603.0Mb
* `Pipe.Flush`: 11103
  * received 1.9Mb
* `ProxyOutputStream.Ack`: 957
  * received 0.1Mb
* `ProxyOutputStream.EOF`: 566
  * received 1.2Mb
* `ProxyOutputStream.Unexport`: 17332
  * received 22.7Mb
* `ProxyWriter.Chunk`: 702
  * received 1.5Mb
* `ProxyWriter.EOF`: 92
  * received 0.2Mb
* `ProxyWriter.Flush`: 92
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 954
  * received 0.6Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 18
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 20
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * received 0.0Mb
* `Response`: 76225
  * received 154.6Mb
* `Unexport`: 203320
  * received 305.2Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 52
  * received 0.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 14
  * received 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 160
  * received 0.4Mb
* `UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 551
  * received 86.1Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 2578
  * waited 2 min 1 sec
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 551
  * waited 27 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 285
  * waited 15 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 285
  * waited 16 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 92
  * waited 6.9 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 570
  * waited 34 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 285
  * waited 12 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 285
  * waited 16 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 285
  * waited 24 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.25 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 3.4 sec
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 15
  * waited 1.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 1.9 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 0.68 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.29 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 6
  * waited 0.36 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 0.42 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 0.83 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 5
  * waited 0.38 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.27 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 1.3 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 10
  * waited 0.44 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 80 ms
* `UserRequest:hudson.FilePath$2`: 2
  * waited 0.1 sec
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * waited 1.9 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 175
  * waited 4 min 25 sec
* `UserRequest:hudson.FilePath$CopyTo`: 60
  * waited 2.9 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 2577
  * waited 1 min 52 sec
* `UserRequest:hudson.FilePath$Exists`: 807
  * waited 38 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 11780
  * waited 9 min 29 sec
* `UserRequest:hudson.FilePath$LastModified`: 60
  * waited 2.8 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 5441
  * waited 3 min 59 sec
* `UserRequest:hudson.FilePath$Read`: 329
  * waited 15 sec
* `UserRequest:hudson.FilePath$Write`: 2578
  * waited 1 min 52 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 2578
  * waited 2 min 13 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 284
  * waited 2 min 24 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 97 ms
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * waited 0.76 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * waited 0.84 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * waited 0.91 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * waited 1.2 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.2 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.3 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.28 sec
* `UserRequest:jenkins.plugins.http_request.HttpRequestExecution`: 517
  * waited 1 min 10 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 90 ms
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 3.5 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 94 ms
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 274
  * waited 50 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 98 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 1 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 1.1 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$GetAgentInfo`: 2578
  * waited 1 min 54 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$1`: 307
  * waited 13 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 11447
  * waited 9 min 15 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$TranscodingCharsetForSystemDefault`: 14021
  * waited 10 min
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 14021
  * waited 11 min
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * waited 1 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 285
  * waited 22 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 662
  * waited 3 min 43 sec

# JARs sent
* `support-core.jar`: 434579b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
* `envinject.jar`: 152990b
* `git-client.jar`: 218600b
* `credentials.jar`: 619610b
* `org.eclipse.jgit-5.6.1.202002131546-r.jar`: 2839536b
* `ssh-credentials.jar`: 65368b
* `git.jar`: 655623b
* `credentials-binding.jar`: 102820b
* `http_request.jar`: 69045b
* `httpclient-4.5.10.jar`: 774640b
* `httpmime-4.5.10.jar`: 41792b
* `httpcore-4.4.12.jar`: 328347b
