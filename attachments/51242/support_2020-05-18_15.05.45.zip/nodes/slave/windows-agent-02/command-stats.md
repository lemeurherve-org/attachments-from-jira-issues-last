# Totals
* Writes: 246704
  * sent 117.9Mb
* Reads: 249801
  * received 225.7Mb
* Responses: 3210
  * waited 49 min

# Commands sent
* `Pipe.Chunk`: 15408
  * sent 60.0Mb
* `Pipe.Connect`: 4
  * sent 0.0Mb
* `Pipe.Flush`: 5422
  * sent 0.9Mb
* `ProxyOutputStream.Ack`: 218824
  * sent 33.7Mb
* `ProxyOutputStream.Dead`: 1
  * sent 0.0Mb
* `ProxyOutputStream.EOF`: 7
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 58
  * sent 0.1Mb
* `ProxyWriter.Ack`: 361
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 2032
  * sent 7.6Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 49
  * sent 0.5Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 68
  * sent 0.4Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 7
  * sent 0.1Mb
* `Response:UserRequest:RPCRequest:hudson.remoting.IChannel.waitForProperty[java.lang.Object]`: 1
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 101
  * sent 0.2Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 58
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 99
  * sent 0.2Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 7
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 10
  * sent 0.0Mb
* `Unexport`: 924
  * sent 1.6Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 103
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 99
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 99
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.accept[]`: 4
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.getPort[]`: 4
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 10
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 36
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.getWorkTree[]`: 16
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 27
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 24
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 54
  * sent 0.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 36
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 27
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tagExists[java.lang.String]`: 9
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tag[java.lang.String,java.lang.String]`: 9
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 27
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 8
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 78
  * sent 0.3Mb
* `UserRequest:hudson.FilePath$Delete`: 78
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 12
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Digest`: 13
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 1298
  * sent 3.9Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Length`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$ListGlob`: 16
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 63
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Read`: 57
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$ReadToString`: 12
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$RenameTo`: 12
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$WritePipe`: 3
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 103
  * sent 0.9Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 26
  * sent 0.1Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetCharset`: 4
  * sent 0.0Mb
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetRemotingJar`: 4
  * sent 0.0Mb
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$SocketHandler`: 4
  * sent 0.0Mb
* `UserRequest:hudson.maven.Maven3ProcessFactory$GetClassWorldsJar`: 4
  * sent 0.0Mb
* `UserRequest:hudson.maven.MavenBuild$CanonicalPath`: 20
  * sent 0.1Mb
* `UserRequest:hudson.maven.MavenModuleSetBuild$PomParser`: 4
  * sent 0.0Mb
* `UserRequest:hudson.maven.MavenVersionCallable`: 4
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 35
  * sent 0.1Mb
* `UserRequest:hudson.plugins.sonar.MsBuildSQRunnerInstallation$1`: 2
  * sent 0.0Mb
* `UserRequest:hudson.plugins.ws_cleanup.Cleanup`: 27
  * sent 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$DetectOS`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$ListFullEnvironment`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$LoadingCount`: 4
  * sent 0.1Mb
* `UserRequest:hudson.slaves.SlaveComputer$LoadingPrefetchCacheCount`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$LoadingTime`: 4
  * sent 0.1Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveVersion`: 2
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Maven$MavenInstallation$GetExecutable`: 19
  * sent 0.1Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetThreadDump`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 275
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 27
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 28
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 21
  * sent 0.2Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 36
  * sent 0.3Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 108
  * sent 0.7Mb
* `UserRequest:sp.sd.nexusartifactuploader.NexusArtifactUploader$1`: 6
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 218824
  * received 194.6Mb
* `Pipe.Flush`: 248
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 15408
  * received 2.4Mb
* `ProxyOutputStream.EOF`: 69
  * received 0.1Mb
* `ProxyOutputStream.Unexport`: 152
  * received 0.2Mb
* `ProxyWriter.Chunk`: 361
  * received 0.8Mb
* `ProxyWriter.EOF`: 18
  * received 0.0Mb
* `ProxyWriter.Flush`: 18
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 2032
  * received 1.2Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 49
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 68
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 7
  * received 0.0Mb
* `Response`: 3210
  * received 9.8Mb
* `Unexport`: 9008
  * received 13.5Mb
* `UserRequest:RPCRequest:hudson.remoting.IChannel.waitForProperty[java.lang.Object]`: 1
  * received 0.0Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 101
  * received 0.8Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 58
  * received 0.3Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 99
  * received 0.3Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 7
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 10
  * received 1.4Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 103
  * waited 4.5 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 99
  * waited 4.4 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 99
  * waited 36 min
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.accept[]`: 4
  * waited 0.73 sec
* `UserRequest:UserRPCRequest:hudson.maven.AbstractMavenProcessFactory$Acceptor.getPort[]`: 4
  * waited 0.15 sec
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 10
  * waited 0.48 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 36
  * waited 4.1 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.getWorkTree[]`: 16
  * waited 0.64 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 27
  * waited 1.1 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 24
  * waited 3.4 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 54
  * waited 6.8 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 36
  * waited 1.4 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 27
  * waited 3.2 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tagExists[java.lang.String]`: 9
  * waited 1.9 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.tag[java.lang.String,java.lang.String]`: 9
  * waited 1.1 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 27
  * waited 5.9 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.2 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 0.63 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 6.6 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.74 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.28 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 1.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 0.71 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 0.99 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.28 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 0.93 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 78 ms
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * waited 2.2 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 8
  * waited 23 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 78
  * waited 3.6 sec
* `UserRequest:hudson.FilePath$Delete`: 78
  * waited 3.6 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 12
  * waited 39 sec
* `UserRequest:hudson.FilePath$Digest`: 13
  * waited 1.8 sec
* `UserRequest:hudson.FilePath$Exists`: 1298
  * waited 55 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 5
  * waited 0.27 sec
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * waited 45 ms
* `UserRequest:hudson.FilePath$Length`: 3
  * waited 0.14 sec
* `UserRequest:hudson.FilePath$ListGlob`: 16
  * waited 3.5 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 63
  * waited 2.6 sec
* `UserRequest:hudson.FilePath$Read`: 57
  * waited 23 sec
* `UserRequest:hudson.FilePath$ReadToString`: 12
  * waited 0.49 sec
* `UserRequest:hudson.FilePath$RenameTo`: 12
  * waited 0.66 sec
* `UserRequest:hudson.FilePath$WritePipe`: 3
  * waited 0.12 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 103
  * waited 6.1 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 26
  * waited 10 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 0.28 sec
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetCharset`: 4
  * waited 0.2 sec
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$GetRemotingJar`: 4
  * waited 0.16 sec
* `UserRequest:hudson.maven.AbstractMavenProcessFactory$SocketHandler`: 4
  * waited 0.56 sec
* `UserRequest:hudson.maven.Maven3ProcessFactory$GetClassWorldsJar`: 4
  * waited 0.24 sec
* `UserRequest:hudson.maven.MavenBuild$CanonicalPath`: 20
  * waited 0.88 sec
* `UserRequest:hudson.maven.MavenModuleSetBuild$PomParser`: 4
  * waited 58 sec
* `UserRequest:hudson.maven.MavenVersionCallable`: 4
  * waited 3.6 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * waited 0.68 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * waited 0.68 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * waited 0.89 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * waited 2.4 sec
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 35
  * waited 9.3 sec
* `UserRequest:hudson.plugins.sonar.MsBuildSQRunnerInstallation$1`: 2
  * waited 0.41 sec
* `UserRequest:hudson.plugins.ws_cleanup.Cleanup`: 27
  * waited 25 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.4 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.26 sec
* `UserRequest:hudson.slaves.SlaveComputer$DetectOS`: 2
  * waited 87 ms
* `UserRequest:hudson.slaves.SlaveComputer$ListFullEnvironment`: 2
  * waited 0.28 sec
* `UserRequest:hudson.slaves.SlaveComputer$LoadingCount`: 4
  * waited 0.22 sec
* `UserRequest:hudson.slaves.SlaveComputer$LoadingPrefetchCacheCount`: 2
  * waited 88 ms
* `UserRequest:hudson.slaves.SlaveComputer$LoadingTime`: 4
  * waited 0.22 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.25 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveVersion`: 2
  * waited 82 ms
* `UserRequest:hudson.tasks.Maven$MavenInstallation$GetExecutable`: 19
  * waited 0.81 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 2
  * waited 0.12 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetThreadDump`: 2
  * waited 0.22 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.1 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 1.2 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 99 ms
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 275
  * waited 19 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 95 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.29 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 0.14 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * waited 0.23 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 27
  * waited 1.1 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 28
  * waited 1.4 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 0.23 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 21
  * waited 1 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 36
  * waited 11 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 108
  * waited 6 min 18 sec
* `UserRequest:sp.sd.nexusartifactuploader.NexusArtifactUploader$1`: 6
  * waited 15 sec

# JARs sent
* `support-core.jar`: 434579b
* `envinject.jar`: 152990b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
* `git-client.jar`: 218600b
* `credentials.jar`: 619610b
* `org.eclipse.jgit-5.6.1.202002131546-r.jar`: 2839536b
* `ssh-credentials.jar`: 65368b
* `git.jar`: 655623b
* `maven-plugin.jar`: 10249910b
* `lib-jenkins-maven-embedder-3.15.jar`: 25685b
* `plexus-classworlds-2.6.0.jar`: 52873b
* `maven-resolver-api-1.1.1.jar`: 146201b
* `maven-core-3.5.4.jar`: 630101b
* `maven-artifact-3.5.4.jar`: 54893b
* `maven-settings-builder-3.5.4.jar`: 43145b
* `maven-plugin-api-3.5.4.jar`: 47639b
* `maven-embedder-3.5.4.jar`: 98372b
* `wagon-file-3.3.2.jar`: 11565b
* `maven32-interceptor-1.13.jar`: 20161b
* `plexus-cipher-1.8.jar`: 13614b
* `maven31-interceptor-1.13.jar`: 19802b
* `maven-model-builder-3.5.4.jar`: 177426b
* `wagon-http-3.3.2.jar`: 11407b
* `maven3-interceptor-1.13.jar`: 15152b
* `maven33-interceptor-1.13.jar`: 20823b
* `maven35-interceptor-1.13.jar`: 21140b
* `wagon-ssh-common-3.3.2.jar`: 26682b
* `maven-compat-3.5.4.jar`: 290368b
* `plexus-sec-dispatcher-1.4.jar`: 27703b
* `wagon-ssh-external-3.3.2.jar`: 15396b
* `wagon-webdav-jackrabbit-3.3.2.jar`: 20721b
* `wagon-ftp-3.3.2.jar`: 18819b
* `wagon-ssh-3.3.2.jar`: 32080b
* `maven-interceptor-1.13.jar`: 22676b
* `maven-resolver-transport-wagon-1.1.1.jar`: 30919b
* `plexus-utils-3.1.0.jar`: 261617b
* `wagon-provider-api-3.3.2.jar`: 55886b
* `maven3-interceptor-commons-1.13.jar`: 6837b
* `jsch-0.1.55.jar`: 282591b
* `maven-resolver-impl-1.1.1.jar`: 184592b
* `maven-resolver-connector-basic-1.1.1.jar`: 42804b
* `maven-resolver-provider-3.5.4.jar`: 67004b
* `maven-resolver-spi-1.1.1.jar`: 35811b
* `maven-model-3.5.4.jar`: 164976b
* `maven-resolver-util-1.1.1.jar`: 158902b
* `wagon-http-shared-3.3.2.jar`: 38426b
* `httpclient-4.5.10.jar`: 774640b
* `httpcore-4.4.12.jar`: 328347b
* `jackrabbit-webdav-2.14.4.jar`: 364983b
* `maven-builder-support-3.5.4.jar`: 14781b
* `plexus-interpolation-1.24.jar`: 78876b
* `maven-settings-3.5.4.jar`: 44566b
* `commons-net-3.6.jar`: 307410b
* `maven-repository-metadata-3.5.4.jar`: 27457b
* `commons-cli-1.4.jar`: 53820b
* `commons-lang3-3.7.jar`: 499634b
* `nexus-artifact-uploader.jar`: 48030b
