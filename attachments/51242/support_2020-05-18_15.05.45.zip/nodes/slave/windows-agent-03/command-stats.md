# Totals
* Writes: 1194
  * sent 4.6Mb
* Reads: 2393
  * received 7.6Mb
* Responses: 479
  * waited 47 sec

# Commands sent
* `Pipe.Chunk`: 254
  * sent 2.1Mb
* `ProxyOutputStream.Ack`: 5
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 4
  * sent 0.0Mb
* `Response:RPCRequest:null.fetch3[java.lang.String]`: 196
  * sent 0.6Mb
* `Response:RPCRequest:null.fetch[java.lang.String]`: 4
  * sent 0.0Mb
* `Response:RPCRequest:null.getResource2[java.lang.String]`: 5
  * sent 0.0Mb
* `Response:RPCRequest:null.getResources2[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest`: 29
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Unexport`: 165
  * sent 0.3Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Digest`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 2
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 275
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 5
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 254
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 4
  * received 0.0Mb
* `RPCRequest:null.fetch3[java.lang.String]`: 196
  * received 0.5Mb
* `RPCRequest:null.fetch[java.lang.String]`: 4
  * received 0.0Mb
* `RPCRequest:null.getResource2[java.lang.String]`: 5
  * received 0.0Mb
* `RPCRequest:null.getResources2[java.lang.String]`: 1
  * received 0.0Mb
* `Response`: 479
  * received 3.3Mb
* `Unexport`: 1364
  * received 3.3Mb
* `UserRequest:UserRPCRequest`: 29
  * received 0.2Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb

# Responses received
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.23 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 0.98 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 6.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.28 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.28 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 1.9 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 0.7 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 1.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.24 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 0.76 sec
* `UserRequest:hudson.FilePath$2`: 2
  * waited 0.22 sec
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * waited 1.8 sec
* `UserRequest:hudson.FilePath$Digest`: 1
  * waited 0.58 sec
* `UserRequest:hudson.FilePath$Exists`: 3
  * waited 1.9 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 5
  * waited 0.28 sec
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * waited 0.22 sec
* `UserRequest:hudson.FilePath$Read`: 2
  * waited 0.18 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 0.1 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * waited 0.63 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * waited 0.65 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * waited 0.76 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * waited 2.3 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.7 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.25 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.27 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.11 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 1.2 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 0.11 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 275
  * waited 17 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 0.3 sec
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.29 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * waited 0.14 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * waited 0.36 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 0.24 sec

# JARs sent
* `support-core.jar`: 434579b
* `envinject.jar`: 152990b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
