# Totals
* Writes: 187608
  * sent 56.2Mb
* Reads: 192948
  * received 208.1Mb
* Responses: 1927
  * waited 3 hr 30 min

# Commands sent
* `Pipe.Chunk`: 1258
  * sent 10.5Mb
* `ProxyOutputStream.Ack`: 182498
  * sent 28.1Mb
* `ProxyOutputStream.Unexport`: 16
  * sent 0.0Mb
* `ProxyWriter.Ack`: 3
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 1271
  * sent 4.8Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 19
  * sent 0.2Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 31
  * sent 0.3Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 5
  * sent 0.0Mb
* `Response:UserRequest:RPCRequest:hudson.remoting.IChannel.waitForProperty[java.lang.Object]`: 1
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 60
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 16
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 31
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 2
  * sent 0.0Mb
* `Unexport`: 417
  * sent 0.7Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 31
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 31
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 31
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 2
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 15
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.getWorkTree[]`: 8
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 15
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 13
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 26
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 15
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 13
  * sent 0.1Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 13
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 29
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Delete`: 29
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 8
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Digest`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 195
  * sent 0.7Mb
* `UserRequest:hudson.FilePath$IsDescendant`: 464
  * sent 4.4Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 23
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$IsUnix`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$LastModified`: 90
  * sent 0.8Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 30
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Read`: 136
  * sent 1.0Mb
* `UserRequest:hudson.FilePath$ReadToString`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$RenameTo`: 8
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 31
  * sent 0.3Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 13
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * sent 0.0Mb
* `UserRequest:hudson.model.DirectoryBrowserSupport$BuildChildPaths`: 10
  * sent 0.1Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 14
  * sent 0.0Mb
* `UserRequest:hudson.plugins.ws_cleanup.Cleanup`: 14
  * sent 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * sent 0.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$DetectOS`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$ListFullEnvironment`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$LoadingCount`: 4
  * sent 0.1Mb
* `UserRequest:hudson.slaves.SlaveComputer$LoadingPrefetchCacheCount`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$LoadingTime`: 4
  * sent 0.1Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveVersion`: 2
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetThreadDump`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * sent 0.0Mb
* `UserRequest:jenkins.util.VirtualFile$Scanner`: 2
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 273
  * sent 0.7Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 15
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 17
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 13
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 15
  * sent 0.1Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 52
  * sent 0.3Mb

# Commands received
* `Pipe.Chunk`: 182498
  * received 190.6Mb
* `Pipe.Flush`: 73
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 1258
  * received 0.2Mb
* `ProxyOutputStream.EOF`: 136
  * received 0.3Mb
* `ProxyOutputStream.Unexport`: 44
  * received 0.1Mb
* `ProxyWriter.Chunk`: 3
  * received 0.0Mb
* `ProxyWriter.EOF`: 11
  * received 0.0Mb
* `ProxyWriter.Flush`: 11
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 1271
  * received 0.7Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 19
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 31
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 5
  * received 0.0Mb
* `Response`: 1926
  * received 7.1Mb
* `Unexport`: 5498
  * received 8.3Mb
* `UserRequest:RPCRequest:hudson.remoting.IChannel.waitForProperty[java.lang.Object]`: 1
  * received 0.0Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 60
  * received 0.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 16
  * received 0.1Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 31
  * received 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * received 0.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$OSProcess$CheckVetoes`: 2
  * received 0.2Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 31
  * waited 1.2 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 31
  * waited 1.2 sec
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 31
  * waited 2 hr 42 min
* `UserRequest:UserRPCRequest:hudson.util.ProcessTreeRemoting$IOSProcess.getArguments[]`: 2
  * waited 0.12 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 15
  * waited 6.2 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.getWorkTree[]`: 8
  * waited 0.34 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 15
  * waited 0.62 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 13
  * waited 1.4 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.revParse[java.lang.String]`: 26
  * waited 2.6 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 15
  * waited 0.58 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 13
  * waited 1.3 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 13
  * waited 11 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 5
  * waited 0.19 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 2
  * waited 2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 6
  * waited 1.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 6
  * waited 0.99 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 6
  * waited 0.76 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 6
  * waited 0.33 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 6
  * waited 0.66 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 5
  * waited 0.91 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 10
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 5
  * waited 0.32 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 6
  * waited 1.1 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 2
  * waited 0.16 sec
* `UserRequest:hudson.FilePath$CallableWith`: 20
  * waited 3 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 29
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$Delete`: 29
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 8
  * waited 14 sec
* `UserRequest:hudson.FilePath$Digest`: 2
  * waited 1.2 sec
* `UserRequest:hudson.FilePath$Exists`: 195
  * waited 14 sec
* `UserRequest:hudson.FilePath$IsDescendant`: 464
  * waited 19 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 23
  * waited 0.98 sec
* `UserRequest:hudson.FilePath$IsUnix`: 2
  * waited 83 ms
* `UserRequest:hudson.FilePath$LastModified`: 90
  * waited 3.5 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 30
  * waited 1.2 sec
* `UserRequest:hudson.FilePath$Read`: 136
  * waited 36 sec
* `UserRequest:hudson.FilePath$ReadToString`: 6
  * waited 0.26 sec
* `UserRequest:hudson.FilePath$RenameTo`: 8
  * waited 0.51 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 31
  * waited 1.5 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 13
  * waited 8.3 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 2
  * waited 0.46 sec
* `UserRequest:hudson.model.DirectoryBrowserSupport$BuildChildPaths`: 10
  * waited 0.65 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 10
  * waited 1 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 10
  * waited 0.83 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 10
  * waited 1.4 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 10
  * waited 4.4 sec
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 14
  * waited 6.9 sec
* `UserRequest:hudson.plugins.ws_cleanup.Cleanup`: 14
  * waited 21 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 52
  * waited 2.3 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 2
  * waited 0.42 sec
* `UserRequest:hudson.slaves.SlaveComputer$DetectOS`: 2
  * waited 0.11 sec
* `UserRequest:hudson.slaves.SlaveComputer$ListFullEnvironment`: 2
  * waited 0.25 sec
* `UserRequest:hudson.slaves.SlaveComputer$LoadingCount`: 4
  * waited 0.21 sec
* `UserRequest:hudson.slaves.SlaveComputer$LoadingPrefetchCacheCount`: 2
  * waited 86 ms
* `UserRequest:hudson.slaves.SlaveComputer$LoadingTime`: 4
  * waited 0.21 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveInitializer`: 1
  * waited 42 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 5
  * waited 0.23 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveVersion`: 2
  * waited 85 ms
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 2
  * waited 0.12 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetThreadDump`: 2
  * waited 0.3 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 2
  * waited 0.22 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 2
  * waited 2.2 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 2
  * waited 0.21 sec
* `UserRequest:jenkins.util.VirtualFile$Scanner`: 2
  * waited 0.86 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 273
  * waited 16 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 2
  * waited 0.22 sec
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 2
  * waited 0.7 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 2
  * waited 0.24 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 2
  * waited 0.23 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 15
  * waited 0.71 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 17
  * waited 1.4 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 2
  * waited 0.28 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 13
  * waited 1 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$GitAPIMasterToSlaveFileCallable`: 15
  * waited 16 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$GitCommandMasterToSlaveCallable`: 52
  * waited 44 min

# JARs sent
* `support-core.jar`: 434579b
* `envinject.jar`: 152990b
* `monitoring.jar`: 44662b
* `javamelody-core-1.83.0.jar`: 1430851b
* `git-client.jar`: 218600b
* `credentials.jar`: 619610b
* `org.eclipse.jgit-5.6.1.202002131546-r.jar`: 2839536b
* `ssh-credentials.jar`: 65368b
* `commons-beanutils-1.9.3.jar`: 246174b
* `jcl-over-slf4j-1.7.26.jar`: 16461b
* `slf4j-api-1.7.26.jar`: 41139b
* `slf4j-jdk14-1.7.26.jar`: 8476b
* `git.jar`: 655623b
* `stapler-jelly-1.258.jar`: 88175b
* `winp-1.28.jar`: 224963b
* `cli-2.222.3.jar`: 3139845b
