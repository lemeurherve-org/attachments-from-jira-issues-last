-----------
 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Kernel Debug Network Adapter
 ** Index - 2
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Amazon Elastic Network Adapter
 ** Index - 3
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter #2
 ** Hardware Address - 00000000000000e0
 ** Index - 4
 ** InetAddress - /fe80:0:0:0:0:5efe:a55:41a8%net0
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Amazon Elastic Network Adapter #2
 ** Hardware Address - 023e4d4e9952
 ** Index - 5
 ** InetAddress - /10.85.65.168
 ** InetAddress - /fe80:0:0:0:2c03:298c:aa0f:6b6c%eth2
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Teredo Tunneling Pseudo-Interface
 ** Hardware Address - 00000000000000e0
 ** Index - 6
 ** InetAddress - /2001:0:2851:782c:20f9:1c10:f5aa:be57
 ** InetAddress - /fe80:0:0:0:20f9:1c10:f5aa:be57%net1
 ** MTU - 1280
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Amazon Elastic Network Adapter #2-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 7
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Amazon Elastic Network Adapter #2-QoS Packet Scheduler-0000
 ** Index - 8
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Amazon Elastic Network Adapter #2-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 9
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
