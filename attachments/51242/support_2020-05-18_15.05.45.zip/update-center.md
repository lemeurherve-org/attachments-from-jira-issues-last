=== Sites ===
 - Url: https://updates.jenkins.io/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 4 hr 13 min
=== Proxy ===
