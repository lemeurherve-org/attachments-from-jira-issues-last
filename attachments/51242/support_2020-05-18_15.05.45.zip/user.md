User
====

Authentication
--------------

  * Authenticated: true
  * Name: hunhda
  * Authorities 
      - `EAMEMINUSBRE`
      - `DL BUD IT DEVOPS OPS NOTIFICATION`
      - `DL_OPS_BUD`
      - `DCX-Jenkins-DevOps-Admin`
      - `AWS-114776006473-ADFS-devops-agco`
      - `agco_vpn_employees`
      - `DL Bud All Users`
      - `usg_www access`
      - `HR Global Distribution List`
      - `authenticated`
  * Raw: `hudson.security.LDAPSecurityRealm$DelegatedLdapAuthentication@294e548b`

