//
//  ViewController.swift
//  Xcode-PlugIn-Test-App
//
//  Created by Francis Labrie on 2022-05-10.
//

import UIKit

class ViewController: UIViewController {

	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view.
	}


}

