Jenkins
=======

Version details
---------------

  * Version: `2.361.2`
  * Instance ID: `30cf955b8f89bd1ed6fa300331f9567a`
  * Mode:    WAR
  * Url:     https://jenkins.spherecom.com:8080/
  * Servlet container
      - Specification: 4.0
      - Name:          `jetty/10.0.11`
  * Java
      - Home:           `C:\Program Files\Java\jdk-11.0.15.1`
      - Vendor:           Oracle Corporation
      - Version:          11.0.15.1
      - Maximum memory:   256.00 MB (268435456)
      - Allocated memory: 256.00 MB (268435456)
      - Free memory:      108.33 MB (113590744)
      - In-use memory:    147.67 MB (154844712)
      - GC strategy:      G1
      - Available CPUs:   4
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 11
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 11
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 11.0.15.1+2-LTS-10
  * Operating system
      - Name:         Windows Server 2019
      - Architecture: amd64
      - Version:      10.0
  * Process ID: 4676 (0x1244)
  * Process started: 2022-10-23 17:11:19.497+0000
  * Process uptime: 5 min 36 sec
  * JVM startup parameters:
      - Classpath: `C:\Jenkins\jenkins.war`
      - Library path: `C:\Program Files\Java\jdk-11.0.15.1\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Perl64\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files\Perforce;C:\Program Files (x86)\Java\jdk1.6.0_18\bin;C:\Python26;C:\Program Files (x86)\apache-maven-3.0.4\bin;C:\Tools\bin;C:\android-sdk-windows\tools;C:\apache-ant-1.8.2\bin;C:\Program Files\Help Workshop;C:\Program Files (x86)\Perforce;C:\Program Files (x86)\Microsoft ASP.NET\ASP.NET Web Pages\v1.0\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft\Web Platform Installer\;C:\Program Files (x86)\Windows Kits\8.1\Windows Performance Toolkit\;C:\Program Files\SafeNet\Authentication\SAC\x64;C:\Program Files\SafeNet\Authentication\SAC\x32;C:\Program Files (x86)\Microsoft SDKs\TypeScript\1.0\;C:\Program Files\Microsoft SQL Server\120\Tools\Binn\;C:\WINDOWS\System32\OpenSSH\;C:\Users\buildsystem\AppData\Local\Microsoft\WindowsApps;.`
      - arg[0]: `-Xrs`
      - arg[1]: `-Xmx256m`
      - arg[2]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

Remoting details
---------------

  * Embedded Version: `3044.vb_940a_a_e4f72e`
  * Minimum Supported Version: `4.2.1`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:475.vf34069fef73c *(update available)* 'Ant Plugin'
  * antisamy-markup-formatter:2.7 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.13-138.v4e7d9a_7b_a_e61 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * bootstrap5-api:5.1.3-7 *(update available)* 'Bootstrap 5 API Plugin'
  * bouncycastle-api:2.26 'bouncycastle API Plugin'
  * branch-api:2.1046.v0ca_37783ecc5 'Branch API Plugin'
  * build-pipeline-plugin:1.5.8 'Build Pipeline Plugin'
  * build-timeout:1.21 *(update available)* 'Build Timeout'
  * caffeine-api:2.9.3-65.v6a_47d0f4d1fe 'Caffeine API Plugin'
  * checks-api:1.7.4 *(update available)* 'Checks API plugin'
  * cloudbees-folder:6.740.ve4f4ffa_dea_54 *(update available)* 'Folders Plugin'
  * command-launcher:84.v4a_97f2027398 *(update available)* 'Command Agent Launcher Plugin'
  * copyartifact:1.46.4 *(update available)* 'Copy Artifact Plugin'
  * credentials:1139.veb_9579fca_33b_ *(update available)* 'Credentials Plugin'
  * credentials-binding:523.vd859a_4b_122e6 'Credentials Binding Plugin'
  * display-url-api:2.3.6 'Display URL API'
  * durable-task:496.va67c6f9eefa7 *(update available)* 'Durable Task Plugin'
  * echarts-api:5.3.3-1 *(update available)* 'ECharts API Plugin'
  * email-ext:2.91 *(update available)* 'Email Extension Plugin'
  * extended-read-permission:3.2 'Jenkins Extended Read Permission Plugin'
  * external-monitor-job:192.ve979ca_8b_3ccd *(update available)* 'External Monitor Job Type Plugin'
  * font-awesome-api:6.1.1-1 *(update available)* 'Font Awesome API Plugin'
  * git:4.11.4 *(update available)* 'Git plugin'
  * git-client:3.11.1 *(update available)* 'Jenkins Git client plugin'
  * github:1.34.5 *(update available)* 'GitHub plugin'
  * github-api:1.303-400.v35c2d8258028 'GitHub API Plugin'
  * github-branch-source:1677.v731f745ea_0cf *(update available)* 'GitHub Branch Source Plugin'
  * gradle:1.39.4 *(update available)* 'Gradle Plugin'
  * groovy:453.vcdb_a_c5c99890 'Groovy'
  * handlebars:3.0.8 'JavaScript GUI Lib: Handlebars bundle plugin'
  * instance-identity:3.1 *(update available)* 'Instance Identity'
  * jackson2-api:2.13.3-285.vc03c0256d517 *(update available)* 'Jackson 2 API Plugin'
  * jakarta-activation-api:2.0.0-3 *(update available)* 'Jakarta Activation API'
  * jakarta-mail-api:2.0.0-6 *(update available)* 'Jakarta Mail API'
  * javadoc:217.v905b_86277a_2a_ *(update available)* 'Javadoc Plugin'
  * javax-activation-api:1.2.0-4 *(update available)* 'JavaBeans Activation Framework (JAF) API'
  * javax-mail-api:1.6.2-7 *(update available)* 'JavaMail API'
  * jaxb:2.3.6-1 *(update available)* 'JAXB plugin'
  * jdk-tool:55.v1b_32b_6ca_f9ca 'Oracle Java SE Development Kit Installer Plugin'
  * jjwt-api:0.11.5-77.v646c772fddb_0 'Java JSON Web Token (JJWT) Plugin'
  * jobConfigHistory:1163.ve82c7c6e60a_3 *(update available)* 'Jenkins Job Configuration History Plugin'
  * jquery:1.12.4-1 'jQuery plugin'
  * jquery3-api:3.6.0-4 *(update available)* 'JQuery3 API Plugin'
  * jsch:0.1.55.2 *(update available)* 'Jenkins JSch dependency plugin'
  * junit:1119.1121.vc43d0fc45561 *(update available)* 'JUnit Plugin'
  * ldap:2.11 *(update available)* 'LDAP Plugin'
  * mailer:435.v79ef3972b_5c7 *(update available)* 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9-28.vf251ce40855d 'MapDB API Plugin'
  * matrix-auth:3.1.5 'Matrix Authorization Strategy Plugin'
  * matrix-project:772.v494f19991984 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:3.19 *(update available)* 'Maven Integration plugin'
  * metrics:4.2.10-389.v93143621b_050 'Metrics Plugin'
  * mina-sshd-api-common:2.8.0-36.v8e25ce90d4b_1 *(update available)* 'Mina SSHD API :: Common'
  * mina-sshd-api-core:2.8.0-36.v8e25ce90d4b_1 *(update available)* 'Mina SSHD API :: Core'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * okhttp-api:4.9.3-108.v0feda04578cf 'OkHttp Plugin'
  * p4:1.13.0 'P4 Plugin'
  * pam-auth:1.8 *(update available)* 'PAM Authentication plugin'
  * parameterized-trigger:2.45 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.18 'Pipeline: Build Step'
  * pipeline-github-lib:38.v445716ea_edda_ 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:195.v5812d95a_a_2f9 'Pipeline Graph Analysis Plugin'
  * pipeline-groovy-lib:612.v84da_9c54906d *(update available)* 'Pipeline: Groovy Libraries'
  * pipeline-input-step:449.v77f0e8b_845c4 *(update available)* 'Pipeline: Input Step'
  * pipeline-milestone-step:101.vd572fef9d926 'Pipeline: Milestone Step'
  * pipeline-model-api:2.2114.v2654ca_721309 *(update available)* 'Pipeline: Model API'
  * pipeline-model-definition:2.2114.v2654ca_721309 *(update available)* 'Pipeline: Declarative'
  * pipeline-model-extensions:2.2114.v2654ca_721309 *(update available)* 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.24 *(update available)* 'Pipeline: REST API Plugin'
  * pipeline-stage-step:293.v200037eefcd5 *(update available)* 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:2.2114.v2654ca_721309 *(update available)* 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.24 *(update available)* 'Pipeline: Stage View Plugin'
  * plain-credentials:139.ved2b_9cf7587b 'Plain Credentials Plugin'
  * plugin-util-api:2.17.0 *(update available)* 'Plugin Utilities API Plugin'
  * popper2-api:2.11.5-2 *(update available)* 'Popper.js 2 API Plugin'
  * resource-disposer:0.19 *(update available)* 'Resource Disposer Plugin'
  * role-strategy:552.v14cb_85499b_89 *(update available)* 'Role-based Authorization Strategy'
  * scm-api:620.v0a_5b_1f8054c0 *(update available)* 'SCM API Plugin'
  * script-security:1175.v4b_d517d6db_f0 *(update available)* 'Script Security Plugin'
  * snakeyaml-api:1.30.2-76.vc104f7ce9870 *(update available)* 'SnakeYAML API Plugin'
  * ssh-credentials:295.vced876c18eb_4 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.834.v622da_57f702c *(update available)* 'SSH Build Agents plugin'
  * sshd:3.242.va_db_9da_b_26a_c3 *(update available)* 'SSH server'
  * structs:324.va_f5d6774f3a_d 'Structs Plugin'
  * support-core:1206.v14049fa_b_d860 'Support Core Plugin'
  * throttle-concurrents:2.8 *(update available)* 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.18 *(update available)* 'Timestamper'
  * token-macro:308.v4f2b_ed62b_b_16 'Token Macro Plugin'
  * trilead-api:1.67.vc3938a_35172f *(update available)* 'Trilead API Plugin'
  * variant:59.vf075fe829ccb 'Variant Plugin'
  * view-job-filters:2.3 'View Job Filters'
  * windows-slaves:1.8.1 'WMI Windows Agents Plugin'
  * workflow-aggregator:590.v6a_d052e5a_a_b_5 'Pipeline'
  * workflow-api:1188.v0016b_4f29881 *(update available)* 'Pipeline: API'
  * workflow-basic-steps:986.v6b_9c830a_6b_37 *(update available)* 'Pipeline: Basic Steps'
  * workflow-cps:2759.v87459c4eea_ca_ *(update available)* 'Pipeline: Groovy'
  * workflow-durable-task-step:1199.v02b_9244f8064 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:1207.ve6191ff089f8 *(update available)* 'Pipeline: Job'
  * workflow-multibranch:716.vc692a_e52371b_ 'Pipeline: Multibranch'
  * workflow-scm-step:400.v6b_89a_1317c9a_ 'Pipeline: SCM Step'
  * workflow-step-api:639.v6eca_cd8c04a_a_ 'Pipeline: Step API'
  * workflow-support:838.va_3a_087b_4055b *(update available)* 'Pipeline: Supporting APIs'
  * ws-cleanup:0.42 *(update available)* 'Jenkins Workspace Cleanup Plugin'
