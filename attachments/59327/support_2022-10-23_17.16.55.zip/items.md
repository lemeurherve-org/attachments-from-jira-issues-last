Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 100
    - Number of builds per job: 10.53 [n=100, s=6.0]

Total job statistics
======================

  * Number of jobs: 100
  * Number of builds per job: 10.53 [n=100, s=6.0]
