Support Bundle Manifest
=======================

Generated on 2022-10-23 17:16:55.539+0000

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `identity.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/Benny/checksums.md5`

      - `nodes/slave/Brock/checksums.md5`

      - `nodes/slave/Builder86/checksums.md5`

      - `nodes/slave/Dizzy-100/checksums.md5`

      - `nodes/slave/Dizzy-Linux/checksums.md5`

      - `nodes/slave/Dizzy/checksums.md5`

      - `nodes/slave/Grabber/checksums.md5`

      - `nodes/slave/osxbuild3/checksums.md5`

      - `nodes/slave/osxbuildmc1/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Agent Protocols

      - `agent-protocols.md`

  * Build queue

      - `buildqueue.md`

  * Controller Custom Log Recorders

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/Benny/exportTable.txt`

      - `nodes/slave/Brock/exportTable.txt`

      - `nodes/slave/Builder86/exportTable.txt`

      - `nodes/slave/Dizzy-100/exportTable.txt`

      - `nodes/slave/Dizzy-Linux/exportTable.txt`

      - `nodes/slave/Dizzy/exportTable.txt`

      - `nodes/slave/Grabber/exportTable.txt`

      - `nodes/slave/osxbuild3/exportTable.txt`

      - `nodes/slave/osxbuildmc1/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/Benny/environment.txt`

      - `nodes/slave/Brock/environment.txt`

      - `nodes/slave/Builder86/environment.txt`

      - `nodes/slave/Dizzy-100/environment.txt`

      - `nodes/slave/Dizzy-Linux/environment.txt`

      - `nodes/slave/Dizzy/environment.txt`

      - `nodes/slave/Grabber/environment.txt`

      - `nodes/slave/osxbuild3/environment.txt`

      - `nodes/slave/osxbuildmc1/environment.txt`

  * File descriptors (Unix only)

      - `nodes/slave/Dizzy-Linux/file-descriptors.txt`

      - `nodes/slave/osxbuildmc1/file-descriptors.txt`

  * Items Content (Computationally expensive)

      - `items.md`

  * Controller JVM process system metrics (Linux only)

  * Controller Log Recorders

      - `nodes/master/logs/all_2022-10-23_17.11.01.log`

      - `nodes/master/logs/all_2022-10-23_17.11.28.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

  * Load Statistics

      - `load-stats/label/AndroidNDK/gnuplot`

      - `load-stats/label/AndroidNDK/hour.csv`

      - `load-stats/label/AndroidNDK/min.csv`

      - `load-stats/label/AndroidNDK/sec10.csv`

      - `load-stats/label/Benny/gnuplot`

      - `load-stats/label/Benny/hour.csv`

      - `load-stats/label/Benny/min.csv`

      - `load-stats/label/Benny/sec10.csv`

      - `load-stats/label/Brock/gnuplot`

      - `load-stats/label/Brock/hour.csv`

      - `load-stats/label/Brock/min.csv`

      - `load-stats/label/Brock/sec10.csv`

      - `load-stats/label/Builder86/gnuplot`

      - `load-stats/label/Builder86/hour.csv`

      - `load-stats/label/Builder86/min.csv`

      - `load-stats/label/Builder86/sec10.csv`

      - `load-stats/label/Dizzy-100/gnuplot`

      - `load-stats/label/Dizzy-100/hour.csv`

      - `load-stats/label/Dizzy-100/min.csv`

      - `load-stats/label/Dizzy-100/sec10.csv`

      - `load-stats/label/Dizzy-Linux/gnuplot`

      - `load-stats/label/Dizzy-Linux/hour.csv`

      - `load-stats/label/Dizzy-Linux/min.csv`

      - `load-stats/label/Dizzy-Linux/sec10.csv`

      - `load-stats/label/Dizzy/gnuplot`

      - `load-stats/label/Dizzy/hour.csv`

      - `load-stats/label/Dizzy/min.csv`

      - `load-stats/label/Dizzy/sec10.csv`

      - `load-stats/label/Grabber/gnuplot`

      - `load-stats/label/Grabber/hour.csv`

      - `load-stats/label/Grabber/min.csv`

      - `load-stats/label/Grabber/sec10.csv`

      - `load-stats/label/PL-NextGen/gnuplot`

      - `load-stats/label/PL-NextGen/hour.csv`

      - `load-stats/label/PL-NextGen/min.csv`

      - `load-stats/label/PL-NextGen/sec10.csv`

      - `load-stats/label/PL-Rel1000/gnuplot`

      - `load-stats/label/PL-Rel1000/hour.csv`

      - `load-stats/label/PL-Rel1000/min.csv`

      - `load-stats/label/PL-Rel1000/sec10.csv`

      - `load-stats/label/PL-Rel1010/gnuplot`

      - `load-stats/label/PL-Rel1010/hour.csv`

      - `load-stats/label/PL-Rel1010/min.csv`

      - `load-stats/label/PL-Rel1010/sec10.csv`

      - `load-stats/label/PL-Rel1020/gnuplot`

      - `load-stats/label/PL-Rel1020/hour.csv`

      - `load-stats/label/PL-Rel1020/min.csv`

      - `load-stats/label/PL-Rel1020/sec10.csv`

      - `load-stats/label/PL-Rel852/gnuplot`

      - `load-stats/label/PL-Rel852/hour.csv`

      - `load-stats/label/PL-Rel852/min.csv`

      - `load-stats/label/PL-Rel852/sec10.csv`

      - `load-stats/label/PL-Rel861/gnuplot`

      - `load-stats/label/PL-Rel861/hour.csv`

      - `load-stats/label/PL-Rel861/min.csv`

      - `load-stats/label/PL-Rel861/sec10.csv`

      - `load-stats/label/PL-Rel870/gnuplot`

      - `load-stats/label/PL-Rel870/hour.csv`

      - `load-stats/label/PL-Rel870/min.csv`

      - `load-stats/label/PL-Rel870/sec10.csv`

      - `load-stats/label/PL-Rel900/gnuplot`

      - `load-stats/label/PL-Rel900/hour.csv`

      - `load-stats/label/PL-Rel900/min.csv`

      - `load-stats/label/PL-Rel900/sec10.csv`

      - `load-stats/label/PL-Rel910/gnuplot`

      - `load-stats/label/PL-Rel910/hour.csv`

      - `load-stats/label/PL-Rel910/min.csv`

      - `load-stats/label/PL-Rel910/sec10.csv`

      - `load-stats/label/PL-Rel912/gnuplot`

      - `load-stats/label/PL-Rel912/hour.csv`

      - `load-stats/label/PL-Rel912/min.csv`

      - `load-stats/label/PL-Rel912/sec10.csv`

      - `load-stats/label/PL-Rel913/gnuplot`

      - `load-stats/label/PL-Rel913/hour.csv`

      - `load-stats/label/PL-Rel913/min.csv`

      - `load-stats/label/PL-Rel913/sec10.csv`

      - `load-stats/label/PL-Rel920/gnuplot`

      - `load-stats/label/PL-Rel920/hour.csv`

      - `load-stats/label/PL-Rel920/min.csv`

      - `load-stats/label/PL-Rel920/sec10.csv`

      - `load-stats/label/PL-Rel921/gnuplot`

      - `load-stats/label/PL-Rel921/hour.csv`

      - `load-stats/label/PL-Rel921/min.csv`

      - `load-stats/label/PL-Rel921/sec10.csv`

      - `load-stats/label/PL-Unicode/gnuplot`

      - `load-stats/label/PL-Unicode/hour.csv`

      - `load-stats/label/PL-Unicode/min.csv`

      - `load-stats/label/PL-Unicode/sec10.csv`

      - `load-stats/label/built-in/gnuplot`

      - `load-stats/label/built-in/hour.csv`

      - `load-stats/label/built-in/min.csv`

      - `load-stats/label/built-in/sec10.csv`

      - `load-stats/label/cordova/gnuplot`

      - `load-stats/label/cordova/hour.csv`

      - `load-stats/label/cordova/min.csv`

      - `load-stats/label/cordova/sec10.csv`

      - `load-stats/label/osxbuild3/gnuplot`

      - `load-stats/label/osxbuild3/hour.csv`

      - `load-stats/label/osxbuild3/min.csv`

      - `load-stats/label/osxbuild3/sec10.csv`

      - `load-stats/label/osxbuildmc1/gnuplot`

      - `load-stats/label/osxbuildmc1/hour.csv`

      - `load-stats/label/osxbuildmc1/min.csv`

      - `load-stats/label/osxbuildmc1/sec10.csv`

      - `load-stats/label/xcode/gnuplot`

      - `load-stats/label/xcode/hour.csv`

      - `load-stats/label/xcode/min.csv`

      - `load-stats/label/xcode/sec10.csv`

      - `load-stats/label/xcode10/gnuplot`

      - `load-stats/label/xcode10/hour.csv`

      - `load-stats/label/xcode10/min.csv`

      - `load-stats/label/xcode10/sec10.csv`

      - `load-stats/label/xcode4/gnuplot`

      - `load-stats/label/xcode4/hour.csv`

      - `load-stats/label/xcode4/min.csv`

      - `load-stats/label/xcode4/sec10.csv`

      - `load-stats/label/xcode5/gnuplot`

      - `load-stats/label/xcode5/hour.csv`

      - `load-stats/label/xcode5/min.csv`

      - `load-stats/label/xcode5/sec10.csv`

      - `load-stats/label/xcode6/gnuplot`

      - `load-stats/label/xcode6/hour.csv`

      - `load-stats/label/xcode6/min.csv`

      - `load-stats/label/xcode6/sec10.csv`

      - `load-stats/label/xcode7/gnuplot`

      - `load-stats/label/xcode7/hour.csv`

      - `load-stats/label/xcode7/min.csv`

      - `load-stats/label/xcode7/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/Benny/networkInterface.md`

      - `nodes/slave/Brock/networkInterface.md`

      - `nodes/slave/Builder86/networkInterface.md`

      - `nodes/slave/Dizzy-100/networkInterface.md`

      - `nodes/slave/Dizzy-Linux/networkInterface.md`

      - `nodes/slave/Dizzy/networkInterface.md`

      - `nodes/slave/Grabber/networkInterface.md`

      - `nodes/slave/osxbuild3/networkInterface.md`

      - `nodes/slave/osxbuildmc1/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Reverse Proxy

      - `reverse-proxy.md`

  * Running Builds

      - `running-builds.txt`

  * Agent Command Statistics

      - `nodes/slave/Dizzy-100/command-stats.md`

      - `nodes/slave/Dizzy-Linux/command-stats.md`

      - `nodes/slave/Dizzy/command-stats.md`

      - `nodes/slave/osxbuildmc1/command-stats.md`

  * Agent system configuration (Linux only)

      - `nodes/slave/Dizzy-Linux/dmesg.txt`

      - `nodes/slave/Dizzy-Linux/dmi.txt`

      - `nodes/slave/Dizzy-Linux/proc/cpuinfo.txt`

      - `nodes/slave/Dizzy-Linux/proc/mounts.txt`

      - `nodes/slave/Dizzy-Linux/proc/net/rpc/nfs.txt`

      - `nodes/slave/Dizzy-Linux/proc/net/rpc/nfsd.txt`

      - `nodes/slave/Dizzy-Linux/proc/swaps.txt`

      - `nodes/slave/Dizzy-Linux/proc/system-uptime.txt`

      - `nodes/slave/Dizzy-Linux/sysctl.txt`

      - `nodes/slave/Dizzy-Linux/userid.txt`

  * Controller system configuration (Linux only)

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/Benny/system.properties`

      - `nodes/slave/Brock/system.properties`

      - `nodes/slave/Builder86/system.properties`

      - `nodes/slave/Dizzy-100/system.properties`

      - `nodes/slave/Dizzy-Linux/system.properties`

      - `nodes/slave/Dizzy/system.properties`

      - `nodes/slave/Grabber/system.properties`

      - `nodes/slave/osxbuild3/system.properties`

      - `nodes/slave/osxbuildmc1/system.properties`

  * Controller Task Log Recorders

      - `task-logs/Fingerprint cleanup.log`

      - `task-logs/Fingerprint cleanup.log.1`

      - `task-logs/Fingerprint cleanup.log.2`

      - `task-logs/Fingerprint cleanup.log.3`

      - `task-logs/Fingerprint cleanup.log.4`

      - `task-logs/Fingerprint cleanup.log.5`

      - `task-logs/Periodic background build discarder.log`

      - `task-logs/Periodic background build discarder.log.1`

      - `task-logs/Periodic background build discarder.log.2`

      - `task-logs/Periodic background build discarder.log.3`

      - `task-logs/Periodic background build discarder.log.4`

      - `task-logs/Periodic background build discarder.log.5`

      - `task-logs/Workspace clean-up.log`

      - `task-logs/Workspace clean-up.log.1`

      - `task-logs/Workspace clean-up.log.2`

      - `task-logs/Workspace clean-up.log.3`

      - `task-logs/Workspace clean-up.log.4`

      - `task-logs/Workspace clean-up.log.5`

      - `task-logs/health-checker.log`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/Benny/thread-dump.txt`

      - `nodes/slave/Brock/thread-dump.txt`

      - `nodes/slave/Builder86/thread-dump.txt`

      - `nodes/slave/Dizzy-100/thread-dump.txt`

      - `nodes/slave/Dizzy-Linux/thread-dump.txt`

      - `nodes/slave/Dizzy/thread-dump.txt`

      - `nodes/slave/Grabber/thread-dump.txt`

      - `nodes/slave/osxbuild3/thread-dump.txt`

      - `nodes/slave/osxbuildmc1/thread-dump.txt`

  * Update Center

      - `update-center.md`

  * User Count

      - `users/count.md`

  * Slow Request Records

  * Thread dumps on high CPU usage

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

