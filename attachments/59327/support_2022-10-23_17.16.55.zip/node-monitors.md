Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Windows Server 2019 (amd64)
   * Benny: null
   * Brock: null
   * Builder86: null
   * Dizzy: Windows Server 2016 (amd64)
   * Dizzy-100: Windows Server 2016 (amd64)
   * Dizzy-Linux: Linux (amd64)
   * Grabber: null
   * osxbuild3: null
   * osxbuildmc1: Mac OS X (x86_64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: In sync
   * Benny: null
   * Brock: null
   * Builder86: null
   * Dizzy: In sync
   * Dizzy-100: In sync
   * Dizzy-Linux: In sync
   * Grabber: null
   * osxbuild3: null
   * osxbuildmc1: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 236.127GB left on C:\ProgramData\Jenkins\.jenkins.
   * Benny: null
   * Brock: null
   * Builder86: null
   * Dizzy: 277.647GB left on C:\Jenkins.
   * Dizzy-100: 333.202GB left on C:\Jenkins.
   * Dizzy-Linux: 370.372GB left on /home/jenkins.
   * Grabber: null
   * osxbuild3: null
   * osxbuildmc1: 743.631GB left on /private/var/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Memory:4909/8191MB  Swap:13554/16383MB
   * Benny: null
   * Brock: null
   * Builder86: null
   * Dizzy: Memory:6869/8191MB  Swap:8039/9471MB
   * Dizzy-100: Memory:6230/8191MB  Swap:7325/9471MB
   * Dizzy-Linux: Memory:1579/9001MB  Swap:659/975MB
   * Grabber: null
   * osxbuild3: null
   * osxbuildmc1: Memory:0/0MB  Swap:947/1024MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 236.127GB left on C:\Users\buildsystem\AppData\Local\Temp.
   * Benny: null
   * Brock: null
   * Builder86: null
   * Dizzy: 277.647GB left on C:\Users\buildsystem\AppData\Local\Temp.
   * Dizzy-100: 333.202GB left on C:\Users\buildsystem\AppData\Local\Temp.
   * Dizzy-Linux: 370.372GB left on /tmp.
   * Grabber: null
   * osxbuild3: null
   * osxbuildmc1: 743.631GB left on /private/var/folders/5k/qb2f89_x2p32_w2tt1vgy0gw0000gq/T.
Response Time
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: 0ms
   * Benny: null
   * Brock: null
   * Builder86: null
   * Dizzy: 141ms
   * Dizzy-100: 140ms
   * Dizzy-Linux: 97ms
   * Grabber: null
   * osxbuild3: null
   * osxbuildmc1: 56ms
