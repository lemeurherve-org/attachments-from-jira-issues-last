Node statistics
===============

  * Total number of nodes
      - Sample size:        21
      - Average (mean):     9.0
      - Average (median):   9.0
      - Standard deviation: 0.0
      - Minimum:            9
      - Maximum:            9
      - 95th percentile:    9.0
      - 99th percentile:    9.0
  * Total number of nodes online
      - Sample size:        21
      - Average (mean):     3.990966738003904
      - Average (median):   4.0
      - Standard deviation: 0.18987218901697506
      - Minimum:            0
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of executors
      - Sample size:        21
      - Average (mean):     4.988708422504878
      - Average (median):   5.0
      - Standard deviation: 0.23734023627121878
      - Minimum:            0
      - Maximum:            5
      - 95th percentile:    5.0
      - 99th percentile:    5.0
  * Total number of executors in use
      - Sample size:        21
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the Jenkins controller's built-in node_
      - Executors:      0
      - FS root:        `C:\ProgramData\Jenkins\.jenkins`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Marked Offline: false
      - Status:         on-line
      - Slave Version:  3044.vb_940a_a_e4f72e
      - Java
          + Home:           `C:\Program Files\Java\jdk-11.0.15.1`
          + Vendor:           Oracle Corporation
          + Version:          11.0.15.1
          + Maximum memory:   256.00 MB (268435456)
          + Allocated memory: 256.00 MB (268435456)
          + Free memory:      106.95 MB (112145872)
          + In-use memory:    149.05 MB (156289584)
          + GC strategy:      G1
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 11.0.15.1+2-LTS-10
      - Operating system
          + Name:         Windows Server 2019
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 4676 (0x1244)
      - Process started: 2022-10-23 17:11:19.497+0000
      - Process uptime: 5 min 36 sec
      - JVM startup parameters:
          + Classpath: `C:\Jenkins\jenkins.war`
          + Library path: `C:\Program Files\Java\jdk-11.0.15.1\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Perl64\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files\Perforce;C:\Program Files (x86)\Java\jdk1.6.0_18\bin;C:\Python26;C:\Program Files (x86)\apache-maven-3.0.4\bin;C:\Tools\bin;C:\android-sdk-windows\tools;C:\apache-ant-1.8.2\bin;C:\Program Files\Help Workshop;C:\Program Files (x86)\Perforce;C:\Program Files (x86)\Microsoft ASP.NET\ASP.NET Web Pages\v1.0\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft\Web Platform Installer\;C:\Program Files (x86)\Windows Kits\8.1\Windows Performance Toolkit\;C:\Program Files\SafeNet\Authentication\SAC\x64;C:\Program Files\SafeNet\Authentication\SAC\x32;C:\Program Files (x86)\Microsoft SDKs\TypeScript\1.0\;C:\Program Files\Microsoft SQL Server\120\Tools\Binn\;C:\WINDOWS\System32\OpenSSH\;C:\Users\buildsystem\AppData\Local\Microsoft\WindowsApps;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Xmx256m`
          + arg[2]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

  * `Benny` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Marked Offline: false
      - Status:         off-line

  * `Brock` (`hudson.slaves.DumbSlave`)
      - Description:    _NextGen Builder_
      - Executors:      1
      - Remote FS root: `C:\Jenkins`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Marked Offline: false
      - Status:         off-line

  * `Builder86` (`hudson.slaves.DumbSlave`)
      - Description:    _Build Machine for 8.5.2_
      - Executors:      3
      - Remote FS root: `c:\Jenkins`
      - Labels:         PL-Rel852
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Marked Offline: false
      - Status:         off-line

  * `Dizzy` (`hudson.slaves.DumbSlave`)
      - Description:    _NextGen Builder_
      - Executors:      1
      - Remote FS root: `C:\Jenkins`
      - Labels:         PL-NextGen PL-Rel1020
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Marked Offline: false
      - Status:         on-line
      - Version:        3044.vb_940a_a_e4f72e
      - Java
          + Home:           `C:\Program Files\Java\jdk-11.0.15.1`
          + Vendor:           Oracle Corporation
          + Version:          11.0.15.1
          + Maximum memory:   2.00 GB (2147483648)
          + Allocated memory: 128.00 MB (134217728)
          + Free memory:      70.06 MB (73463576)
          + In-use memory:    57.94 MB (60754152)
          + GC strategy:      G1
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 11.0.15.1+2-LTS-10
      - Operating system
          + Name:         Windows Server 2016
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 5028 (0x13a4)
      - Process started: 2022-10-23 17:11:52.469+0000
      - Process uptime: 5 min 4 sec
      - JVM startup parameters:
          + Classpath: `c:\Jenkins\slave.jar`
          + Library path: `C:\Program Files\Java\jdk-11.0.15.1\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Perl64\site\bin;C:\Perl64\bin;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\dotnet\;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Program Files\Perforce\;C:\Python27;C:\Tools\bin;C:\Program Files\Perforce;C:\Program Files\Java\jdk1.8.0_65\bin;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Program Files (x86)\NASM;C:\Program Files (x86)\apache-maven-3.0.4\bin;C:\Users\buildsystem\AppData\Local\Microsoft\WindowsApps;C:\Users\buildsystem\.dotnet\tools;.`
          + arg[0]: `-Xrs`

  * `Dizzy-100` (`hudson.slaves.DumbSlave`)
      - Description:    _NextGen Builder_
      - Executors:      1
      - Remote FS root: `C:\Jenkins`
      - Labels:         PL-Rel1000 PL-Rel1010
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Marked Offline: false
      - Status:         on-line
      - Version:        3044.vb_940a_a_e4f72e
      - Java
          + Home:           `C:\Program Files\Java\jdk-11.0.15.1`
          + Vendor:           Oracle Corporation
          + Version:          11.0.15.1
          + Maximum memory:   2.00 GB (2147483648)
          + Allocated memory: 128.00 MB (134217728)
          + Free memory:      45.69 MB (47911120)
          + In-use memory:    82.31 MB (86306608)
          + GC strategy:      G1
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 11.0.15.1+2-LTS-10
      - Operating system
          + Name:         Windows Server 2016
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 5920 (0x1720)
      - Process started: 2022-10-23 17:11:51.012+0000
      - Process uptime: 5 min 5 sec
      - JVM startup parameters:
          + Classpath: `c:\Jenkins\slave.jar`
          + Library path: `C:\Program Files\Java\jdk-11.0.15.1\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Perl64\site\bin;C:\Perl64\bin;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\dotnet\;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Program Files\Perforce\;C:\Python27;C:\Tools\bin;C:\Program Files\Perforce;C:\Program Files\Java\jdk1.8.0_65\bin;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Program Files (x86)\NASM;C:\Program Files (x86)\apache-maven-3.0.4\bin;C:\Users\buildsystem\AppData\Local\Microsoft\WindowsApps;C:\Users\buildsystem\.dotnet\tools;.`
          + arg[0]: `-Xrs`

  * `Dizzy-Linux` (`hudson.slaves.DumbSlave`)
      - Description:    _NextGen Linux builder_
      - Executors:      1
      - Remote FS root: `/home/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Marked Offline: false
      - Status:         on-line
      - Version:        3044.vb_940a_a_e4f72e
      - Java
          + Home:           `/usr/lib/jvm/java-11-openjdk-amd64`
          + Vendor:           Ubuntu
          + Version:          11.0.16
          + Maximum memory:   2.20 GB (2361393152)
          + Allocated memory: 144.00 MB (150994944)
          + Free memory:      105.61 MB (110743848)
          + In-use memory:    38.39 MB (40251096)
          + GC strategy:      G1
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Ubuntu
          + Version: 11.0.16+8-post-Ubuntu-0ubuntu120.04
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      5.15.0-50-generic
          + Distribution: Ubuntu 20.04.5 LTS
      - Process ID: 131934 (0x2035e)
      - Process started: 2022-10-23 17:11:48.214+0000
      - Process uptime: 5 min 8 sec
      - JVM startup parameters:
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

  * `Grabber` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         PL-Unicode PL-Rel861 PL-Rel870 PL-Rel900 PL-Rel910 PL-Rel912 PL-Rel913 PL-Rel920 PL-Rel921
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Marked Offline: false
      - Status:         off-line

  * `osxbuild3` (`hudson.slaves.DumbSlave`)
      - Description:    _OSX Build Machine 3_
      - Executors:      2
      - Remote FS root: `/var/jenkins`
      - Labels:         xcode4 xcode5 AndroidNDK cordova
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Marked Offline: false
      - Status:         off-line

  * `osxbuildmc1` (`hudson.slaves.DumbSlave`)
      - Description:    _OSX Build Machine MC1_
      - Executors:      2
      - Remote FS root: `/var/jenkins`
      - Labels:         xcode xcode10 xcode6 xcode7 AndroidNDK cordova
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Marked Offline: false
      - Status:         on-line
      - Version:        3044.vb_940a_a_e4f72e
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk-11.0.16.jdk/Contents/Home`
          + Vendor:           Oracle Corporation
          + Version:          11.0.16
          + Maximum memory:   4.00 GB (4294967296)
          + Allocated memory: 256.00 MB (268435456)
          + Free memory:      207.24 MB (217310720)
          + In-use memory:    48.76 MB (51124736)
          + GC strategy:      G1
          + Available CPUs:   6
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 11.0.16+11-LTS-199
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86&#95;64
          + Version:      12.6
      - Process ID: 16463 (0x404f)
      - Process started: 2022-10-23 17:11:47.317+0000
      - Process uptime: 5 min 9 sec
      - JVM startup parameters:
          + Classpath: `remoting.jar`
          + Library path: `/Users/jenkins/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Dhudson.util.ProcessTreeKiller.disable=true`

