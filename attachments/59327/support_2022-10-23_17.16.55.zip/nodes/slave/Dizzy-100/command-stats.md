# Totals
* Writes: 5925
  * sent 5.5Mb
* Reads: 6176
  * received 44.5Mb
* Responses: 44
  * waited 10 sec

# Commands sent
* `Pipe.Chunk`: 476
  * sent 4.0Mb
* `ProxyOutputStream.Ack`: 5201
  * sent 0.8Mb
* `ProxyOutputStream.Unexport`: 2
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 150
  * sent 0.5Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 6
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 10
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 2
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 2
  * sent 0.0Mb
* `Unexport`: 31
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentDigest`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentVersion`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 11
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 5201
  * received 43.7Mb
* `ProxyOutputStream.Ack`: 476
  * received 0.1Mb
* `ProxyOutputStream.EOF`: 11
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 150
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 6
  * received 0.0Mb
* `Response`: 44
  * received 0.1Mb
* `Unexport`: 273
  * received 0.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 10
  * received 0.1Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 2
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 2
  * received 0.0Mb

# Responses received
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * waited 2 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 0.84 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentDigest`: 2
  * waited 1.6 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentVersion`: 2
  * waited 7 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * waited 0.22 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * waited 17 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * waited 47 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 1
  * waited 0.24 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 2
  * waited 50 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * waited 6 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * waited 0.26 sec
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * waited 0.26 sec
* `UserRequest:hudson.FilePath$Exists`: 1
  * waited 0.57 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 1
  * waited 28 ms
* `UserRequest:hudson.FilePath$Read`: 11
  * waited 4.5 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * waited 0.1 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * waited 27 ms
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * waited 0.11 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * waited 0.37 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 2
  * waited 17 ms
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 49 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * waited 16 ms
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 16 ms
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.49 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 32 ms

# JARs sent
* `support-core.jar`: 501495b
* `winstone15771592448055638016.jar`: 3383324b
