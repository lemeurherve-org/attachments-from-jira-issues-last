 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Hyper-V Network Adapter #2
 ** Hardware Address - 00155d6f8815
 ** Index - 4
 ** InetAddress - /172.25.111.52
 ** InetAddress - /fe80:0:0:0:8139:7c32:a00e:24a7%eth0
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Kernel Debug Network Adapter
 ** Index - 5
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft ISATAP Adapter
 ** Hardware Address - 00000000000000e0
 ** Index - 12
 ** InetAddress - /fe80:0:0:0:0:5efe:ac19:6f34%net0
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false

 * Name Microsoft Hyper-V Network Adapter #2-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 14
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Hyper-V Network Adapter #2-Npcap Packet Driver (NPCAP)-0000
 ** Index - 15
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Hyper-V Network Adapter #2-QoS Packet Scheduler-0000
 ** Index - 16
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Hyper-V Network Adapter #2-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 17
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
