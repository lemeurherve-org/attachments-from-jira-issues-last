# Totals
* Writes: 352
  * sent 1.2Mb
* Reads: 472
  * received 0.8Mb
* Responses: 71
  * waited 3.7 sec

# Commands sent
* `Pipe.Chunk`: 62
  * sent 0.5Mb
* `ProxyOutputStream.Ack`: 11
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 155
  * sent 0.4Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 6
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 11
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 2
  * sent 0.0Mb
* `Unexport`: 31
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentDigest`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentVersion`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 10
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$LastModified`: 12
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 3
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 11
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 62
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 13
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 155
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 6
  * received 0.0Mb
* `Response`: 71
  * received 0.3Mb
* `Unexport`: 139
  * received 0.2Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 11
  * received 0.1Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 2
  * received 0.0Mb

# Responses received
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * waited 3 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 0.44 sec
* `UserRequest:com.cloudbees.jenkins.support.api.BaseCommandOutputContent$CommandLauncher`: 6
  * waited 0.11 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentDigest`: 2
  * waited 0.4 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentVersion`: 2
  * waited 10 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * waited 0.32 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * waited 9 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 2
  * waited 0.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * waited 13 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 1
  * waited 0.22 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 2
  * waited 28 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 2
  * waited 0.37 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * waited 6 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * waited 0.26 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 3
  * waited 19 ms
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * waited 0.18 sec
* `UserRequest:hudson.FilePath$CopyTo`: 10
  * waited 28 ms
* `UserRequest:hudson.FilePath$Exists`: 1
  * waited 0.36 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 1
  * waited 13 ms
* `UserRequest:hudson.FilePath$LastModified`: 12
  * waited 21 ms
* `UserRequest:hudson.FilePath$Read`: 3
  * waited 0.1 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * waited 0.1 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * waited 16 ms
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * waited 97 ms
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * waited 58 ms
* `UserRequest:hudson.remoting.PingThread$Ping`: 2
  * waited 13 ms
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 42 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * waited 7 ms
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.27 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 41 ms
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 27 ms

# JARs sent
* `support-core.jar`: 501495b
