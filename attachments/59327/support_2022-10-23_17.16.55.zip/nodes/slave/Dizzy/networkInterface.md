 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Hyper-V Network Adapter
 ** Hardware Address - 00155d6f891d
 ** Index - 2
 ** InetAddress - /172.25.111.51
 ** InetAddress - /fe80:0:0:0:9d8e:f78:db7d:afef%eth0
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Kernel Debug Network Adapter
 ** Index - 3
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft ISATAP Adapter
 ** Hardware Address - 00000000000000e0
 ** Index - 4
 ** InetAddress - /fe80:0:0:0:0:5efe:ac19:6f33%net0
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false

 * Name Microsoft Hyper-V Network Adapter-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 5
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Hyper-V Network Adapter-QoS Packet Scheduler-0000
 ** Index - 6
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Hyper-V Network Adapter-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 7
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
