# Totals
* Writes: 313
  * sent 1.2Mb
* Reads: 342
  * received 0.4Mb
* Responses: 43
  * waited 3 sec

# Commands sent
* `Pipe.Chunk`: 62
  * sent 0.5Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 155
  * sent 0.5Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 6
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 11
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 2
  * sent 0.0Mb
* `Unexport`: 31
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentDigest`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentVersion`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 3
  * sent 0.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 2
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb

# Commands received
* `ProxyOutputStream.Ack`: 62
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 155
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 6
  * received 0.0Mb
* `Response`: 43
  * received 0.1Mb
* `Unexport`: 60
  * received 0.1Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 11
  * received 0.1Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 2
  * received 0.0Mb

# Responses received
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * waited 4 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 0.59 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentDigest`: 2
  * waited 57 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentVersion`: 2
  * waited 9 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * waited 0.12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * waited 9 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 2
  * waited 21 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * waited 20 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 1
  * waited 0.12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 2
  * waited 22 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * waited 8 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * waited 0.19 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 3
  * waited 12 ms
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 24 ms
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$Exists`: 3
  * waited 0.51 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 1
  * waited 10 ms
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * waited 6 ms
* `UserRequest:hudson.FilePath$Read`: 1
  * waited 53 ms
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * waited 57 ms
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * waited 12 ms
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * waited 55 ms
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * waited 0.44 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 2
  * waited 5 ms
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 37 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * waited 8 ms
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.45 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 39 ms
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 27 ms

# JARs sent
* `support-core.jar`: 501495b
