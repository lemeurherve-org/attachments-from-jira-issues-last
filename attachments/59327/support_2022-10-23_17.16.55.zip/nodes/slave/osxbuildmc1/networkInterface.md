 * Name utun2
 ** Index - 16
 ** InetAddress - /fe80:0:0:0:ce81:b1c:bd2c:69e%utun2
 ** MTU - 1000
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true

 * Name utun1
 ** Index - 15
 ** InetAddress - /fe80:0:0:0:3c02:5be3:d658:2716%utun1
 ** MTU - 2000
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true

 * Name utun0
 ** Index - 14
 ** InetAddress - /fe80:0:0:0:329a:784:468e:8907%utun0
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true

 * Name en6
 ** Hardware Address - acde48001122
 ** Index - 5
 ** InetAddress - /fe80:0:0:0:aede:48ff:fe00:1122%en6
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name en0
 ** Hardware Address - f01898e83819
 ** Index - 4
 ** InetAddress - /fe80:0:0:0:1468:dcf:2fcb:3ef7%en0
 ** InetAddress - /172.25.111.57
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name lo0
 ** Index - 1
 ** InetAddress - /fe80:0:0:0:0:0:0:1%lo0
 ** InetAddress - /0:0:0:0:0:0:0:1%lo0
 ** InetAddress - /127.0.0.1
 ** MTU - 16384
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
