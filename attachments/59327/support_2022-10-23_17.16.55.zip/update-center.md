=== Sites ===
 - Id: default
 - Url: http://updates.jenkins.io/update-center.json
 - Connection Url: https://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 7 hr 26 min
=== Proxy ===
