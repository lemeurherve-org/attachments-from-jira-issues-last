User
====

Authentication
--------------

  * Authenticated: true
  * Name: alan.weir
  * Authorities 
      - `authenticated`
      - `Jenkins-Admins`
      - `Wireless Users`
      - `Global Architecture`
      - `RndlabAdminFromOnsys`
      - `Engineering Senior Staff`
      - `CONFERENCE ROOM MGRS`
      - `GA Folder Read-Write`
      - `Limited Releases Read Write`
      - `Engineering`
      - `Sphericall Admins`
      - `Sharepoint Project NextGen Secure`
      - `vcenter-vmadmins`
      - `Installs Folder Full Control`
      - `Perforce Server Local Admin`
      - `Global Development Management`
      - `COMPASS Engineering Share Full-Access`
      - `CodeSigningCertsFolder`
      - `Sharepoint IoT`
      - `Postmaster Users`
      - `Engineering-3C`
      - `NEC ECT Mgmt Site`

