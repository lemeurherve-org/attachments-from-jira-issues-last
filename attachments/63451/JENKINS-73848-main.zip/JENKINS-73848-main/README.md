# Using Groovy SSH tool for [JENKINS-73848](https://issues.jenkins.io/browse/JENKINS-73848).

## Prerequisites

* Java 11.0.24;
* Maven 3.8.8.

# Build and run

* to build: mvn clean package
* to run: java -jar target/ssh-execute-1.0.0.jar
