function Invoke-ChildDir {
    Write-Information "This is some child directory script"
}
