Describe "Some tests" -Tag "UnitTest" {
    Context "when called" {
        It "write some output" {
            . $PSScriptRoot\Invoke-Foo.ps1
            Mock Write-Information {} -Verifiable

            Invoke-Foo

            Should -InvokeVerifiable
        }
    }

    Context "when calling a plain script" {
        It "write some output" {
            Mock Write-Information {} -Verifiable

            & $PSScriptRoot\Invoke-FooPlain.ps1

            Should -InvokeVerifiable
        }

        It "writes also output with a copy of the script" {
            Mock Write-Information {} -Verifiable

            & $PSScriptRoot\Invoke-FooPlain2.ps1

            Should -InvokeVerifiable
        }
    }

    Context "when calling a script from a child directory with a hashtag in the name" {
        It "writes some output" {
            & $PSScriptRoot\#_child_directory\Invoke-ChildDir.ps1
        }
    }
}