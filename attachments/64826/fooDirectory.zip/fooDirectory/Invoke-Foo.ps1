function Invoke-Foo {
    Write-Information "This is some function"
}
