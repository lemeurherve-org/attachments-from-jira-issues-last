Write-Information "This is some plain script"
