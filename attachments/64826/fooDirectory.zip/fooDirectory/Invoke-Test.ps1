$config = [PesterConfiguration]@{
    CodeCoverage = @{
        Enabled = $true
        Path = @(
            "$PSScriptRoot\Invoke-Foo.ps1"
            "$PSScriptRoot\Invoke-FooPlain.ps1"
            "$PSScriptRoot\Invoke-FooPlain2.ps1"
            "$PSScriptRoot\#_child_directory\Invoke-ChildDir.ps1"
        )
        OutputPath = "$PSScriptRoot\XML\coverage.xml"
    }
    Filter = @{
        Tag = "UnitTest"
    }
    Run = @{
        Path = @(
            "$PSScriptRoot\Invoke-Foo.Unit.Tests.ps1"
        )
        PassThru = $true
    }
    Output = @{
        Verbosity = 'Detailed'
    }
}
Invoke-Pester -Configuration $config
